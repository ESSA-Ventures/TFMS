/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: app_smartkerja
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accept_estimates`
--

DROP TABLE IF EXISTS `accept_estimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accept_estimates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `estimate_id` int(10) unsigned NOT NULL,
  `full_name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `signature` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accept_estimates_company_id_foreign` (`company_id`),
  KEY `accept_estimates_estimate_id_foreign` (`estimate_id`),
  CONSTRAINT `accept_estimates_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `accept_estimates_estimate_id_foreign` FOREIGN KEY (`estimate_id`) REFERENCES `estimates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accept_estimates`
--

LOCK TABLES `accept_estimates` WRITE;
/*!40000 ALTER TABLE `accept_estimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `accept_estimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_sources`
--

DROP TABLE IF EXISTS `application_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_sources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_source` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_sources`
--

LOCK TABLES `application_sources` WRITE;
/*!40000 ALTER TABLE `application_sources` DISABLE KEYS */;
INSERT INTO `application_sources` VALUES (1,'Linkedin','2023-08-21 05:41:19','2023-08-21 05:41:19'),(2,'Facebook','2023-08-21 05:41:19','2023-08-21 05:41:19'),(3,'Instagram','2023-08-21 05:41:19','2023-08-21 05:41:19'),(4,'Twitter','2023-08-21 05:41:19','2023-08-21 05:41:19'),(5,'Other','2023-08-21 05:41:19','2023-08-21 05:41:19');
/*!40000 ALTER TABLE `application_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appreciations`
--

DROP TABLE IF EXISTS `appreciations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appreciations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `award_id` bigint(20) unsigned NOT NULL,
  `award_to` int(10) unsigned NOT NULL,
  `award_date` date NOT NULL,
  `image` varchar(191) DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `added_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appreciations_company_id_foreign` (`company_id`),
  KEY `appreciations_award_id_foreign` (`award_id`),
  KEY `appreciations_award_to_foreign` (`award_to`),
  KEY `appreciations_added_by_foreign` (`added_by`),
  CONSTRAINT `appreciations_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `appreciations_award_id_foreign` FOREIGN KEY (`award_id`) REFERENCES `awards` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `appreciations_award_to_foreign` FOREIGN KEY (`award_to`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `appreciations_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appreciations`
--

LOCK TABLES `appreciations` WRITE;
/*!40000 ALTER TABLE `appreciations` DISABLE KEYS */;
/*!40000 ALTER TABLE `appreciations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance_settings`
--

DROP TABLE IF EXISTS `attendance_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `auto_clock_in` enum('yes','no') NOT NULL DEFAULT 'no',
  `auto_clock_in_location` enum('office','home') NOT NULL DEFAULT 'office',
  `office_start_time` time NOT NULL,
  `office_end_time` time NOT NULL,
  `halfday_mark_time` time DEFAULT NULL,
  `late_mark_duration` tinyint(4) NOT NULL,
  `clockin_in_day` int(11) NOT NULL DEFAULT 1,
  `employee_clock_in_out` enum('yes','no') NOT NULL DEFAULT 'yes',
  `office_open_days` varchar(191) NOT NULL DEFAULT '[1,2,3,4,5]',
  `ip_address` text DEFAULT NULL,
  `radius` int(11) DEFAULT NULL,
  `radius_check` enum('yes','no') NOT NULL DEFAULT 'no',
  `ip_check` enum('yes','no') NOT NULL DEFAULT 'no',
  `alert_after` int(11) DEFAULT NULL,
  `alert_after_status` tinyint(1) NOT NULL DEFAULT 1,
  `save_current_location` tinyint(1) NOT NULL DEFAULT 0,
  `default_employee_shift` bigint(20) unsigned DEFAULT 1,
  `week_start_from` varchar(191) NOT NULL DEFAULT '1',
  `allow_shift_change` tinyint(1) NOT NULL DEFAULT 1,
  `show_clock_in_button` enum('yes','no') NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `monthly_report` tinyint(1) NOT NULL DEFAULT 0,
  `monthly_report_roles` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attendance_settings_company_id_foreign` (`company_id`),
  KEY `attendance_settings_default_employee_shift_foreign` (`default_employee_shift`),
  CONSTRAINT `attendance_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `attendance_settings_default_employee_shift_foreign` FOREIGN KEY (`default_employee_shift`) REFERENCES `employee_shifts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance_settings`
--

LOCK TABLES `attendance_settings` WRITE;
/*!40000 ALTER TABLE `attendance_settings` DISABLE KEYS */;
INSERT INTO `attendance_settings` VALUES (1,1,'no','office','09:00:00','18:00:00',NULL,20,1,'yes','[1,2,3,4,5]',NULL,NULL,'no','no',NULL,0,0,2,'1',1,'no','2023-08-10 14:06:55','2023-08-10 14:06:55',0,NULL),(3,3,'no','office','09:00:00','18:00:00',NULL,20,1,'yes','[1,2,3,4,5]',NULL,NULL,'no','no',NULL,0,0,6,'1',1,'no','2023-08-10 14:17:22','2023-08-10 14:17:22',0,NULL),(7,7,'no','office','09:00:00','18:00:00',NULL,20,1,'yes','[1,2,3,4,5]',NULL,NULL,'no','no',NULL,0,0,14,'1',1,'no','2023-08-21 16:25:19','2023-08-21 16:25:19',0,NULL);
/*!40000 ALTER TABLE `attendance_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendances`
--

DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `location_id` bigint(20) unsigned DEFAULT NULL,
  `clock_in_time` datetime NOT NULL,
  `clock_out_time` datetime DEFAULT NULL,
  `clock_in_ip` varchar(191) NOT NULL,
  `clock_out_ip` varchar(191) DEFAULT NULL,
  `working_from` varchar(191) DEFAULT 'office',
  `late` enum('yes','no') NOT NULL DEFAULT 'no',
  `half_day` enum('yes','no') NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `shift_start_time` datetime DEFAULT NULL,
  `shift_end_time` datetime DEFAULT NULL,
  `employee_shift_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `work_from_type` enum('home','office','other') NOT NULL DEFAULT 'other',
  `overwrite_attendance` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  KEY `attendances_company_id_foreign` (`company_id`),
  KEY `attendances_user_id_foreign` (`user_id`),
  KEY `attendances_location_id_foreign` (`location_id`),
  KEY `attendances_clock_in_time_index` (`clock_in_time`),
  KEY `attendances_clock_out_time_index` (`clock_out_time`),
  KEY `attendances_added_by_foreign` (`added_by`),
  KEY `attendances_last_updated_by_foreign` (`last_updated_by`),
  KEY `attendances_employee_shift_id_foreign` (`employee_shift_id`),
  CONSTRAINT `attendances_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `attendances_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `attendances_employee_shift_id_foreign` FOREIGN KEY (`employee_shift_id`) REFERENCES `employee_shifts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `attendances_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `attendances_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `company_addresses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `attendances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendances`
--

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
INSERT INTO `attendances` VALUES (1,1,2,1,'2023-08-16 09:07:31',NULL,'60.50.171.93',NULL,NULL,'yes','no',2,2,NULL,NULL,'2023-08-16 09:00:00','2023-08-16 18:00:00',2,'2023-08-16 09:07:31','2023-08-16 09:07:31','office','no');
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authorize_invoices`
--

DROP TABLE IF EXISTS `authorize_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authorize_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `package_id` bigint(20) unsigned NOT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `amount` varchar(191) DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `next_pay_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authorize_invoices_company_id_foreign` (`company_id`),
  KEY `authorize_invoices_package_id_foreign` (`package_id`),
  CONSTRAINT `authorize_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `authorize_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authorize_invoices`
--

LOCK TABLES `authorize_invoices` WRITE;
/*!40000 ALTER TABLE `authorize_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `authorize_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authorize_subscriptions`
--

DROP TABLE IF EXISTS `authorize_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authorize_subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `subscription_id` varchar(191) NOT NULL,
  `plan_id` bigint(20) unsigned DEFAULT NULL,
  `plan_type` varchar(191) DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authorize_subscriptions_company_id_foreign` (`company_id`),
  KEY `authorize_subscriptions_plan_id_foreign` (`plan_id`),
  CONSTRAINT `authorize_subscriptions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `authorize_subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authorize_subscriptions`
--

LOCK TABLES `authorize_subscriptions` WRITE;
/*!40000 ALTER TABLE `authorize_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `authorize_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `award_icons`
--

DROP TABLE IF EXISTS `award_icons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `award_icons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `icon` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `award_icons`
--

LOCK TABLES `award_icons` WRITE;
/*!40000 ALTER TABLE `award_icons` DISABLE KEYS */;
INSERT INTO `award_icons` VALUES (1,'Trophy','trophy',NULL,NULL),(2,'Thumbs Up','hand-thumbs-up',NULL,NULL),(3,'Award','award',NULL,NULL),(4,'Book','book',NULL,NULL),(5,'Gift','gift',NULL,NULL),(6,'Watch','watch',NULL,NULL),(7,'Cup','cup-hot',NULL,NULL),(8,'Puzzle','puzzle',NULL,NULL),(9,'Plane','airplane',NULL,NULL),(10,'Money','piggy-bank',NULL,NULL),(11,'Trophy','trophy','2023-08-10 14:06:55','2023-08-10 14:06:55'),(12,'Thumbs Up','hand-thumbs-up','2023-08-10 14:06:55','2023-08-10 14:06:55'),(13,'Award','award','2023-08-10 14:06:55','2023-08-10 14:06:55'),(14,'Book','book','2023-08-10 14:06:55','2023-08-10 14:06:55'),(15,'Gift','gift','2023-08-10 14:06:55','2023-08-10 14:06:55'),(16,'Watch','watch','2023-08-10 14:06:55','2023-08-10 14:06:55'),(17,'Cup','cup-hot','2023-08-10 14:06:55','2023-08-10 14:06:55'),(18,'Puzzle','puzzle','2023-08-10 14:06:55','2023-08-10 14:06:55'),(19,'Plane','airplane','2023-08-10 14:06:55','2023-08-10 14:06:55'),(20,'Money','piggy-bank','2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `award_icons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `awards`
--

DROP TABLE IF EXISTS `awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `awards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `award_icon_id` bigint(20) unsigned DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `color_code` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `awards_company_id_foreign` (`company_id`),
  KEY `awards_award_icon_id_foreign` (`award_icon_id`),
  CONSTRAINT `awards_award_icon_id_foreign` FOREIGN KEY (`award_icon_id`) REFERENCES `award_icons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `awards_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `awards`
--

LOCK TABLES `awards` WRITE;
/*!40000 ALTER TABLE `awards` DISABLE KEYS */;
/*!40000 ALTER TABLE `awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_accounts`
--

DROP TABLE IF EXISTS `bank_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(191) DEFAULT NULL,
  `bank_name` varchar(191) DEFAULT NULL,
  `account_name` varchar(191) DEFAULT NULL,
  `account_number` varchar(191) DEFAULT NULL,
  `account_type` varchar(191) DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `contact_number` varchar(191) DEFAULT NULL,
  `opening_balance` double(15,2) DEFAULT NULL,
  `bank_logo` varchar(191) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `bank_balance` double(16,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bank_accounts_company_id_foreign` (`company_id`),
  KEY `bank_accounts_currency_id_foreign` (`currency_id`),
  KEY `bank_accounts_added_by_foreign` (`added_by`),
  KEY `bank_accounts_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `bank_accounts_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bank_accounts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bank_accounts_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bank_accounts_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_accounts`
--

LOCK TABLES `bank_accounts` WRITE;
/*!40000 ALTER TABLE `bank_accounts` DISABLE KEYS */;
INSERT INTO `bank_accounts` VALUES (1,3,'cash',NULL,'Ascot Hill',NULL,'saving',13,'0103213634',100.00,NULL,1,3,3,95.00,'2023-08-16 12:05:10','2023-08-16 12:07:45');
/*!40000 ALTER TABLE `bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_transactions`
--

DROP TABLE IF EXISTS `bank_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `bank_account_id` int(10) unsigned DEFAULT NULL,
  `payment_id` int(10) unsigned DEFAULT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `expense_id` int(10) unsigned DEFAULT NULL,
  `amount` double(15,2) DEFAULT NULL,
  `type` enum('Cr','Dr') NOT NULL DEFAULT 'Cr',
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `memo` text DEFAULT NULL,
  `transaction_relation` varchar(191) DEFAULT NULL,
  `transaction_related_to` varchar(191) DEFAULT NULL,
  `title` text DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `bank_balance` double(16,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bank_transactions_company_id_foreign` (`company_id`),
  KEY `bank_transactions_bank_account_id_foreign` (`bank_account_id`),
  KEY `bank_transactions_payment_id_foreign` (`payment_id`),
  KEY `bank_transactions_invoice_id_foreign` (`invoice_id`),
  KEY `bank_transactions_expense_id_foreign` (`expense_id`),
  KEY `bank_transactions_added_by_foreign` (`added_by`),
  KEY `bank_transactions_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `bank_transactions_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bank_transactions_bank_account_id_foreign` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bank_transactions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `bank_transactions_expense_id_foreign` FOREIGN KEY (`expense_id`) REFERENCES `expenses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bank_transactions_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bank_transactions_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `bank_transactions_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_transactions`
--

LOCK TABLES `bank_transactions` WRITE;
/*!40000 ALTER TABLE `bank_transactions` DISABLE KEYS */;
INSERT INTO `bank_transactions` VALUES (1,3,1,NULL,NULL,NULL,100.00,'Cr',3,3,NULL,'bank',NULL,'bank-account-created','2023-08-16',100.00,'2023-08-16 12:05:10','2023-08-16 12:05:10'),(2,3,1,NULL,NULL,NULL,10.00,'Cr',3,3,NULL,'bank',NULL,'bank-account-deposit','2023-08-16',110.00,'2023-08-16 12:05:20','2023-08-16 12:05:20'),(3,3,1,NULL,NULL,NULL,10.00,'Dr',3,3,NULL,'bank',NULL,'bank-account-withdraw','2023-08-16',100.00,'2023-08-16 12:05:26','2023-08-16 12:05:26'),(4,3,1,NULL,NULL,NULL,5.00,'Dr',3,3,'tng','bank',NULL,'bank-account-withdraw','2023-08-16',95.00,'2023-08-16 12:07:45','2023-08-16 12:07:45');
/*!40000 ALTER TABLE `bank_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_categories`
--

DROP TABLE IF EXISTS `client_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_categories_company_id_foreign` (`company_id`),
  CONSTRAINT `client_categories_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_categories`
--

LOCK TABLES `client_categories` WRITE;
/*!40000 ALTER TABLE `client_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_contacts`
--

DROP TABLE IF EXISTS `client_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `contact_name` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_contacts_company_id_foreign` (`company_id`),
  KEY `client_contacts_user_id_foreign` (`user_id`),
  KEY `client_contacts_added_by_foreign` (`added_by`),
  KEY `client_contacts_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `client_contacts_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_contacts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_contacts_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_contacts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_contacts`
--

LOCK TABLES `client_contacts` WRITE;
/*!40000 ALTER TABLE `client_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_details`
--

DROP TABLE IF EXISTS `client_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `company_name` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `postal_code` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `office` varchar(191) DEFAULT NULL,
  `website` varchar(191) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `linkedin` varchar(191) DEFAULT NULL,
  `facebook` varchar(191) DEFAULT NULL,
  `twitter` varchar(191) DEFAULT NULL,
  `skype` varchar(191) DEFAULT NULL,
  `gst_number` varchar(191) DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `sub_category_id` bigint(20) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `company_logo` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `office_phone` varchar(191) DEFAULT NULL,
  `country_id` int(10) unsigned DEFAULT NULL,
  `quickbooks_client_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_details_company_id_foreign` (`company_id`),
  KEY `client_details_user_id_foreign` (`user_id`),
  KEY `client_details_category_id_foreign` (`category_id`),
  KEY `client_details_sub_category_id_foreign` (`sub_category_id`),
  KEY `client_details_added_by_foreign` (`added_by`),
  KEY `client_details_last_updated_by_foreign` (`last_updated_by`),
  KEY `client_details_country_id_foreign` (`country_id`),
  CONSTRAINT `client_details_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_details_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `client_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_details_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_details_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_details_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_details_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `client_sub_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_details`
--

LOCK TABLES `client_details` WRITE;
/*!40000 ALTER TABLE `client_details` DISABLE KEYS */;
INSERT INTO `client_details` VALUES (1,7,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<p><br></p>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,8,NULL,'2023-08-21 16:31:15','2023-08-21 16:31:15',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `client_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_docs`
--

DROP TABLE IF EXISTS `client_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_docs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `hashname` varchar(200) NOT NULL,
  `size` varchar(200) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_docs_company_id_foreign` (`company_id`),
  KEY `client_docs_user_id_foreign` (`user_id`),
  KEY `client_docs_added_by_foreign` (`added_by`),
  KEY `client_docs_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `client_docs_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_docs_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_docs_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_docs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_docs`
--

LOCK TABLES `client_docs` WRITE;
/*!40000 ALTER TABLE `client_docs` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_notes`
--

DROP TABLE IF EXISTS `client_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `member_id` int(10) unsigned DEFAULT NULL,
  `is_client_show` tinyint(1) NOT NULL DEFAULT 0,
  `ask_password` tinyint(1) NOT NULL DEFAULT 0,
  `details` longtext NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_notes_company_id_foreign` (`company_id`),
  KEY `client_notes_client_id_foreign` (`client_id`),
  KEY `client_notes_member_id_foreign` (`member_id`),
  KEY `client_notes_added_by_foreign` (`added_by`),
  KEY `client_notes_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `client_notes_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_notes_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_notes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_notes_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `client_notes_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_notes`
--

LOCK TABLES `client_notes` WRITE;
/*!40000 ALTER TABLE `client_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_sub_categories`
--

DROP TABLE IF EXISTS `client_sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_sub_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `category_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_sub_categories_company_id_foreign` (`company_id`),
  KEY `client_sub_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `client_sub_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `client_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_sub_categories_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_sub_categories`
--

LOCK TABLES `client_sub_categories` WRITE;
/*!40000 ALTER TABLE `client_sub_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_sub_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_user_notes`
--

DROP TABLE IF EXISTS `client_user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `client_note_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_user_notes_company_id_foreign` (`company_id`),
  KEY `client_user_notes_user_id_foreign` (`user_id`),
  KEY `client_user_notes_client_note_id_foreign` (`client_note_id`),
  CONSTRAINT `client_user_notes_client_note_id_foreign` FOREIGN KEY (`client_note_id`) REFERENCES `client_notes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_user_notes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `client_user_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_user_notes`
--

LOCK TABLES `client_user_notes` WRITE;
/*!40000 ALTER TABLE `client_user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(191) NOT NULL,
  `app_name` varchar(191) DEFAULT NULL,
  `company_email` varchar(191) NOT NULL,
  `company_phone` varchar(191) DEFAULT NULL,
  `logo` varchar(191) DEFAULT NULL,
  `light_logo` varchar(191) DEFAULT NULL,
  `favicon` varchar(191) DEFAULT NULL,
  `auth_theme` enum('dark','light') NOT NULL DEFAULT 'light',
  `auth_theme_text` enum('dark','light') NOT NULL DEFAULT 'dark',
  `sidebar_logo_style` enum('square','full') NOT NULL DEFAULT 'square',
  `login_background` varchar(191) DEFAULT NULL,
  `address` text NOT NULL,
  `website` varchar(191) DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `package_id` bigint(20) unsigned DEFAULT NULL,
  `package_type` enum('monthly','annual') NOT NULL DEFAULT 'monthly',
  `timezone` varchar(191) NOT NULL DEFAULT 'Asia/Kolkata',
  `date_format` varchar(20) NOT NULL DEFAULT 'd-m-Y',
  `date_picker_format` varchar(191) NOT NULL DEFAULT 'dd-mm-yyyy',
  `year_starts_from` varchar(191) NOT NULL DEFAULT '1',
  `moment_format` varchar(191) NOT NULL DEFAULT 'DD-MM-YYYY',
  `time_format` varchar(20) NOT NULL DEFAULT 'h:i a',
  `locale` varchar(191) NOT NULL DEFAULT 'en',
  `latitude` decimal(10,8) NOT NULL DEFAULT 26.91243360,
  `longitude` decimal(11,8) NOT NULL DEFAULT 75.78727090,
  `leaves_start_from` enum('joining_date','year_start') NOT NULL DEFAULT 'joining_date',
  `active_theme` enum('default','custom') NOT NULL DEFAULT 'default',
  `status` enum('active','inactive','license_expired') DEFAULT 'active',
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `currency_converter_key` varchar(191) DEFAULT NULL,
  `google_map_key` varchar(191) DEFAULT NULL,
  `task_self` enum('yes','no') NOT NULL DEFAULT 'yes',
  `purchase_code` varchar(100) DEFAULT NULL,
  `license_type` varchar(20) DEFAULT NULL,
  `supported_until` timestamp NULL DEFAULT NULL,
  `google_recaptcha_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `google_recaptcha_v2_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `google_recaptcha_v2_site_key` varchar(191) DEFAULT NULL,
  `google_recaptcha_v2_secret_key` varchar(191) DEFAULT NULL,
  `google_recaptcha_v3_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `google_recaptcha_v3_site_key` varchar(191) DEFAULT NULL,
  `google_recaptcha_v3_secret_key` varchar(191) DEFAULT NULL,
  `app_debug` tinyint(1) NOT NULL DEFAULT 0,
  `rounded_theme` tinyint(1) NOT NULL DEFAULT 1,
  `hide_cron_message` tinyint(1) NOT NULL DEFAULT 0,
  `system_update` tinyint(1) NOT NULL DEFAULT 1,
  `logo_background_color` varchar(191) NOT NULL DEFAULT '#ffffff',
  `header_color` varchar(191) NOT NULL DEFAULT '#1D82F5',
  `before_days` int(11) NOT NULL,
  `after_days` int(11) NOT NULL,
  `on_deadline` enum('yes','no') NOT NULL DEFAULT 'yes',
  `default_task_status` int(10) unsigned DEFAULT NULL,
  `show_review_modal` tinyint(1) NOT NULL DEFAULT 1,
  `dashboard_clock` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_form_google_captcha` tinyint(1) NOT NULL DEFAULT 0,
  `lead_form_google_captcha` tinyint(1) NOT NULL DEFAULT 0,
  `taskboard_length` int(11) NOT NULL DEFAULT 10,
  `datatable_row_limit` int(11) NOT NULL DEFAULT 10,
  `last_cron_run` timestamp NULL DEFAULT NULL,
  `session_driver` enum('file','database') NOT NULL DEFAULT 'file',
  `allow_client_signup` tinyint(1) NOT NULL,
  `admin_client_signup_approval` tinyint(1) NOT NULL,
  `allowed_file_types` text DEFAULT NULL,
  `google_calendar_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `google_client_id` text DEFAULT NULL,
  `google_client_secret` text DEFAULT NULL,
  `google_calendar_verification_status` enum('verified','non_verified') NOT NULL DEFAULT 'non_verified',
  `google_id` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `token` text DEFAULT NULL,
  `hash` varchar(191) DEFAULT NULL,
  `allowed_file_size` int(11) NOT NULL DEFAULT 10,
  `currency_key_version` enum('free','api') NOT NULL DEFAULT 'free',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `rtl` tinyint(1) NOT NULL DEFAULT 0,
  `stripe_id` varchar(191) DEFAULT NULL,
  `card_brand` varchar(191) DEFAULT NULL,
  `card_last_four` varchar(191) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `licence_expire_on` date DEFAULT NULL,
  `license_updated_at` timestamp NULL DEFAULT NULL,
  `subscription_updated_at` timestamp NULL DEFAULT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 1,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `show_new_webhook_alert` tinyint(1) NOT NULL DEFAULT 0,
  `pm_type` varchar(191) DEFAULT NULL,
  `pm_last_four` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `companies_currency_id_foreign` (`currency_id`),
  KEY `companies_last_updated_by_foreign` (`last_updated_by`),
  KEY `companies_default_task_status_foreign` (`default_task_status`),
  KEY `companies_package_id_foreign` (`package_id`),
  KEY `companies_approved_by_foreign` (`approved_by`),
  CONSTRAINT `companies_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `companies_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `companies_default_task_status_foreign` FOREIGN KEY (`default_task_status`) REFERENCES `taskboard_columns` (`id`) ON DELETE SET NULL,
  CONSTRAINT `companies_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `companies_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Demo Company','Demo Company','company@email.com','0322012021',NULL,NULL,NULL,'light','dark','square',NULL,'Your Company address here','https://demoibfim.biz',1,1,'monthly','Asia/Kuala_Lumpur','d-m-Y','dd-mm-yyyy','1','DD-MM-YYYY','h:i a','en',26.91243360,75.78727090,'joining_date','default','active',2,NULL,NULL,'yes',NULL,NULL,NULL,'deactive','deactive',NULL,NULL,'deactive',NULL,NULL,0,1,0,1,'#ffffff','#1D82F5',0,0,'yes',1,1,1,0,0,10,10,NULL,'file',0,0,NULL,'inactive',NULL,NULL,'non_verified',NULL,NULL,NULL,'d1045db6849e1110f077898ec31d7d7f',10,'free','2023-08-10 14:06:55','2023-08-21 23:50:46','2023-08-21 23:50:07',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL),(3,'MIFC','MIFC','ascothill21k@gmail.com',NULL,NULL,NULL,NULL,'light','dark','square',NULL,'Ascot Hill',NULL,13,1,'monthly','Asia/Kuala_Lumpur','d-m-Y','dd-mm-yyyy','1','DD-MM-YYYY','h:i a','en',26.91243360,75.78727090,'joining_date','default','active',1,NULL,NULL,'yes',NULL,NULL,NULL,'deactive','deactive',NULL,NULL,'deactive',NULL,NULL,0,1,0,1,'#ffffff','#1D82F5',0,0,'yes',9,1,0,0,0,10,10,NULL,'file',0,0,NULL,'inactive',NULL,NULL,'non_verified',NULL,NULL,NULL,'7b5eda6bc7e40e3125395bc8b590d3e3',10,'free','2023-08-10 14:17:21','2024-07-14 15:45:18','2024-07-14 15:45:18',0,'cus_OQbsuE96dFZSjm',NULL,NULL,NULL,NULL,NULL,'2023-08-11 02:10:35',1,NULL,0,'visa','4242'),(7,'Smartkerja','Smartkerja','sm4rtkerja@gmail.com','+603 2021 1010','78fbe3c0e77329159173af3e6a85b7de.png','7776e48b6a836ca0996730d0128968f3.png','c3fbe58d5e57463ce64457a4131eeefb.png','light','','square',NULL,'IBFIM','https://smartkerja.org',33,1,'monthly','Asia/Kuala_Lumpur','d-m-Y','dd-mm-yyyy','1','DD-MM-YYYY','h:i a','en',26.91243360,75.78727090,'joining_date','default','active',8,NULL,NULL,'yes',NULL,NULL,NULL,'deactive','deactive',NULL,NULL,'deactive',NULL,NULL,0,1,0,1,'','#1D82F5',0,0,'yes',25,1,1,0,0,10,10,NULL,'file',0,0,NULL,'inactive',NULL,NULL,'non_verified',NULL,NULL,NULL,'6a9d28ca3c801f42fbc89d71fb21dde6',10,'free','2023-08-21 16:25:19','2024-07-15 13:27:18','2024-07-15 00:24:18',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_addresses`
--

DROP TABLE IF EXISTS `company_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_addresses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `address` mediumtext NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `tax_number` varchar(191) DEFAULT NULL,
  `tax_name` varchar(191) DEFAULT NULL,
  `location` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `company_addresses_company_id_foreign` (`company_id`),
  CONSTRAINT `company_addresses_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_addresses`
--

LOCK TABLES `company_addresses` WRITE;
/*!40000 ALTER TABLE `company_addresses` DISABLE KEYS */;
INSERT INTO `company_addresses` VALUES (1,1,'Your Company address here',1,NULL,NULL,'Demo IBFIM','2023-08-10 14:06:55','2023-08-21 23:51:00',NULL,NULL),(3,3,'Ascot Hill',1,NULL,NULL,'Ascot Hill','2023-08-10 14:17:22','2023-08-10 14:17:22',NULL,NULL),(7,7,'AVTS',1,NULL,NULL,'AVTS','2023-08-21 16:25:19','2024-07-14 15:47:24',NULL,NULL);
/*!40000 ALTER TABLE `company_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_discussions`
--

DROP TABLE IF EXISTS `contract_discussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_discussions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `contract_id` bigint(20) unsigned NOT NULL,
  `from` int(10) unsigned NOT NULL,
  `message` longtext NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_discussions_company_id_foreign` (`company_id`),
  KEY `contract_discussions_contract_id_foreign` (`contract_id`),
  KEY `contract_discussions_from_foreign` (`from`),
  KEY `contract_discussions_added_by_foreign` (`added_by`),
  KEY `contract_discussions_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `contract_discussions_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `contract_discussions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_discussions_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_discussions_from_foreign` FOREIGN KEY (`from`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_discussions_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_discussions`
--

LOCK TABLES `contract_discussions` WRITE;
/*!40000 ALTER TABLE `contract_discussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_discussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_files`
--

DROP TABLE IF EXISTS `contract_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `contract_id` bigint(20) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) NOT NULL,
  `size` varchar(191) NOT NULL,
  `google_url` varchar(191) NOT NULL,
  `dropbox_link` varchar(191) NOT NULL,
  `external_link_name` varchar(191) NOT NULL,
  `external_link` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_files_company_id_foreign` (`company_id`),
  KEY `contract_files_user_id_foreign` (`user_id`),
  KEY `contract_files_contract_id_foreign` (`contract_id`),
  KEY `contract_files_added_by_foreign` (`added_by`),
  KEY `contract_files_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `contract_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `contract_files_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_files_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `contract_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_files`
--

LOCK TABLES `contract_files` WRITE;
/*!40000 ALTER TABLE `contract_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_renews`
--

DROP TABLE IF EXISTS `contract_renews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_renews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `renewed_by` int(10) unsigned NOT NULL,
  `contract_id` bigint(20) unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_renews_company_id_foreign` (`company_id`),
  KEY `contract_renews_renewed_by_foreign` (`renewed_by`),
  KEY `contract_renews_contract_id_foreign` (`contract_id`),
  KEY `contract_renews_added_by_foreign` (`added_by`),
  KEY `contract_renews_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `contract_renews_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `contract_renews_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_renews_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_renews_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `contract_renews_renewed_by_foreign` FOREIGN KEY (`renewed_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_renews`
--

LOCK TABLES `contract_renews` WRITE;
/*!40000 ALTER TABLE `contract_renews` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_renews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_signs`
--

DROP TABLE IF EXISTS `contract_signs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_signs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `contract_id` bigint(20) unsigned NOT NULL,
  `full_name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `signature` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `place` varchar(191) DEFAULT NULL,
  `date` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_signs_contract_id_foreign` (`contract_id`),
  KEY `contract_signs_company_id_foreign` (`company_id`),
  CONSTRAINT `contract_signs_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_signs_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_signs`
--

LOCK TABLES `contract_signs` WRITE;
/*!40000 ALTER TABLE `contract_signs` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_signs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_templates`
--

DROP TABLE IF EXISTS `contract_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contract_template_number` bigint(20) DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `subject` varchar(191) NOT NULL,
  `description` longtext DEFAULT NULL,
  `amount` varchar(191) NOT NULL,
  `contract_type_id` bigint(20) unsigned NOT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `contract_detail` longtext DEFAULT NULL,
  `added_by` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_templates_company_id_foreign` (`company_id`),
  KEY `contract_templates_contract_type_id_foreign` (`contract_type_id`),
  KEY `contract_templates_currency_id_foreign` (`currency_id`),
  CONSTRAINT `contract_templates_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_templates_contract_type_id_foreign` FOREIGN KEY (`contract_type_id`) REFERENCES `contract_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contract_templates_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_templates`
--

LOCK TABLES `contract_templates` WRITE;
/*!40000 ALTER TABLE `contract_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_types`
--

DROP TABLE IF EXISTS `contract_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_types_company_id_foreign` (`company_id`),
  CONSTRAINT `contract_types_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_types`
--

LOCK TABLES `contract_types` WRITE;
/*!40000 ALTER TABLE `contract_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contracts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contract_number` bigint(20) DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `subject` varchar(191) NOT NULL,
  `amount` varchar(191) NOT NULL,
  `original_amount` decimal(15,2) NOT NULL,
  `contract_type_id` bigint(20) unsigned DEFAULT NULL,
  `start_date` date NOT NULL,
  `original_start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `original_end_date` date DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `contract_name` varchar(191) DEFAULT NULL,
  `alternate_address` varchar(191) DEFAULT NULL,
  `contract_note` text DEFAULT NULL,
  `cell` varchar(191) DEFAULT NULL,
  `office` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `postal_code` varchar(191) DEFAULT NULL,
  `contract_detail` longtext DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `hash` varchar(191) DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `event_id` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `company_sign` varchar(191) DEFAULT NULL,
  `sign_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contracts_company_id_foreign` (`company_id`),
  KEY `contracts_client_id_foreign` (`client_id`),
  KEY `contracts_contract_type_id_foreign` (`contract_type_id`),
  KEY `contracts_added_by_foreign` (`added_by`),
  KEY `contracts_last_updated_by_foreign` (`last_updated_by`),
  KEY `contracts_currency_id_foreign` (`currency_id`),
  KEY `contracts_project_id_foreign` (`project_id`),
  CONSTRAINT `contracts_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `contracts_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contracts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contracts_contract_type_id_foreign` FOREIGN KEY (`contract_type_id`) REFERENCES `contract_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `contracts_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contracts_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `contracts_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation`
--

DROP TABLE IF EXISTS `conversation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conversation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_one` int(10) unsigned NOT NULL,
  `user_two` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `conversation_company_id_foreign` (`company_id`),
  KEY `conversation_user_one_foreign` (`user_one`),
  KEY `conversation_user_two_foreign` (`user_two`),
  CONSTRAINT `conversation_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation`
--

LOCK TABLES `conversation` WRITE;
/*!40000 ALTER TABLE `conversation` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_reply`
--

DROP TABLE IF EXISTS `conversation_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conversation_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `conversation_id` int(10) unsigned NOT NULL,
  `reply` text NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `conversation_reply_company_id_foreign` (`company_id`),
  KEY `conversation_reply_conversation_id_foreign` (`conversation_id`),
  KEY `conversation_reply_user_id_foreign` (`user_id`),
  CONSTRAINT `conversation_reply_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `conversation_reply_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversation` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `conversation_reply_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_reply`
--

LOCK TABLES `conversation_reply` WRITE;
/*!40000 ALTER TABLE `conversation_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversation_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `iso` char(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `nicename` varchar(80) NOT NULL,
  `iso3` char(3) DEFAULT NULL,
  `numcode` smallint(6) DEFAULT NULL,
  `phonecode` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'AF','AFGHANISTAN','Afghanistan','AFG',4,93),(2,'AL','ALBANIA','Albania','ALB',8,355),(3,'DZ','ALGERIA','Algeria','DZA',12,213),(4,'AS','AMERICAN SAMOA','American Samoa','ASM',16,1684),(5,'AD','ANDORRA','Andorra','AND',20,376),(6,'AO','ANGOLA','Angola','AGO',24,244),(7,'AI','ANGUILLA','Anguilla','AIA',660,1264),(8,'AQ','ANTARCTICA','Antarctica',NULL,NULL,0),(9,'AG','ANTIGUA AND BARBUDA','Antigua and Barbuda','ATG',28,1268),(10,'AR','ARGENTINA','Argentina','ARG',32,54),(11,'AM','ARMENIA','Armenia','ARM',51,374),(12,'AW','ARUBA','Aruba','ABW',533,297),(13,'AU','AUSTRALIA','Australia','AUS',36,61),(14,'AT','AUSTRIA','Austria','AUT',40,43),(15,'AZ','AZERBAIJAN','Azerbaijan','AZE',31,994),(16,'BS','BAHAMAS','Bahamas','BHS',44,1242),(17,'BH','BAHRAIN','Bahrain','BHR',48,973),(18,'BD','BANGLADESH','Bangladesh','BGD',50,880),(19,'BB','BARBADOS','Barbados','BRB',52,1246),(20,'BY','BELARUS','Belarus','BLR',112,375),(21,'BE','BELGIUM','Belgium','BEL',56,32),(22,'BZ','BELIZE','Belize','BLZ',84,501),(23,'BJ','BENIN','Benin','BEN',204,229),(24,'BM','BERMUDA','Bermuda','BMU',60,1441),(25,'BT','BHUTAN','Bhutan','BTN',64,975),(26,'BO','BOLIVIA','Bolivia','BOL',68,591),(27,'BA','BOSNIA AND HERZEGOVINA','Bosnia and Herzegovina','BIH',70,387),(28,'BW','BOTSWANA','Botswana','BWA',72,267),(29,'BV','BOUVET ISLAND','Bouvet Island',NULL,NULL,0),(30,'BR','BRAZIL','Brazil','BRA',76,55),(31,'IO','BRITISH INDIAN OCEAN TERRITORY','British Indian Ocean Territory',NULL,NULL,246),(32,'BN','BRUNEI DARUSSALAM','Brunei Darussalam','BRN',96,673),(33,'BG','BULGARIA','Bulgaria','BGR',100,359),(34,'BF','BURKINA FASO','Burkina Faso','BFA',854,226),(35,'BI','BURUNDI','Burundi','BDI',108,257),(36,'KH','CAMBODIA','Cambodia','KHM',116,855),(37,'CM','CAMEROON','Cameroon','CMR',120,237),(38,'CA','CANADA','Canada','CAN',124,1),(39,'CV','CAPE VERDE','Cape Verde','CPV',132,238),(40,'KY','CAYMAN ISLANDS','Cayman Islands','CYM',136,1345),(41,'CF','CENTRAL AFRICAN REPUBLIC','Central African Republic','CAF',140,236),(42,'TD','CHAD','Chad','TCD',148,235),(43,'CL','CHILE','Chile','CHL',152,56),(44,'CN','CHINA','China','CHN',156,86),(45,'CX','CHRISTMAS ISLAND','Christmas Island',NULL,NULL,61),(46,'CC','COCOS (KEELING) ISLANDS','Cocos (Keeling) Islands',NULL,NULL,672),(47,'CO','COLOMBIA','Colombia','COL',170,57),(48,'KM','COMOROS','Comoros','COM',174,269),(49,'CG','CONGO','Congo','COG',178,242),(50,'CD','CONGO, THE DEMOCRATIC REPUBLIC OF THE','Congo, the Democratic Republic of the','COD',180,242),(51,'CK','COOK ISLANDS','Cook Islands','COK',184,682),(52,'CR','COSTA RICA','Costa Rica','CRI',188,506),(53,'CI','COTE D\'IVOIRE','Cote D\'Ivoire','CIV',384,225),(54,'HR','CROATIA','Croatia','HRV',191,385),(55,'CU','CUBA','Cuba','CUB',192,53),(56,'CY','CYPRUS','Cyprus','CYP',196,357),(57,'CZ','CZECH REPUBLIC','Czech Republic','CZE',203,420),(58,'DK','DENMARK','Denmark','DNK',208,45),(59,'DJ','DJIBOUTI','Djibouti','DJI',262,253),(60,'DM','DOMINICA','Dominica','DMA',212,1767),(61,'DO','DOMINICAN REPUBLIC','Dominican Republic','DOM',214,1809),(62,'EC','ECUADOR','Ecuador','ECU',218,593),(63,'EG','EGYPT','Egypt','EGY',818,20),(64,'SV','EL SALVADOR','El Salvador','SLV',222,503),(65,'GQ','EQUATORIAL GUINEA','Equatorial Guinea','GNQ',226,240),(66,'ER','ERITREA','Eritrea','ERI',232,291),(67,'EE','ESTONIA','Estonia','EST',233,372),(68,'ET','ETHIOPIA','Ethiopia','ETH',231,251),(69,'FK','FALKLAND ISLANDS (MALVINAS)','Falkland Islands (Malvinas)','FLK',238,500),(70,'FO','FAROE ISLANDS','Faroe Islands','FRO',234,298),(71,'FJ','FIJI','Fiji','FJI',242,679),(72,'FI','FINLAND','Finland','FIN',246,358),(73,'FR','FRANCE','France','FRA',250,33),(74,'GF','FRENCH GUIANA','French Guiana','GUF',254,594),(75,'PF','FRENCH POLYNESIA','French Polynesia','PYF',258,689),(76,'TF','FRENCH SOUTHERN TERRITORIES','French Southern Territories',NULL,NULL,0),(77,'GA','GABON','Gabon','GAB',266,241),(78,'GM','GAMBIA','Gambia','GMB',270,220),(79,'GE','GEORGIA','Georgia','GEO',268,995),(80,'DE','GERMANY','Germany','DEU',276,49),(81,'GH','GHANA','Ghana','GHA',288,233),(82,'GI','GIBRALTAR','Gibraltar','GIB',292,350),(83,'GR','GREECE','Greece','GRC',300,30),(84,'GL','GREENLAND','Greenland','GRL',304,299),(85,'GD','GRENADA','Grenada','GRD',308,1473),(86,'GP','GUADELOUPE','Guadeloupe','GLP',312,590),(87,'GU','GUAM','Guam','GUM',316,1671),(88,'GT','GUATEMALA','Guatemala','GTM',320,502),(89,'GN','GUINEA','Guinea','GIN',324,224),(90,'GW','GUINEA-BISSAU','Guinea-Bissau','GNB',624,245),(91,'GY','GUYANA','Guyana','GUY',328,592),(92,'HT','HAITI','Haiti','HTI',332,509),(93,'HM','HEARD ISLAND AND MCDONALD ISLANDS','Heard Island and Mcdonald Islands',NULL,NULL,0),(94,'VA','HOLY SEE (VATICAN CITY STATE)','Holy See (Vatican City State)','VAT',336,39),(95,'HN','HONDURAS','Honduras','HND',340,504),(96,'HK','HONG KONG','Hong Kong','HKG',344,852),(97,'HU','HUNGARY','Hungary','HUN',348,36),(98,'IS','ICELAND','Iceland','ISL',352,354),(99,'IN','INDIA','India','IND',356,91),(100,'ID','INDONESIA','Indonesia','IDN',360,62),(101,'IR','IRAN, ISLAMIC REPUBLIC OF','Iran, Islamic Republic of','IRN',364,98),(102,'IQ','IRAQ','Iraq','IRQ',368,964),(103,'IE','IRELAND','Ireland','IRL',372,353),(104,'IL','ISRAEL','Israel','ISR',376,972),(105,'IT','ITALY','Italy','ITA',380,39),(106,'JM','JAMAICA','Jamaica','JAM',388,1876),(107,'JP','JAPAN','Japan','JPN',392,81),(108,'JO','JORDAN','Jordan','JOR',400,962),(109,'KZ','KAZAKHSTAN','Kazakhstan','KAZ',398,7),(110,'KE','KENYA','Kenya','KEN',404,254),(111,'KI','KIRIBATI','Kiribati','KIR',296,686),(112,'KP','KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF','Korea, Democratic People\'s Republic of','PRK',408,850),(113,'KR','KOREA, REPUBLIC OF','Korea, Republic of','KOR',410,82),(114,'KW','KUWAIT','Kuwait','KWT',414,965),(115,'KG','KYRGYZSTAN','Kyrgyzstan','KGZ',417,996),(116,'LA','LAO PEOPLE\'S DEMOCRATIC REPUBLIC','Lao People\'s Democratic Republic','LAO',418,856),(117,'LV','LATVIA','Latvia','LVA',428,371),(118,'LB','LEBANON','Lebanon','LBN',422,961),(119,'LS','LESOTHO','Lesotho','LSO',426,266),(120,'LR','LIBERIA','Liberia','LBR',430,231),(121,'LY','LIBYAN ARAB JAMAHIRIYA','Libyan Arab Jamahiriya','LBY',434,218),(122,'LI','LIECHTENSTEIN','Liechtenstein','LIE',438,423),(123,'LT','LITHUANIA','Lithuania','LTU',440,370),(124,'LU','LUXEMBOURG','Luxembourg','LUX',442,352),(125,'MO','MACAO','Macao','MAC',446,853),(126,'MK','MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF','Macedonia, the Former Yugoslav Republic of','MKD',807,389),(127,'MG','MADAGASCAR','Madagascar','MDG',450,261),(128,'MW','MALAWI','Malawi','MWI',454,265),(129,'MY','MALAYSIA','Malaysia','MYS',458,60),(130,'MV','MALDIVES','Maldives','MDV',462,960),(131,'ML','MALI','Mali','MLI',466,223),(132,'MT','MALTA','Malta','MLT',470,356),(133,'MH','MARSHALL ISLANDS','Marshall Islands','MHL',584,692),(134,'MQ','MARTINIQUE','Martinique','MTQ',474,596),(135,'MR','MAURITANIA','Mauritania','MRT',478,222),(136,'MU','MAURITIUS','Mauritius','MUS',480,230),(137,'YT','MAYOTTE','Mayotte',NULL,NULL,269),(138,'MX','MEXICO','Mexico','MEX',484,52),(139,'FM','MICRONESIA, FEDERATED STATES OF','Micronesia, Federated States of','FSM',583,691),(140,'MD','MOLDOVA, REPUBLIC OF','Moldova, Republic of','MDA',498,373),(141,'MC','MONACO','Monaco','MCO',492,377),(142,'MN','MONGOLIA','Mongolia','MNG',496,976),(143,'MS','MONTSERRAT','Montserrat','MSR',500,1664),(144,'MA','MOROCCO','Morocco','MAR',504,212),(145,'MZ','MOZAMBIQUE','Mozambique','MOZ',508,258),(146,'MM','MYANMAR','Myanmar','MMR',104,95),(147,'NA','NAMIBIA','Namibia','NAM',516,264),(148,'NR','NAURU','Nauru','NRU',520,674),(149,'NP','NEPAL','Nepal','NPL',524,977),(150,'NL','NETHERLANDS','Netherlands','NLD',528,31),(151,'AN','NETHERLANDS ANTILLES','Netherlands Antilles','ANT',530,599),(152,'NC','NEW CALEDONIA','New Caledonia','NCL',540,687),(153,'NZ','NEW ZEALAND','New Zealand','NZL',554,64),(154,'NI','NICARAGUA','Nicaragua','NIC',558,505),(155,'NE','NIGER','Niger','NER',562,227),(156,'NG','NIGERIA','Nigeria','NGA',566,234),(157,'NU','NIUE','Niue','NIU',570,683),(158,'NF','NORFOLK ISLAND','Norfolk Island','NFK',574,672),(159,'MP','NORTHERN MARIANA ISLANDS','Northern Mariana Islands','MNP',580,1670),(160,'NO','NORWAY','Norway','NOR',578,47),(161,'OM','OMAN','Oman','OMN',512,968),(162,'PK','PAKISTAN','Pakistan','PAK',586,92),(163,'PW','PALAU','Palau','PLW',585,680),(164,'PS','PALESTINIAN TERRITORY, OCCUPIED','Palestinian Territory, Occupied',NULL,NULL,970),(165,'PA','PANAMA','Panama','PAN',591,507),(166,'PG','PAPUA NEW GUINEA','Papua New Guinea','PNG',598,675),(167,'PY','PARAGUAY','Paraguay','PRY',600,595),(168,'PE','PERU','Peru','PER',604,51),(169,'PH','PHILIPPINES','Philippines','PHL',608,63),(170,'PN','PITCAIRN','Pitcairn','PCN',612,0),(171,'PL','POLAND','Poland','POL',616,48),(172,'PT','PORTUGAL','Portugal','PRT',620,351),(173,'PR','PUERTO RICO','Puerto Rico','PRI',630,1787),(174,'QA','QATAR','Qatar','QAT',634,974),(175,'RE','REUNION','Reunion','REU',638,262),(176,'RO','ROMANIA','Romania','ROM',642,40),(177,'RU','RUSSIAN FEDERATION','Russian Federation','RUS',643,7),(178,'RW','RWANDA','Rwanda','RWA',646,250),(179,'SH','SAINT HELENA','Saint Helena','SHN',654,290),(180,'KN','SAINT KITTS AND NEVIS','Saint Kitts and Nevis','KNA',659,1869),(181,'LC','SAINT LUCIA','Saint Lucia','LCA',662,1758),(182,'PM','SAINT PIERRE AND MIQUELON','Saint Pierre and Miquelon','SPM',666,508),(183,'VC','SAINT VINCENT AND THE GRENADINES','Saint Vincent and the Grenadines','VCT',670,1784),(184,'WS','SAMOA','Samoa','WSM',882,684),(185,'SM','SAN MARINO','San Marino','SMR',674,378),(186,'ST','SAO TOME AND PRINCIPE','Sao Tome and Principe','STP',678,239),(187,'SA','SAUDI ARABIA','Saudi Arabia','SAU',682,966),(188,'SN','SENEGAL','Senegal','SEN',686,221),(189,'CS','SERBIA AND MONTENEGRO','Serbia and Montenegro',NULL,NULL,381),(190,'SC','SEYCHELLES','Seychelles','SYC',690,248),(191,'SL','SIERRA LEONE','Sierra Leone','SLE',694,232),(192,'SG','SINGAPORE','Singapore','SGP',702,65),(193,'SK','SLOVAKIA','Slovakia','SVK',703,421),(194,'SI','SLOVENIA','Slovenia','SVN',705,386),(195,'SB','SOLOMON ISLANDS','Solomon Islands','SLB',90,677),(196,'SO','SOMALIA','Somalia','SOM',706,252),(197,'ZA','SOUTH AFRICA','South Africa','ZAF',710,27),(198,'GS','SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS','South Georgia and the South Sandwich Islands',NULL,NULL,0),(199,'ES','SPAIN','Spain','ESP',724,34),(200,'LK','SRI LANKA','Sri Lanka','LKA',144,94),(201,'SD','SUDAN','Sudan','SDN',736,249),(202,'SR','SURINAME','Suriname','SUR',740,597),(203,'SJ','SVALBARD AND JAN MAYEN','Svalbard and Jan Mayen','SJM',744,47),(204,'SZ','SWAZILAND','Swaziland','SWZ',748,268),(205,'SE','SWEDEN','Sweden','SWE',752,46),(206,'CH','SWITZERLAND','Switzerland','CHE',756,41),(207,'SY','SYRIAN ARAB REPUBLIC','Syrian Arab Republic','SYR',760,963),(208,'TW','TAIWAN, PROVINCE OF CHINA','Taiwan, Province of China','TWN',158,886),(209,'TJ','TAJIKISTAN','Tajikistan','TJK',762,992),(210,'TZ','TANZANIA, UNITED REPUBLIC OF','Tanzania, United Republic of','TZA',834,255),(211,'TH','THAILAND','Thailand','THA',764,66),(212,'TL','TIMOR-LESTE','Timor-Leste',NULL,NULL,670),(213,'TG','TOGO','Togo','TGO',768,228),(214,'TK','TOKELAU','Tokelau','TKL',772,690),(215,'TO','TONGA','Tonga','TON',776,676),(216,'TT','TRINIDAD AND TOBAGO','Trinidad and Tobago','TTO',780,1868),(217,'TN','TUNISIA','Tunisia','TUN',788,216),(218,'TR','TURKEY','Turkey','TUR',792,90),(219,'TM','TURKMENISTAN','Turkmenistan','TKM',795,7370),(220,'TC','TURKS AND CAICOS ISLANDS','Turks and Caicos Islands','TCA',796,1649),(221,'TV','TUVALU','Tuvalu','TUV',798,688),(222,'UG','UGANDA','Uganda','UGA',800,256),(223,'UA','UKRAINE','Ukraine','UKR',804,380),(224,'AE','UNITED ARAB EMIRATES','United Arab Emirates','ARE',784,971),(225,'GB','UNITED KINGDOM','United Kingdom','GBR',826,44),(226,'US','UNITED STATES','United States','USA',840,1),(227,'UM','UNITED STATES MINOR OUTLYING ISLANDS','United States Minor Outlying Islands',NULL,NULL,1),(228,'UY','URUGUAY','Uruguay','URY',858,598),(229,'UZ','UZBEKISTAN','Uzbekistan','UZB',860,998),(230,'VU','VANUATU','Vanuatu','VUT',548,678),(231,'VE','VENEZUELA','Venezuela','VEN',862,58),(232,'VN','VIET NAM','Viet Nam','VNM',704,84),(233,'VG','VIRGIN ISLANDS, BRITISH','Virgin Islands, British','VGB',92,1284),(234,'VI','VIRGIN ISLANDS, U.S.','Virgin Islands, U.s.','VIR',850,1340),(235,'WF','WALLIS AND FUTUNA','Wallis and Futuna','WLF',876,681),(236,'EH','WESTERN SAHARA','Western Sahara','ESH',732,212),(237,'YE','YEMEN','Yemen','YEM',887,967),(238,'ZM','ZAMBIA','Zambia','ZMB',894,260),(239,'ZW','ZIMBABWE','Zimbabwe','ZWE',716,263),(240,'RS','SERBIA','Serbia','SRB',688,381),(241,'AP','ASIA PACIFIC REGION','Asia / Pacific Region','0',0,0),(242,'ME','MONTENEGRO','Montenegro','MNE',499,382),(243,'AX','ALAND ISLANDS','Aland Islands','ALA',248,358),(244,'BQ','BONAIRE, SINT EUSTATIUS AND SABA','Bonaire, Sint Eustatius and Saba','BES',535,599),(245,'CW','CURACAO','Curacao','CUW',531,599),(246,'GG','GUERNSEY','Guernsey','GGY',831,44),(247,'IM','ISLE OF MAN','Isle of Man','IMN',833,44),(248,'JE','JERSEY','Jersey','JEY',832,44),(249,'XK','KOSOVO','Kosovo','---',0,381),(250,'BL','SAINT BARTHELEMY','Saint Barthelemy','BLM',652,590),(251,'MF','SAINT MARTIN','Saint Martin','MAF',663,590),(252,'SX','SINT MAARTEN','Sint Maarten','SXM',534,1),(253,'SS','SOUTH SUDAN','South Sudan','SSD',728,211);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_note_item_images`
--

DROP TABLE IF EXISTS `credit_note_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_note_item_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `credit_note_item_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_note_item_images_credit_note_item_id_foreign` (`credit_note_item_id`),
  CONSTRAINT `credit_note_item_images_credit_note_item_id_foreign` FOREIGN KEY (`credit_note_item_id`) REFERENCES `credit_note_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_note_item_images`
--

LOCK TABLES `credit_note_item_images` WRITE;
/*!40000 ALTER TABLE `credit_note_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_note_items`
--

DROP TABLE IF EXISTS `credit_note_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_note_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(10) unsigned NOT NULL,
  `item_name` varchar(191) NOT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `quantity` int(11) NOT NULL,
  `unit_price` double(8,2) NOT NULL,
  `amount` double(8,2) NOT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `item_summary` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_note_items_credit_note_id_foreign` (`credit_note_id`),
  KEY `credit_note_items_unit_id_foreign` (`unit_id`),
  KEY `credit_note_items_product_id_foreign` (`product_id`),
  CONSTRAINT `credit_note_items_credit_note_id_foreign` FOREIGN KEY (`credit_note_id`) REFERENCES `credit_notes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `credit_note_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `credit_note_items_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_note_items`
--

LOCK TABLES `credit_note_items` WRITE;
/*!40000 ALTER TABLE `credit_note_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_note_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_notes`
--

DROP TABLE IF EXISTS `credit_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `cn_number` varchar(191) NOT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `discount` double NOT NULL DEFAULT 0,
  `discount_type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `sub_total` double(15,2) NOT NULL,
  `total` double(15,2) NOT NULL,
  `adjustment_amount` double(8,2) DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `status` enum('closed','open') NOT NULL DEFAULT 'open',
  `recurring` enum('yes','no') NOT NULL DEFAULT 'no',
  `billing_frequency` varchar(191) DEFAULT NULL,
  `billing_interval` int(11) DEFAULT NULL,
  `billing_cycle` int(11) DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `file_original_name` varchar(191) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `calculate_tax` enum('after_discount','before_discount') NOT NULL DEFAULT 'after_discount',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit_notes_company_id_foreign` (`company_id`),
  KEY `credit_notes_project_id_foreign` (`project_id`),
  KEY `credit_notes_client_id_foreign` (`client_id`),
  KEY `credit_notes_currency_id_foreign` (`currency_id`),
  KEY `credit_notes_added_by_foreign` (`added_by`),
  KEY `credit_notes_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `credit_notes_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `credit_notes_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `credit_notes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `credit_notes_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `credit_notes_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `credit_notes_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_notes`
--

LOCK TABLES `credit_notes` WRITE;
/*!40000 ALTER TABLE `credit_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `currency_name` varchar(191) NOT NULL,
  `currency_symbol` varchar(191) DEFAULT NULL,
  `currency_code` varchar(191) NOT NULL,
  `exchange_rate` double DEFAULT NULL,
  `is_cryptocurrency` enum('yes','no') NOT NULL DEFAULT 'no',
  `usd_price` double DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `no_of_decimal` int(10) unsigned NOT NULL DEFAULT 2,
  `thousand_separator` varchar(191) DEFAULT NULL,
  `decimal_separator` varchar(191) DEFAULT NULL,
  `currency_position` enum('left','right','left_with_space','right_with_space') NOT NULL DEFAULT 'left',
  PRIMARY KEY (`id`),
  KEY `currencies_company_id_foreign` (`company_id`),
  CONSTRAINT `currencies_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,1,'Dollars','$','USD',1,'no',NULL,NULL,NULL,2,',','.','left'),(2,1,'Pounds','£','GBP',1,'no',NULL,NULL,NULL,2,',','.','left'),(3,1,'Euros','€','EUR',1,'no',NULL,NULL,NULL,2,',','.','left'),(4,1,'Rupee','₹','INR',1,'no',NULL,NULL,NULL,2,',','.','left'),(9,3,'Dollars','$','USD',1,'no',NULL,NULL,NULL,2,',','.','left'),(10,3,'Pounds','£','GBP',1,'no',NULL,NULL,NULL,2,',','.','left'),(11,3,'Euros','€','EUR',1,'no',NULL,NULL,NULL,2,',','.','left'),(12,3,'Rupee','₹','INR',1,'no',NULL,NULL,NULL,2,',','.','left'),(13,3,'Malaysian Ringgit','RM','MYR',1,'no',NULL,'2023-08-14 12:26:41','2023-08-14 12:26:41',2,',','.','left'),(29,7,'Dollars','$','USD',1,'no',NULL,NULL,NULL,2,',','.','left'),(30,7,'Pounds','£','GBP',1,'no',NULL,NULL,NULL,2,',','.','left'),(31,7,'Euros','€','EUR',1,'no',NULL,NULL,NULL,2,',','.','left'),(32,7,'Rupee','₹','INR',1,'no',NULL,NULL,NULL,2,',','.','left'),(33,7,'Malaysian Ringgit','RM','MYR',1,'no',NULL,NULL,NULL,2,',','.','left'),(34,1,'Ringgit','RM','MYR',1,'no',NULL,'2023-08-21 23:51:29','2023-08-21 23:51:29',2,',','.','left');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_format_settings`
--

DROP TABLE IF EXISTS `currency_format_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency_format_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `currency_position` enum('left','right','left_with_space','right_with_space') NOT NULL DEFAULT 'left',
  `no_of_decimal` int(10) unsigned NOT NULL DEFAULT 2,
  `thousand_separator` varchar(191) DEFAULT NULL,
  `decimal_separator` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency_format_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `currency_format_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_format_settings`
--

LOCK TABLES `currency_format_settings` WRITE;
/*!40000 ALTER TABLE `currency_format_settings` DISABLE KEYS */;
INSERT INTO `currency_format_settings` VALUES (1,NULL,'left',2,',','.');
/*!40000 ALTER TABLE `currency_format_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_groups`
--

DROP TABLE IF EXISTS `custom_field_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `model` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_field_groups_company_id_foreign` (`company_id`),
  KEY `custom_field_groups_model_index` (`model`),
  CONSTRAINT `custom_field_groups_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_groups`
--

LOCK TABLES `custom_field_groups` WRITE;
/*!40000 ALTER TABLE `custom_field_groups` DISABLE KEYS */;
INSERT INTO `custom_field_groups` VALUES (1,NULL,'Company','App\\Models\\Company'),(2,1,'Client','App\\Models\\ClientDetails'),(3,1,'Employee','App\\Models\\EmployeeDetails'),(4,1,'Project','App\\Models\\Project'),(5,1,'Invoice','App\\Models\\Invoice'),(6,1,'Estimate','App\\Models\\Estimate'),(7,1,'Task','App\\Models\\Task'),(8,1,'Expense','App\\Models\\Expense'),(9,1,'Lead','App\\Models\\Lead'),(10,1,'Product','App\\Models\\Product'),(11,1,'Ticket','App\\Models\\Ticket'),(12,1,'Time Log','App\\Models\\ProjectTimeLog'),(13,1,'Contract','App\\Models\\Contract'),(26,3,'Client','App\\Models\\ClientDetails'),(27,3,'Employee','App\\Models\\EmployeeDetails'),(28,3,'Project','App\\Models\\Project'),(29,3,'Invoice','App\\Models\\Invoice'),(30,3,'Estimate','App\\Models\\Estimate'),(31,3,'Task','App\\Models\\Task'),(32,3,'Expense','App\\Models\\Expense'),(33,3,'Lead','App\\Models\\Lead'),(34,3,'Product','App\\Models\\Product'),(35,3,'Ticket','App\\Models\\Ticket'),(36,3,'Time Log','App\\Models\\ProjectTimeLog'),(37,3,'Contract','App\\Models\\Contract'),(74,7,'Client','App\\Models\\ClientDetails'),(75,7,'Employee','App\\Models\\EmployeeDetails'),(76,7,'Project','App\\Models\\Project'),(77,7,'Invoice','App\\Models\\Invoice'),(78,7,'Estimate','App\\Models\\Estimate'),(79,7,'Task','App\\Models\\Task'),(80,7,'Expense','App\\Models\\Expense'),(81,7,'Lead','App\\Models\\Lead'),(82,7,'Product','App\\Models\\Product'),(83,7,'Ticket','App\\Models\\Ticket'),(84,7,'Time Log','App\\Models\\ProjectTimeLog'),(85,7,'Contract','App\\Models\\Contract');
/*!40000 ALTER TABLE `custom_field_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `custom_field_group_id` int(10) unsigned DEFAULT NULL,
  `label` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(10) NOT NULL,
  `required` enum('yes','no') NOT NULL DEFAULT 'no',
  `values` varchar(5000) DEFAULT NULL,
  `export` tinyint(1) DEFAULT 0,
  `visible` enum('true','false') DEFAULT 'false',
  PRIMARY KEY (`id`),
  KEY `custom_fields_company_id_foreign` (`company_id`),
  KEY `custom_fields_custom_field_group_id_foreign` (`custom_field_group_id`),
  CONSTRAINT `custom_fields_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `custom_fields_custom_field_group_id_foreign` FOREIGN KEY (`custom_field_group_id`) REFERENCES `custom_field_groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields_data`
--

DROP TABLE IF EXISTS `custom_fields_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `custom_field_id` int(10) unsigned NOT NULL,
  `model_id` int(10) unsigned NOT NULL,
  `model` varchar(191) DEFAULT NULL,
  `value` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_fields_data_custom_field_id_foreign` (`custom_field_id`),
  KEY `custom_fields_data_model_index` (`model`),
  CONSTRAINT `custom_fields_data_custom_field_id_foreign` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields_data`
--

LOCK TABLES `custom_fields_data` WRITE;
/*!40000 ALTER TABLE `custom_fields_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_link_settings`
--

DROP TABLE IF EXISTS `custom_link_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_link_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `link_title` varchar(191) NOT NULL,
  `url` text NOT NULL,
  `can_be_viewed_by` varchar(191) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_link_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `custom_link_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_link_settings`
--

LOCK TABLES `custom_link_settings` WRITE;
/*!40000 ALTER TABLE `custom_link_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_link_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_widgets`
--

DROP TABLE IF EXISTS `dashboard_widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_widgets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `widget_name` varchar(191) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `dashboard_type` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `dashboard_widgets_company_id_foreign` (`company_id`),
  CONSTRAINT `dashboard_widgets_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=568 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_widgets`
--

LOCK TABLES `dashboard_widgets` WRITE;
/*!40000 ALTER TABLE `dashboard_widgets` DISABLE KEYS */;
INSERT INTO `dashboard_widgets` VALUES (1,1,'total_clients',1,'admin-dashboard',NULL,NULL,1),(2,1,'total_employees',1,'admin-dashboard',NULL,NULL,1),(3,1,'total_projects',1,'admin-dashboard',NULL,NULL,1),(4,1,'total_unpaid_invoices',1,'admin-dashboard',NULL,NULL,1),(5,1,'total_hours_logged',1,'admin-dashboard',NULL,NULL,1),(6,1,'total_pending_tasks',1,'admin-dashboard',NULL,NULL,1),(7,1,'total_today_attendance',1,'admin-dashboard',NULL,NULL,1),(8,1,'total_unresolved_tickets',1,'admin-dashboard',NULL,NULL,1),(9,1,'recent_earnings',1,'admin-dashboard',NULL,NULL,1),(10,1,'settings_leaves',1,'admin-dashboard',NULL,NULL,1),(11,1,'new_tickets',1,'admin-dashboard',NULL,NULL,1),(12,1,'overdue_tasks',1,'admin-dashboard',NULL,NULL,1),(13,1,'pending_follow_up',1,'admin-dashboard',NULL,NULL,1),(14,1,'project_activity_timeline',1,'admin-dashboard',NULL,NULL,1),(15,1,'user_activity_timeline',1,'admin-dashboard',NULL,NULL,1),(16,1,'timelogs',1,'admin-dashboard',NULL,NULL,1),(17,1,'total_clients',1,'admin-client-dashboard',NULL,NULL,1),(18,1,'total_leads',1,'admin-client-dashboard',NULL,NULL,1),(19,1,'total_lead_conversions',1,'admin-client-dashboard',NULL,NULL,1),(20,1,'total_contracts_generated',1,'admin-client-dashboard',NULL,NULL,1),(21,1,'total_contracts_signed',1,'admin-client-dashboard',NULL,NULL,1),(22,1,'client_wise_earnings',1,'admin-client-dashboard',NULL,NULL,1),(23,1,'client_wise_timelogs',1,'admin-client-dashboard',NULL,NULL,1),(24,1,'lead_vs_status',1,'admin-client-dashboard',NULL,NULL,1),(25,1,'lead_vs_source',1,'admin-client-dashboard',NULL,NULL,1),(26,1,'latest_client',1,'admin-client-dashboard',NULL,NULL,1),(27,1,'recent_login_activities',1,'admin-client-dashboard',NULL,NULL,1),(28,1,'total_paid_invoices',1,'admin-finance-dashboard',NULL,NULL,1),(29,1,'total_expenses',1,'admin-finance-dashboard',NULL,NULL,1),(30,1,'total_earnings',1,'admin-finance-dashboard',NULL,NULL,1),(31,1,'total_pending_amount',1,'admin-finance-dashboard',NULL,NULL,1),(32,1,'invoice_overview',1,'admin-finance-dashboard',NULL,NULL,1),(33,1,'estimate_overview',1,'admin-finance-dashboard',NULL,NULL,1),(34,1,'proposal_overview',1,'admin-finance-dashboard',NULL,NULL,1),(35,1,'earnings_by_client',1,'admin-finance-dashboard',NULL,NULL,1),(36,1,'earnings_by_projects',1,'admin-finance-dashboard',NULL,NULL,1),(37,1,'total_unpaid_invoices',1,'admin-finance-dashboard',NULL,NULL,1),(38,1,'total_leaves_approved',1,'admin-hr-dashboard',NULL,NULL,1),(39,1,'total_new_employee',1,'admin-hr-dashboard',NULL,NULL,1),(40,1,'total_employee_exits',1,'admin-hr-dashboard',NULL,NULL,1),(41,1,'average_attendance',1,'admin-hr-dashboard',NULL,NULL,1),(42,1,'department_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(43,1,'designation_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(44,1,'gender_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(45,1,'role_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(46,1,'leaves_taken',1,'admin-hr-dashboard',NULL,NULL,1),(47,1,'late_attendance_mark',1,'admin-hr-dashboard',NULL,NULL,1),(48,1,'headcount',1,'admin-hr-dashboard',NULL,NULL,1),(49,1,'joining_vs_attrition',1,'admin-hr-dashboard',NULL,NULL,1),(50,1,'birthday',1,'admin-hr-dashboard',NULL,NULL,1),(51,1,'total_today_attendance',1,'admin-hr-dashboard',NULL,NULL,1),(52,1,'total_project',1,'admin-project-dashboard',NULL,NULL,1),(53,1,'total_hours_logged',1,'admin-project-dashboard',NULL,NULL,1),(54,1,'total_overdue_project',1,'admin-project-dashboard',NULL,NULL,1),(55,1,'status_wise_project',1,'admin-project-dashboard',NULL,NULL,1),(56,1,'pending_milestone',1,'admin-project-dashboard',NULL,NULL,1),(57,1,'total_tickets',1,'admin-ticket-dashboard',NULL,NULL,1),(58,1,'total_unassigned_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(59,1,'type_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(60,1,'status_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(61,1,'channel_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(62,1,'new_tickets',1,'admin-ticket-dashboard',NULL,NULL,1),(63,1,'profile',1,'private-dashboard',NULL,NULL,1),(64,1,'shift_schedule',1,'private-dashboard',NULL,NULL,1),(65,1,'birthday',1,'private-dashboard',NULL,NULL,1),(66,1,'notices',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(67,1,'tasks',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(68,1,'projects',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(69,1,'my_task',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(70,1,'my_calender',1,'private-dashboard',NULL,NULL,1),(71,1,'week_timelog',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(72,1,'leave',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(73,1,'lead',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(74,1,'work_from_home',1,'private-dashboard',NULL,NULL,1),(75,1,'appreciation',1,'private-dashboard',NULL,NULL,1),(76,1,'work_anniversary',1,'private-dashboard',NULL,NULL,1),(77,1,'ticket',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(78,1,'notice_period_duration',1,'private-dashboard',NULL,NULL,1),(79,1,'probation_date',1,'private-dashboard',NULL,NULL,1),(80,1,'contract_date',1,'private-dashboard',NULL,'2023-08-21 05:42:40',1),(81,1,'internship_date',1,'private-dashboard',NULL,NULL,1),(163,3,'total_clients',1,'admin-dashboard',NULL,NULL,1),(164,3,'total_employees',1,'admin-dashboard',NULL,NULL,1),(165,3,'total_projects',1,'admin-dashboard',NULL,NULL,1),(166,3,'total_unpaid_invoices',1,'admin-dashboard',NULL,NULL,1),(167,3,'total_hours_logged',1,'admin-dashboard',NULL,NULL,1),(168,3,'total_pending_tasks',1,'admin-dashboard',NULL,NULL,1),(169,3,'total_today_attendance',1,'admin-dashboard',NULL,NULL,1),(170,3,'total_unresolved_tickets',1,'admin-dashboard',NULL,NULL,1),(171,3,'recent_earnings',1,'admin-dashboard',NULL,NULL,1),(172,3,'settings_leaves',1,'admin-dashboard',NULL,NULL,1),(173,3,'new_tickets',1,'admin-dashboard',NULL,NULL,1),(174,3,'overdue_tasks',1,'admin-dashboard',NULL,NULL,1),(175,3,'pending_follow_up',1,'admin-dashboard',NULL,NULL,1),(176,3,'project_activity_timeline',1,'admin-dashboard',NULL,NULL,1),(177,3,'user_activity_timeline',1,'admin-dashboard',NULL,NULL,1),(178,3,'timelogs',1,'admin-dashboard',NULL,NULL,1),(179,3,'total_clients',1,'admin-client-dashboard',NULL,NULL,1),(180,3,'total_leads',1,'admin-client-dashboard',NULL,NULL,1),(181,3,'total_lead_conversions',1,'admin-client-dashboard',NULL,NULL,1),(182,3,'total_contracts_generated',1,'admin-client-dashboard',NULL,NULL,1),(183,3,'total_contracts_signed',1,'admin-client-dashboard',NULL,NULL,1),(184,3,'client_wise_earnings',1,'admin-client-dashboard',NULL,NULL,1),(185,3,'client_wise_timelogs',1,'admin-client-dashboard',NULL,NULL,1),(186,3,'lead_vs_status',1,'admin-client-dashboard',NULL,NULL,1),(187,3,'lead_vs_source',1,'admin-client-dashboard',NULL,NULL,1),(188,3,'latest_client',1,'admin-client-dashboard',NULL,NULL,1),(189,3,'recent_login_activities',1,'admin-client-dashboard',NULL,NULL,1),(190,3,'total_paid_invoices',1,'admin-finance-dashboard',NULL,NULL,1),(191,3,'total_expenses',1,'admin-finance-dashboard',NULL,NULL,1),(192,3,'total_earnings',1,'admin-finance-dashboard',NULL,NULL,1),(193,3,'total_pending_amount',1,'admin-finance-dashboard',NULL,NULL,1),(194,3,'invoice_overview',1,'admin-finance-dashboard',NULL,NULL,1),(195,3,'estimate_overview',1,'admin-finance-dashboard',NULL,NULL,1),(196,3,'proposal_overview',1,'admin-finance-dashboard',NULL,NULL,1),(197,3,'earnings_by_client',1,'admin-finance-dashboard',NULL,NULL,1),(198,3,'earnings_by_projects',1,'admin-finance-dashboard',NULL,NULL,1),(199,3,'total_unpaid_invoices',1,'admin-finance-dashboard',NULL,NULL,1),(200,3,'total_leaves_approved',1,'admin-hr-dashboard',NULL,NULL,1),(201,3,'total_new_employee',1,'admin-hr-dashboard',NULL,NULL,1),(202,3,'total_employee_exits',1,'admin-hr-dashboard',NULL,NULL,1),(203,3,'average_attendance',1,'admin-hr-dashboard',NULL,NULL,1),(204,3,'department_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(205,3,'designation_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(206,3,'gender_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(207,3,'role_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(208,3,'leaves_taken',1,'admin-hr-dashboard',NULL,NULL,1),(209,3,'late_attendance_mark',1,'admin-hr-dashboard',NULL,NULL,1),(210,3,'headcount',1,'admin-hr-dashboard',NULL,NULL,1),(211,3,'joining_vs_attrition',1,'admin-hr-dashboard',NULL,NULL,1),(212,3,'birthday',1,'admin-hr-dashboard',NULL,NULL,1),(213,3,'total_today_attendance',1,'admin-hr-dashboard',NULL,NULL,1),(214,3,'total_project',1,'admin-project-dashboard',NULL,NULL,1),(215,3,'total_hours_logged',1,'admin-project-dashboard',NULL,NULL,1),(216,3,'total_overdue_project',1,'admin-project-dashboard',NULL,NULL,1),(217,3,'status_wise_project',1,'admin-project-dashboard',NULL,NULL,1),(218,3,'pending_milestone',1,'admin-project-dashboard',NULL,NULL,1),(219,3,'total_tickets',1,'admin-ticket-dashboard',NULL,NULL,1),(220,3,'total_unassigned_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(221,3,'type_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(222,3,'status_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(223,3,'channel_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(224,3,'new_tickets',1,'admin-ticket-dashboard',NULL,NULL,1),(225,3,'profile',1,'private-dashboard',NULL,NULL,1),(226,3,'shift_schedule',1,'private-dashboard',NULL,NULL,1),(227,3,'birthday',1,'private-dashboard',NULL,NULL,1),(228,3,'notices',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(229,3,'tasks',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(230,3,'projects',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(231,3,'my_task',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(232,3,'my_calender',1,'private-dashboard',NULL,NULL,1),(233,3,'week_timelog',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(234,3,'leave',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(235,3,'lead',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(236,3,'work_from_home',1,'private-dashboard',NULL,NULL,1),(237,3,'appreciation',1,'private-dashboard',NULL,NULL,1),(238,3,'work_anniversary',1,'private-dashboard',NULL,NULL,1),(239,3,'ticket',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(240,3,'notice_period_duration',1,'private-dashboard',NULL,NULL,1),(241,3,'probation_date',1,'private-dashboard',NULL,NULL,1),(242,3,'contract_date',1,'private-dashboard',NULL,'2023-08-21 16:08:31',1),(243,3,'internship_date',1,'private-dashboard',NULL,NULL,1),(487,7,'total_clients',1,'admin-dashboard',NULL,NULL,1),(488,7,'total_employees',1,'admin-dashboard',NULL,NULL,1),(489,7,'total_projects',1,'admin-dashboard',NULL,NULL,1),(490,7,'total_unpaid_invoices',1,'admin-dashboard',NULL,NULL,1),(491,7,'total_hours_logged',1,'admin-dashboard',NULL,NULL,1),(492,7,'total_pending_tasks',1,'admin-dashboard',NULL,NULL,1),(493,7,'total_today_attendance',1,'admin-dashboard',NULL,NULL,1),(494,7,'total_unresolved_tickets',1,'admin-dashboard',NULL,NULL,1),(495,7,'recent_earnings',1,'admin-dashboard',NULL,NULL,1),(496,7,'settings_leaves',1,'admin-dashboard',NULL,NULL,1),(497,7,'new_tickets',1,'admin-dashboard',NULL,NULL,1),(498,7,'overdue_tasks',1,'admin-dashboard',NULL,NULL,1),(499,7,'pending_follow_up',1,'admin-dashboard',NULL,NULL,1),(500,7,'project_activity_timeline',1,'admin-dashboard',NULL,NULL,1),(501,7,'user_activity_timeline',1,'admin-dashboard',NULL,NULL,1),(502,7,'timelogs',1,'admin-dashboard',NULL,NULL,1),(503,7,'total_clients',1,'admin-client-dashboard',NULL,NULL,1),(504,7,'total_leads',1,'admin-client-dashboard',NULL,NULL,1),(505,7,'total_lead_conversions',1,'admin-client-dashboard',NULL,NULL,1),(506,7,'total_contracts_generated',1,'admin-client-dashboard',NULL,NULL,1),(507,7,'total_contracts_signed',1,'admin-client-dashboard',NULL,NULL,1),(508,7,'client_wise_earnings',1,'admin-client-dashboard',NULL,NULL,1),(509,7,'client_wise_timelogs',1,'admin-client-dashboard',NULL,NULL,1),(510,7,'lead_vs_status',1,'admin-client-dashboard',NULL,NULL,1),(511,7,'lead_vs_source',1,'admin-client-dashboard',NULL,NULL,1),(512,7,'latest_client',1,'admin-client-dashboard',NULL,NULL,1),(513,7,'recent_login_activities',1,'admin-client-dashboard',NULL,NULL,1),(514,7,'total_paid_invoices',1,'admin-finance-dashboard',NULL,NULL,1),(515,7,'total_expenses',1,'admin-finance-dashboard',NULL,NULL,1),(516,7,'total_earnings',1,'admin-finance-dashboard',NULL,NULL,1),(517,7,'total_pending_amount',1,'admin-finance-dashboard',NULL,NULL,1),(518,7,'invoice_overview',1,'admin-finance-dashboard',NULL,NULL,1),(519,7,'estimate_overview',1,'admin-finance-dashboard',NULL,NULL,1),(520,7,'proposal_overview',1,'admin-finance-dashboard',NULL,NULL,1),(521,7,'earnings_by_client',1,'admin-finance-dashboard',NULL,NULL,1),(522,7,'earnings_by_projects',1,'admin-finance-dashboard',NULL,NULL,1),(523,7,'total_unpaid_invoices',1,'admin-finance-dashboard',NULL,NULL,1),(524,7,'total_leaves_approved',1,'admin-hr-dashboard',NULL,NULL,1),(525,7,'total_new_employee',1,'admin-hr-dashboard',NULL,NULL,1),(526,7,'total_employee_exits',1,'admin-hr-dashboard',NULL,NULL,1),(527,7,'average_attendance',1,'admin-hr-dashboard',NULL,NULL,1),(528,7,'department_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(529,7,'designation_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(530,7,'gender_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(531,7,'role_wise_employee',1,'admin-hr-dashboard',NULL,NULL,1),(532,7,'leaves_taken',1,'admin-hr-dashboard',NULL,NULL,1),(533,7,'late_attendance_mark',1,'admin-hr-dashboard',NULL,NULL,1),(534,7,'headcount',1,'admin-hr-dashboard',NULL,NULL,1),(535,7,'joining_vs_attrition',1,'admin-hr-dashboard',NULL,NULL,1),(536,7,'birthday',1,'admin-hr-dashboard',NULL,NULL,1),(537,7,'total_today_attendance',1,'admin-hr-dashboard',NULL,NULL,1),(538,7,'total_project',1,'admin-project-dashboard',NULL,NULL,1),(539,7,'total_hours_logged',1,'admin-project-dashboard',NULL,NULL,1),(540,7,'total_overdue_project',1,'admin-project-dashboard',NULL,NULL,1),(541,7,'status_wise_project',1,'admin-project-dashboard',NULL,NULL,1),(542,7,'pending_milestone',1,'admin-project-dashboard',NULL,NULL,1),(543,7,'total_tickets',1,'admin-ticket-dashboard',NULL,NULL,1),(544,7,'total_unassigned_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(545,7,'type_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(546,7,'status_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(547,7,'channel_wise_ticket',1,'admin-ticket-dashboard',NULL,NULL,1),(548,7,'new_tickets',1,'admin-ticket-dashboard',NULL,NULL,1),(549,7,'profile',1,'private-dashboard',NULL,NULL,1),(550,7,'shift_schedule',1,'private-dashboard',NULL,NULL,1),(551,7,'birthday',1,'private-dashboard',NULL,NULL,1),(552,7,'notices',1,'private-dashboard',NULL,NULL,1),(553,7,'tasks',1,'private-dashboard',NULL,NULL,1),(554,7,'projects',1,'private-dashboard',NULL,NULL,1),(555,7,'my_task',1,'private-dashboard',NULL,NULL,1),(556,7,'my_calender',1,'private-dashboard',NULL,NULL,1),(557,7,'week_timelog',1,'private-dashboard',NULL,NULL,1),(558,7,'leave',1,'private-dashboard',NULL,NULL,1),(559,7,'lead',1,'private-dashboard',NULL,NULL,1),(560,7,'work_from_home',1,'private-dashboard',NULL,NULL,1),(561,7,'appreciation',1,'private-dashboard',NULL,NULL,1),(562,7,'work_anniversary',1,'private-dashboard',NULL,NULL,1),(563,7,'ticket',1,'private-dashboard',NULL,NULL,1),(564,7,'notice_period_duration',1,'private-dashboard',NULL,NULL,1),(565,7,'probation_date',1,'private-dashboard',NULL,NULL,1),(566,7,'contract_date',1,'private-dashboard',NULL,NULL,1),(567,7,'internship_date',1,'private-dashboard',NULL,NULL,1);
/*!40000 ALTER TABLE `dashboard_widgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `database_backup_cron_settings`
--

DROP TABLE IF EXISTS `database_backup_cron_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `database_backup_cron_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `hour_of_day` time DEFAULT NULL,
  `backup_after_days` varchar(191) DEFAULT NULL,
  `delete_backup_after_days` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `database_backup_cron_settings`
--

LOCK TABLES `database_backup_cron_settings` WRITE;
/*!40000 ALTER TABLE `database_backup_cron_settings` DISABLE KEYS */;
INSERT INTO `database_backup_cron_settings` VALUES (1,'inactive','00:00:00','0','0');
/*!40000 ALTER TABLE `database_backup_cron_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `database_backups`
--

DROP TABLE IF EXISTS `database_backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `database_backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `database_backups`
--

LOCK TABLES `database_backups` WRITE;
/*!40000 ALTER TABLE `database_backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `database_backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `designations`
--

DROP TABLE IF EXISTS `designations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designations_company_id_foreign` (`company_id`),
  KEY `designations_added_by_foreign` (`added_by`),
  KEY `designations_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `designations_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `designations_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `designations_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `designations`
--

LOCK TABLES `designations` WRITE;
/*!40000 ALTER TABLE `designations` DISABLE KEYS */;
INSERT INTO `designations` VALUES (1,1,'Staff',NULL,NULL,NULL,'2023-08-21 05:44:28','2023-08-21 05:44:28');
/*!40000 ALTER TABLE `designations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussion_categories`
--

DROP TABLE IF EXISTS `discussion_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 1,
  `name` varchar(191) NOT NULL,
  `color` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discussion_categories_company_id_foreign` (`company_id`),
  CONSTRAINT `discussion_categories_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussion_categories`
--

LOCK TABLES `discussion_categories` WRITE;
/*!40000 ALTER TABLE `discussion_categories` DISABLE KEYS */;
INSERT INTO `discussion_categories` VALUES (1,1,1,'General','#3498DB','2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,1,'General','#3498DB','2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,1,'General','#3498DB','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `discussion_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussion_files`
--

DROP TABLE IF EXISTS `discussion_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `discussion_id` int(10) unsigned DEFAULT NULL,
  `discussion_reply_id` int(10) unsigned DEFAULT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discussion_files_company_id_foreign` (`company_id`),
  KEY `discussion_files_user_id_foreign` (`user_id`),
  KEY `discussion_files_discussion_id_foreign` (`discussion_id`),
  KEY `discussion_files_discussion_reply_id_foreign` (`discussion_reply_id`),
  CONSTRAINT `discussion_files_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussion_files_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussion_files_discussion_reply_id_foreign` FOREIGN KEY (`discussion_reply_id`) REFERENCES `discussion_replies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussion_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussion_files`
--

LOCK TABLES `discussion_files` WRITE;
/*!40000 ALTER TABLE `discussion_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `discussion_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussion_replies`
--

DROP TABLE IF EXISTS `discussion_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion_replies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `discussion_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `body` longtext NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discussion_replies_discussion_id_foreign` (`discussion_id`),
  KEY `discussion_replies_user_id_foreign` (`user_id`),
  KEY `discussion_replies_company_id_foreign` (`company_id`),
  CONSTRAINT `discussion_replies_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussion_replies_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussion_replies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussion_replies`
--

LOCK TABLES `discussion_replies` WRITE;
/*!40000 ALTER TABLE `discussion_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `discussion_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussions`
--

DROP TABLE IF EXISTS `discussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `discussion_category_id` int(10) unsigned DEFAULT 1,
  `project_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `color` varchar(20) DEFAULT '#232629',
  `user_id` int(10) unsigned NOT NULL,
  `pinned` tinyint(1) NOT NULL DEFAULT 0,
  `closed` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_reply_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `best_answer_id` int(10) unsigned DEFAULT NULL,
  `last_reply_by_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discussions_discussion_category_id_foreign` (`discussion_category_id`),
  KEY `discussions_project_id_foreign` (`project_id`),
  KEY `discussions_user_id_foreign` (`user_id`),
  KEY `discussions_best_answer_id_foreign` (`best_answer_id`),
  KEY `discussions_last_reply_by_id_foreign` (`last_reply_by_id`),
  KEY `discussions_added_by_foreign` (`added_by`),
  KEY `discussions_last_updated_by_foreign` (`last_updated_by`),
  KEY `discussions_company_id_foreign` (`company_id`),
  CONSTRAINT `discussions_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `discussions_best_answer_id_foreign` FOREIGN KEY (`best_answer_id`) REFERENCES `discussion_replies` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `discussions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussions_discussion_category_id_foreign` FOREIGN KEY (`discussion_category_id`) REFERENCES `discussion_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `discussions_last_reply_by_id_foreign` FOREIGN KEY (`last_reply_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `discussions_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `discussions_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussions`
--

LOCK TABLES `discussions` WRITE;
/*!40000 ALTER TABLE `discussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `discussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_notification_settings`
--

DROP TABLE IF EXISTS `email_notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_notification_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `setting_name` varchar(191) NOT NULL,
  `send_email` enum('yes','no') NOT NULL DEFAULT 'no',
  `send_slack` enum('yes','no') NOT NULL DEFAULT 'no',
  `send_push` enum('yes','no') NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email_notification_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `email_notification_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_notification_settings`
--

LOCK TABLES `email_notification_settings` WRITE;
/*!40000 ALTER TABLE `email_notification_settings` DISABLE KEYS */;
INSERT INTO `email_notification_settings` VALUES (1,1,'new-expenseadded-by-admin','New Expense/Added by Admin','no','no','no',NULL,'2023-08-10 14:16:13'),(2,1,'new-expenseadded-by-member','New Expense/Added by Member','no','no','no',NULL,'2023-08-10 14:16:13'),(3,1,'expense-status-changed','Expense Status Changed','no','no','no',NULL,'2023-08-10 14:16:13'),(4,1,'new-support-ticket-request','New Support Ticket Request','no','no','no',NULL,'2023-08-10 14:16:13'),(5,1,'new-leave-application','New Leave Application','no','no','no',NULL,'2023-08-10 14:16:13'),(6,1,'task-completed','Task Completed','no','no','no',NULL,'2023-08-10 14:16:13'),(7,1,'invoice-createupdate-notification','Invoice Create/Update Notification','no','no','no',NULL,'2023-08-10 14:16:13'),(8,1,'discussion-reply','Discussion Reply','no','no','no',NULL,'2023-08-10 14:16:13'),(9,1,'new-product-purchase-request','New Product Purchase Request','no','no','no',NULL,'2023-08-10 14:16:13'),(10,1,'lead-notification','Lead notification','no','no','no',NULL,'2023-08-10 14:16:13'),(11,1,'order-createupdate-notification','Order Create/Update Notification','no','no','no',NULL,NULL),(12,1,'user-join-via-invitation','User Join via Invitation','no','no','no',NULL,NULL),(13,1,'follow-up-reminder','Follow Up Reminder','no','no','no',NULL,NULL),(14,1,'user-registrationadded-by-admin','User Registration/Added by Admin','no','no','no',NULL,'2023-08-10 14:16:13'),(15,1,'employee-assign-to-project','Employee Assign to Project','no','no','no',NULL,'2023-08-10 14:16:13'),(16,1,'new-notice-published','New Notice Published','no','no','no',NULL,NULL),(17,1,'user-assign-to-task','User Assign to Task','no','no','no',NULL,'2023-08-10 14:16:13'),(18,1,'birthday-notification','Birthday notification','no','yes','no',NULL,'2023-08-10 14:16:13'),(19,1,'payment-notification','Payment Notification','no','no','no',NULL,'2023-08-10 14:16:13'),(20,1,'appreciation-notification','Employee Appreciation','no','no','no',NULL,'2023-08-10 14:16:13'),(21,1,'clock-in-notification','Clock In Notification','no','no','no',NULL,NULL),(22,1,'holiday-notification','Holiday Notification','no','no','no',NULL,NULL),(23,1,'estimate-notification','Estimate Notification','no','no','no',NULL,'2023-08-10 14:16:13'),(24,1,'event-notification','Event Notification','no','no','no',NULL,'2023-08-10 14:16:13'),(25,1,'message-notification','Message Notification','no','no','no',NULL,'2023-08-10 14:16:13'),(26,1,'project-mention-notification','Project Mention Notification','no','no','no',NULL,'2023-08-10 14:16:13'),(27,1,'task-mention-notification','Task Mention','no','no','no',NULL,'2023-08-10 14:16:13'),(28,1,'shift-assign-notification','Shift Assign Notification','no','no','no',NULL,'2023-08-10 14:16:13'),(57,3,'new-expenseadded-by-admin','New Expense/Added by Admin','no','no','no',NULL,'2023-08-21 16:03:04'),(58,3,'new-expenseadded-by-member','New Expense/Added by Member','no','no','no',NULL,'2023-08-21 16:03:04'),(59,3,'expense-status-changed','Expense Status Changed','no','no','no',NULL,'2023-08-21 16:03:04'),(60,3,'new-support-ticket-request','New Support Ticket Request','no','no','no',NULL,'2023-08-21 16:03:04'),(61,3,'new-leave-application','New Leave Application','no','no','no',NULL,'2023-08-21 16:03:04'),(62,3,'task-completed','Task Completed','no','no','no',NULL,'2023-08-21 16:03:04'),(63,3,'invoice-createupdate-notification','Invoice Create/Update Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(64,3,'discussion-reply','Discussion Reply','no','no','no',NULL,'2023-08-21 16:03:04'),(65,3,'new-product-purchase-request','New Product Purchase Request','no','no','no',NULL,'2023-08-21 16:03:04'),(66,3,'lead-notification','Lead notification','no','no','no',NULL,'2023-08-21 16:03:04'),(67,3,'order-createupdate-notification','Order Create/Update Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(68,3,'user-join-via-invitation','User Join via Invitation','no','no','no',NULL,'2023-08-21 16:03:04'),(69,3,'follow-up-reminder','Follow Up Reminder','no','no','no',NULL,'2023-08-21 16:03:04'),(70,3,'user-registrationadded-by-admin','User Registration/Added by Admin','no','no','no',NULL,'2023-08-21 16:03:04'),(71,3,'employee-assign-to-project','Employee Assign to Project','no','no','no',NULL,'2023-08-21 16:03:04'),(72,3,'new-notice-published','New Notice Published','no','no','no',NULL,'2023-08-21 16:03:04'),(73,3,'user-assign-to-task','User Assign to Task','no','no','no',NULL,'2023-08-21 16:03:04'),(74,3,'birthday-notification','Birthday notification','no','yes','no',NULL,'2023-08-21 16:03:04'),(75,3,'payment-notification','Payment Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(76,3,'appreciation-notification','Employee Appreciation','no','no','no',NULL,'2023-08-21 16:03:04'),(77,3,'clock-in-notification','Clock In Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(78,3,'holiday-notification','Holiday Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(79,3,'estimate-notification','Estimate Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(80,3,'event-notification','Event Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(81,3,'message-notification','Message Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(82,3,'project-mention-notification','Project Mention Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(83,3,'task-mention-notification','Task Mention','no','no','no',NULL,'2023-08-21 16:03:04'),(84,3,'shift-assign-notification','Shift Assign Notification','no','no','no',NULL,'2023-08-21 16:03:04'),(169,7,'new-expenseadded-by-admin','New Expense/Added by Admin','no','no','no',NULL,'2023-08-21 16:37:26'),(170,7,'new-expenseadded-by-member','New Expense/Added by Member','no','no','no',NULL,'2023-08-21 16:37:26'),(171,7,'expense-status-changed','Expense Status Changed','no','no','no',NULL,'2023-08-21 16:37:26'),(172,7,'new-support-ticket-request','New Support Ticket Request','no','no','no',NULL,'2023-08-21 16:37:26'),(173,7,'new-leave-application','New Leave Application','no','no','no',NULL,'2023-08-21 16:37:26'),(174,7,'task-completed','Task Completed','no','no','no',NULL,'2023-08-21 16:37:26'),(175,7,'invoice-createupdate-notification','Invoice Create/Update Notification','no','no','no',NULL,'2023-08-21 16:37:26'),(176,7,'discussion-reply','Discussion Reply','no','no','no',NULL,'2023-08-21 16:37:26'),(177,7,'new-product-purchase-request','New Product Purchase Request','no','no','no',NULL,'2023-08-21 16:37:26'),(178,7,'lead-notification','Lead notification','no','no','no',NULL,'2023-08-21 16:37:26'),(179,7,'order-createupdate-notification','Order Create/Update Notification','no','no','no',NULL,NULL),(180,7,'user-join-via-invitation','User Join via Invitation','no','no','no',NULL,NULL),(181,7,'follow-up-reminder','Follow Up Reminder','no','no','no',NULL,NULL),(182,7,'user-registrationadded-by-admin','User Registration/Added by Admin','no','no','no',NULL,'2023-08-21 16:37:26'),(183,7,'employee-assign-to-project','Employee Assign to Project','no','no','no',NULL,'2023-08-21 16:37:26'),(184,7,'new-notice-published','New Notice Published','no','no','no',NULL,NULL),(185,7,'user-assign-to-task','User Assign to Task','no','no','no',NULL,'2023-08-21 16:37:26'),(186,7,'birthday-notification','Birthday notification','no','yes','no',NULL,'2023-08-21 16:37:26'),(187,7,'payment-notification','Payment Notification','no','no','no',NULL,'2023-08-21 16:37:26'),(188,7,'appreciation-notification','Employee Appreciation','no','no','no',NULL,'2023-08-21 16:37:26'),(189,7,'clock-in-notification','Clock In Notification','no','no','no',NULL,NULL),(190,7,'holiday-notification','Holiday Notification','no','no','no',NULL,NULL),(191,7,'estimate-notification','Estimate Notification','no','no','no',NULL,'2023-08-21 16:37:26'),(192,7,'event-notification','Event Notification','no','no','no',NULL,'2023-08-21 16:37:26'),(193,7,'message-notification','Message Notification','no','no','no',NULL,'2023-08-21 16:37:26'),(194,7,'project-mention-notification','Project Mention Notification','no','no','no',NULL,'2023-08-21 16:37:26'),(195,7,'task-mention-notification','Task Mention','no','no','no',NULL,'2023-08-21 16:37:26'),(196,7,'shift-assign-notification','Shift Assign Notification','no','no','no',NULL,'2023-08-21 16:37:26');
/*!40000 ALTER TABLE `email_notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emergency_contacts`
--

DROP TABLE IF EXISTS `emergency_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emergency_contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `relation` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `emergency_contacts_company_id_foreign` (`company_id`),
  KEY `emergency_contacts_user_id_foreign` (`user_id`),
  KEY `emergency_contacts_added_by_foreign` (`added_by`),
  KEY `emergency_contacts_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `emergency_contacts_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `emergency_contacts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `emergency_contacts_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `emergency_contacts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emergency_contacts`
--

LOCK TABLES `emergency_contacts` WRITE;
/*!40000 ALTER TABLE `emergency_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `emergency_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_details`
--

DROP TABLE IF EXISTS `employee_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `employee_id` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `hourly_rate` double DEFAULT NULL,
  `slack_username` varchar(191) DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `designation_id` bigint(20) unsigned DEFAULT NULL,
  `joining_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_date` date DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `attendance_reminder` date DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `calendar_view` text DEFAULT NULL,
  `about_me` text DEFAULT NULL,
  `reporting_to` int(10) unsigned DEFAULT NULL,
  `contract_end_date` date DEFAULT NULL,
  `internship_end_date` date DEFAULT NULL,
  `employment_type` varchar(191) DEFAULT NULL,
  `marriage_anniversary_date` date DEFAULT NULL,
  `marital_status` varchar(191) DEFAULT 'unmarried',
  `notice_period_end_date` date DEFAULT NULL,
  `notice_period_start_date` date DEFAULT NULL,
  `probation_end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_details_employee_id_company_id_unique` (`employee_id`,`company_id`),
  UNIQUE KEY `employee_details_slack_username_company_id_unique` (`slack_username`,`company_id`),
  KEY `employee_details_company_id_foreign` (`company_id`),
  KEY `employee_details_user_id_foreign` (`user_id`),
  KEY `employee_details_department_id_foreign` (`department_id`),
  KEY `employee_details_designation_id_foreign` (`designation_id`),
  KEY `employee_details_added_by_foreign` (`added_by`),
  KEY `employee_details_last_updated_by_foreign` (`last_updated_by`),
  KEY `employee_details_reporting_to_foreign` (`reporting_to`),
  CONSTRAINT `employee_details_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `employee_details_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_details_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `teams` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `employee_details_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_details_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `employee_details_reporting_to_foreign` FOREIGN KEY (`reporting_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `employee_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_details`
--

LOCK TABLES `employee_details` WRITE;
/*!40000 ALTER TABLE `employee_details` DISABLE KEYS */;
INSERT INTO `employee_details` VALUES (1,1,2,'EMP-1',NULL,NULL,NULL,NULL,NULL,'2023-08-10 14:07:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'unmarried',NULL,NULL,NULL,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(2,3,3,'EMP-1',NULL,NULL,NULL,NULL,NULL,'2023-08-10 14:17:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'unmarried',NULL,NULL,NULL,'2023-08-10 14:17:29','2023-08-10 14:17:29'),(3,1,4,'2',NULL,NULL,NULL,1,1,'2023-08-21 00:00:00',NULL,2,2,NULL,'1986-08-07','task,events,holiday,tickets,leaves',NULL,NULL,NULL,NULL,NULL,NULL,'unmarried',NULL,NULL,NULL,'2023-08-21 05:44:55','2023-08-21 05:44:55'),(4,7,8,'EMP-1',NULL,NULL,NULL,NULL,NULL,'2023-08-21 16:25:19',NULL,NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'unmarried',NULL,NULL,NULL,'2023-08-21 16:25:19','2024-07-14 15:48:09');
/*!40000 ALTER TABLE `employee_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_docs`
--

DROP TABLE IF EXISTS `employee_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_docs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `hashname` varchar(200) NOT NULL,
  `size` varchar(200) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_docs_company_id_foreign` (`company_id`),
  KEY `employee_docs_user_id_foreign` (`user_id`),
  KEY `employee_docs_added_by_foreign` (`added_by`),
  KEY `employee_docs_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `employee_docs_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `employee_docs_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_docs_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `employee_docs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_docs`
--

LOCK TABLES `employee_docs` WRITE;
/*!40000 ALTER TABLE `employee_docs` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_docs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_leave_quotas`
--

DROP TABLE IF EXISTS `employee_leave_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_leave_quotas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `leave_type_id` int(10) unsigned NOT NULL,
  `no_of_leaves` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_leave_quotas_user_id_foreign` (`user_id`),
  KEY `employee_leave_quotas_leave_type_id_foreign` (`leave_type_id`),
  CONSTRAINT `employee_leave_quotas_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_leave_quotas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_leave_quotas`
--

LOCK TABLES `employee_leave_quotas` WRITE;
/*!40000 ALTER TABLE `employee_leave_quotas` DISABLE KEYS */;
INSERT INTO `employee_leave_quotas` VALUES (1,2,1,5,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(2,2,2,5,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(3,2,3,5,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(4,3,7,5,'2023-08-10 14:17:29','2023-08-10 14:17:29'),(5,3,8,5,'2023-08-10 14:17:29','2023-08-10 14:17:29'),(6,3,9,5,'2023-08-10 14:17:29','2023-08-10 14:17:29'),(7,4,1,5,'2023-08-21 05:44:55','2023-08-21 05:44:55'),(8,4,2,5,'2023-08-21 05:44:55','2023-08-21 05:44:55'),(9,4,3,5,'2023-08-21 05:44:55','2023-08-21 05:44:55'),(10,8,19,5,'2023-08-21 16:25:20','2023-08-21 16:25:20'),(11,8,20,5,'2023-08-21 16:25:20','2023-08-21 16:25:20'),(12,8,21,5,'2023-08-21 16:25:20','2023-08-21 16:25:20');
/*!40000 ALTER TABLE `employee_leave_quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_monthly_salaries`
--

DROP TABLE IF EXISTS `employee_monthly_salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_monthly_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `annual_salary` varchar(191) DEFAULT NULL,
  `amount` varchar(191) NOT NULL DEFAULT '0',
  `basic_salary` varchar(191) DEFAULT NULL,
  `fixed_allowance` varchar(191) NOT NULL,
  `basic_value_type` enum('fixed','ctc_percent') DEFAULT NULL,
  `type` enum('initial','increment','decrement') NOT NULL DEFAULT 'initial',
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `allow_generate_payroll` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  KEY `employee_monthly_salaries_user_id_foreign` (`user_id`),
  CONSTRAINT `employee_monthly_salaries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_monthly_salaries`
--

LOCK TABLES `employee_monthly_salaries` WRITE;
/*!40000 ALTER TABLE `employee_monthly_salaries` DISABLE KEYS */;
INSERT INTO `employee_monthly_salaries` VALUES (1,2,'500','41.666666666667','50','20.833333333333','ctc_percent','initial','2023-08-21','2023-08-21 05:45:16','2023-08-21 05:45:46','yes'),(2,4,'500','41.666666666667','50','20.833333333333','ctc_percent','initial','2023-08-21','2023-08-21 05:45:58','2023-08-21 05:46:08','yes');
/*!40000 ALTER TABLE `employee_monthly_salaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_payroll_cycles`
--

DROP TABLE IF EXISTS `employee_payroll_cycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_payroll_cycles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `payroll_cycle_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_payroll_cycles_payroll_cycle_id_foreign` (`payroll_cycle_id`),
  KEY `employee_payroll_cycles_user_id_foreign` (`user_id`),
  KEY `employee_payroll_cycles_company_id_foreign` (`company_id`),
  CONSTRAINT `employee_payroll_cycles_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_payroll_cycles_payroll_cycle_id_foreign` FOREIGN KEY (`payroll_cycle_id`) REFERENCES `payroll_cycles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_payroll_cycles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_payroll_cycles`
--

LOCK TABLES `employee_payroll_cycles` WRITE;
/*!40000 ALTER TABLE `employee_payroll_cycles` DISABLE KEYS */;
INSERT INTO `employee_payroll_cycles` VALUES (1,1,1,2,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(2,3,1,3,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(3,1,1,4,'2023-08-21 05:44:55','2023-08-21 05:44:55'),(4,7,1,9,'2023-08-21 16:31:15','2023-08-21 16:31:15');
/*!40000 ALTER TABLE `employee_payroll_cycles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_salary_groups`
--

DROP TABLE IF EXISTS `employee_salary_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_salary_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `salary_group_id` bigint(20) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_salary_groups_salary_group_id_foreign` (`salary_group_id`),
  KEY `employee_salary_groups_user_id_foreign` (`user_id`),
  CONSTRAINT `employee_salary_groups_salary_group_id_foreign` FOREIGN KEY (`salary_group_id`) REFERENCES `salary_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_salary_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_salary_groups`
--

LOCK TABLES `employee_salary_groups` WRITE;
/*!40000 ALTER TABLE `employee_salary_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_salary_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_shift_change_requests`
--

DROP TABLE IF EXISTS `employee_shift_change_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_shift_change_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `shift_schedule_id` bigint(20) unsigned NOT NULL,
  `employee_shift_id` bigint(20) unsigned NOT NULL,
  `status` enum('waiting','accepted','rejected') NOT NULL DEFAULT 'waiting',
  `reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_shift_change_requests_company_id_foreign` (`company_id`),
  KEY `employee_shift_change_requests_shift_schedule_id_foreign` (`shift_schedule_id`),
  KEY `employee_shift_change_requests_employee_shift_id_foreign` (`employee_shift_id`),
  CONSTRAINT `employee_shift_change_requests_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_shift_change_requests_employee_shift_id_foreign` FOREIGN KEY (`employee_shift_id`) REFERENCES `employee_shifts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_shift_change_requests_shift_schedule_id_foreign` FOREIGN KEY (`shift_schedule_id`) REFERENCES `employee_shift_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_shift_change_requests`
--

LOCK TABLES `employee_shift_change_requests` WRITE;
/*!40000 ALTER TABLE `employee_shift_change_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_shift_change_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_shift_schedules`
--

DROP TABLE IF EXISTS `employee_shift_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_shift_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `employee_shift_id` bigint(20) unsigned NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `shift_start_time` datetime DEFAULT NULL,
  `shift_end_time` datetime DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `file` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_shift_schedules_user_id_foreign` (`user_id`),
  KEY `employee_shift_schedules_date_index` (`date`),
  KEY `employee_shift_schedules_employee_shift_id_foreign` (`employee_shift_id`),
  KEY `employee_shift_schedules_added_by_foreign` (`added_by`),
  KEY `employee_shift_schedules_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `employee_shift_schedules_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `employee_shift_schedules_employee_shift_id_foreign` FOREIGN KEY (`employee_shift_id`) REFERENCES `employee_shifts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_shift_schedules_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `employee_shift_schedules_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_shift_schedules`
--

LOCK TABLES `employee_shift_schedules` WRITE;
/*!40000 ALTER TABLE `employee_shift_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_shift_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_shifts`
--

DROP TABLE IF EXISTS `employee_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_shifts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `shift_name` varchar(191) NOT NULL,
  `shift_short_code` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  `office_start_time` time NOT NULL,
  `office_end_time` time NOT NULL,
  `halfday_mark_time` time DEFAULT NULL,
  `late_mark_duration` tinyint(4) NOT NULL,
  `clockin_in_day` tinyint(4) NOT NULL,
  `office_open_days` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `early_clock_in` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_shifts_company_id_foreign` (`company_id`),
  CONSTRAINT `employee_shifts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_shifts`
--

LOCK TABLES `employee_shifts` WRITE;
/*!40000 ALTER TABLE `employee_shifts` DISABLE KEYS */;
INSERT INTO `employee_shifts` VALUES (1,1,'Day Off','DO','#E8EEF3','00:00:00','00:00:00',NULL,0,0,'','2023-08-10 14:06:55','2023-08-10 14:06:55',NULL),(2,1,'General Shift','GS','#99C7F1','09:00:00','18:00:00',NULL,20,2,'[\"1\",\"2\",\"3\",\"4\",\"5\"]','2023-08-10 14:06:55','2023-08-10 14:06:55',NULL),(5,3,'Day Off','DO','#E8EEF3','00:00:00','00:00:00',NULL,0,0,'','2023-08-10 14:17:22','2023-08-10 14:17:22',NULL),(6,3,'General Shift','GS','#99C7F1','09:00:00','18:00:00',NULL,20,2,'[\"1\",\"2\",\"3\",\"4\",\"5\"]','2023-08-10 14:17:22','2023-08-10 14:17:22',NULL),(13,7,'Day Off','DO','#E8EEF3','00:00:00','00:00:00',NULL,0,0,'','2023-08-21 16:25:19','2023-08-21 16:25:19',NULL),(14,7,'General Shift','GS','#99C7F1','09:00:00','18:00:00',NULL,20,2,'[\"1\",\"2\",\"3\",\"4\",\"5\"]','2023-08-21 16:25:19','2023-08-21 16:25:19',NULL);
/*!40000 ALTER TABLE `employee_shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_skills`
--

DROP TABLE IF EXISTS `employee_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `skill_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_skills_company_id_foreign` (`company_id`),
  KEY `employee_skills_user_id_foreign` (`user_id`),
  KEY `employee_skills_skill_id_foreign` (`skill_id`),
  CONSTRAINT `employee_skills_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_skills_skill_id_foreign` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_skills_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_skills`
--

LOCK TABLES `employee_skills` WRITE;
/*!40000 ALTER TABLE `employee_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_teams`
--

DROP TABLE IF EXISTS `employee_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `team_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_teams_company_id_foreign` (`company_id`),
  KEY `employee_teams_team_id_foreign` (`team_id`),
  KEY `employee_teams_user_id_foreign` (`user_id`),
  CONSTRAINT `employee_teams_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_teams_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `employee_teams_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_teams`
--

LOCK TABLES `employee_teams` WRITE;
/*!40000 ALTER TABLE `employee_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_variable_salaries`
--

DROP TABLE IF EXISTS `employee_variable_salaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_variable_salaries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `monthly_salary_id` bigint(20) unsigned NOT NULL,
  `variable_component_id` bigint(20) unsigned NOT NULL,
  `variable_value` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_variable_salaries_monthly_salary_id_foreign` (`monthly_salary_id`),
  KEY `employee_variable_salaries_variable_component_id_foreign` (`variable_component_id`),
  CONSTRAINT `employee_variable_salaries_monthly_salary_id_foreign` FOREIGN KEY (`monthly_salary_id`) REFERENCES `employee_monthly_salaries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `employee_variable_salaries_variable_component_id_foreign` FOREIGN KEY (`variable_component_id`) REFERENCES `salary_components` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_variable_salaries`
--

LOCK TABLES `employee_variable_salaries` WRITE;
/*!40000 ALTER TABLE `employee_variable_salaries` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_variable_salaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimate_item_images`
--

DROP TABLE IF EXISTS `estimate_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estimate_item_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estimate_item_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estimate_item_images_estimate_item_id_foreign` (`estimate_item_id`),
  CONSTRAINT `estimate_item_images_estimate_item_id_foreign` FOREIGN KEY (`estimate_item_id`) REFERENCES `estimate_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate_item_images`
--

LOCK TABLES `estimate_item_images` WRITE;
/*!40000 ALTER TABLE `estimate_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimate_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimate_items`
--

DROP TABLE IF EXISTS `estimate_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estimate_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estimate_id` int(10) unsigned NOT NULL,
  `item_name` varchar(191) NOT NULL,
  `item_summary` text DEFAULT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `quantity` double(16,2) NOT NULL,
  `unit_price` double(16,2) NOT NULL,
  `amount` double(16,2) NOT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estimate_items_estimate_id_foreign` (`estimate_id`),
  KEY `estimate_items_unit_id_foreign` (`unit_id`),
  KEY `estimate_items_product_id_foreign` (`product_id`),
  CONSTRAINT `estimate_items_estimate_id_foreign` FOREIGN KEY (`estimate_id`) REFERENCES `estimates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimate_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `estimate_items_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate_items`
--

LOCK TABLES `estimate_items` WRITE;
/*!40000 ALTER TABLE `estimate_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimate_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimate_template_item_images`
--

DROP TABLE IF EXISTS `estimate_template_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estimate_template_item_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `estimate_template_item_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estimate_template_item_images_company_id_foreign` (`company_id`),
  KEY `estimate_template_item_images_estimate_template_item_id_foreign` (`estimate_template_item_id`),
  CONSTRAINT `estimate_template_item_images_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimate_template_item_images_estimate_template_item_id_foreign` FOREIGN KEY (`estimate_template_item_id`) REFERENCES `estimate_template_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate_template_item_images`
--

LOCK TABLES `estimate_template_item_images` WRITE;
/*!40000 ALTER TABLE `estimate_template_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimate_template_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimate_template_items`
--

DROP TABLE IF EXISTS `estimate_template_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estimate_template_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `estimate_template_id` bigint(20) unsigned NOT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `item_name` varchar(191) NOT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `quantity` tinyint(4) NOT NULL,
  `unit_price` double NOT NULL,
  `amount` double NOT NULL,
  `item_summary` text DEFAULT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estimate_template_items_company_id_foreign` (`company_id`),
  KEY `estimate_template_items_estimate_template_id_foreign` (`estimate_template_id`),
  KEY `estimate_template_items_unit_id_foreign` (`unit_id`),
  KEY `estimate_template_items_product_id_foreign` (`product_id`),
  CONSTRAINT `estimate_template_items_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimate_template_items_estimate_template_id_foreign` FOREIGN KEY (`estimate_template_id`) REFERENCES `estimate_templates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimate_template_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `estimate_template_items_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate_template_items`
--

LOCK TABLES `estimate_template_items` WRITE;
/*!40000 ALTER TABLE `estimate_template_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimate_template_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimate_templates`
--

DROP TABLE IF EXISTS `estimate_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estimate_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `sub_total` double NOT NULL,
  `total` double NOT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `discount_type` enum('percent','fixed') NOT NULL,
  `discount` double NOT NULL,
  `invoice_convert` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('declined','accepted','waiting') NOT NULL DEFAULT 'waiting',
  `note` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `calculate_tax` enum('after_discount','before_discount') NOT NULL DEFAULT 'after_discount',
  `client_comment` text DEFAULT NULL,
  `signature_approval` tinyint(1) NOT NULL DEFAULT 1,
  `hash` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `estimate_templates_company_id_foreign` (`company_id`),
  KEY `estimate_templates_currency_id_foreign` (`currency_id`),
  KEY `estimate_templates_added_by_foreign` (`added_by`),
  KEY `estimate_templates_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `estimate_templates_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `estimate_templates_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimate_templates_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimate_templates_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimate_templates`
--

LOCK TABLES `estimate_templates` WRITE;
/*!40000 ALTER TABLE `estimate_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimate_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimates`
--

DROP TABLE IF EXISTS `estimates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estimates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `estimate_number` bigint(20) DEFAULT NULL,
  `valid_till` date NOT NULL,
  `sub_total` double(16,2) NOT NULL,
  `discount` double NOT NULL DEFAULT 0,
  `discount_type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `total` double(16,2) NOT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `status` enum('declined','accepted','waiting','sent','draft','canceled') NOT NULL DEFAULT 'waiting',
  `note` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `send_status` tinyint(1) NOT NULL DEFAULT 1,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `hash` text DEFAULT NULL,
  `calculate_tax` enum('after_discount','before_discount') NOT NULL DEFAULT 'after_discount',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_viewed` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estimates_estimate_number_company_id_unique` (`estimate_number`,`company_id`),
  KEY `estimates_company_id_foreign` (`company_id`),
  KEY `estimates_client_id_foreign` (`client_id`),
  KEY `estimates_currency_id_foreign` (`currency_id`),
  KEY `estimates_added_by_foreign` (`added_by`),
  KEY `estimates_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `estimates_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `estimates_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimates_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimates_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `estimates_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimates`
--

LOCK TABLES `estimates` WRITE;
/*!40000 ALTER TABLE `estimates` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_attendees`
--

DROP TABLE IF EXISTS `event_attendees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_attendees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `event_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_attendees_company_id_foreign` (`company_id`),
  KEY `event_attendees_user_id_foreign` (`user_id`),
  KEY `event_attendees_event_id_foreign` (`event_id`),
  CONSTRAINT `event_attendees_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `event_attendees_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `event_attendees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_attendees`
--

LOCK TABLES `event_attendees` WRITE;
/*!40000 ALTER TABLE `event_attendees` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_attendees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_files`
--

DROP TABLE IF EXISTS `event_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `event_id` int(10) unsigned NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `hashname` varchar(200) DEFAULT NULL,
  `size` varchar(200) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_files_company_id_foreign` (`company_id`),
  KEY `event_files_event_id_foreign` (`event_id`),
  KEY `event_files_added_by_foreign` (`added_by`),
  KEY `event_files_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `event_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `event_files_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `event_files_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `event_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_files`
--

LOCK TABLES `event_files` WRITE;
/*!40000 ALTER TABLE `event_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `event_name` varchar(191) NOT NULL,
  `label_color` varchar(191) NOT NULL,
  `where` varchar(191) NOT NULL,
  `description` mediumtext NOT NULL,
  `start_date_time` datetime NOT NULL,
  `end_date_time` datetime NOT NULL,
  `repeat` enum('yes','no') NOT NULL DEFAULT 'no',
  `repeat_every` int(11) DEFAULT NULL,
  `repeat_cycles` int(11) DEFAULT NULL,
  `repeat_type` enum('day','week','month','year') NOT NULL DEFAULT 'day',
  `send_reminder` enum('yes','no') NOT NULL DEFAULT 'no',
  `remind_time` int(11) DEFAULT NULL,
  `remind_type` enum('day','hour','minute') NOT NULL DEFAULT 'day',
  `event_link` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `event_id` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `events_company_id_foreign` (`company_id`),
  KEY `events_added_by_foreign` (`added_by`),
  KEY `events_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `events_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `events_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `events_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `item_name` varchar(191) NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_from` varchar(191) DEFAULT NULL,
  `price` double(16,2) NOT NULL,
  `currency_id` int(10) unsigned NOT NULL,
  `default_currency_id` int(10) unsigned DEFAULT NULL,
  `exchange_rate` double DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `bill` varchar(191) DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `can_claim` tinyint(1) NOT NULL DEFAULT 1,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `expenses_recurring_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `approver_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bank_account_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_company_id_foreign` (`company_id`),
  KEY `expenses_currency_id_foreign` (`currency_id`),
  KEY `expenses_user_id_foreign` (`user_id`),
  KEY `expenses_category_id_foreign` (`category_id`),
  KEY `expenses_expenses_recurring_id_foreign` (`expenses_recurring_id`),
  KEY `expenses_created_by_foreign` (`created_by`),
  KEY `expenses_added_by_foreign` (`added_by`),
  KEY `expenses_last_updated_by_foreign` (`last_updated_by`),
  KEY `expenses_approver_id_foreign` (`approver_id`),
  KEY `expenses_bank_account_id_foreign` (`bank_account_id`),
  KEY `expenses_default_currency_id_foreign` (`default_currency_id`),
  CONSTRAINT `expenses_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `expenses_approver_id_foreign` FOREIGN KEY (`approver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_bank_account_id_foreign` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `expenses_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `expenses_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `expenses_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_default_currency_id_foreign` FOREIGN KEY (`default_currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_expenses_recurring_id_foreign` FOREIGN KEY (`expenses_recurring_id`) REFERENCES `expenses_recurring` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `expenses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_category`
--

DROP TABLE IF EXISTS `expenses_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_name` varchar(191) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_category_company_id_foreign` (`company_id`),
  KEY `expenses_category_added_by_foreign` (`added_by`),
  KEY `expenses_category_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `expenses_category_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `expenses_category_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_category_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_category`
--

LOCK TABLES `expenses_category` WRITE;
/*!40000 ALTER TABLE `expenses_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_category_roles`
--

DROP TABLE IF EXISTS `expenses_category_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses_category_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `expenses_category_id` bigint(20) unsigned DEFAULT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_category_roles_company_id_foreign` (`company_id`),
  KEY `expenses_category_roles_expenses_category_id_foreign` (`expenses_category_id`),
  KEY `expenses_category_roles_role_id_foreign` (`role_id`),
  CONSTRAINT `expenses_category_roles_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_category_roles_expenses_category_id_foreign` FOREIGN KEY (`expenses_category_id`) REFERENCES `expenses_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_category_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_category_roles`
--

LOCK TABLES `expenses_category_roles` WRITE;
/*!40000 ALTER TABLE `expenses_category_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_category_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_recurring`
--

DROP TABLE IF EXISTS `expenses_recurring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses_recurring` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `item_name` varchar(191) NOT NULL,
  `day_of_month` int(11) DEFAULT 1,
  `day_of_week` int(11) DEFAULT 1,
  `payment_method` varchar(191) DEFAULT NULL,
  `rotation` enum('monthly','weekly','bi-weekly','quarterly','half-yearly','annually','daily') NOT NULL,
  `billing_cycle` int(11) DEFAULT NULL,
  `issue_date` date NOT NULL,
  `next_expense_date` date DEFAULT NULL,
  `unlimited_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `price` double NOT NULL,
  `bill` varchar(191) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `description` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `purchase_from` varchar(191) DEFAULT NULL,
  `immediate_expense` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bank_account_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_recurring_company_id_foreign` (`company_id`),
  KEY `expenses_recurring_category_id_foreign` (`category_id`),
  KEY `expenses_recurring_currency_id_foreign` (`currency_id`),
  KEY `expenses_recurring_project_id_foreign` (`project_id`),
  KEY `expenses_recurring_user_id_foreign` (`user_id`),
  KEY `expenses_recurring_created_by_foreign` (`created_by`),
  KEY `expenses_recurring_added_by_foreign` (`added_by`),
  KEY `expenses_recurring_last_updated_by_foreign` (`last_updated_by`),
  KEY `expenses_recurring_bank_account_id_foreign` (`bank_account_id`),
  CONSTRAINT `expenses_recurring_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_bank_account_id_foreign` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `expenses_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `expenses_recurring_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_recurring`
--

LOCK TABLES `expenses_recurring` WRITE;
/*!40000 ALTER TABLE `expenses_recurring` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_recurring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_categories`
--

DROP TABLE IF EXISTS `faq_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_categories`
--

LOCK TABLES `faq_categories` WRITE;
/*!40000 ALTER TABLE `faq_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faq_files`
--

DROP TABLE IF EXISTS `faq_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faq_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `faq_id` bigint(20) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faq_files_user_id_foreign` (`user_id`),
  KEY `faq_files_faq_id_foreign` (`faq_id`),
  CONSTRAINT `faq_files_faq_id_foreign` FOREIGN KEY (`faq_id`) REFERENCES `faqs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `faq_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faq_files`
--

LOCK TABLES `faq_files` WRITE;
/*!40000 ALTER TABLE `faq_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `faq_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(191) DEFAULT NULL,
  `faq_category_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faqs_faq_category_id_foreign` (`faq_category_id`),
  CONSTRAINT `faqs_faq_category_id_foreign` FOREIGN KEY (`faq_category_id`) REFERENCES `faq_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `description` longtext DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `icon` varchar(200) DEFAULT NULL,
  `type` enum('image','icon','task','bills','team','apps') NOT NULL DEFAULT 'image',
  `front_feature_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `features_language_setting_id_foreign` (`language_setting_id`),
  KEY `features_front_feature_id_foreign` (`front_feature_id`),
  CONSTRAINT `features_front_feature_id_foreign` FOREIGN KEY (`front_feature_id`) REFERENCES `front_features` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `features_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features`
--

LOCK TABLES `features` WRITE;
/*!40000 ALTER TABLE `features` DISABLE KEYS */;
INSERT INTO `features` VALUES (1,1,'Meet Your Business Needs','<p>Manage your projects and your talent in a single system, resulting in empowered teams, satisfied clients, and increased profitability.</p><ul class=\"list1 border-top pt-5 mt-5\">\n                            <li class=\"mb-3\">\n                                Keep a track of all your projects in most simple way.\n                            </li>\n                            <li class=\"mb-3\">\n                                Assign tasks to project members and track the status.\n                            </li>\n                            <li class=\"mb-3\">\n                                Add members to your projects and keep them in sync  with the progress.\n                            </li>\n                        </ul>',NULL,NULL,'image',NULL,NULL,NULL),(2,1,'Analyse Your Workflow','<p>Reports section to analyse what\'s working and what\'s not for your business</p><ul class=\"list1 border-top pt-5 mt-5\">\n                            <li class=\"mb-3\">\n                                It Shows how much you earned and how much you spent.\n                            </li>\n                            <li class=\"mb-3\">\n                                Ticket report shows you Open vs Closed tickets.\n                            </li>\n                            <li class=\"mb-3\">\n                                It creates task report to track completed vs pending tasks.\n                            </li>\n                        </ul>',NULL,NULL,'image',NULL,NULL,NULL),(3,1,'Manage your support tickets efficiently','<p>Whether someone\'s internet is not working, someone is facing issue with housekeeping or need something regarding their work they can raise a ticket for all their problems.</p><ul class=\"list1 border-top pt-5 mt-5\"><li class=\"mb-3\">Admin can assign the tickets to respective department agents.</li></ul>',NULL,NULL,'image',NULL,NULL,NULL),(4,1,'Responsive','Your website works on any device: desktop, tablet or mobile.',NULL,'fas fa-desktop','icon',NULL,NULL,NULL),(5,1,'Customizable','You can easily read, edit, and write your own code, or change everything.',NULL,'fas fa-wrench','icon',NULL,NULL,NULL),(6,1,'UI Elements','There is a bunch of useful and necessary elements for developing your website.',NULL,'fas fa-cubes','icon',NULL,NULL,NULL),(7,1,'Clean Code','You can find our code well organized, commented and readable.',NULL,'fas fa-code','icon',NULL,NULL,NULL),(8,1,'Documented','As you can see in the source code, we provided a comprehensive documentation.',NULL,'far fa-file-alt','icon',NULL,NULL,NULL),(9,1,'Free Updates','When you purchase this template, you\'ll freely receive future updates.',NULL,'fas fa-download','icon',NULL,NULL,NULL),(10,1,'Track Projects','Keep a track of all your projects in the most simple way.',NULL,'fas fa-desktop','task',1,NULL,'2023-08-10 14:06:56'),(11,1,'Add Members','Add members to your projects and keep them in sync with the progress.',NULL,'fas fa-users','task',1,NULL,'2023-08-10 14:06:56'),(12,1,'Assign Tasks','Your website is fully responsive, it will work on any device, desktop, tablet and mobile.',NULL,'fas fa-list','task',1,NULL,'2023-08-10 14:06:56'),(13,1,'Estimates','Create estimates how much project can cost and send to your clients.',NULL,'fas fa-calculator','bills',2,NULL,'2023-08-10 14:06:56'),(14,1,'Invoices','Simple and professional invoices can be download in form of PDF.',NULL,'far fa-file-alt','bills',2,NULL,'2023-08-10 14:06:56'),(15,1,'Payments','Track payments done by clients in the payment section.',NULL,'fas fa-money-bill-alt','bills',2,NULL,'2023-08-10 14:06:56'),(16,1,'Tickets','When someone is facing a problem, they can raise a ticket for their problems. Admin can assign the tickets to respective department agents.',NULL,'fas fa-ticket-alt','team',3,NULL,'2023-08-10 14:06:56'),(17,1,'Leaves','Employees can apply for the multiple leaves from their panel. Admin can approve or reject the leave applications.',NULL,'fas fa-ban','team',3,NULL,'2023-08-10 14:06:56'),(18,1,'Attendance','Attendance module allows employees to clock-in and clock-out, right from their dashboard. Admin can track the attendance of the team.',NULL,'far fa-check-circle','team',3,NULL,'2023-08-10 14:06:56'),(19,1,'OneSignal',NULL,NULL,NULL,'apps',NULL,NULL,NULL),(20,1,'Slack',NULL,NULL,NULL,'apps',NULL,NULL,NULL),(21,1,'Paypal',NULL,NULL,NULL,'apps',NULL,NULL,NULL),(22,1,'Pusher',NULL,NULL,NULL,'apps',NULL,NULL,NULL);
/*!40000 ALTER TABLE `features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_storage`
--

DROP TABLE IF EXISTS `file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_storage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `path` varchar(191) NOT NULL,
  `filename` varchar(191) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `size` int(10) unsigned NOT NULL,
  `storage_location` enum('local','aws_s3','digitalocean','wasabi','minio') NOT NULL DEFAULT 'local',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `file_storage_company_id_foreign` (`company_id`),
  CONSTRAINT `file_storage_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_storage`
--

LOCK TABLES `file_storage` WRITE;
/*!40000 ALTER TABLE `file_storage` DISABLE KEYS */;
INSERT INTO `file_storage` VALUES (1,3,'offline-invoice','6cf9b1f9953589f509f7a0de63cbd98c.jpg','image/jpeg',123112,'local','2023-08-10 14:20:41','2023-08-10 14:20:41'),(3,NULL,'app-logo','c4c223b585dacd43afab387ebcbce3ed.png','image/png',40112,'local','2023-08-21 15:53:32','2023-08-21 15:53:32'),(7,NULL,'favicon','e8760d3da65f7d0949f92fcb457d3c16.png','image/png',40112,'local','2023-08-21 16:02:33','2023-08-21 16:02:33'),(10,NULL,'front','b90b2941691945f890f54a2a8f26fd39.png','image/png',206404,'local','2023-08-21 16:28:22','2023-08-21 16:28:22'),(11,7,'avatar','f54d48ceec53e1b193ebbfc9a11d2762.png','image/png',9582,'local','2023-08-21 16:31:15','2023-08-21 16:31:15'),(12,7,'avatar','7ee9b0c5991cc52eff6852d8786cd762.png','image/png',65688,'local','2024-07-14 15:50:34','2024-07-14 15:50:34'),(13,7,'app-logo','78fbe3c0e77329159173af3e6a85b7de.png','image/png',65707,'local','2024-07-14 15:51:26','2024-07-14 15:51:26'),(14,7,'app-logo','7776e48b6a836ca0996730d0128968f3.png','image/png',65786,'local','2024-07-14 15:51:26','2024-07-14 15:51:26'),(15,7,'favicon','c3fbe58d5e57463ce64457a4131eeefb.png','image/png',64992,'local','2024-07-14 15:51:26','2024-07-14 15:51:26'),(16,NULL,'avatar','9711e2cc75c294f7767daca325d6e670.png','image/png',65738,'local','2024-07-14 15:56:22','2024-07-14 15:56:22'),(17,NULL,'app-logo','0f8a3c66c4ad116ba7ff06cc4d4b0d1f.png','image/png',65655,'local','2024-07-14 16:10:57','2024-07-14 16:10:57'),(18,NULL,'app-logo','148257eb60a390014eefb6369b1ef5a8.png','image/png',65731,'local','2024-07-14 16:10:57','2024-07-14 16:10:57'),(19,NULL,'app-logo','a4ef9bcd70d507df032d414730fb414d.png','image/png',65582,'local','2024-07-14 16:10:57','2024-07-14 16:10:57'),(20,NULL,'favicon','98f27c3f7a4584d1d4179124cfcca72f.png','image/png',64992,'local','2024-07-14 16:10:57','2024-07-14 16:10:57');
/*!40000 ALTER TABLE `file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_storage_settings`
--

DROP TABLE IF EXISTS `file_storage_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_storage_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filesystem` varchar(191) NOT NULL,
  `auth_keys` text DEFAULT NULL,
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'disabled',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_storage_settings`
--

LOCK TABLES `file_storage_settings` WRITE;
/*!40000 ALTER TABLE `file_storage_settings` DISABLE KEYS */;
INSERT INTO `file_storage_settings` VALUES (1,'local',NULL,'enabled','2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `file_storage_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flags`
--

DROP TABLE IF EXISTS `flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `capital` varchar(191) DEFAULT NULL,
  `code` varchar(191) DEFAULT NULL,
  `continent` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flags`
--

LOCK TABLES `flags` WRITE;
/*!40000 ALTER TABLE `flags` DISABLE KEYS */;
INSERT INTO `flags` VALUES (1,'Kabul','af','Asia','Afghanistan'),(2,'Mariehamn','ax','Europe','Aland Islands'),(3,'Tirana','al','Europe','Albania'),(4,'Algiers','dz','Africa','Algeria'),(5,'Pago Pago','as','Oceania','American Samoa'),(6,'Andorra la Vella','ad','Europe','Andorra'),(7,'Luanda','ao','Africa','Angola'),(8,'The Valley','ai','North America','Anguilla'),(9,'','aq','','Antarctica'),(10,'St. John\'s','ag','North America','Antigua and Barbuda'),(11,'Buenos Aires','ar','South America','Argentina'),(12,'Yerevan','am','Asia','Armenia'),(13,'Oranjestad','aw','South America','Aruba'),(14,'Georgetown','ac','Africa','Ascension Island'),(15,'Canberra','au','Oceania','Australia'),(16,'Vienna','at','Europe','Austria'),(17,'Baku','az','Asia','Azerbaijan'),(18,'Nassau','bs','North America','Bahamas'),(19,'Manama','bh','Asia','Bahrain'),(20,'Dhaka','bd','Asia','Bangladesh'),(21,'Bridgetown','bb','North America','Barbados'),(22,'Minsk','by','Europe','Belarus'),(23,'Brussels','be','Europe','Belgium'),(24,'Belmopan','bz','North America','Belize'),(25,'Porto-Novo','bj','Africa','Benin'),(26,'Hamilton','bm','North America','Bermuda'),(27,'Thimphu','bt','Asia','Bhutan'),(28,'Sucre','bo','South America','Bolivia'),(29,'Kralendijk','bq','South America','Bonaire, Sint Eustatius and Saba'),(30,'Sarajevo','ba','Europe','Bosnia and Herzegovina'),(31,'Gaborone','bw','Africa','Botswana'),(32,'','bv','','Bouvet Island'),(33,'Brasília','br','South America','Brazil'),(34,'Diego Garcia','io','Asia','British Indian Ocean Territory'),(35,'Bandar Seri Begawan','bn','Asia','Brunei Darussalam'),(36,'Sofia','bg','Europe','Bulgaria'),(37,'Ouagadougou','bf','Africa','Burkina Faso'),(38,'Bujumbura','bi','Africa','Burundi'),(39,'Praia','cv','Africa','Cabo Verde'),(40,'Phnom Penh','kh','Asia','Cambodia'),(41,'Yaoundé','cm','Africa','Cameroon'),(42,'Ottawa','ca','North America','Canada'),(43,'','ic','','Canary Islands'),(44,'','es-ct','','Catalonia'),(45,'George Town','ky','North America','Cayman Islands'),(46,'Bangui','cf','Africa','Central African Republic'),(47,'','cefta','','Central European Free Trade Agreement'),(48,'','ea','','Ceuta & Melilla'),(49,'N\'Djamena','td','Africa','Chad'),(50,'Santiago','cl','South America','Chile'),(51,'Beijing','cn','Asia','China'),(52,'Flying Fish Cove','cx','Asia','Christmas Island'),(53,'','cp','','Clipperton Island'),(54,'West Island','cc','Asia','Cocos (Keeling) Islands'),(55,'Bogotá','co','South America','Colombia'),(56,'Moroni','km','Africa','Comoros'),(57,'Avarua','ck','Oceania','Cook Islands'),(58,'San José','cr','North America','Costa Rica'),(59,'Zagreb','hr','Europe','Croatia'),(60,'Havana','cu','North America','Cuba'),(61,'Willemstad','cw','South America','Curaçao'),(62,'Nicosia','cy','Europe','Cyprus'),(63,'Prague','cz','Europe','Czech Republic'),(64,'Yamoussoukro','ci','Africa','Côte d\'Ivoire'),(65,'Kinshasa','cd','Africa','Democratic Republic of the Congo'),(66,'Copenhagen','dk','Europe','Denmark'),(67,'','dg','','Diego Garcia'),(68,'Djibouti','dj','Africa','Djibouti'),(69,'Roseau','dm','North America','Dominica'),(70,'Santo Domingo','do','North America','Dominican Republic'),(71,'Quito','ec','South America','Ecuador'),(72,'Cairo','eg','Africa','Egypt'),(73,'San Salvador','sv','North America','El Salvador'),(74,'London','gb-eng','Europe','England'),(75,'Malabo','gq','Africa','Equatorial Guinea'),(76,'Asmara','er','Africa','Eritrea'),(77,'Tallinn','ee','Europe','Estonia'),(78,'Lobamba, Mbabane','sz','Africa','Eswatini'),(79,'Addis Ababa','et','Africa','Ethiopia'),(80,'','eu','','Europe'),(81,'Stanley','fk','South America','Falkland Islands'),(82,'Tórshavn','fo','Europe','Faroe Islands'),(83,'Palikir','fm','Oceania','Federated States of Micronesia'),(84,'Suva','fj','Oceania','Fiji'),(85,'Helsinki','fi','Europe','Finland'),(86,'Paris','fr','Europe','France'),(87,'Cayenne','gf','South America','French Guiana'),(88,'Papeete','pf','Oceania','French Polynesia'),(89,'Saint-Pierre, Réunion','tf','Africa','French Southern Territories'),(90,'Libreville','ga','Africa','Gabon'),(91,'','es-ga','','Galicia'),(92,'Banjul','gm','Africa','Gambia'),(93,'Tbilisi','ge','Asia','Georgia'),(94,'Berlin','de','Europe','Germany'),(95,'Accra','gh','Africa','Ghana'),(96,'Gibraltar','gi','Europe','Gibraltar'),(97,'Athens','gr','Europe','Greece'),(98,'Nuuk','gl','North America','Greenland'),(99,'St. George\'s','gd','North America','Grenada'),(100,'Basse-Terre','gp','North America','Guadeloupe'),(101,'Hagåtña','gu','Oceania','Guam'),(102,'Guatemala City','gt','North America','Guatemala'),(103,'Saint Peter Port','gg','Europe','Guernsey'),(104,'Conakry','gn','Africa','Guinea'),(105,'Bissau','gw','Africa','Guinea-Bissau'),(106,'Georgetown','gy','South America','Guyana'),(107,'Port-au-Prince','ht','North America','Haiti'),(108,'','hm','','Heard Island and McDonald Islands'),(109,'Vatican City','va','Europe','Holy See'),(110,'Tegucigalpa','hn','North America','Honduras'),(111,'Hong Kong','hk','Asia','Hong Kong'),(112,'Budapest','hu','Europe','Hungary'),(113,'Reykjavik','is','Europe','Iceland'),(114,'New Delhi','in','Asia','India'),(115,'Jakarta','id','Asia','Indonesia'),(116,'Tehran','ir','Asia','Iran'),(117,'Baghdad','iq','Asia','Iraq'),(118,'Dublin','ie','Europe','Ireland'),(119,'Douglas','im','Europe','Isle of Man'),(120,'Jerusalem','il','Asia','Israel'),(121,'Rome','it','Europe','Italy'),(122,'Kingston','jm','North America','Jamaica'),(123,'Tokyo','jp','Asia','Japan'),(124,'Saint Helier','je','Europe','Jersey'),(125,'Amman','jo','Asia','Jordan'),(126,'Astana','kz','Asia','Kazakhstan'),(127,'Nairobi','ke','Africa','Kenya'),(128,'South Tarawa','ki','Oceania','Kiribati'),(129,'Pristina','xk','Europe','Kosovo'),(130,'Kuwait City','kw','Asia','Kuwait'),(131,'Bishkek','kg','Asia','Kyrgyzstan'),(132,'Vientiane','la','Asia','Laos'),(133,'Riga','lv','Europe','Latvia'),(134,'Beirut','lb','Asia','Lebanon'),(135,'Maseru','ls','Africa','Lesotho'),(136,'Monrovia','lr','Africa','Liberia'),(137,'Tripoli','ly','Africa','Libya'),(138,'Vaduz','li','Europe','Liechtenstein'),(139,'Vilnius','lt','Europe','Lithuania'),(140,'Luxembourg City','lu','Europe','Luxembourg'),(141,'Macau','mo','Asia','Macau'),(142,'Antananarivo','mg','Africa','Madagascar'),(143,'Lilongwe','mw','Africa','Malawi'),(144,'Kuala Lumpur','my','Asia','Malaysia'),(145,'Malé','mv','Asia','Maldives'),(146,'Bamako','ml','Africa','Mali'),(147,'Valletta','mt','Europe','Malta'),(148,'Majuro','mh','Oceania','Marshall Islands'),(149,'Fort-de-France','mq','North America','Martinique'),(150,'Nouakchott','mr','Africa','Mauritania'),(151,'Port Louis','mu','Africa','Mauritius'),(152,'Mamoudzou','yt','Africa','Mayotte'),(153,'Mexico City','mx','North America','Mexico'),(154,'Chișinău','md','Europe','Moldova'),(155,'Monaco','mc','Europe','Monaco'),(156,'Ulaanbaatar','mn','Asia','Mongolia'),(157,'Podgorica','me','Europe','Montenegro'),(158,'Little Bay, Brades, Plymouth','ms','North America','Montserrat'),(159,'Rabat','ma','Africa','Morocco'),(160,'Maputo','mz','Africa','Mozambique'),(161,'Naypyidaw','mm','Asia','Myanmar'),(162,'Windhoek','na','Africa','Namibia'),(163,'Yaren District','nr','Oceania','Nauru'),(164,'Kathmandu','np','Asia','Nepal'),(165,'Amsterdam','nl','Europe','Netherlands'),(166,'Nouméa','nc','Oceania','New Caledonia'),(167,'Wellington','nz','Oceania','New Zealand'),(168,'Managua','ni','North America','Nicaragua'),(169,'Niamey','ne','Africa','Niger'),(170,'Abuja','ng','Africa','Nigeria'),(171,'Alofi','nu','Oceania','Niue'),(172,'Kingston','nf','Oceania','Norfolk Island'),(173,'Pyongyang','kp','Asia','North Korea'),(174,'Skopje','mk','Europe','North Macedonia'),(175,'Belfast','gb-nir','Europe','Northern Ireland'),(176,'Saipan','mp','Oceania','Northern Mariana Islands'),(177,'Oslo','no','Europe','Norway'),(178,'Muscat','om','Asia','Oman'),(179,'Islamabad','pk','Asia','Pakistan'),(180,'Ngerulmud','pw','Oceania','Palau'),(181,'Panama City','pa','North America','Panama'),(182,'Port Moresby','pg','Oceania','Papua New Guinea'),(183,'Asunción','py','South America','Paraguay'),(184,'Lima','pe','South America','Peru'),(185,'Manila','ph','Asia','Philippines'),(186,'Adamstown','pn','Oceania','Pitcairn'),(187,'Warsaw','pl','Europe','Poland'),(188,'Lisbon','pt','Europe','Portugal'),(189,'San Juan','pr','North America','Puerto Rico'),(190,'Doha','qa','Asia','Qatar'),(191,'Brazzaville','cg','Africa','Republic of the Congo'),(192,'Bucharest','ro','Europe','Romania'),(193,'Moscow','ru','Europe','Russia'),(194,'Kigali','rw','Africa','Rwanda'),(195,'Saint-Denis','re','Africa','Réunion'),(196,'Gustavia','bl','North America','Saint Barthélemy'),(197,'Jamestown','sh','Africa','Saint Helena, Ascension and Tristan da Cunha'),(198,'Basseterre','kn','North America','Saint Kitts and Nevis'),(199,'Castries','lc','North America','Saint Lucia'),(200,'Marigot','mf','North America','Saint Martin'),(201,'Saint-Pierre','pm','North America','Saint Pierre and Miquelon'),(202,'Kingstown','vc','North America','Saint Vincent and the Grenadines'),(203,'Apia','ws','Oceania','Samoa'),(204,'San Marino','sm','Europe','San Marino'),(205,'São Tomé','st','Africa','Sao Tome and Principe'),(206,'Riyadh','sa','Asia','Saudi Arabia'),(207,'Edinburgh','gb-sct','Europe','Scotland'),(208,'Dakar','sn','Africa','Senegal'),(209,'Belgrade','rs','Europe','Serbia'),(210,'Victoria','sc','Africa','Seychelles'),(211,'Freetown','sl','Africa','Sierra Leone'),(212,'Singapore','sg','Asia','Singapore'),(213,'Philipsburg','sx','North America','Sint Maarten'),(214,'Bratislava','sk','Europe','Slovakia'),(215,'Ljubljana','si','Europe','Slovenia'),(216,'Honiara','sb','Oceania','Solomon Islands'),(217,'Mogadishu','so','Africa','Somalia'),(218,'Pretoria','za','Africa','South Africa'),(219,'King Edward Point','gs','Antarctica','South Georgia and the South Sandwich Islands'),(220,'Seoul','kr','Asia','South Korea'),(221,'Juba','ss','Africa','South Sudan'),(222,'Madrid','es','Europe','Spain'),(223,'Sri Jayawardenepura Kotte, Colombo','lk','Asia','Sri Lanka'),(224,'Ramallah','ps','Asia','State of Palestine'),(225,'Khartoum','sd','Africa','Sudan'),(226,'Paramaribo','sr','South America','Suriname'),(227,'Longyearbyen','sj','Europe','Svalbard and Jan Mayen'),(228,'Stockholm','se','Europe','Sweden'),(229,'Bern','ch','Europe','Switzerland'),(230,'Damascus','sy','Asia','Syria'),(231,'Taipei','tw','Asia','Taiwan'),(232,'Dushanbe','tj','Asia','Tajikistan'),(233,'Dodoma','tz','Africa','Tanzania'),(234,'Bangkok','th','Asia','Thailand'),(235,'Dili','tl','Asia','Timor-Leste'),(236,'Lomé','tg','Africa','Togo'),(237,'Nukunonu, Atafu,Tokelau','tk','Oceania','Tokelau'),(238,'Nukuʻalofa','to','Oceania','Tonga'),(239,'Port of Spain','tt','South America','Trinidad and Tobago'),(240,'','ta','','Tristan da Cunha'),(241,'Tunis','tn','Africa','Tunisia'),(242,'Ankara','tr','Asia','Turkey'),(243,'Ashgabat','tm','Asia','Turkmenistan'),(244,'Cockburn Town','tc','North America','Turks and Caicos Islands'),(245,'Funafuti','tv','Oceania','Tuvalu'),(246,'Kampala','ug','Africa','Uganda'),(247,'Kiev','ua','Europe','Ukraine'),(248,'Abu Dhabi','ae','Asia','United Arab Emirates'),(249,'London','gb','Europe','United Kingdom'),(250,'','un','','United Nations'),(251,'Washington, D.C.','um','North America','United States Minor Outlying Islands'),(252,'Washington, D.C.','us','North America','United States of America'),(253,'','xx','','Unknown'),(254,'Montevideo','uy','South America','Uruguay'),(255,'Tashkent','uz','Asia','Uzbekistan'),(256,'Port Vila','vu','Oceania','Vanuatu'),(257,'Caracas','ve','South America','Venezuela'),(258,'Hanoi','vn','Asia','Vietnam'),(259,'Road Town','vg','North America','Virgin Islands (British)'),(260,'Charlotte Amalie','vi','North America','Virgin Islands (U.S.)'),(261,'Cardiff','gb-wls','Europe','Wales'),(262,'Mata-Utu','wf','Oceania','Wallis and Futuna'),(263,'Laayoune','eh','Africa','Western Sahara'),(264,'Sana\'a','ye','Asia','Yemen'),(265,'Lusaka','zm','Africa','Zambia'),(266,'Harare','zw','Africa','Zimbabwe');
/*!40000 ALTER TABLE `flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `footer_menu`
--

DROP TABLE IF EXISTS `footer_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `footer_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` longtext DEFAULT NULL,
  `video_link` varchar(191) DEFAULT NULL,
  `video_embed` text DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `hash_name` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `type` enum('header','footer','both') DEFAULT 'footer',
  `status` enum('active','inactive') DEFAULT 'active',
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `private` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `footer_menu_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `footer_menu_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `footer_menu`
--

LOCK TABLES `footer_menu` WRITE;
/*!40000 ALTER TABLE `footer_menu` DISABLE KEYS */;
INSERT INTO `footer_menu` VALUES (1,'Terms of use','terms-of-use','<div><b><span style=\"font-size: 14px;\"><span style=\"font-size: 14px;\">TERMS OF USE FOR WORKSUITE.BIZ</span></span></b></div><div><br></div><div>The use of any product, service or feature (the \"Materials\") available through the internet web sites accessible at Worksuite.com (the \"Web Site\") by any user of the Web Site (\"You\" or \"Your\" hereafter) shall be governed by the following terms of use:</div><div>This Web Site is provided by Worksuite, a partnership awaiting registration with Government of India, and shall be used for informational purposes only. By using the Web Site or downloading Materials from the Web Site, You hereby agree to abide by the terms and conditions set forth in this Terms of Use. In the event of You not agreeing to these terms and conditions, You are requested by Worksuite not to use the Web Site or download Materials from the Web Site. This Web Site, including all Materials present (excluding any applicable third party materials), is the property of Worksuite and is copyrighted and protected by worldwide copyright laws and treaty provisions. You hereby agree to comply with all copyright laws worldwide in Your use of this Web Site and to prevent any unauthorized copying of the Materials. Worksuite does not grant any express or implied rights under any patents, trademarks, copyrights or trade secret information.</div><div>Worksuite has business relationships with many customers, suppliers, governments, and others. For convenience and simplicity, words like joint venture, partnership, and partner are used to indicate business relationships involving common activities and interests, and those words may not indicate precise legal relationships.</div><div><br></div><div><b><span style=\"font-size: 14px;\">LIMITED LICENSE:</span></b></div><div><br></div><div>Subject to the terms and conditions set forth in these Terms of Use, Worksuite grants You a non-exclusive, non-transferable, limited right to access, use and display this Web Site and the Materials thereon. You agree not to interrupt or attempt to interrupt the operation of the Web Site in any manner. Unless otherwise specified, the Web Site is for Your personal and non-commercial use. You shall not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, create derivative works from, transfer, or sell any information, software, products or services obtained from this Web Site.</div><div><br></div><div><b><span style=\"font-size: 14px;\">THIRD PARTY CONTENT</span></b></div><div>The Web Site makes information of third parties available, including articles, analyst reports, news reports, and company information, including any regulatory authority, content licensed under Content Licensed under Creative Commons Attribution License, and other data from external sources (the \"Third Party Content\"). You acknowledge and agree that the Third Party Content is not created or endorsed by Worksuite. The provision of Third Party Content is for general informational purposes only and does not constitute a recommendation or solicitation to purchase or sell any securities or shares or to make any other type of investment or investment decision. In addition, the Third Party Content is not intended to provide tax, legal or investment advice. You acknowledge that the Third Party Content provided to You is obtained from sources believed to be reliable, but that no guarantees are made by Worksuite or the providers of the Third Party Content as to its accuracy, completeness, timeliness. You agree not to hold Worksuite, any business offering products or services through the Web Site or any provider of Third Party Content liable for any investment decision or other transaction You may make based on Your reliance on or use of such data, or any liability that may arise due to delays or interruptions in the delivery of the Third Party Content for any reason</div><div>By using any Third Party Content, You may leave this Web Site and be directed to an external website, or to a website maintained by an entity other than Worksuite. If You decide to visit any such site, You do so at Your own risk and it is Your responsibility to take all protective measures to guard against viruses or any other destructive elements. Worksuite makes no warranty or representation regarding and does not endorse, any linked web sites or the information appearing thereon or any of the products or services described thereon. Links do not imply that Worksuite or this Web Site sponsors, endorses, is affiliated or associated with, or is legally authorized to use any trademark, trade name, logo or copyright symbol displayed in or accessible through the links, or that any linked site is authorized to use any trademark, trade name, logo or copyright symbol of Worksuite or any of its affiliates or subsidiaries. You hereby expressly acknowledge and agree that the linked sites are not under the control of Worksuite and Worksuite is not responsible for the contents of any linked site or any link contained in a linked site, or any changes or updates to such sites. Worksuite is not responsible for webcasting or any other form of transmission received from any linked site. Worksuite is providing these links to You only as a convenience, and the inclusion of any link shall not be construed to imply endorsement by Worksuite in any manner of the website.</div><div><br></div><div><br></div><div><b><span style=\"font-size: 14px;\">NO WARRANTIES</span></b></div><div>THIS WEB SITE, THE INFORMATION AND MATERIALS ON THE SITE, AND ANY SOFTWARE MADE AVAILABLE ON THE WEB SITE, ARE PROVIDED \"AS IS\" WITHOUT ANY REPRESENTATION OR WARRANTY, EXPRESS OR IMPLIED, OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY, NON INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE. THERE IS NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, REGARDING THIRD PARTY CONTENT. INSPITE OF FROIDEN BEST ENDEAVOURS, THERE IS NO WARRANTY ON BEHALF OF FROIDEN THAT THIS WEB SITE WILL BE FREE OF ANY COMPUTER VIRUSES. SOME JURISDICTIONS DO NOT ALLOW FOR THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS MAY NOT APPLY TO YOU.</div><div>LIMITATION OF DAMAGES:</div><div>IN NO EVENT SHALL FROIDEN OR ANY OF ITS SUBSIDIARIES OR AFFILIATES BE LIABLE TO ANY ENTITY FOR ANY DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL OR OTHER DAMAGES (INCLUDING, WITHOUT LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS OF INFORMATION OR PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM) THAT ARE RELATED TO THE USE OF, OR THE INABILITY TO USE, THE CONTENT, MATERIALS, AND FUNCTIONS OF THIS WEB SITE OR ANY LINKED WEB SITE, EVEN IF FROIDEN IS EXPRESSLY ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.</div><div><br></div><div><b><span style=\"font-size: 14px;\">DISCLAIMER:</span></b></div><div>THE WEB SITE MAY CONTAIN INACCURACIES AND TYPOGRAPHICAL AND CLERICAL ERRORS. FROIDEN EXPRESSLY DISCLAIMS ANY OBLIGATION(S) TO UPDATE THIS WEBSITE OR ANY OF THE MATERIALS ON THIS WEBSITE. FROIDEN DOES NOT WARRANT THE ACCURACY OR COMPLETENESS OF THE MATERIALS OR THE RELIABILITY OF ANY ADVICE, OPINION, STATEMENT OR OTHER INFORMATION DISPLAYED OR DISTRIBUTED THROUGH THE WEB SITE. YOU ACKNOWLEDGE THAT ANY RELIANCE ON ANY SUCH OPINION, ADVICE, STATEMENT, MEMORANDUM, OR INFORMATION SHALL BE AT YOUR SOLE RISK. FROIDEN RESERVES THE RIGHT, IN ITS SOLE DISCRETION, TO CORRECT ANY ERRORS OR OMISSIONS IN ANY PORTION OF THE WEB SITE. FROIDEN MAY MAKE ANY OTHER CHANGES TO THE WEB SITE, THE MATERIALS AND THE PRODUCTS, PROGRAMS, SERVICES OR PRICES (IF ANY) DESCRIBED IN THE WEB SITE AT ANY TIME WITHOUT NOTICE. THIS WEB SITE IS FOR INFORMATIONAL PURPOSES ONLY AND SHOULD NOT BE CONSTRUED AS TECHNICAL ADVICE OF ANY MANNER.</div><div>UNLAWFUL AND/OR PROHIBITED USE OF THE WEB SITE</div><div>As a condition of Your use of the Web Site, You shall not use the Web Site for any purpose(s) that is unlawful or prohibited by the Terms of Use. You shall not use the Web Site in any manner that could damage, disable, overburden, or impair any Worksuite server, or the network(s) connected to any Worksuite server, or interfere with any other party\'s use and enjoyment of any services associated with the Web Site. You shall not attempt to gain unauthorized access to any section of the Web Site, other accounts, computer systems or networks connected to any Worksuite server or to any of the services associated with the Web Site, through hacking, password mining or any other means. You shall not obtain or attempt to obtain any Materials or information through any means not intentionally made available through the Web Site.</div><div><br></div><div><b><span style=\"font-size: 14px;\">INDEMNITY:</span></b></div><div>You agree to indemnify and hold harmless Worksuite, its subsidiaries and affiliates from any claim, cost, expense, judgment or other loss relating to Your use of this Web Site in any manner, including without limitation of the foregoing, any action You take which is in violation of the terms and conditions of these Terms of Use and against any applicable law.</div><div><br></div><div><b><span style=\"font-size: 14px;\">CHANGES:</span></b></div><div>Worksuite reserves the rights, at its sole discretion, to change, modify, add or remove any portion of these Terms of Use in whole or in part, at any time. Changes in these Terms of Use will be effective when notice of such change is posted. Your continued use of the Web Site after any changes to these Terms of Use are posted will be considered acceptance of those changes. Worksuite may terminate, change, suspend or discontinue any aspect of the Web Site, including the availability of any feature(s) of the Web Site, at any time. Worksuite may also impose limits on certain features and services or restrict Your access to certain sections or all of the Web Site without notice or liability. You hereby acknowledge and agree that Worksuite may terminate the authorization, rights, and license given above at any point of time at its own sole discretion, and upon such termination; You shall immediately destroy all Materials.</div><div><br></div><div><br></div><div><b><span style=\"font-size: 14px;\">INTERNATIONAL USERS AND CHOICE OF LAW:</span></b></div><div>This Site is controlled, operated, and administered by Worksuite from within India. Worksuite makes no representation that Materials on this Web Site are appropriate or available for use at any other location(s) outside India. Any access to this Web Site from territories where their contents are illegal is prohibited. You may not use the Web Site or export the Materials in violation of any applicable export laws and regulations. If You access this Web Site from a location outside India, You are responsible for compliance with all local laws.</div><div>These Terms of Use shall be governed by the laws of India,Terms of Use for worksuite.biz</div><div>The use of any product, service or feature (the \"Materials\") available through the internet web sites accessible at Worksuite.com (the \"Web Site\") by any user of the Web Site (\"You\" or \"Your\" hereafter) shall be governed by the following terms of use:</div><div>This Web Site is provided by Worksuite, a partnership awaiting registration with Government of India, and shall be used for informational purposes only. By using the Web Site or downloading Materials from the Web Site, You hereby agree to abide by the terms and conditions set forth in this Terms of Use. In the event of You not agreeing to these terms and conditions, You are requested by Worksuite not to use the Web Site or download Materials from the Web Site. This Web Site, including all Materials present (excluding any applicable third party materials), is the property of Worksuite and is copyrighted and protected by worldwide copyright laws and treaty provisions. You hereby agree to comply with all copyright laws worldwide in Your use of this Web Site and to prevent any unauthorized copying of the Materials. Worksuite does not grant any express or implied rights under any patents, trademarks, copyrights or trade secret information.</div><div>Worksuite has business relationships with many customers, suppliers, governments, and others. For convenience and simplicity, words like joint venture, partnership, and partner are used to indicate business relationships involving common activities and interests, and those words may not indicate precise legal relationships.</div><div><br></div><div><b><span style=\"font-size: 14px;\">LIMITED LICENSE:</span></b></div><div>Subject to the terms and conditions set forth in these Terms of Use, Worksuite grants You a non-exclusive, non-transferable, limited right to access, use and display this Web Site and the Materials thereon. You agree not to interrupt or attempt to interrupt the operation of the Web Site in any manner. Unless otherwise specified, the Web Site is for Your personal and non-commercial use. You shall not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, create derivative works from, transfer, or sell any information, software, products or services obtained from this Web Site.</div><div><br></div><div><b><span style=\"font-size: 14px;\">THIRD-PARTY CONTENT</span></b></div><div>The Web Site makes information of third parties available, including articles, analyst reports, news reports, and company information, including any regulatory authority, content licensed under Content Licensed under Creative Commons Attribution License, and other data from external sources (the \"Third Party Content\"). You acknowledge and agree that the Third Party Content is not created or endorsed by Worksuite. The provision of Third Party Content is for general informational purposes only and does not constitute a recommendation or solicitation to purchase or sell any securities or shares or to make any other type of investment or investment decision. In addition, the Third Party Content is not intended to provide tax, legal or investment advice. You acknowledge that the Third Party Content provided to You is obtained from sources believed to be reliable, but that no guarantees are made by Worksuite or the providers of the Third Party Content as to its accuracy, completeness, timeliness. You agree not to hold Worksuite, any business offering products or services through the Web Site or any provider of Third Party Content liable for any investment decision or other transaction You may make based on Your reliance on or use of such data, or any liability that may arise due to delays or interruptions in the delivery of the Third Party Content for any reason</div><div>By using any Third Party Content, You may leave this Web Site and be directed to an external website, or to a website maintained by an entity other than Worksuite. If You decide to visit any such site, You do so at Your own risk and it is Your responsibility to take all protective measures to guard against viruses or any other destructive elements. Worksuite makes no warranty or representation regarding, and does not endorse, any linked web sites or the information appearing thereon or any of the products or services described thereon. Links do not imply that Worksuite or this Web Site sponsors, endorses, is affiliated or associated with, or is legally authorized to use any trademark, trade name, logo or copyright symbol displayed in or accessible through the links, or that any linked site is authorized to use any trademark, trade name, logo or copyright symbol of Worksuite or any of its affiliates or subsidiaries. You hereby expressly acknowledge and agree that the linked sites are not under the control of Worksuite and Worksuite is not responsible for the contents of any linked site or any link contained in a linked site, or any changes or updates to such sites. Worksuite is not responsible for webcasting or any other form of transmission received from any linked site. Worksuite is providing these links to You only as a convenience, and the inclusion of any link shall not be construed to imply endorsement by Worksuite in any manner of the website.</div><div><br></div><div><b><span style=\"font-size: 14px;\">NO WARRANTIES</span></b></div><div>THIS WEB SITE, THE INFORMATION AND MATERIALS ON THE SITE, AND ANY SOFTWARE MADE AVAILABLE ON THE WEB SITE, ARE PROVIDED \"AS IS\" WITHOUT ANY REPRESENTATION OR WARRANTY, EXPRESS OR IMPLIED, OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY, NON INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE. THERE IS NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, REGARDING THIRD PARTY CONTENT. INSPITE OF FROIDEN BEST ENDEAVOURS, THERE IS NO WARRANTY ON BEHALF OF FROIDEN THAT THIS WEB SITE WILL BE FREE OF ANY COMPUTER VIRUSES. SOME JURISDICTIONS DO NOT ALLOW FOR THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS MAY NOT APPLY TO YOU.</div><div>LIMITATION OF DAMAGES:</div><div>IN NO EVENT SHALL FROIDEN OR ANY OF ITS SUBSIDIARIES OR AFFILIATES BE LIABLE TO ANY ENTITY FOR ANY DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL OR OTHER DAMAGES (INCLUDING, WITHOUT LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS OF INFORMATION OR PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM) THAT ARE RELATED TO THE USE OF, OR THE INABILITY TO USE, THE CONTENT, MATERIALS, AND FUNCTIONS OF THIS WEB SITE OR ANY LINKED WEB SITE, EVEN IF FROIDEN IS EXPRESSLY ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.</div><div><br></div><div><b><span style=\"font-size: 14px;\">DISCLAIMER:</span></b></div><div><span style=\"font-size: 12px;\">THE WEB SITE MAY CONTAIN INACCURACIES AND TYPOGRAPHICAL AND CLERICAL ERRORS. FROIDEN EXPRESSLY DISCLAIMS ANY OBLIGATION(S) TO UPDATE THIS WEBSITE OR ANY OF THE MATERIALS ON THIS WEBSITE. FROIDEN DOES NOT WARRANT THE ACCURACY OR COMPLETENESS OF THE MATERIALS OR THE RELIABILITY OF ANY ADVICE, OPINION, STATEMENT OR OTHER INFORMATION DISPLAYED OR DISTRIBUTED THROUGH THE WEB SITE. YOU ACKNOWLEDGE THAT ANY RELIANCE ON ANY SUCH OPINION, ADVICE, STATEMENT, MEMORANDUM, OR INFORMATION SHALL BE AT YOUR SOLE RISK. FROIDEN RESERVES THE RIGHT, IN ITS SOLE DISCRETION, TO CORRECT ANY ERRORS OR OMISSIONS IN ANY PORTION OF THE WEB SITE. FROIDEN MAY MAKE ANY OTHER CHANGES TO THE WEB SITE, THE MATERIALS AND THE PRODUCTS, PROGRAMS, SERVICES OR PRICES (IF ANY) DESCRIBED IN THE WEB SITE AT ANY TIME WITHOUT NOTICE. THIS WEB SITE IS FOR INFORMATIONAL PURPOSES ONLY AND SHOULD NOT BE CONSTRUED AS TECHNICAL ADVICE OF ANY MANNER.</span></div><div><span style=\"font-size: 12px;\">UNLAWFUL AND/OR PROHIBITED USE OF THE WEB SITE</span></div><div>As a condition of Your use of the Web Site, You shall not use the Web Site for any purpose(s) that is unlawful or prohibited by the Terms of Use. You shall not use the Web Site in any manner that could damage, disable, overburden, or impair any Worksuite server, or the network(s) connected to any Worksuite server, or interfere with any other party\'s use and enjoyment of any services associated with the Web Site. You shall not attempt to gain unauthorized access to any section of the Web Site, other accounts, computer systems or networks connected to any Worksuite server or to any of the services associated with the Web Site, through hacking, password mining or any other means. You shall not obtain or attempt to obtain any materials or information through any means not intentionally made available through the Web Site.</div><div><br></div><div><b><span style=\"font-size: 14px;\">INDEMNITY:</span></b></div><div>You agree to indemnify and hold harmless Worksuite, its subsidiaries and affiliates from any claim, cost, expense, judgment or other loss relating to Your use of this Web Site in any manner, including without limitation of the foregoing, any action You take which is in violation of the terms and conditions of these Terms of Use and against any applicable law.</div><div><br></div><div><b><span style=\"font-size: 14px;\">CHANGES:</span></b></div><div>Worksuite reserves the rights, at its sole discretion, to change, modify, add or remove any portion of these Terms of Use in whole or in part, at any time. Changes in these Terms of Use will be effective when notice of such change is posted. Your continued use of the Web Site after any changes to these Terms of Use are posted will be considered acceptance of those changes. Worksuite may terminate, change, suspend or discontinue any aspect of the Web Site, including the availability of any feature(s) of the Web Site, at any time. Worksuite may also impose limits on certain features and services or restrict Your access to certain sections or all of the Web Site without notice or liability. You hereby acknowledge and agree that Worksuite may terminate the authorization, rights, and license given above at any point of time at its own sole discretion, and upon such termination; You shall immediately destroy all Materials.</div><div><br></div><div><b><span style=\"font-size: 14px;\">INTERNATIONAL USERS AND CHOICE OF LAW:</span></b></div><div>This Site is controlled, operated, and administered by Worksuite from within India. Worksuite makes no representation that Materials on this Web Site are appropriate or available for use at any other location(s) outside India. Any access to this Web Site from territories where their contents are illegal is prohibited. You may not use the Web Site or export the Materials in violation of any applicable export laws and regulations. If You access this Web Site from a location outside India, You are responsible for compliance with all local laws.</div><div>These Terms of Use shall be governed by the laws of India, without giving effect to its conflict of laws provisions. You agree that the appropriate court(s) in Bangalore, India, will have the exclusive jurisdiction to resolve all disputes arising under these Terms of Use and You hereby consent to personal jurisdiction in such forum.</div><div>These Terms of Use constitute the entire agreement between Worksuite and You with respect to Your use of the Web Site. Any claim You may have with respect to Your use of the Web Site must be commenced within one (1) year of the cause of action. If any provision(s) of this Terms of Use is held by a court of competent jurisdiction to be contrary to law then such provision(s) shall be severed from this Terms of Use and the other remaining provisions of this Terms of Use shall remain in full force and effect. without giving effect to its conflict of laws provisions. You agree that the appropriate court(s) in Bangalore, India, will have the exclusive jurisdiction to resolve all disputes arising under these Terms of Use and You hereby consent to personal jurisdiction in such forum.</div><div>These Terms of Use constitute the entire agreement between Worksuite and You with respect to Your use of the Web Site. Any claim You may have with respect to Your use of the Web Site must be commenced within one (1) year of the cause of action. If any provision(s) of this Terms of Use is held by a court of competent jurisdiction to be contrary to law then such provision(s) shall be severed from this Terms of Use and the other remaining provisions of this Terms of Use shall remain in full force and effect.</div>',NULL,NULL,NULL,NULL,NULL,'footer','active',1,NULL,NULL,0),(2,'Privacy Policy','privacy-policy','<div><b><span style=\"font-size: 14px;\"><span style=\"font-size: 14px;\">TERMS OF USE FOR WORKSUITE.BIZ</span></span></b></div><div><br></div><div>The use of any product, service or feature (the \"Materials\") available through the internet web sites accessible at Worksuite.com (the \"Web Site\") by any user of the Web Site (\"You\" or \"Your\" hereafter) shall be governed by the following terms of use:</div><div>This Web Site is provided by Worksuite, a partnership awaiting registration with Government of India, and shall be used for informational purposes only. By using the Web Site or downloading Materials from the Web Site, You hereby agree to abide by the terms and conditions set forth in this Terms of Use. In the event of You not agreeing to these terms and conditions, You are requested by Worksuite not to use the Web Site or download Materials from the Web Site. This Web Site, including all Materials present (excluding any applicable third party materials), is the property of Worksuite and is copyrighted and protected by worldwide copyright laws and treaty provisions. You hereby agree to comply with all copyright laws worldwide in Your use of this Web Site and to prevent any unauthorized copying of the Materials. Worksuite does not grant any express or implied rights under any patents, trademarks, copyrights or trade secret information.</div><div>Worksuite has business relationships with many customers, suppliers, governments, and others. For convenience and simplicity, words like joint venture, partnership, and partner are used to indicate business relationships involving common activities and interests, and those words may not indicate precise legal relationships.</div><div><br></div><div><b><span style=\"font-size: 14px;\">LIMITED LICENSE:</span></b></div><div><br></div><div>Subject to the terms and conditions set forth in these Terms of Use, Worksuite grants You a non-exclusive, non-transferable, limited right to access, use and display this Web Site and the Materials thereon. You agree not to interrupt or attempt to interrupt the operation of the Web Site in any manner. Unless otherwise specified, the Web Site is for Your personal and non-commercial use. You shall not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, create derivative works from, transfer, or sell any information, software, products or services obtained from this Web Site.</div><div><br></div><div><b><span style=\"font-size: 14px;\">THIRD PARTY CONTENT</span></b></div><div>The Web Site makes information of third parties available, including articles, analyst reports, news reports, and company information, including any regulatory authority, content licensed under Content Licensed under Creative Commons Attribution License, and other data from external sources (the \"Third Party Content\"). You acknowledge and agree that the Third Party Content is not created or endorsed by Worksuite. The provision of Third Party Content is for general informational purposes only and does not constitute a recommendation or solicitation to purchase or sell any securities or shares or to make any other type of investment or investment decision. In addition, the Third Party Content is not intended to provide tax, legal or investment advice. You acknowledge that the Third Party Content provided to You is obtained from sources believed to be reliable, but that no guarantees are made by Worksuite or the providers of the Third Party Content as to its accuracy, completeness, timeliness. You agree not to hold Worksuite, any business offering products or services through the Web Site or any provider of Third Party Content liable for any investment decision or other transaction You may make based on Your reliance on or use of such data, or any liability that may arise due to delays or interruptions in the delivery of the Third Party Content for any reason</div><div>By using any Third Party Content, You may leave this Web Site and be directed to an external website, or to a website maintained by an entity other than Worksuite. If You decide to visit any such site, You do so at Your own risk and it is Your responsibility to take all protective measures to guard against viruses or any other destructive elements. Worksuite makes no warranty or representation regarding and does not endorse, any linked web sites or the information appearing thereon or any of the products or services described thereon. Links do not imply that Worksuite or this Web Site sponsors, endorses, is affiliated or associated with, or is legally authorized to use any trademark, trade name, logo or copyright symbol displayed in or accessible through the links, or that any linked site is authorized to use any trademark, trade name, logo or copyright symbol of Worksuite or any of its affiliates or subsidiaries. You hereby expressly acknowledge and agree that the linked sites are not under the control of Worksuite and Worksuite is not responsible for the contents of any linked site or any link contained in a linked site, or any changes or updates to such sites. Worksuite is not responsible for webcasting or any other form of transmission received from any linked site. Worksuite is providing these links to You only as a convenience, and the inclusion of any link shall not be construed to imply endorsement by Worksuite in any manner of the website.</div><div><br></div><div><br></div><div><b><span style=\"font-size: 14px;\">NO WARRANTIES</span></b></div><div>THIS WEB SITE, THE INFORMATION AND MATERIALS ON THE SITE, AND ANY SOFTWARE MADE AVAILABLE ON THE WEB SITE, ARE PROVIDED \"AS IS\" WITHOUT ANY REPRESENTATION OR WARRANTY, EXPRESS OR IMPLIED, OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY, NON INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE. THERE IS NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, REGARDING THIRD PARTY CONTENT. INSPITE OF FROIDEN BEST ENDEAVOURS, THERE IS NO WARRANTY ON BEHALF OF FROIDEN THAT THIS WEB SITE WILL BE FREE OF ANY COMPUTER VIRUSES. SOME JURISDICTIONS DO NOT ALLOW FOR THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS MAY NOT APPLY TO YOU.</div><div>LIMITATION OF DAMAGES:</div><div>IN NO EVENT SHALL FROIDEN OR ANY OF ITS SUBSIDIARIES OR AFFILIATES BE LIABLE TO ANY ENTITY FOR ANY DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL OR OTHER DAMAGES (INCLUDING, WITHOUT LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS OF INFORMATION OR PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM) THAT ARE RELATED TO THE USE OF, OR THE INABILITY TO USE, THE CONTENT, MATERIALS, AND FUNCTIONS OF THIS WEB SITE OR ANY LINKED WEB SITE, EVEN IF FROIDEN IS EXPRESSLY ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.</div><div><br></div><div><b><span style=\"font-size: 14px;\">DISCLAIMER:</span></b></div><div>THE WEB SITE MAY CONTAIN INACCURACIES AND TYPOGRAPHICAL AND CLERICAL ERRORS. FROIDEN EXPRESSLY DISCLAIMS ANY OBLIGATION(S) TO UPDATE THIS WEBSITE OR ANY OF THE MATERIALS ON THIS WEBSITE. FROIDEN DOES NOT WARRANT THE ACCURACY OR COMPLETENESS OF THE MATERIALS OR THE RELIABILITY OF ANY ADVICE, OPINION, STATEMENT OR OTHER INFORMATION DISPLAYED OR DISTRIBUTED THROUGH THE WEB SITE. YOU ACKNOWLEDGE THAT ANY RELIANCE ON ANY SUCH OPINION, ADVICE, STATEMENT, MEMORANDUM, OR INFORMATION SHALL BE AT YOUR SOLE RISK. FROIDEN RESERVES THE RIGHT, IN ITS SOLE DISCRETION, TO CORRECT ANY ERRORS OR OMISSIONS IN ANY PORTION OF THE WEB SITE. FROIDEN MAY MAKE ANY OTHER CHANGES TO THE WEB SITE, THE MATERIALS AND THE PRODUCTS, PROGRAMS, SERVICES OR PRICES (IF ANY) DESCRIBED IN THE WEB SITE AT ANY TIME WITHOUT NOTICE. THIS WEB SITE IS FOR INFORMATIONAL PURPOSES ONLY AND SHOULD NOT BE CONSTRUED AS TECHNICAL ADVICE OF ANY MANNER.</div><div>UNLAWFUL AND/OR PROHIBITED USE OF THE WEB SITE</div><div>As a condition of Your use of the Web Site, You shall not use the Web Site for any purpose(s) that is unlawful or prohibited by the Terms of Use. You shall not use the Web Site in any manner that could damage, disable, overburden, or impair any Worksuite server, or the network(s) connected to any Worksuite server, or interfere with any other party\'s use and enjoyment of any services associated with the Web Site. You shall not attempt to gain unauthorized access to any section of the Web Site, other accounts, computer systems or networks connected to any Worksuite server or to any of the services associated with the Web Site, through hacking, password mining or any other means. You shall not obtain or attempt to obtain any Materials or information through any means not intentionally made available through the Web Site.</div><div><br></div><div><b><span style=\"font-size: 14px;\">INDEMNITY:</span></b></div><div>You agree to indemnify and hold harmless Worksuite, its subsidiaries and affiliates from any claim, cost, expense, judgment or other loss relating to Your use of this Web Site in any manner, including without limitation of the foregoing, any action You take which is in violation of the terms and conditions of these Terms of Use and against any applicable law.</div><div><br></div><div><b><span style=\"font-size: 14px;\">CHANGES:</span></b></div><div>Worksuite reserves the rights, at its sole discretion, to change, modify, add or remove any portion of these Terms of Use in whole or in part, at any time. Changes in these Terms of Use will be effective when notice of such change is posted. Your continued use of the Web Site after any changes to these Terms of Use are posted will be considered acceptance of those changes. Worksuite may terminate, change, suspend or discontinue any aspect of the Web Site, including the availability of any feature(s) of the Web Site, at any time. Worksuite may also impose limits on certain features and services or restrict Your access to certain sections or all of the Web Site without notice or liability. You hereby acknowledge and agree that Worksuite may terminate the authorization, rights, and license given above at any point of time at its own sole discretion, and upon such termination; You shall immediately destroy all Materials.</div><div><br></div><div><br></div><div><b><span style=\"font-size: 14px;\">INTERNATIONAL USERS AND CHOICE OF LAW:</span></b></div><div>This Site is controlled, operated, and administered by Worksuite from within India. Worksuite makes no representation that Materials on this Web Site are appropriate or available for use at any other location(s) outside India. Any access to this Web Site from territories where their contents are illegal is prohibited. You may not use the Web Site or export the Materials in violation of any applicable export laws and regulations. If You access this Web Site from a location outside India, You are responsible for compliance with all local laws.</div><div>These Terms of Use shall be governed by the laws of India,Terms of Use for worksuite.biz</div><div>The use of any product, service or feature (the \"Materials\") available through the internet web sites accessible at Worksuite.com (the \"Web Site\") by any user of the Web Site (\"You\" or \"Your\" hereafter) shall be governed by the following terms of use:</div><div>This Web Site is provided by Worksuite, a partnership awaiting registration with Government of India, and shall be used for informational purposes only. By using the Web Site or downloading Materials from the Web Site, You hereby agree to abide by the terms and conditions set forth in this Terms of Use. In the event of You not agreeing to these terms and conditions, You are requested by Worksuite not to use the Web Site or download Materials from the Web Site. This Web Site, including all Materials present (excluding any applicable third party materials), is the property of Worksuite and is copyrighted and protected by worldwide copyright laws and treaty provisions. You hereby agree to comply with all copyright laws worldwide in Your use of this Web Site and to prevent any unauthorized copying of the Materials. Worksuite does not grant any express or implied rights under any patents, trademarks, copyrights or trade secret information.</div><div>Worksuite has business relationships with many customers, suppliers, governments, and others. For convenience and simplicity, words like joint venture, partnership, and partner are used to indicate business relationships involving common activities and interests, and those words may not indicate precise legal relationships.</div><div><br></div><div><b><span style=\"font-size: 14px;\">LIMITED LICENSE:</span></b></div><div>Subject to the terms and conditions set forth in these Terms of Use, Worksuite grants You a non-exclusive, non-transferable, limited right to access, use and display this Web Site and the Materials thereon. You agree not to interrupt or attempt to interrupt the operation of the Web Site in any manner. Unless otherwise specified, the Web Site is for Your personal and non-commercial use. You shall not modify, copy, distribute, transmit, display, perform, reproduce, publish, license, create derivative works from, transfer, or sell any information, software, products or services obtained from this Web Site.</div><div><br></div><div><b><span style=\"font-size: 14px;\">THIRD-PARTY CONTENT</span></b></div><div>The Web Site makes information of third parties available, including articles, analyst reports, news reports, and company information, including any regulatory authority, content licensed under Content Licensed under Creative Commons Attribution License, and other data from external sources (the \"Third Party Content\"). You acknowledge and agree that the Third Party Content is not created or endorsed by Worksuite. The provision of Third Party Content is for general informational purposes only and does not constitute a recommendation or solicitation to purchase or sell any securities or shares or to make any other type of investment or investment decision. In addition, the Third Party Content is not intended to provide tax, legal or investment advice. You acknowledge that the Third Party Content provided to You is obtained from sources believed to be reliable, but that no guarantees are made by Worksuite or the providers of the Third Party Content as to its accuracy, completeness, timeliness. You agree not to hold Worksuite, any business offering products or services through the Web Site or any provider of Third Party Content liable for any investment decision or other transaction You may make based on Your reliance on or use of such data, or any liability that may arise due to delays or interruptions in the delivery of the Third Party Content for any reason</div><div>By using any Third Party Content, You may leave this Web Site and be directed to an external website, or to a website maintained by an entity other than Worksuite. If You decide to visit any such site, You do so at Your own risk and it is Your responsibility to take all protective measures to guard against viruses or any other destructive elements. Worksuite makes no warranty or representation regarding, and does not endorse, any linked web sites or the information appearing thereon or any of the products or services described thereon. Links do not imply that Worksuite or this Web Site sponsors, endorses, is affiliated or associated with, or is legally authorized to use any trademark, trade name, logo or copyright symbol displayed in or accessible through the links, or that any linked site is authorized to use any trademark, trade name, logo or copyright symbol of Worksuite or any of its affiliates or subsidiaries. You hereby expressly acknowledge and agree that the linked sites are not under the control of Worksuite and Worksuite is not responsible for the contents of any linked site or any link contained in a linked site, or any changes or updates to such sites. Worksuite is not responsible for webcasting or any other form of transmission received from any linked site. Worksuite is providing these links to You only as a convenience, and the inclusion of any link shall not be construed to imply endorsement by Worksuite in any manner of the website.</div><div><br></div><div><b><span style=\"font-size: 14px;\">NO WARRANTIES</span></b></div><div>THIS WEB SITE, THE INFORMATION AND MATERIALS ON THE SITE, AND ANY SOFTWARE MADE AVAILABLE ON THE WEB SITE, ARE PROVIDED \"AS IS\" WITHOUT ANY REPRESENTATION OR WARRANTY, EXPRESS OR IMPLIED, OF ANY KIND, INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY, NON INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE. THERE IS NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, REGARDING THIRD PARTY CONTENT. INSPITE OF FROIDEN BEST ENDEAVOURS, THERE IS NO WARRANTY ON BEHALF OF FROIDEN THAT THIS WEB SITE WILL BE FREE OF ANY COMPUTER VIRUSES. SOME JURISDICTIONS DO NOT ALLOW FOR THE EXCLUSION OF IMPLIED WARRANTIES, SO THE ABOVE EXCLUSIONS MAY NOT APPLY TO YOU.</div><div>LIMITATION OF DAMAGES:</div><div>IN NO EVENT SHALL FROIDEN OR ANY OF ITS SUBSIDIARIES OR AFFILIATES BE LIABLE TO ANY ENTITY FOR ANY DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL OR OTHER DAMAGES (INCLUDING, WITHOUT LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOSS OF INFORMATION OR PROGRAMS OR OTHER DATA ON YOUR INFORMATION HANDLING SYSTEM) THAT ARE RELATED TO THE USE OF, OR THE INABILITY TO USE, THE CONTENT, MATERIALS, AND FUNCTIONS OF THIS WEB SITE OR ANY LINKED WEB SITE, EVEN IF FROIDEN IS EXPRESSLY ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.</div><div><br></div><div><b><span style=\"font-size: 14px;\">DISCLAIMER:</span></b></div><div><span style=\"font-size: 12px;\">THE WEB SITE MAY CONTAIN INACCURACIES AND TYPOGRAPHICAL AND CLERICAL ERRORS. FROIDEN EXPRESSLY DISCLAIMS ANY OBLIGATION(S) TO UPDATE THIS WEBSITE OR ANY OF THE MATERIALS ON THIS WEBSITE. FROIDEN DOES NOT WARRANT THE ACCURACY OR COMPLETENESS OF THE MATERIALS OR THE RELIABILITY OF ANY ADVICE, OPINION, STATEMENT OR OTHER INFORMATION DISPLAYED OR DISTRIBUTED THROUGH THE WEB SITE. YOU ACKNOWLEDGE THAT ANY RELIANCE ON ANY SUCH OPINION, ADVICE, STATEMENT, MEMORANDUM, OR INFORMATION SHALL BE AT YOUR SOLE RISK. FROIDEN RESERVES THE RIGHT, IN ITS SOLE DISCRETION, TO CORRECT ANY ERRORS OR OMISSIONS IN ANY PORTION OF THE WEB SITE. FROIDEN MAY MAKE ANY OTHER CHANGES TO THE WEB SITE, THE MATERIALS AND THE PRODUCTS, PROGRAMS, SERVICES OR PRICES (IF ANY) DESCRIBED IN THE WEB SITE AT ANY TIME WITHOUT NOTICE. THIS WEB SITE IS FOR INFORMATIONAL PURPOSES ONLY AND SHOULD NOT BE CONSTRUED AS TECHNICAL ADVICE OF ANY MANNER.</span></div><div><span style=\"font-size: 12px;\">UNLAWFUL AND/OR PROHIBITED USE OF THE WEB SITE</span></div><div>As a condition of Your use of the Web Site, You shall not use the Web Site for any purpose(s) that is unlawful or prohibited by the Terms of Use. You shall not use the Web Site in any manner that could damage, disable, overburden, or impair any Worksuite server, or the network(s) connected to any Worksuite server, or interfere with any other party\'s use and enjoyment of any services associated with the Web Site. You shall not attempt to gain unauthorized access to any section of the Web Site, other accounts, computer systems or networks connected to any Worksuite server or to any of the services associated with the Web Site, through hacking, password mining or any other means. You shall not obtain or attempt to obtain any materials or information through any means not intentionally made available through the Web Site.</div><div><br></div><div><b><span style=\"font-size: 14px;\">INDEMNITY:</span></b></div><div>You agree to indemnify and hold harmless Worksuite, its subsidiaries and affiliates from any claim, cost, expense, judgment or other loss relating to Your use of this Web Site in any manner, including without limitation of the foregoing, any action You take which is in violation of the terms and conditions of these Terms of Use and against any applicable law.</div><div><br></div><div><b><span style=\"font-size: 14px;\">CHANGES:</span></b></div><div>Worksuite reserves the rights, at its sole discretion, to change, modify, add or remove any portion of these Terms of Use in whole or in part, at any time. Changes in these Terms of Use will be effective when notice of such change is posted. Your continued use of the Web Site after any changes to these Terms of Use are posted will be considered acceptance of those changes. Worksuite may terminate, change, suspend or discontinue any aspect of the Web Site, including the availability of any feature(s) of the Web Site, at any time. Worksuite may also impose limits on certain features and services or restrict Your access to certain sections or all of the Web Site without notice or liability. You hereby acknowledge and agree that Worksuite may terminate the authorization, rights, and license given above at any point of time at its own sole discretion, and upon such termination; You shall immediately destroy all Materials.</div><div><br></div><div><b><span style=\"font-size: 14px;\">INTERNATIONAL USERS AND CHOICE OF LAW:</span></b></div><div>This Site is controlled, operated, and administered by Worksuite from within India. Worksuite makes no representation that Materials on this Web Site are appropriate or available for use at any other location(s) outside India. Any access to this Web Site from territories where their contents are illegal is prohibited. You may not use the Web Site or export the Materials in violation of any applicable export laws and regulations. If You access this Web Site from a location outside India, You are responsible for compliance with all local laws.</div><div>These Terms of Use shall be governed by the laws of India, without giving effect to its conflict of laws provisions. You agree that the appropriate court(s) in Bangalore, India, will have the exclusive jurisdiction to resolve all disputes arising under these Terms of Use and You hereby consent to personal jurisdiction in such forum.</div><div>These Terms of Use constitute the entire agreement between Worksuite and You with respect to Your use of the Web Site. Any claim You may have with respect to Your use of the Web Site must be commenced within one (1) year of the cause of action. If any provision(s) of this Terms of Use is held by a court of competent jurisdiction to be contrary to law then such provision(s) shall be severed from this Terms of Use and the other remaining provisions of this Terms of Use shall remain in full force and effect. without giving effect to its conflict of laws provisions. You agree that the appropriate court(s) in Bangalore, India, will have the exclusive jurisdiction to resolve all disputes arising under these Terms of Use and You hereby consent to personal jurisdiction in such forum.</div><div>These Terms of Use constitute the entire agreement between Worksuite and You with respect to Your use of the Web Site. Any claim You may have with respect to Your use of the Web Site must be commenced within one (1) year of the cause of action. If any provision(s) of this Terms of Use is held by a court of competent jurisdiction to be contrary to law then such provision(s) shall be severed from this Terms of Use and the other remaining provisions of this Terms of Use shall remain in full force and effect.</div>',NULL,NULL,NULL,NULL,NULL,'footer','active',1,NULL,NULL,0);
/*!40000 ALTER TABLE `footer_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_clients`
--

DROP TABLE IF EXISTS `front_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `front_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `front_clients_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `front_clients_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_clients`
--

LOCK TABLES `front_clients` WRITE;
/*!40000 ALTER TABLE `front_clients` DISABLE KEYS */;
INSERT INTO `front_clients` VALUES (1,'Client 1',NULL,1,NULL,NULL),(2,'Client 2',NULL,1,NULL,NULL),(3,'Client 3',NULL,1,NULL,NULL),(4,'Client 4',NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `front_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_details`
--

DROP TABLE IF EXISTS `front_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `front_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `get_started_show` enum('yes','no') NOT NULL DEFAULT 'yes',
  `sign_in_show` enum('yes','no') NOT NULL DEFAULT 'yes',
  `address` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `social_links` text DEFAULT NULL,
  `primary_color` varchar(191) DEFAULT NULL,
  `custom_css` longtext DEFAULT NULL,
  `custom_css_theme_two` longtext DEFAULT NULL,
  `locale` varchar(191) DEFAULT 'en',
  `contact_html` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `homepage_background` enum('default','color','image','image_and_color') NOT NULL DEFAULT 'default',
  `background_color` varchar(191) DEFAULT '#CDDCDC',
  `background_image` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_details`
--

LOCK TABLES `front_details` WRITE;
/*!40000 ALTER TABLE `front_details` DISABLE KEYS */;
INSERT INTO `front_details` VALUES (1,'yes','yes','IBFIM 200701005076 (763075-W)\r\nLevel 5, Bangunan AICB No. 10,\r\nJalan Dato’ Onn 50480 Kuala Lumpur','+603 2031 1010','contact@ibfim.com','[{\"name\":\"facebook\",\"link\":\"https:\\/\\/www.facebook.com\\/worksuiteapp\"},{\"name\":\"twitter\",\"link\":\"https:\\/\\/twitter.com\\/worksuiteapp\"},{\"name\":\"instagram\",\"link\":\"https:\\/\\/www.instagram.com\\/worksuiteapp\\/\"},{\"name\":\"dribbble\",\"link\":\"https:\\/\\/dribbble.com\"},{\"name\":\"youtube\",\"link\":\"https:\\/\\/www.youtube.com\\/channel\\/UCoqD9VJ4E1UHz3nE_noyKng\"}]','#453130',NULL,NULL,'en',NULL,'2023-08-10 14:06:56','2023-08-21 16:17:51','default','#CDDCDC',NULL);
/*!40000 ALTER TABLE `front_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_faqs`
--

DROP TABLE IF EXISTS `front_faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `front_faqs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(191) NOT NULL,
  `answer` text NOT NULL,
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `front_faqs_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `front_faqs_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_faqs`
--

LOCK TABLES `front_faqs` WRITE;
/*!40000 ALTER TABLE `front_faqs` DISABLE KEYS */;
INSERT INTO `front_faqs` VALUES (1,'Can i see demo?','<span style=\"color: rgb(68, 68, 68); font-family: Lato, sans-serif; font-size: 16px;\">Yes, definitely. We would be happy to demonstrate you Worksuite through a web conference at your convenience. Please submit a query on our contact us page or drop a mail to our mail id worksuite@froiden.com.</span>',1,NULL,NULL),(2,'How can i update app?','<span style=\"color: rgb(68, 68, 68); font-family: Lato, sans-serif; font-size: 16px;\">Yes, definitely. We would be happy to demonstrate you Worksuite through a web conference at your convenience. Please submit a query on our contact us page or drop a mail to our mail id worksuite@froiden.com.</span>',1,NULL,NULL);
/*!40000 ALTER TABLE `front_faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_features`
--

DROP TABLE IF EXISTS `front_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `front_features` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `status` enum('enable','disable') NOT NULL DEFAULT 'enable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `front_features_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `front_features_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_features`
--

LOCK TABLES `front_features` WRITE;
/*!40000 ALTER TABLE `front_features` DISABLE KEYS */;
INSERT INTO `front_features` VALUES (1,1,'Task Management','Manage your projects and talent in one system for empowered teams, satisfied clients, and increased profitability.','enable','2023-08-10 14:06:56','2023-08-10 14:06:56'),(2,1,'Manage All Bills','Automate billing and revenue recognition to streamline the contract-to-cash cycle.','enable','2023-08-10 14:06:56','2023-08-10 14:06:56'),(3,1,NULL,NULL,'enable','2023-08-10 14:06:56','2023-08-10 14:06:56');
/*!40000 ALTER TABLE `front_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_menu_buttons`
--

DROP TABLE IF EXISTS `front_menu_buttons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `front_menu_buttons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `home` varchar(20) DEFAULT 'home',
  `feature` varchar(20) DEFAULT 'feature',
  `price` varchar(20) DEFAULT 'price',
  `contact` varchar(20) DEFAULT 'contact',
  `get_start` varchar(20) DEFAULT 'get_start',
  `login` varchar(20) DEFAULT 'login',
  `contact_submit` varchar(20) DEFAULT 'contact_submit',
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `front_menu_buttons_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `front_menu_buttons_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_menu_buttons`
--

LOCK TABLES `front_menu_buttons` WRITE;
/*!40000 ALTER TABLE `front_menu_buttons` DISABLE KEYS */;
INSERT INTO `front_menu_buttons` VALUES (1,'Home','Features','Pricing','Contact','Get Started','Login','Submit Enquiry',1,'2023-08-10 14:06:56','2023-08-10 14:06:56');
/*!40000 ALTER TABLE `front_menu_buttons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `front_widgets`
--

DROP TABLE IF EXISTS `front_widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `front_widgets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `footer_script` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `header_script` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `front_widgets`
--

LOCK TABLES `front_widgets` WRITE;
/*!40000 ALTER TABLE `front_widgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `front_widgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdpr_settings`
--

DROP TABLE IF EXISTS `gdpr_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gdpr_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `enable_gdpr` tinyint(1) NOT NULL DEFAULT 0,
  `show_customer_area` tinyint(1) NOT NULL DEFAULT 0,
  `show_customer_footer` tinyint(1) NOT NULL DEFAULT 0,
  `top_information_block` longtext DEFAULT NULL,
  `enable_export` tinyint(1) NOT NULL DEFAULT 0,
  `data_removal` tinyint(1) NOT NULL DEFAULT 0,
  `lead_removal_public_form` tinyint(1) NOT NULL DEFAULT 0,
  `terms_customer_footer` tinyint(1) NOT NULL DEFAULT 0,
  `terms` longtext DEFAULT NULL,
  `policy` longtext DEFAULT NULL,
  `public_lead_edit` tinyint(1) NOT NULL DEFAULT 0,
  `consent_customer` tinyint(1) NOT NULL DEFAULT 0,
  `consent_leads` tinyint(1) NOT NULL DEFAULT 0,
  `consent_block` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdpr_settings`
--

LOCK TABLES `gdpr_settings` WRITE;
/*!40000 ALTER TABLE `gdpr_settings` DISABLE KEYS */;
INSERT INTO `gdpr_settings` VALUES (1,0,0,0,NULL,0,0,0,0,NULL,NULL,0,0,0,NULL,'2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `gdpr_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_currencies`
--

DROP TABLE IF EXISTS `global_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_currencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(191) NOT NULL,
  `currency_symbol` varchar(191) NOT NULL,
  `currency_code` varchar(191) NOT NULL,
  `exchange_rate` double DEFAULT NULL,
  `usd_price` double DEFAULT NULL,
  `is_cryptocurrency` enum('yes','no') NOT NULL DEFAULT 'no',
  `currency_position` enum('left','right','left_with_space','right_with_space') NOT NULL DEFAULT 'left',
  `no_of_decimal` int(10) unsigned NOT NULL DEFAULT 2,
  `thousand_separator` varchar(191) DEFAULT NULL,
  `decimal_separator` varchar(191) DEFAULT NULL,
  `status` enum('enable','disable') NOT NULL DEFAULT 'enable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_currencies`
--

LOCK TABLES `global_currencies` WRITE;
/*!40000 ALTER TABLE `global_currencies` DISABLE KEYS */;
INSERT INTO `global_currencies` VALUES (1,'Dollars','$','USD',1,NULL,'no','left',2,',','.','enable',NULL,NULL,NULL),(2,'Pounds','£','GBP',1,NULL,'no','left',2,',','.','enable',NULL,NULL,NULL),(3,'Euros','€','EUR',1,NULL,'no','left',2,',','.','enable',NULL,NULL,NULL),(4,'Rupee','₹','INR',1,NULL,'no','left',2,',','.','enable',NULL,NULL,NULL),(5,'Malaysian Ringgit','RM','MYR',1,NULL,'no','left',2,',','.','enable','2023-08-11 02:06:14','2023-08-11 02:06:14',NULL);
/*!40000 ALTER TABLE `global_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_invoice_settings`
--

DROP TABLE IF EXISTS `global_invoice_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_invoice_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `logo` varchar(191) DEFAULT NULL,
  `template` varchar(191) NOT NULL,
  `locale` varchar(191) DEFAULT 'en',
  `authorised_signatory` tinyint(1) NOT NULL DEFAULT 0,
  `authorised_signatory_signature` varchar(191) DEFAULT NULL,
  `invoice_terms` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_invoice_settings`
--

LOCK TABLES `global_invoice_settings` WRITE;
/*!40000 ALTER TABLE `global_invoice_settings` DISABLE KEYS */;
INSERT INTO `global_invoice_settings` VALUES (1,'c4c223b585dacd43afab387ebcbce3ed.png','invoice-5','en',0,NULL,'Thank you for your business.','2023-08-10 14:06:42','2023-08-21 15:53:32');
/*!40000 ALTER TABLE `global_invoice_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_invoices`
--

DROP TABLE IF EXISTS `global_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `currency_id` bigint(20) unsigned DEFAULT NULL,
  `package_id` bigint(20) unsigned DEFAULT NULL,
  `global_subscription_id` int(10) unsigned DEFAULT NULL,
  `offline_method_id` int(10) unsigned DEFAULT NULL,
  `m_payment_id` varchar(191) DEFAULT NULL,
  `pf_payment_id` varchar(191) DEFAULT NULL,
  `payfast_plan` varchar(191) DEFAULT NULL,
  `signature` varchar(191) DEFAULT NULL,
  `token` varchar(191) DEFAULT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `package_type` varchar(191) DEFAULT NULL,
  `sub_total` double DEFAULT NULL,
  `total` double DEFAULT NULL,
  `billing_frequency` varchar(191) DEFAULT NULL,
  `billing_interval` varchar(191) DEFAULT NULL,
  `recurring` enum('yes','no') DEFAULT NULL,
  `plan_id` varchar(191) DEFAULT NULL,
  `event_id` varchar(191) DEFAULT NULL,
  `order_id` varchar(191) DEFAULT NULL,
  `subscription_id` varchar(191) DEFAULT NULL,
  `invoice_id` varchar(191) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `stripe_invoice_number` varchar(191) DEFAULT NULL,
  `pay_date` datetime DEFAULT NULL,
  `next_pay_date` datetime DEFAULT NULL,
  `gateway_name` varchar(191) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `global_invoices_company_id_foreign` (`company_id`),
  KEY `global_invoices_currency_id_foreign` (`currency_id`),
  KEY `global_invoices_package_id_foreign` (`package_id`),
  KEY `global_invoices_global_subscription_id_foreign` (`global_subscription_id`),
  KEY `global_invoices_offline_method_id_foreign` (`offline_method_id`),
  CONSTRAINT `global_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_invoices_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `global_currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_invoices_global_subscription_id_foreign` FOREIGN KEY (`global_subscription_id`) REFERENCES `global_subscriptions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_invoices_offline_method_id_foreign` FOREIGN KEY (`offline_method_id`) REFERENCES `offline_payment_methods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_invoices`
--

LOCK TABLES `global_invoices` WRITE;
/*!40000 ALTER TABLE `global_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `global_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_payment_gateway_credentials`
--

DROP TABLE IF EXISTS `global_payment_gateway_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_payment_gateway_credentials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `paypal_client_id` varchar(191) DEFAULT NULL,
  `paypal_secret` varchar(191) DEFAULT NULL,
  `sandbox_paypal_client_id` varchar(191) DEFAULT NULL,
  `sandbox_paypal_secret` varchar(191) DEFAULT NULL,
  `paypal_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `paypal_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `live_stripe_client_id` varchar(191) DEFAULT NULL,
  `live_stripe_secret` varchar(191) DEFAULT NULL,
  `live_stripe_webhook_secret` varchar(191) DEFAULT NULL,
  `test_stripe_client_id` varchar(191) DEFAULT NULL,
  `test_stripe_secret` varchar(191) DEFAULT NULL,
  `test_stripe_webhook_secret` varchar(191) DEFAULT NULL,
  `stripe_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `stripe_mode` enum('test','live') NOT NULL DEFAULT 'test',
  `live_razorpay_key` varchar(191) DEFAULT NULL,
  `live_razorpay_secret` varchar(191) DEFAULT NULL,
  `test_razorpay_key` varchar(191) DEFAULT NULL,
  `test_razorpay_secret` varchar(191) DEFAULT NULL,
  `razorpay_webhook_secret` varchar(191) DEFAULT NULL,
  `razorpay_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `razorpay_mode` enum('test','live') NOT NULL DEFAULT 'test',
  `paystack_key` varchar(191) DEFAULT NULL,
  `paystack_secret` varchar(191) DEFAULT NULL,
  `paystack_merchant_email` varchar(191) DEFAULT NULL,
  `test_paystack_key` varchar(191) DEFAULT NULL,
  `test_paystack_secret` varchar(191) DEFAULT NULL,
  `test_paystack_merchant_email` varchar(191) DEFAULT NULL,
  `paystack_payment_url` varchar(191) DEFAULT 'https://api.paystack.co',
  `paystack_status` enum('active','deactive') DEFAULT 'deactive',
  `paystack_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `mollie_api_key` varchar(191) DEFAULT NULL,
  `mollie_status` enum('active','deactive') DEFAULT 'deactive',
  `payfast_merchant_id` varchar(191) DEFAULT NULL,
  `payfast_merchant_key` varchar(191) DEFAULT NULL,
  `payfast_passphrase` varchar(191) DEFAULT NULL,
  `test_payfast_merchant_id` varchar(191) DEFAULT NULL,
  `test_payfast_merchant_key` varchar(191) DEFAULT NULL,
  `test_payfast_passphrase` varchar(191) DEFAULT NULL,
  `payfast_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `payfast_status` enum('active','deactive') DEFAULT 'deactive',
  `authorize_api_login_id` varchar(191) DEFAULT NULL,
  `authorize_transaction_key` varchar(191) DEFAULT NULL,
  `authorize_environment` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `authorize_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `square_application_id` varchar(191) DEFAULT NULL,
  `square_access_token` varchar(191) DEFAULT NULL,
  `square_location_id` varchar(191) DEFAULT NULL,
  `square_environment` enum('sandbox','production') NOT NULL DEFAULT 'sandbox',
  `square_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `test_flutterwave_key` varchar(191) DEFAULT NULL,
  `test_flutterwave_secret` varchar(191) DEFAULT NULL,
  `test_flutterwave_hash` varchar(191) DEFAULT NULL,
  `live_flutterwave_key` varchar(191) DEFAULT NULL,
  `live_flutterwave_secret` varchar(191) DEFAULT NULL,
  `live_flutterwave_hash` varchar(191) DEFAULT NULL,
  `flutterwave_webhook_secret_hash` varchar(191) DEFAULT NULL,
  `flutterwave_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `flutterwave_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_payment_gateway_credentials`
--

LOCK TABLES `global_payment_gateway_credentials` WRITE;
/*!40000 ALTER TABLE `global_payment_gateway_credentials` DISABLE KEYS */;
INSERT INTO `global_payment_gateway_credentials` VALUES (1,NULL,NULL,NULL,NULL,'deactive','sandbox',NULL,NULL,NULL,'pk_test_51NdSqGCC83aJafqlwrNXVfa9KrxVUnPINC3fWoA9PfvgcpWg80cYTBVqMOfE9ZFzawuGuKyR0oCJfFISRWfipYPB00vhgOPaPM','sk_test_51NdSqGCC83aJafqlaP6jzrIullsQ28jUeIYgVfxRDTJ6keDq2R3KjjoOwz87RM05KTP0HVA9BfCxUTdbYS4fl2Lg00qgb3tqp1','whsec_W6PUNi7kg2AF6K8BQo1kpzfM9vpFAOw3','active','test',NULL,NULL,NULL,NULL,NULL,'inactive','test',NULL,NULL,NULL,NULL,NULL,NULL,'https://api.paystack.co','deactive','sandbox',NULL,'deactive',NULL,NULL,NULL,NULL,NULL,NULL,'sandbox','deactive',NULL,NULL,'sandbox','deactive',NULL,NULL,NULL,'sandbox','deactive',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'deactive','sandbox','2023-08-10 14:06:55','2023-08-11 01:59:00');
/*!40000 ALTER TABLE `global_payment_gateway_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_settings`
--

DROP TABLE IF EXISTS `global_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `global_app_name` varchar(191) DEFAULT NULL,
  `logo` varchar(191) DEFAULT NULL,
  `light_logo` varchar(191) DEFAULT NULL,
  `login_background` varchar(191) DEFAULT NULL,
  `logo_background_color` varchar(191) DEFAULT NULL,
  `header_color` varchar(191) NOT NULL DEFAULT '#1D82F5',
  `sidebar_logo_style` varchar(191) DEFAULT 'square',
  `locale` varchar(191) NOT NULL DEFAULT 'en',
  `hash` varchar(191) DEFAULT NULL,
  `purchase_code` varchar(100) DEFAULT NULL,
  `supported_until` timestamp NULL DEFAULT NULL,
  `last_license_verified_at` timestamp NULL DEFAULT NULL,
  `google_recaptcha_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `google_recaptcha_v2_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `google_recaptcha_v2_site_key` varchar(191) DEFAULT NULL,
  `google_recaptcha_v2_secret_key` varchar(191) DEFAULT NULL,
  `google_recaptcha_v3_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `google_recaptcha_v3_site_key` varchar(191) DEFAULT NULL,
  `google_recaptcha_v3_secret_key` varchar(191) DEFAULT NULL,
  `app_debug` tinyint(1) NOT NULL DEFAULT 0,
  `currency_converter_key` varchar(191) DEFAULT NULL,
  `currency_key_version` varchar(191) NOT NULL DEFAULT 'free',
  `moment_format` varchar(191) NOT NULL DEFAULT 'DD-MM-YYYY',
  `timezone` varchar(191) NOT NULL DEFAULT 'Asia/Kolkata',
  `rtl` tinyint(1) NOT NULL DEFAULT 0,
  `license_type` varchar(20) DEFAULT NULL,
  `hide_cron_message` tinyint(1) NOT NULL DEFAULT 0,
  `system_update` tinyint(1) NOT NULL DEFAULT 1,
  `show_review_modal` tinyint(1) NOT NULL DEFAULT 1,
  `last_cron_run` timestamp NULL DEFAULT NULL,
  `favicon` varchar(191) DEFAULT NULL,
  `auth_theme` enum('dark','light') NOT NULL DEFAULT 'light',
  `auth_theme_text` enum('dark','light') NOT NULL DEFAULT 'dark',
  `session_driver` enum('file','database') NOT NULL DEFAULT 'file',
  `allowed_file_types` text DEFAULT NULL,
  `allowed_file_size` int(11) NOT NULL DEFAULT 10,
  `allow_max_no_of_files` int(11) NOT NULL DEFAULT 10,
  `datatable_row_limit` int(11) NOT NULL DEFAULT 10,
  `show_update_popup` tinyint(1) NOT NULL DEFAULT 1,
  `sign_up_terms` enum('yes','no') NOT NULL DEFAULT 'no',
  `terms_link` text DEFAULT NULL,
  `google_calendar_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `google_client_id` text DEFAULT NULL,
  `google_client_secret` text DEFAULT NULL,
  `google_calendar_verification_status` enum('verified','non_verified') NOT NULL DEFAULT 'non_verified',
  `google_id` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `token` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `company_email` varchar(191) NOT NULL,
  `company_phone` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `website` varchar(191) DEFAULT NULL,
  `currency_id` bigint(20) unsigned DEFAULT NULL,
  `date_format` varchar(20) NOT NULL DEFAULT 'd-m-Y',
  `date_picker_format` varchar(191) DEFAULT NULL,
  `time_format` varchar(20) NOT NULL DEFAULT 'h:i a',
  `latitude` decimal(10,8) NOT NULL DEFAULT 26.91243360,
  `longitude` decimal(11,8) NOT NULL DEFAULT 75.78727090,
  `active_theme` enum('default','custom') NOT NULL DEFAULT 'default',
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `google_map_key` varchar(191) NOT NULL,
  `rounded_theme` tinyint(1) NOT NULL,
  `front_design` tinyint(1) NOT NULL DEFAULT 1,
  `email_verification` tinyint(1) NOT NULL DEFAULT 0,
  `logo_front` varchar(191) DEFAULT NULL,
  `login_ui` tinyint(1) NOT NULL,
  `auth_css` longtext DEFAULT NULL,
  `auth_css_theme_two` longtext DEFAULT NULL,
  `new_company_locale` varchar(191) DEFAULT NULL,
  `frontend_disable` tinyint(1) NOT NULL DEFAULT 0,
  `setup_homepage` varchar(191) NOT NULL DEFAULT 'default',
  `custom_homepage_url` varchar(191) DEFAULT NULL,
  `expired_message` text DEFAULT NULL,
  `enable_register` tinyint(1) NOT NULL DEFAULT 1,
  `registration_open` tinyint(1) NOT NULL DEFAULT 1,
  `company_need_approval` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `global_settings_last_updated_by_foreign` (`last_updated_by`),
  KEY `global_settings_currency_id_foreign` (`currency_id`),
  CONSTRAINT `global_settings_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `global_currencies` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `global_settings_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_settings`
--

LOCK TABLES `global_settings` WRITE;
/*!40000 ALTER TABLE `global_settings` DISABLE KEYS */;
INSERT INTO `global_settings` VALUES (1,'SmartKerja','148257eb60a390014eefb6369b1ef5a8.png','a4ef9bcd70d507df032d414730fb414d.png',NULL,'#FFFFFF','#1D82F5','square','en','c41a51adc0482a9204cc07b418cc1c25',NULL,NULL,NULL,'deactive','deactive',NULL,NULL,'deactive',NULL,NULL,0,NULL,'free','DD-MM-YYYY','Asia/Kuala_Lumpur',0,NULL,0,1,1,NULL,'98f27c3f7a4584d1d4179124cfcca72f.png','light','dark','file','image/*,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/docx,application/pdf,text/plain,application/msword,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/zip,application/x-zip-compressed, application/x-compressed, multipart/x-zip,.xlsx,video/x-flv,video/mp4,application/x-mpegURL,video/MP2T,video/3gpp,video/quicktime,video/x-msvideo,video/x-ms-wmv,application/sla,.stl',10,10,10,1,'no',NULL,'inactive',NULL,NULL,'non_verified',NULL,NULL,NULL,'2023-08-10 14:06:55','2024-07-14 16:11:11','',NULL,NULL,NULL,5,'d-m-Y',NULL,'h:i a',26.91243360,75.78727090,'default',NULL,'',0,1,0,'0f8a3c66c4ad116ba7ff06cc4d4b0d1f.png',0,NULL,NULL,NULL,1,'default','https://smartkerja.org',NULL,1,1,0);
/*!40000 ALTER TABLE `global_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global_subscriptions`
--

DROP TABLE IF EXISTS `global_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `package_id` bigint(20) unsigned DEFAULT NULL,
  `currency_id` bigint(20) unsigned DEFAULT NULL,
  `package_type` varchar(191) DEFAULT NULL,
  `plan_type` varchar(191) DEFAULT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `customer_id` varchar(191) DEFAULT NULL,
  `user_id` varchar(191) DEFAULT NULL,
  `payfast_plan` varchar(191) DEFAULT NULL,
  `payfast_status` varchar(191) DEFAULT NULL,
  `quantity` varchar(191) DEFAULT NULL,
  `token` varchar(191) DEFAULT NULL,
  `razorpay_id` varchar(191) DEFAULT NULL,
  `razorpay_plan` varchar(191) DEFAULT NULL,
  `stripe_id` varchar(191) DEFAULT NULL,
  `stripe_status` varchar(191) DEFAULT NULL,
  `stripe_price` varchar(191) DEFAULT NULL,
  `gateway_name` varchar(191) DEFAULT NULL,
  `trial_ends_at` varchar(191) DEFAULT NULL,
  `subscription_status` enum('active','inactive') DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `subscribed_on_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `global_subscriptions_company_id_foreign` (`company_id`),
  KEY `global_subscriptions_package_id_foreign` (`package_id`),
  KEY `global_subscriptions_currency_id_foreign` (`currency_id`),
  CONSTRAINT `global_subscriptions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_subscriptions_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `global_currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `global_subscriptions_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_subscriptions`
--

LOCK TABLES `global_subscriptions` WRITE;
/*!40000 ALTER TABLE `global_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `global_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `google_calendar_modules`
--

DROP TABLE IF EXISTS `google_calendar_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `google_calendar_modules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `lead_status` tinyint(1) NOT NULL DEFAULT 0,
  `leave_status` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_status` tinyint(1) NOT NULL DEFAULT 0,
  `contract_status` tinyint(1) NOT NULL DEFAULT 0,
  `task_status` tinyint(1) NOT NULL DEFAULT 0,
  `event_status` tinyint(1) NOT NULL DEFAULT 0,
  `holiday_status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `google_calendar_modules_company_id_foreign` (`company_id`),
  CONSTRAINT `google_calendar_modules_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `google_calendar_modules`
--

LOCK TABLES `google_calendar_modules` WRITE;
/*!40000 ALTER TABLE `google_calendar_modules` DISABLE KEYS */;
INSERT INTO `google_calendar_modules` VALUES (1,1,0,0,0,0,0,0,0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,0,0,0,0,0,0,0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,0,0,0,0,0,0,0,'2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `google_calendar_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holidays`
--

DROP TABLE IF EXISTS `holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holidays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `date` date NOT NULL,
  `occassion` varchar(100) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `event_id` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `holidays_company_id_foreign` (`company_id`),
  KEY `holidays_date_index` (`date`),
  KEY `holidays_added_by_foreign` (`added_by`),
  KEY `holidays_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `holidays_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `holidays_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `holidays_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holidays`
--

LOCK TABLES `holidays` WRITE;
/*!40000 ALTER TABLE `holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `holidays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_files`
--

DROP TABLE IF EXISTS `invoice_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(10) unsigned NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `hashname` varchar(200) DEFAULT NULL,
  `size` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_files_invoice_id_foreign` (`invoice_id`),
  KEY `invoice_files_added_by_foreign` (`added_by`),
  KEY `invoice_files_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `invoice_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoice_files_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_files`
--

LOCK TABLES `invoice_files` WRITE;
/*!40000 ALTER TABLE `invoice_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_item_images`
--

DROP TABLE IF EXISTS `invoice_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_item_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_item_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_item_images_invoice_item_id_foreign` (`invoice_item_id`),
  CONSTRAINT `invoice_item_images_invoice_item_id_foreign` FOREIGN KEY (`invoice_item_id`) REFERENCES `invoice_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_item_images`
--

LOCK TABLES `invoice_item_images` WRITE;
/*!40000 ALTER TABLE `invoice_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` int(10) unsigned NOT NULL,
  `item_name` varchar(191) NOT NULL,
  `item_summary` text DEFAULT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `quantity` double(16,2) NOT NULL,
  `unit_price` double(16,2) NOT NULL,
  `amount` double(16,2) NOT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_items_invoice_id_foreign` (`invoice_id`),
  KEY `invoice_items_unit_id_foreign` (`unit_id`),
  KEY `invoice_items_product_id_foreign` (`product_id`),
  CONSTRAINT `invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoice_items_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_recurring`
--

DROP TABLE IF EXISTS `invoice_recurring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_recurring` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `issue_date` date NOT NULL,
  `next_invoice_date` date DEFAULT NULL,
  `due_date` date NOT NULL,
  `sub_total` double NOT NULL DEFAULT 0,
  `total` double NOT NULL DEFAULT 0,
  `discount` double NOT NULL DEFAULT 0,
  `discount_type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `file` varchar(191) DEFAULT NULL,
  `file_original_name` varchar(191) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `show_shipping_address` enum('yes','no') NOT NULL DEFAULT 'no',
  `day_of_month` int(11) DEFAULT 1,
  `day_of_week` int(11) DEFAULT 1,
  `payment_method` varchar(191) DEFAULT NULL,
  `rotation` enum('monthly','weekly','bi-weekly','quarterly','half-yearly','annually','daily') NOT NULL,
  `billing_cycle` int(11) DEFAULT NULL,
  `client_can_stop` tinyint(1) NOT NULL DEFAULT 1,
  `unlimited_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` datetime DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `calculate_tax` enum('after_discount','before_discount') NOT NULL DEFAULT 'after_discount',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `immediate_invoice` tinyint(1) NOT NULL DEFAULT 0,
  `bank_account_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_recurring_company_id_foreign` (`company_id`),
  KEY `invoice_recurring_currency_id_foreign` (`currency_id`),
  KEY `invoice_recurring_project_id_foreign` (`project_id`),
  KEY `invoice_recurring_client_id_foreign` (`client_id`),
  KEY `invoice_recurring_user_id_foreign` (`user_id`),
  KEY `invoice_recurring_created_by_foreign` (`created_by`),
  KEY `invoice_recurring_added_by_foreign` (`added_by`),
  KEY `invoice_recurring_last_updated_by_foreign` (`last_updated_by`),
  KEY `invoice_recurring_bank_account_id_foreign` (`bank_account_id`),
  CONSTRAINT `invoice_recurring_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_bank_account_id_foreign` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_recurring`
--

LOCK TABLES `invoice_recurring` WRITE;
/*!40000 ALTER TABLE `invoice_recurring` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_recurring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_recurring_item_images`
--

DROP TABLE IF EXISTS `invoice_recurring_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_recurring_item_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_recurring_item_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_recurring_item_images_invoice_recurring_item_id_foreign` (`invoice_recurring_item_id`),
  CONSTRAINT `invoice_recurring_item_images_invoice_recurring_item_id_foreign` FOREIGN KEY (`invoice_recurring_item_id`) REFERENCES `invoice_recurring_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_recurring_item_images`
--

LOCK TABLES `invoice_recurring_item_images` WRITE;
/*!40000 ALTER TABLE `invoice_recurring_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_recurring_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_recurring_items`
--

DROP TABLE IF EXISTS `invoice_recurring_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_recurring_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_recurring_id` bigint(20) unsigned NOT NULL,
  `item_name` varchar(191) NOT NULL,
  `quantity` double NOT NULL,
  `unit_price` double NOT NULL,
  `amount` double NOT NULL,
  `taxes` text DEFAULT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `item_summary` text DEFAULT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_recurring_items_invoice_recurring_id_foreign` (`invoice_recurring_id`),
  KEY `invoice_recurring_items_unit_id_foreign` (`unit_id`),
  KEY `invoice_recurring_items_product_id_foreign` (`product_id`),
  CONSTRAINT `invoice_recurring_items_invoice_recurring_id_foreign` FOREIGN KEY (`invoice_recurring_id`) REFERENCES `invoice_recurring` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoice_recurring_items_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_recurring_items`
--

LOCK TABLES `invoice_recurring_items` WRITE;
/*!40000 ALTER TABLE `invoice_recurring_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_recurring_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_settings`
--

DROP TABLE IF EXISTS `invoice_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `invoice_prefix` varchar(191) NOT NULL,
  `invoice_number_separator` varchar(191) NOT NULL DEFAULT '#',
  `invoice_digit` int(10) unsigned NOT NULL DEFAULT 3,
  `estimate_prefix` varchar(191) NOT NULL DEFAULT 'EST',
  `estimate_number_separator` varchar(191) NOT NULL DEFAULT '#',
  `estimate_digit` int(10) unsigned NOT NULL DEFAULT 3,
  `credit_note_prefix` varchar(191) NOT NULL DEFAULT 'CN',
  `credit_note_number_separator` varchar(191) NOT NULL DEFAULT '#',
  `credit_note_digit` int(10) unsigned NOT NULL DEFAULT 3,
  `contract_prefix` varchar(191) NOT NULL DEFAULT 'CONT',
  `contract_number_separator` varchar(191) NOT NULL DEFAULT '#',
  `contract_digit` int(10) unsigned NOT NULL DEFAULT 3,
  `order_prefix` varchar(191) NOT NULL DEFAULT 'ODR',
  `order_number_separator` varchar(191) NOT NULL DEFAULT '#',
  `order_digit` int(10) unsigned NOT NULL DEFAULT 3,
  `template` varchar(191) NOT NULL,
  `due_after` int(11) NOT NULL,
  `invoice_terms` text NOT NULL,
  `estimate_terms` text DEFAULT NULL,
  `gst_number` varchar(191) DEFAULT NULL,
  `show_gst` enum('yes','no') DEFAULT 'no',
  `logo` varchar(80) DEFAULT NULL,
  `hsn_sac_code_show` tinyint(1) NOT NULL DEFAULT 0,
  `locale` varchar(191) DEFAULT 'en',
  `send_reminder` int(11) NOT NULL DEFAULT 0,
  `reminder` enum('after','every') DEFAULT NULL,
  `send_reminder_after` int(11) NOT NULL DEFAULT 0,
  `tax_calculation_msg` tinyint(1) NOT NULL DEFAULT 0,
  `show_status` tinyint(1) NOT NULL DEFAULT 1,
  `authorised_signatory` tinyint(1) NOT NULL DEFAULT 0,
  `authorised_signatory_signature` varchar(191) DEFAULT NULL,
  `show_project` int(11) NOT NULL DEFAULT 0,
  `show_client_name` enum('yes','no') DEFAULT 'no',
  `show_client_email` enum('yes','no') DEFAULT 'no',
  `show_client_phone` enum('yes','no') DEFAULT 'no',
  `show_client_company_address` enum('yes','no') DEFAULT 'no',
  `show_client_company_name` enum('yes','no') DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `invoice_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_settings`
--

LOCK TABLES `invoice_settings` WRITE;
/*!40000 ALTER TABLE `invoice_settings` DISABLE KEYS */;
INSERT INTO `invoice_settings` VALUES (1,1,'INV','#',3,'EST','#',3,'CN','#',3,'CONT','#',3,'ODR','#',3,'invoice-5',15,'Thank you for your business.',NULL,NULL,'no',NULL,0,'en',0,NULL,0,0,1,0,NULL,0,'yes','yes','yes','yes','yes','2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,'INV','#',3,'EST','#',3,'CN','#',3,'CONT','#',3,'ODR','#',3,'invoice-5',15,'Thank you for your business.',NULL,NULL,'no',NULL,0,'en',0,NULL,0,0,1,0,NULL,0,'yes','yes','yes','yes','yes','2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,'INV','#',3,'EST','#',3,'CN','#',3,'CONT','#',3,'ODR','#',3,'invoice-5',15,'Thank you for your business.',NULL,NULL,'no',NULL,0,'en',0,NULL,0,0,1,0,NULL,0,'yes','yes','yes','yes','yes','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `invoice_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `invoice_number` bigint(20) NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `sub_total` double(16,2) NOT NULL,
  `discount` double NOT NULL DEFAULT 0,
  `discount_type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `total` double(16,2) NOT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `default_currency_id` int(10) unsigned DEFAULT NULL,
  `exchange_rate` double DEFAULT NULL,
  `status` enum('paid','unpaid','partial','canceled','draft') NOT NULL DEFAULT 'unpaid',
  `recurring` enum('yes','no') NOT NULL DEFAULT 'no',
  `billing_cycle` int(11) DEFAULT NULL,
  `billing_interval` int(11) DEFAULT NULL,
  `billing_frequency` varchar(191) DEFAULT NULL,
  `file` varchar(191) DEFAULT NULL,
  `file_original_name` varchar(191) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `credit_note` tinyint(1) NOT NULL DEFAULT 0,
  `show_shipping_address` enum('yes','no') NOT NULL DEFAULT 'no',
  `estimate_id` int(10) unsigned DEFAULT NULL,
  `send_status` tinyint(1) NOT NULL DEFAULT 1,
  `due_amount` double(8,2) NOT NULL DEFAULT 0.00,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `invoice_recurring_id` bigint(20) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `hash` text DEFAULT NULL,
  `calculate_tax` enum('after_discount','before_discount') NOT NULL DEFAULT 'after_discount',
  `company_address_id` bigint(20) unsigned DEFAULT NULL,
  `event_id` text DEFAULT NULL,
  `custom_invoice_number` varchar(191) DEFAULT NULL,
  `payment_status` enum('1','0') NOT NULL DEFAULT '0',
  `offline_method_id` int(10) unsigned DEFAULT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `gateway` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bank_account_id` int(10) unsigned DEFAULT NULL,
  `last_viewed` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  `quickbooks_invoice_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_company_id_unique` (`invoice_number`,`company_id`),
  UNIQUE KEY `invoices_transaction_id_unique` (`transaction_id`),
  KEY `invoices_company_id_foreign` (`company_id`),
  KEY `invoices_project_id_foreign` (`project_id`),
  KEY `invoices_client_id_foreign` (`client_id`),
  KEY `invoices_order_id_foreign` (`order_id`),
  KEY `invoices_due_date_index` (`due_date`),
  KEY `invoices_currency_id_foreign` (`currency_id`),
  KEY `invoices_estimate_id_foreign` (`estimate_id`),
  KEY `invoices_parent_id_foreign` (`parent_id`),
  KEY `invoices_invoice_recurring_id_foreign` (`invoice_recurring_id`),
  KEY `invoices_created_by_foreign` (`created_by`),
  KEY `invoices_added_by_foreign` (`added_by`),
  KEY `invoices_last_updated_by_foreign` (`last_updated_by`),
  KEY `invoices_company_address_id_foreign` (`company_address_id`),
  KEY `invoices_bank_account_id_foreign` (`bank_account_id`),
  KEY `invoices_default_currency_id_foreign` (`default_currency_id`),
  KEY `payments_offline_method_id_foreign` (`offline_method_id`),
  CONSTRAINT `invoices_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoices_bank_account_id_foreign` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoices_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoices_company_address_id_foreign` FOREIGN KEY (`company_address_id`) REFERENCES `company_addresses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoices_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  CONSTRAINT `invoices_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoices_default_currency_id_foreign` FOREIGN KEY (`default_currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoices_estimate_id_foreign` FOREIGN KEY (`estimate_id`) REFERENCES `estimates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoices_invoice_recurring_id_foreign` FOREIGN KEY (`invoice_recurring_id`) REFERENCES `invoice_recurring` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoices_offline_method_id_foreign` FOREIGN KEY (`offline_method_id`) REFERENCES `offline_payment_methods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoices_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoices_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `invoices_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `issues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `description` mediumtext NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `status` enum('pending','resolved') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issues_company_id_foreign` (`company_id`),
  KEY `issues_user_id_foreign` (`user_id`),
  KEY `issues_project_id_foreign` (`project_id`),
  CONSTRAINT `issues_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `issues_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `issues_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` text NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_interview_stages`
--

DROP TABLE IF EXISTS `job_interview_stages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_interview_stages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_id` bigint(20) unsigned NOT NULL,
  `recruit_interview_stage_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_interview_stages_recruit_job_id_foreign` (`recruit_job_id`),
  KEY `jis_recruit_interview_stage_id_foreign` (`recruit_interview_stage_id`),
  CONSTRAINT `jis_recruit_interview_stage_id_foreign` FOREIGN KEY (`recruit_interview_stage_id`) REFERENCES `recruit_interview_stages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `job_interview_stages_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_interview_stages`
--

LOCK TABLES `job_interview_stages` WRITE;
/*!40000 ALTER TABLE `job_interview_stages` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_interview_stages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'default','{\"uuid\":\"6aebd934-402f-487e-aab5-4f8ac4ef934d\",\"displayName\":\"Illuminate\\\\Foundation\\\\Console\\\\QueuedCommand\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Foundation\\\\Console\\\\QueuedCommand\",\"command\":\"O:43:\\\"Illuminate\\\\Foundation\\\\Console\\\\QueuedCommand\\\":10:{s:7:\\\"\\u0000*\\u0000data\\\";a:2:{i:0;s:10:\\\"backup:run\\\";i:1;a:2:{s:9:\\\"--only-db\\\";b:1;s:23:\\\"--disable-notifications\\\";b:1;}}s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1692596465,1692596465),(2,'default','{\"uuid\":\"c353566e-de21-4c7a-8e7b-991401e5a179\",\"displayName\":\"App\\\\Notifications\\\\SuperAdmin\\\\NewCompanyRegister\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:2:{i:0;s:13:\\\"clientDetails\\\";i:1;s:14:\\\"employeeDetail\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:47:\\\"App\\\\Notifications\\\\SuperAdmin\\\\NewCompanyRegister\\\":2:{s:59:\\\"\\u0000App\\\\Notifications\\\\SuperAdmin\\\\NewCompanyRegister\\u0000forCompany\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";N;s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"abbedbe6-73ba-4cb4-8cc9-615474e5eac4\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1692635119,1692635119),(3,'default','{\"uuid\":\"ce0c0a3d-9884-4fb4-bb0c-93222672c15e\",\"displayName\":\"App\\\\Notifications\\\\SuperAdmin\\\\NewCompanyRegister\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:2:{i:0;s:13:\\\"clientDetails\\\";i:1;s:14:\\\"employeeDetail\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:47:\\\"App\\\\Notifications\\\\SuperAdmin\\\\NewCompanyRegister\\\":2:{s:59:\\\"\\u0000App\\\\Notifications\\\\SuperAdmin\\\\NewCompanyRegister\\u0000forCompany\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";N;s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"abbedbe6-73ba-4cb4-8cc9-615474e5eac4\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1692635119,1692635119),(4,'default','{\"uuid\":\"6902eb49-b0ac-41e5-909f-e79702379f25\",\"displayName\":\"App\\\\Notifications\\\\NewUser\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:8;}s:9:\\\"relations\\\";a:2:{i:0;s:7:\\\"company\\\";i:1;s:15:\\\"company.package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:25:\\\"App\\\\Notifications\\\\NewUser\\\":4:{s:35:\\\"\\u0000App\\\\Notifications\\\\NewUser\\u0000password\\\";s:8:\\\"ibfim123\\\";s:39:\\\"\\u0000App\\\\Notifications\\\\NewUser\\u0000emailSetting\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:35:\\\"App\\\\Models\\\\EmailNotificationSetting\\\";s:2:\\\"id\\\";i:182;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:10:\\\"\\u0000*\\u0000company\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"5b239044-5e7b-424a-813e-8e453d19e963\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1692635119,1692635119),(5,'default','{\"uuid\":\"37e4171d-3ace-4c02-b5ee-073f99e6867c\",\"displayName\":\"App\\\\Notifications\\\\NewUser\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:8;}s:9:\\\"relations\\\";a:2:{i:0;s:7:\\\"company\\\";i:1;s:15:\\\"company.package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:25:\\\"App\\\\Notifications\\\\NewUser\\\":4:{s:35:\\\"\\u0000App\\\\Notifications\\\\NewUser\\u0000password\\\";s:8:\\\"ibfim123\\\";s:39:\\\"\\u0000App\\\\Notifications\\\\NewUser\\u0000emailSetting\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:35:\\\"App\\\\Models\\\\EmailNotificationSetting\\\";s:2:\\\"id\\\";i:182;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:10:\\\"\\u0000*\\u0000company\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"5b239044-5e7b-424a-813e-8e453d19e963\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1692635119,1692635119),(6,'default','{\"uuid\":\"6afd4bd0-f29f-4313-bfd8-5c834dcb19f8\",\"displayName\":\"App\\\\Notifications\\\\NewUser\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:9;}s:9:\\\"relations\\\";a:2:{i:0;s:7:\\\"company\\\";i:1;s:15:\\\"company.package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:25:\\\"App\\\\Notifications\\\\NewUser\\\":4:{s:35:\\\"\\u0000App\\\\Notifications\\\\NewUser\\u0000password\\\";s:8:\\\"syU84pJI\\\";s:39:\\\"\\u0000App\\\\Notifications\\\\NewUser\\u0000emailSetting\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:35:\\\"App\\\\Models\\\\EmailNotificationSetting\\\";s:2:\\\"id\\\";i:182;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:10:\\\"\\u0000*\\u0000company\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"e75c1326-6233-47e1-88b8-35d2456fe677\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1692635475,1692635475),(7,'default','{\"uuid\":\"daa8a365-0f02-44e6-9026-877e55897885\",\"displayName\":\"App\\\\Notifications\\\\NewUser\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:9;}s:9:\\\"relations\\\";a:2:{i:0;s:7:\\\"company\\\";i:1;s:15:\\\"company.package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:25:\\\"App\\\\Notifications\\\\NewUser\\\":4:{s:35:\\\"\\u0000App\\\\Notifications\\\\NewUser\\u0000password\\\";s:8:\\\"syU84pJI\\\";s:39:\\\"\\u0000App\\\\Notifications\\\\NewUser\\u0000emailSetting\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:35:\\\"App\\\\Models\\\\EmailNotificationSetting\\\";s:2:\\\"id\\\";i:182;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:10:\\\"\\u0000*\\u0000company\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"e75c1326-6233-47e1-88b8-35d2456fe677\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1692635475,1692635475),(8,'default','{\"uuid\":\"1b959785-8ff7-45c7-b44e-7930373ed3b8\",\"displayName\":\"App\\\\Notifications\\\\LeadAgentAssigned\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:8;}s:9:\\\"relations\\\";a:5:{i:0;s:14:\\\"employeeDetail\\\";i:1;s:26:\\\"employeeDetail.designation\\\";i:2;s:22:\\\"employeeDetail.company\\\";i:3;s:30:\\\"employeeDetail.company.package\\\";i:4;s:25:\\\"employeeDetail.department\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:35:\\\"App\\\\Notifications\\\\LeadAgentAssigned\\\":4:{s:41:\\\"\\u0000App\\\\Notifications\\\\LeadAgentAssigned\\u0000lead\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Lead\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:2:{i:0;s:7:\\\"company\\\";i:1;s:15:\\\"company.package\\\";}s:10:\\\"connection\\\";N;s:15:\\\"collectionClass\\\";N;}s:49:\\\"\\u0000App\\\\Notifications\\\\LeadAgentAssigned\\u0000emailSetting\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:35:\\\"App\\\\Models\\\\EmailNotificationSetting\\\";s:2:\\\"id\\\";i:178;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:10:\\\"\\u0000*\\u0000company\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"216273a3-cd15-4829-a530-ae6f92c2eaa8\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1692635721,1692635721),(9,'default','{\"uuid\":\"08afae44-e2bb-49bc-a1ca-048323a51ea9\",\"displayName\":\"App\\\\Notifications\\\\LeadAgentAssigned\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:8;}s:9:\\\"relations\\\";a:5:{i:0;s:14:\\\"employeeDetail\\\";i:1;s:26:\\\"employeeDetail.designation\\\";i:2;s:22:\\\"employeeDetail.company\\\";i:3;s:30:\\\"employeeDetail.company.package\\\";i:4;s:25:\\\"employeeDetail.department\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:35:\\\"App\\\\Notifications\\\\LeadAgentAssigned\\\":4:{s:41:\\\"\\u0000App\\\\Notifications\\\\LeadAgentAssigned\\u0000lead\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Lead\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:2:{i:0;s:7:\\\"company\\\";i:1;s:15:\\\"company.package\\\";}s:10:\\\"connection\\\";N;s:15:\\\"collectionClass\\\";N;}s:49:\\\"\\u0000App\\\\Notifications\\\\LeadAgentAssigned\\u0000emailSetting\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:35:\\\"App\\\\Models\\\\EmailNotificationSetting\\\";s:2:\\\"id\\\";i:178;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:10:\\\"\\u0000*\\u0000company\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"216273a3-cd15-4829-a530-ae6f92c2eaa8\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1692635721,1692635721),(10,'default','{\"uuid\":\"cd48bf55-0639-4567-85cf-6d01fea730d2\",\"displayName\":\"App\\\\Notifications\\\\NewProposal\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Lead\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:29:\\\"App\\\\Notifications\\\\NewProposal\\\":3:{s:39:\\\"\\u0000App\\\\Notifications\\\\NewProposal\\u0000proposal\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:19:\\\"App\\\\Models\\\\Proposal\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:3:{i:0;s:4:\\\"lead\\\";i:1;s:7:\\\"company\\\";i:2;s:15:\\\"company.package\\\";}s:10:\\\"connection\\\";N;s:15:\\\"collectionClass\\\";N;}s:10:\\\"\\u0000*\\u0000company\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"35a287c2-759e-4f91-b4eb-e98992a810ca\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}}\"}}',0,NULL,1692635753,1692635753),(11,'default','{\"uuid\":\"3aeb6536-b337-4ca5-8679-3c6ff26d14f7\",\"displayName\":\"App\\\\Notifications\\\\NewProposal\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\Lead\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:12:\\\"notification\\\";O:29:\\\"App\\\\Notifications\\\\NewProposal\\\":3:{s:39:\\\"\\u0000App\\\\Notifications\\\\NewProposal\\u0000proposal\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:19:\\\"App\\\\Models\\\\Proposal\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:3:{i:0;s:4:\\\"lead\\\";i:1;s:7:\\\"company\\\";i:2;s:15:\\\"company.package\\\";}s:10:\\\"connection\\\";N;s:15:\\\"collectionClass\\\";N;}s:10:\\\"\\u0000*\\u0000company\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:18:\\\"App\\\\Models\\\\Company\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:1:{i:0;s:7:\\\"package\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"id\\\";s:36:\\\"35a287c2-759e-4f91-b4eb-e98992a810ca\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1692635753,1692635753),(12,'default','{\"uuid\":\"7d3a5f6e-ac68-4d28-8c21-25dab66d5d12\",\"displayName\":\"App\\\\Notifications\\\\TestEmail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:29:\\\"Illuminate\\\\Support\\\\Collection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:44:\\\"Illuminate\\\\Notifications\\\\AnonymousNotifiable\\\":1:{s:6:\\\"routes\\\";a:1:{s:4:\\\"mail\\\";s:20:\\\"sm4rtkerja@gmail.com\\\";}}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:12:\\\"notification\\\";O:27:\\\"App\\\\Notifications\\\\TestEmail\\\":1:{s:2:\\\"id\\\";s:36:\\\"ef9dde8e-9165-4403-9c85-b41fd9357143\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1720973524,1720973524),(13,'default','{\"uuid\":\"b5812d2e-1016-4577-bc61-f05a8d6a7edf\",\"displayName\":\"App\\\\Notifications\\\\TestEmail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:29:\\\"Illuminate\\\\Support\\\\Collection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:44:\\\"Illuminate\\\\Notifications\\\\AnonymousNotifiable\\\":1:{s:6:\\\"routes\\\";a:1:{s:4:\\\"mail\\\";s:20:\\\"sm4rtkerja@gmail.com\\\";}}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:12:\\\"notification\\\";O:27:\\\"App\\\\Notifications\\\\TestEmail\\\":1:{s:2:\\\"id\\\";s:36:\\\"59b0deaa-103f-4c55-a2e9-0b950f8dc915\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1720973530,1720973530),(14,'default','{\"uuid\":\"6afa9dee-d331-4464-88f1-46c11115f570\",\"displayName\":\"App\\\\Notifications\\\\TestEmail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:29:\\\"Illuminate\\\\Support\\\\Collection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:44:\\\"Illuminate\\\\Notifications\\\\AnonymousNotifiable\\\":1:{s:6:\\\"routes\\\";a:1:{s:4:\\\"mail\\\";s:18:\\\"ibfimlms@gmail.com\\\";}}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:12:\\\"notification\\\";O:27:\\\"App\\\\Notifications\\\\TestEmail\\\":1:{s:2:\\\"id\\\";s:36:\\\"0c3eb989-b977-48fa-b857-19fc90552659\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1720973610,1720973610),(15,'default','{\"uuid\":\"6158b7af-774d-4362-8684-545565b65310\",\"displayName\":\"App\\\\Notifications\\\\TestEmail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":3:{s:11:\\\"notifiables\\\";O:29:\\\"Illuminate\\\\Support\\\\Collection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:44:\\\"Illuminate\\\\Notifications\\\\AnonymousNotifiable\\\":1:{s:6:\\\"routes\\\";a:1:{s:4:\\\"mail\\\";s:18:\\\"ibfimlms@gmail.com\\\";}}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:12:\\\"notification\\\";O:27:\\\"App\\\\Notifications\\\\TestEmail\\\":1:{s:2:\\\"id\\\";s:36:\\\"eeadfd7c-087e-4c5a-aec4-8d8f489906dd\\\";}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}}\"}}',0,NULL,1720973654,1720973654);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_files`
--

DROP TABLE IF EXISTS `knowledge_base_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_base_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `knowledge_base_id` int(10) unsigned NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `hashname` varchar(200) DEFAULT NULL,
  `size` varchar(200) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `external_link` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `knowledge_base_files_company_id_foreign` (`company_id`),
  KEY `knowledge_base_files_knowledge_base_id_foreign` (`knowledge_base_id`),
  KEY `knowledge_base_files_added_by_foreign` (`added_by`),
  KEY `knowledge_base_files_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `knowledge_base_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `knowledge_base_files_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `knowledge_base_files_knowledge_base_id_foreign` FOREIGN KEY (`knowledge_base_id`) REFERENCES `knowledge_bases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `knowledge_base_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_files`
--

LOCK TABLES `knowledge_base_files` WRITE;
/*!40000 ALTER TABLE `knowledge_base_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_bases`
--

DROP TABLE IF EXISTS `knowledge_bases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_bases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `to` varchar(191) NOT NULL DEFAULT 'employee',
  `heading` varchar(191) DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `added_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `knowledge_bases_company_id_foreign` (`company_id`),
  KEY `knowledge_bases_category_id_foreign` (`category_id`),
  CONSTRAINT `knowledge_bases_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `knowledge_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `knowledge_bases_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_bases`
--

LOCK TABLES `knowledge_bases` WRITE;
/*!40000 ALTER TABLE `knowledge_bases` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_bases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_categories`
--

DROP TABLE IF EXISTS `knowledge_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `knowledge_categories_company_id_foreign` (`company_id`),
  CONSTRAINT `knowledge_categories_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_categories`
--

LOCK TABLES `knowledge_categories` WRITE;
/*!40000 ALTER TABLE `knowledge_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_settings`
--

DROP TABLE IF EXISTS `language_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `language_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language_code` varchar(191) NOT NULL,
  `language_name` varchar(191) NOT NULL,
  `status` enum('enabled','disabled') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `flag_code` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_settings`
--

LOCK TABLES `language_settings` WRITE;
/*!40000 ALTER TABLE `language_settings` DISABLE KEYS */;
INSERT INTO `language_settings` VALUES (1,'en','English','enabled',NULL,NULL,'en'),(2,'ar','Arabic','disabled',NULL,NULL,'sa'),(3,'de','German','disabled',NULL,NULL,'de'),(4,'es','Spanish','disabled',NULL,NULL,'es'),(5,'et','Estonian','disabled',NULL,NULL,'et'),(6,'fa','Farsi','disabled',NULL,NULL,'ir'),(7,'fr','French','disabled',NULL,NULL,'fr'),(8,'gr','Greek','disabled',NULL,NULL,'gr'),(9,'it','Italian','disabled',NULL,NULL,'it'),(10,'nl','Dutch','disabled',NULL,NULL,'nl'),(11,'pl','Polish','disabled',NULL,NULL,'pl'),(12,'pt','Portuguese','disabled',NULL,NULL,'pt'),(13,'pt-br','Portuguese (Brazil)','disabled',NULL,NULL,'br'),(14,'ro','Romanian','disabled',NULL,NULL,'ro'),(15,'ru','Russian','disabled',NULL,NULL,'ru'),(16,'tr','Turkish','disabled',NULL,NULL,'tr'),(17,'zh-CN','Chinese (S)','disabled',NULL,NULL,'cn'),(18,'zh-TW','Chinese (T)','disabled',NULL,NULL,'cn');
/*!40000 ALTER TABLE `language_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_agents`
--

DROP TABLE IF EXISTS `lead_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_agents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'enabled',
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_agents_company_id_foreign` (`company_id`),
  KEY `lead_agents_user_id_foreign` (`user_id`),
  KEY `lead_agents_added_by_foreign` (`added_by`),
  KEY `lead_agents_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `lead_agents_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_agents_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_agents_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_agents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_agents`
--

LOCK TABLES `lead_agents` WRITE;
/*!40000 ALTER TABLE `lead_agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_category`
--

DROP TABLE IF EXISTS `lead_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_name` varchar(191) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_category_company_id_foreign` (`company_id`),
  KEY `lead_category_added_by_foreign` (`added_by`),
  KEY `lead_category_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `lead_category_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_category_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_category_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_category`
--

LOCK TABLES `lead_category` WRITE;
/*!40000 ALTER TABLE `lead_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_custom_forms`
--

DROP TABLE IF EXISTS `lead_custom_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_custom_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `custom_fields_id` int(10) unsigned DEFAULT NULL,
  `field_display_name` varchar(191) NOT NULL,
  `field_name` varchar(191) NOT NULL,
  `field_order` int(11) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_custom_forms_company_id_foreign` (`company_id`),
  KEY `lead_custom_forms_custom_fields_id_foreign` (`custom_fields_id`),
  KEY `lead_custom_forms_added_by_foreign` (`added_by`),
  KEY `lead_custom_forms_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `lead_custom_forms_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_custom_forms_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_custom_forms_custom_fields_id_foreign` FOREIGN KEY (`custom_fields_id`) REFERENCES `custom_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_custom_forms_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_custom_forms`
--

LOCK TABLES `lead_custom_forms` WRITE;
/*!40000 ALTER TABLE `lead_custom_forms` DISABLE KEYS */;
INSERT INTO `lead_custom_forms` VALUES (1,1,NULL,'Name','name',1,'active',1,NULL,NULL,NULL,NULL),(2,1,NULL,'Email','email',2,'active',0,NULL,NULL,NULL,NULL),(3,1,NULL,'Company Name','company_name',3,'active',0,NULL,NULL,NULL,NULL),(4,1,NULL,'Website','website',4,'active',0,NULL,NULL,NULL,NULL),(5,1,NULL,'Address','address',5,'active',0,NULL,NULL,NULL,NULL),(6,1,NULL,'Mobile','mobile',6,'active',0,NULL,NULL,NULL,NULL),(7,1,NULL,'Message','message',7,'active',0,NULL,NULL,NULL,NULL),(8,1,NULL,'City','city',1,'active',0,NULL,NULL,NULL,NULL),(9,1,NULL,'State','state',2,'active',0,NULL,NULL,NULL,NULL),(10,1,NULL,'Country','country',3,'active',0,NULL,NULL,NULL,NULL),(11,1,NULL,'Postal Code','postal_code',4,'active',0,NULL,NULL,NULL,NULL),(12,1,NULL,'Source','source',8,'active',0,NULL,NULL,NULL,NULL),(13,1,NULL,'Product','product',9,'active',0,NULL,NULL,NULL,NULL),(27,3,NULL,'Name','name',1,'active',1,NULL,NULL,NULL,NULL),(28,3,NULL,'Email','email',2,'active',0,NULL,NULL,NULL,NULL),(29,3,NULL,'Company Name','company_name',3,'active',0,NULL,NULL,NULL,NULL),(30,3,NULL,'Website','website',4,'active',0,NULL,NULL,NULL,NULL),(31,3,NULL,'Address','address',5,'active',0,NULL,NULL,NULL,NULL),(32,3,NULL,'Mobile','mobile',6,'active',0,NULL,NULL,NULL,NULL),(33,3,NULL,'Message','message',7,'active',0,NULL,NULL,NULL,NULL),(34,3,NULL,'City','city',1,'active',0,NULL,NULL,NULL,NULL),(35,3,NULL,'State','state',2,'active',0,NULL,NULL,NULL,NULL),(36,3,NULL,'Country','country',3,'active',0,NULL,NULL,NULL,NULL),(37,3,NULL,'Postal Code','postal_code',4,'active',0,NULL,NULL,NULL,NULL),(38,3,NULL,'Source','source',8,'active',0,NULL,NULL,NULL,NULL),(39,3,NULL,'Product','product',9,'active',0,NULL,NULL,NULL,NULL),(79,7,NULL,'Name','name',1,'active',1,NULL,NULL,NULL,NULL),(80,7,NULL,'Email','email',2,'active',0,NULL,NULL,NULL,NULL),(81,7,NULL,'Company Name','company_name',3,'active',0,NULL,NULL,NULL,NULL),(82,7,NULL,'Website','website',4,'active',0,NULL,NULL,NULL,NULL),(83,7,NULL,'Address','address',5,'active',0,NULL,NULL,NULL,NULL),(84,7,NULL,'Mobile','mobile',6,'active',0,NULL,NULL,NULL,NULL),(85,7,NULL,'Message','message',7,'active',0,NULL,NULL,NULL,NULL),(86,7,NULL,'City','city',1,'active',0,NULL,NULL,NULL,NULL),(87,7,NULL,'State','state',2,'active',0,NULL,NULL,NULL,NULL),(88,7,NULL,'Country','country',3,'active',0,NULL,NULL,NULL,NULL),(89,7,NULL,'Postal Code','postal_code',4,'active',0,NULL,NULL,NULL,NULL),(90,7,NULL,'Source','source',8,'active',0,NULL,NULL,NULL,NULL),(91,7,NULL,'Product','product',9,'active',0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lead_custom_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_files`
--

DROP TABLE IF EXISTS `lead_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `filename` varchar(200) NOT NULL,
  `hashname` varchar(200) NOT NULL,
  `size` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_files_lead_id_foreign` (`lead_id`),
  KEY `lead_files_user_id_foreign` (`user_id`),
  KEY `lead_files_added_by_foreign` (`added_by`),
  KEY `lead_files_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `lead_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_files_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_files`
--

LOCK TABLES `lead_files` WRITE;
/*!40000 ALTER TABLE `lead_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_follow_up`
--

DROP TABLE IF EXISTS `lead_follow_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_follow_up` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `remark` longtext DEFAULT NULL,
  `next_follow_up_date` datetime DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `event_id` text DEFAULT NULL,
  `send_reminder` enum('yes','no') DEFAULT 'no',
  `remind_time` text DEFAULT NULL,
  `remind_type` enum('minute','hour','day') DEFAULT NULL,
  `status` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_follow_up_lead_id_foreign` (`lead_id`),
  KEY `lead_follow_up_added_by_foreign` (`added_by`),
  KEY `lead_follow_up_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `lead_follow_up_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_follow_up_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_follow_up_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_follow_up`
--

LOCK TABLES `lead_follow_up` WRITE;
/*!40000 ALTER TABLE `lead_follow_up` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_follow_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_notes`
--

DROP TABLE IF EXISTS `lead_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `member_id` int(10) unsigned DEFAULT NULL,
  `is_lead_show` tinyint(1) NOT NULL DEFAULT 0,
  `ask_password` tinyint(1) NOT NULL DEFAULT 0,
  `details` longtext NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_notes_lead_id_foreign` (`lead_id`),
  KEY `lead_notes_member_id_foreign` (`member_id`),
  KEY `lead_notes_added_by_foreign` (`added_by`),
  KEY `lead_notes_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `lead_notes_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_notes_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_notes_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_notes_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_notes`
--

LOCK TABLES `lead_notes` WRITE;
/*!40000 ALTER TABLE `lead_notes` DISABLE KEYS */;
INSERT INTO `lead_notes` VALUES (1,1,'Note',0,NULL,0,0,'',8,8,'2023-08-21 16:35:21','2023-08-21 16:35:21');
/*!40000 ALTER TABLE `lead_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_products`
--

DROP TABLE IF EXISTS `lead_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_products_lead_id_foreign` (`lead_id`),
  KEY `lead_products_product_id_foreign` (`product_id`),
  CONSTRAINT `lead_products_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_products`
--

LOCK TABLES `lead_products` WRITE;
/*!40000 ALTER TABLE `lead_products` DISABLE KEYS */;
INSERT INTO `lead_products` VALUES (1,1,1,'2023-08-21 16:35:21','2023-08-21 16:35:21');
/*!40000 ALTER TABLE `lead_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_sources`
--

DROP TABLE IF EXISTS `lead_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_sources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(191) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lead_sources_type_company_id_unique` (`type`,`company_id`),
  KEY `lead_sources_company_id_foreign` (`company_id`),
  KEY `lead_sources_added_by_foreign` (`added_by`),
  KEY `lead_sources_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `lead_sources_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `lead_sources_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_sources_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_sources`
--

LOCK TABLES `lead_sources` WRITE;
/*!40000 ALTER TABLE `lead_sources` DISABLE KEYS */;
INSERT INTO `lead_sources` VALUES (1,1,'email',NULL,NULL,NULL,NULL),(2,1,'google',NULL,NULL,NULL,NULL),(3,1,'facebook',NULL,NULL,NULL,NULL),(4,1,'friend',NULL,NULL,NULL,NULL),(5,1,'direct visit',NULL,NULL,NULL,NULL),(6,1,'tv ad',NULL,NULL,NULL,NULL),(13,3,'email',NULL,NULL,NULL,NULL),(14,3,'google',NULL,NULL,NULL,NULL),(15,3,'facebook',NULL,NULL,NULL,NULL),(16,3,'friend',NULL,NULL,NULL,NULL),(17,3,'direct visit',NULL,NULL,NULL,NULL),(18,3,'tv ad',NULL,NULL,NULL,NULL),(37,7,'email',NULL,NULL,NULL,NULL),(38,7,'google',NULL,NULL,NULL,NULL),(39,7,'facebook',NULL,NULL,NULL,NULL),(40,7,'friend',NULL,NULL,NULL,NULL),(41,7,'direct visit',NULL,NULL,NULL,NULL),(42,7,'tv ad',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lead_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_status`
--

DROP TABLE IF EXISTS `lead_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(191) NOT NULL,
  `priority` int(11) NOT NULL,
  `default` tinyint(1) NOT NULL,
  `label_color` varchar(191) NOT NULL DEFAULT '#ff0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lead_status_type_company_id_unique` (`type`,`company_id`),
  KEY `lead_status_company_id_foreign` (`company_id`),
  CONSTRAINT `lead_status_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_status`
--

LOCK TABLES `lead_status` WRITE;
/*!40000 ALTER TABLE `lead_status` DISABLE KEYS */;
INSERT INTO `lead_status` VALUES (1,1,'pending',1,1,'#FFE700',NULL,NULL),(2,1,'in process',2,0,'#009EFF',NULL,NULL),(3,1,'done',3,0,'#1FAE07',NULL,NULL),(7,3,'pending',1,1,'#FFE700',NULL,NULL),(8,3,'in process',2,0,'#009EFF',NULL,NULL),(9,3,'done',3,0,'#1FAE07',NULL,NULL),(19,7,'pending',1,1,'#FFE700',NULL,NULL),(20,7,'in process',2,0,'#009EFF',NULL,NULL),(21,7,'done',3,0,'#1FAE07',NULL,NULL);
/*!40000 ALTER TABLE `lead_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_user_notes`
--

DROP TABLE IF EXISTS `lead_user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lead_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `lead_note_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_user_notes_user_id_foreign` (`user_id`),
  KEY `lead_user_notes_lead_note_id_foreign` (`lead_note_id`),
  CONSTRAINT `lead_user_notes_lead_note_id_foreign` FOREIGN KEY (`lead_note_id`) REFERENCES `lead_notes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lead_user_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_user_notes`
--

LOCK TABLES `lead_user_notes` WRITE;
/*!40000 ALTER TABLE `lead_user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `source_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `column_priority` int(11) NOT NULL,
  `agent_id` bigint(20) unsigned DEFAULT NULL,
  `company_name` varchar(191) DEFAULT NULL,
  `website` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `salutation` enum('mr','mrs','miss','dr','sir','madam') DEFAULT NULL,
  `client_name` varchar(191) NOT NULL,
  `client_email` varchar(191) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `cell` varchar(191) DEFAULT NULL,
  `office` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `postal_code` varchar(191) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `next_follow_up` enum('yes','no') NOT NULL DEFAULT 'yes',
  `value` double DEFAULT 0,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `hash` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leads_company_id_foreign` (`company_id`),
  KEY `leads_agent_id_foreign` (`agent_id`),
  KEY `leads_currency_id_foreign` (`currency_id`),
  KEY `leads_category_id_foreign` (`category_id`),
  KEY `leads_added_by_foreign` (`added_by`),
  KEY `leads_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `leads_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leads_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `lead_agents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `leads_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `lead_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leads_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `leads_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leads_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

LOCK TABLES `leads` WRITE;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
INSERT INTO `leads` VALUES (1,7,NULL,NULL,19,0,NULL,NULL,NULL,NULL,'mr','Shahrul Nizam','nafasdoa2023@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','yes',5000,33,NULL,8,8,'95c2cc8b8403de31510be5effce85dc5','2023-08-21 16:35:21','2023-08-21 16:35:21');
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_files`
--

DROP TABLE IF EXISTS `leave_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_files` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `leave_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_files_company_id_foreign` (`company_id`),
  KEY `leave_files_user_id_foreign` (`user_id`),
  KEY `leave_files_leave_id_foreign` (`leave_id`),
  KEY `leave_files_added_by_foreign` (`added_by`),
  KEY `leave_files_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `leave_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leave_files_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `leave_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leave_files_leave_id_foreign` FOREIGN KEY (`leave_id`) REFERENCES `leaves` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `leave_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_files`
--

LOCK TABLES `leave_files` WRITE;
/*!40000 ALTER TABLE `leave_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `leave_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_settings`
--

DROP TABLE IF EXISTS `leave_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `manager_permission` enum('pre-approve','approved','cannot-approve') NOT NULL DEFAULT 'pre-approve',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `leave_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_settings`
--

LOCK TABLES `leave_settings` WRITE;
/*!40000 ALTER TABLE `leave_settings` DISABLE KEYS */;
INSERT INTO `leave_settings` VALUES (1,1,'pre-approve','2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,'pre-approve','2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,'pre-approve','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `leave_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leave_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `type_name` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  `no_of_leaves` int(11) NOT NULL DEFAULT 5,
  `paid` tinyint(1) NOT NULL DEFAULT 1,
  `monthly_limit` int(11) NOT NULL DEFAULT 0,
  `effective_after` int(11) DEFAULT NULL,
  `effective_type` varchar(191) DEFAULT NULL,
  `unused_leave` varchar(191) DEFAULT NULL,
  `encashed` tinyint(1) NOT NULL,
  `allowed_probation` tinyint(1) NOT NULL,
  `allowed_notice` tinyint(1) NOT NULL,
  `gender` varchar(191) DEFAULT NULL,
  `marital_status` varchar(191) DEFAULT NULL,
  `department` varchar(191) DEFAULT NULL,
  `designation` varchar(191) DEFAULT NULL,
  `role` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leave_types_company_id_foreign` (`company_id`),
  CONSTRAINT `leave_types_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_types`
--

LOCK TABLES `leave_types` WRITE;
/*!40000 ALTER TABLE `leave_types` DISABLE KEYS */;
INSERT INTO `leave_types` VALUES (1,1,'Casual','#16813D',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]','[1]','[1]','[1,2]',NULL,'2023-08-21 05:44:28'),(2,1,'Sick','#DB1313',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]','[1]','[1]','[1,2]',NULL,'2023-08-21 05:44:28'),(3,1,'Earned','#B078C6',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]','[1]','[1]','[1,2]',NULL,'2023-08-21 05:44:28'),(7,3,'Casual','#16813D',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]',NULL,NULL,'[8,9]',NULL,NULL),(8,3,'Sick','#DB1313',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]',NULL,NULL,'[8,9]',NULL,NULL),(9,3,'Earned','#B078C6',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]',NULL,NULL,'[8,9]',NULL,NULL),(19,7,'Casual','#16813D',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]',NULL,NULL,'[20,21]',NULL,NULL),(20,7,'Sick','#DB1313',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]',NULL,NULL,'[20,21]',NULL,NULL),(21,7,'Earned','#B078C6',5,1,0,NULL,NULL,NULL,0,0,0,'[\"male\",\"female\",\"others\"]','[\"married\",\"unmarried\"]',NULL,NULL,'[20,21]',NULL,NULL);
/*!40000 ALTER TABLE `leave_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leaves`
--

DROP TABLE IF EXISTS `leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leaves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `leave_type_id` int(10) unsigned NOT NULL,
  `unique_id` varchar(191) DEFAULT NULL,
  `duration` varchar(191) NOT NULL,
  `leave_date` date NOT NULL,
  `reason` text NOT NULL,
  `status` enum('approved','pending','rejected') NOT NULL,
  `reject_reason` text DEFAULT NULL,
  `paid` tinyint(1) NOT NULL DEFAULT 0,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `event_id` text DEFAULT NULL,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `half_day_type` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `manager_status_permission` enum('pre-approve','approved') DEFAULT NULL,
  `approve_reason` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leaves_company_id_foreign` (`company_id`),
  KEY `leaves_user_id_foreign` (`user_id`),
  KEY `leaves_leave_type_id_foreign` (`leave_type_id`),
  KEY `leaves_leave_date_index` (`leave_date`),
  KEY `leaves_added_by_foreign` (`added_by`),
  KEY `leaves_last_updated_by_foreign` (`last_updated_by`),
  KEY `leaves_approved_by_foreign` (`approved_by`),
  CONSTRAINT `leaves_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leaves_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leaves_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `leaves_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `leaves_leave_type_id_foreign` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `leaves_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leaves`
--

LOCK TABLES `leaves` WRITE;
/*!40000 ALTER TABLE `leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `leaves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_time_for`
--

DROP TABLE IF EXISTS `log_time_for`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_time_for` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `log_time_for` enum('project','task') NOT NULL DEFAULT 'project',
  `auto_timer_stop` enum('yes','no') NOT NULL DEFAULT 'no',
  `approval_required` tinyint(1) NOT NULL,
  `tracker_reminder` tinyint(1) NOT NULL,
  `timelog_report` tinyint(1) NOT NULL,
  `daily_report_roles` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `log_time_for_company_id_foreign` (`company_id`),
  CONSTRAINT `log_time_for_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_time_for`
--

LOCK TABLES `log_time_for` WRITE;
/*!40000 ALTER TABLE `log_time_for` DISABLE KEYS */;
INSERT INTO `log_time_for` VALUES (1,1,'project','no',0,0,0,NULL,'2023-08-10 14:06:55','2023-08-10 14:06:55',NULL),(3,3,'project','no',0,0,0,NULL,'2023-08-10 14:17:22','2023-08-10 14:17:22',NULL),(7,7,'project','no',0,0,0,NULL,'2023-08-21 16:25:19','2023-08-21 16:25:19',NULL);
/*!40000 ALTER TABLE `log_time_for` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ltm_translations`
--

DROP TABLE IF EXISTS `ltm_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ltm_translations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL DEFAULT 0,
  `locale` varchar(191) NOT NULL,
  `group` varchar(191) NOT NULL,
  `key` varchar(191) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ltm_translations`
--

LOCK TABLES `ltm_translations` WRITE;
/*!40000 ALTER TABLE `ltm_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ltm_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mention_users`
--

DROP TABLE IF EXISTS `mention_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mention_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task_comment_id` int(10) unsigned DEFAULT NULL,
  `task_note_id` int(10) unsigned DEFAULT NULL,
  `task_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `project_note_id` int(10) unsigned DEFAULT NULL,
  `discussion_id` int(10) unsigned DEFAULT NULL,
  `ticket_id` int(10) unsigned DEFAULT NULL,
  `event_id` int(10) unsigned DEFAULT NULL,
  `user_chat_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `discussion_reply_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mention_users_task_comment_id_foreign` (`task_comment_id`),
  KEY `mention_users_task_note_id_foreign` (`task_note_id`),
  KEY `mention_users_task_id_foreign` (`task_id`),
  KEY `mention_users_project_id_foreign` (`project_id`),
  KEY `mention_users_project_note_id_foreign` (`project_note_id`),
  KEY `mention_users_discussion_id_foreign` (`discussion_id`),
  KEY `mention_users_user_id_foreign` (`user_id`),
  KEY `mention_users_discussion_reply_id_foreign` (`discussion_reply_id`),
  KEY `mention_users_ticket_id_foreign` (`ticket_id`),
  KEY `mention_users_event_id_foreign` (`event_id`),
  KEY `mention_users_user_chat_id_foreign` (`user_chat_id`),
  CONSTRAINT `mention_users_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_discussion_reply_id_foreign` FOREIGN KEY (`discussion_reply_id`) REFERENCES `discussion_replies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_project_note_id_foreign` FOREIGN KEY (`project_note_id`) REFERENCES `project_notes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_task_comment_id_foreign` FOREIGN KEY (`task_comment_id`) REFERENCES `task_comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_task_note_id_foreign` FOREIGN KEY (`task_note_id`) REFERENCES `task_notes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_user_chat_id_foreign` FOREIGN KEY (`user_chat_id`) REFERENCES `users_chat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mention_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mention_users`
--

LOCK TABLES `mention_users` WRITE;
/*!40000 ALTER TABLE `mention_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `mention_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_settings`
--

DROP TABLE IF EXISTS `menu_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `main_menu` longtext DEFAULT NULL,
  `default_main_menu` longtext DEFAULT NULL,
  `setting_menu` longtext DEFAULT NULL,
  `default_setting_menu` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_settings`
--

LOCK TABLES `menu_settings` WRITE;
/*!40000 ALTER TABLE `menu_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) NOT NULL,
  `translate_name` varchar(191) DEFAULT NULL,
  `route` varchar(100) DEFAULT NULL,
  `module` varchar(191) DEFAULT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `setting_menu` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menus`
--

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_settings`
--

DROP TABLE IF EXISTS `message_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `allow_client_admin` enum('yes','no') NOT NULL DEFAULT 'no',
  `allow_client_employee` enum('yes','no') NOT NULL DEFAULT 'no',
  `restrict_client` enum('yes','no') NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `send_sound_notification` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `message_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `message_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_settings`
--

LOCK TABLES `message_settings` WRITE;
/*!40000 ALTER TABLE `message_settings` DISABLE KEYS */;
INSERT INTO `message_settings` VALUES (1,1,'no','no','no','2023-08-10 14:06:55','2023-08-10 14:06:55',0),(3,3,'no','no','no','2023-08-10 14:17:22','2023-08-10 14:17:22',0),(7,7,'no','no','no','2023-08-21 16:25:19','2023-08-21 16:25:19',0);
/*!40000 ALTER TABLE `message_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2017_01_01_000000_create_worksuite_table_collation_fix',1),(2,'2018_01_01_000000_create_worksuite_new_table',1),(3,'2018_01_01_000000_create_worksuite_saas_upgrade_new_table',1),(4,'2018_02_01_000000_create_worksuite_saas_upgrade_fix_table',1),(5,'2022_07_04_111754_add_project_short_code_column_project_table',1),(6,'2022_07_14_063826_contract_templates',1),(7,'2022_07_22_042424_create_proposal_templates_table',1),(8,'2022_07_28_043824_add_export_column_custom_fields_table',1),(9,'2022_08_03_101616_create_event_files_table',1),(10,'2022_08_12_000000_create_other_migration_till_date_table',1),(11,'2022_08_13_070443_add_task_unique_id_column_tasks_table',1),(12,'2022_08_18_120924_create_task_settings_table',1),(13,'2022_08_19_100314_add_leave_widget_in_dashboard_widget_table',1),(14,'2022_08_19_115209_create_project_status_settings_table',1),(15,'2022_08_22_104028_knowledge_heading_missing',1),(16,'2022_08_23_065943_change_status_type_projects_table',1),(17,'2022_08_24_122345_add_lead_widget_in_dashboard_widget_table',1),(18,'2022_08_25_085025_add_other_location_to_attendances_table',1),(19,'2022_08_25_123713_add_work_from_home_widget_in_dashboard_widgets_table',1),(20,'2022_08_26_042542_remove_on_delete_cascade_from_invoice_recurring_id_to_invoices',1),(21,'2022_08_26_053139_add_parent_id_column_designation_table',1),(22,'2022_08_29_064339_add_added_by_to_project_template',1),(23,'2022_08_29_103443_add_flag_code_column_to_language_settings',1),(24,'2022_09_00_000000_create_company_table',1),(25,'2022_09_01_000000_add_company_id_in_all_table',1),(26,'2022_09_01_060824_create_appreciations_table',1),(27,'2022_09_01_083053_create_global_settings_table',1),(28,'2022_09_02_151515_create_flags_table',1),(29,'2022_09_05_064405_add_miro_board_column_in_project_table',1),(30,'2022_09_07_172743_add_lead_status_column_to_permissions',1),(31,'2022_09_13_075642_add_customised_permission_column',1),(32,'2022_09_13_075642_create_leave_settings_table',1),(33,'2022_09_16_071005_add_headcount_and_joining_vs_attrition_widget_in_dashboard_widget_table',1),(34,'2022_09_16_105720_update_permission_of_client_and_employee_document',1),(35,'2022_09_19_124014_add_delete_approve_leave_in_permission_table',1),(36,'2022_09_20_045836_add_bank_account_module_in_module_table',1),(37,'2022_09_23_053942_update_type_of_hsn_sac_code_to_proposal_template_items',1),(38,'2022_09_23_181722_add_approve_reason_column_to_leaves_table',1),(39,'2022_10_03_080325_create_super_admin_tables_table',1),(40,'2022_10_09_155207_add_custom_year_to_companies_table',1),(41,'2022_10_19_112953_create_user_auths_table',1),(42,'2022_10_31_130459_order_with_order_number',1),(43,'2022_11_03_115958_add_auto_clock_in_location_to_attendance_settings_table',1),(44,'2022_11_16_122431_add_contract_note_to_contracts_table',1),(45,'2022_11_23_070556_show_new_webhook_alert',1),(46,'2022_11_24_112953_create_global_payment_gateway_credentials_table',1),(47,'2022_11_25_083742_add_company_id_for_null_values',1),(48,'2022_12_01_070705_create_leave_files_table',1),(49,'2022_12_05_062331_create_emoji_address_ticket_widget_table',1),(50,'2022_12_12_113800_add_wasabi_hash_test_payfast',1),(51,'2022_12_13_071454_add_currency_id_in_currency_format_table',1),(52,'2022_12_13_112213_add_new_fields_in_employee_details_table',1),(53,'2022_12_28_112213_add_new_fields_in_companies_table',1),(54,'2022_12_29_061634_add_column_in_invoice_table',1),(55,'2022_12_29_084526_create_subscriptions_table',1),(56,'2022_12_30_045028_add_number_separator_to_invoice_settings_table',1),(57,'2022_12_30_090615_move_google_map_key',1),(58,'2023_01_05_084453_add_column_in_log_time_table',1),(59,'2023_01_09_162235_create_estimate_templates_table',1),(60,'2023_01_11_080325_create_super_admin_paystack_subscription_tables_table',1),(61,'2023_01_20_052539_create_unit_types_table',1),(62,'2023_01_23_122023_add_column_in_invoice_recurring_table',1),(63,'2023_01_31_072924_add_settings_to_email_notification_settings',1),(64,'2023_02_01_085841_add_company_sign_contracts_table',1),(65,'2023_02_04_064358_create_lead_products_table',1),(66,'2023_02_07_122807_create_quick_books_settings_table',1),(67,'2023_02_09_083357_create_passprt_and_visa_table',1),(68,'2023_02_13_045833_add_report_column_in_log_time_table',1),(69,'2023_02_15_045950_add_unit_id_orders_table',1),(70,'2023_02_15_121548_add_data_in_ticket_custom_forms_table',1),(71,'2023_02_17_052112_add_permissions_for_lead_report',1),(72,'2023_02_27_081104_add_column_in_leave_type_table',1),(73,'2023_03_02_065728_custom_fileds_data_fix',1),(74,'2023_03_05_065728_missing_data_fix',1),(75,'2023_03_16_105629_add_manage_ticket_group_field_in_permission_table',1),(76,'2023_03_17_045842_lead_custom_field',1),(77,'2023_03_21_090422_add_order_prefix_in_invoice_settings_table',1),(78,'2023_03_21_095340_add_column_in_attendance_setting_table',1),(79,'2023_03_21_095341_create_role_permission_superadmin_table',1),(80,'2023_03_21_120725_fix_global_invoices_saas_fix',1),(81,'2023_03_23_064221_add_country_phonecode_column_in_users_table',1),(82,'2023_03_24_073030_add_payment_columns_in_invoices_table',1),(83,'2023_03_24_081626_add_permission_for_sales_report',1),(84,'2023_03_29_072032_create_order_carts_table',1),(85,'2023_03_29_090137_create_custom_link_settings_table',1),(86,'2023_03_30_191625_add_restrict_admin_theme_change_column_theme_settings',1),(87,'2023_03_31_123237_fix_timelog_project_id',1),(88,'2023_04_03_132318_fix_invoice_units',2),(89,'2023_04_04_101429_google_calendar_keys_move_to_global_settings',2),(90,'2023_04_11_083659_add_bank_column_in_recurring_invoice_table',2),(91,'2023_04_11_092420_add_overwrite_existing_attendance_column_in_attendances_table',2),(92,'2023_04_11_101429_task_hash_insert_in_task_table',2),(93,'2023_04_12_073033_add_contract_setting_permission',2),(94,'2023_04_14_110419_add_send_status_column_in_proposals_table',2),(95,'2023_04_17_085738_add_visible_column_in_custom_fields_table',2),(96,'2023_04_18_061829_add_file_column_in_employee_shift_schedules_table',2),(97,'2023_04_18_124728_create_mention_users_table',2),(98,'2023_04_19_100128_add_auth_theme_text_to_global_settings_table',2),(99,'2023_04_27_082330_create_invoice_files_table',2),(100,'2023_05_02_100907_fix_bug',2),(101,'2023_05_04_083334_add_early_clock_in_employee_shift_table',2),(102,'2023_05_07_120424_add_email_verification_code_column_user_auths_table',2),(103,'2023_05_16_083058_add_ids_in_mention_users_table',2),(104,'2023_05_16_083334_add_allow_max_file_to_global_settings_table',2),(105,'2023_05_16_085400_remove_translations',2),(106,'2023_05_16_114755_file_upload_to_s3',2),(107,'2023_05_21_113800_add_minio_s3',2),(108,'2023_05_31_052844_add_user_chat_id_in_mention_users_table',2),(109,'2023_06_12_094139_fix_file_upload_to_s3',2),(110,'2023_06_12_094906_fix_file_upload_to_s3_saas',2),(111,'2023_06_15_104818_fix_company_packages',2),(112,'2023_06_15_120113_remove_user_from_user_auth_table_for_forget_password',2),(113,'2023_06_19_090642_add_active_column_in_dashboard_widgets_table',2),(114,'2023_06_22_070900_fix_module_is_superadmin',2),(115,'2023_06_23_044723_fix_user-permissions',2),(116,'2023_06_28_120547_alter_description_column_in_expenses_table',2),(117,'2023_07_10_064057_add_shift_assign_notification_setting',2),(118,'2023_07_13_064630_create_package_update_notifies_table',2),(119,'2023_07_13_113131_add_term_column_in_global_settings_table',2),(120,'2019_10_01_184956_create_salary_groups_table',3),(121,'2019_10_07_191322_create_salary_components_table',3),(122,'2019_10_07_192042_create_salary_tds_table_table',3),(123,'2019_10_10_114655_create_salary_group_components_table',3),(124,'2019_10_10_115749_create_employee_salary_groups_table',3),(125,'2019_10_18_095840_create_salary_slips_table',3),(126,'2019_10_18_111743_create_employee_monthly_salary_table',3),(127,'2019_10_22_124159_add_columns_salary_slips_table',3),(128,'2019_10_23_181854_create_payroll_settings_table',3),(129,'2019_10_30_121810_add_tds_column_salary_slips_table',3),(130,'2019_11_13_084620_add_gross_salary_column_salary_slips_table',3),(131,'2019_11_21_122601_add_purchase_code_column_payroll_settings_table',3),(132,'2021_08_25_092728_alter_allowed_permission_column_in_payroll_permissions_table',3),(133,'2021_08_28_123557_add_owned_by_columns_payrolls',3),(134,'2021_09_12_061155_payroll_custom_field_table',3),(135,'2021_09_21_073111_create_payroll_cycle_table',3),(136,'2021_09_21_081203_create_employee_payroll_cycle_table',3),(137,'2022_02_16_124407_fix_payroll_permissions',3),(138,'2022_08_18_071222_alter_in_salary_components_table',3),(139,'2022_08_24_093601_add_column_in_employee_monthly_salaries_table',3),(140,'2022_08_24_095802_create_employee_variable_commponent_salaries_table',3),(141,'2022_09_01_000000_create_payroll_global_settings',3),(142,'2022_09_02_000000_add_company_id_payroll_module_table',3),(143,'2022_09_15_051422_add_column_in_payroll_settings_table',3),(144,'2022_09_21_061658_add_column_weekly_in_salary_components_table',3),(145,'2022_10_18_061658_add_column_fixed_salary_slip_table',3),(146,'2022_11_24_071222_alter_currency_id_payroll_setting_table',3),(147,'2022_12_21_071222_add_currency_id_column_in_salary_slip_table',3),(148,'2023_01_01_071222_fix_currency_id_column_in_salary_slip_table',3),(149,'2023_01_01_071222_payroll_cycle_insert_users_table',3),(150,'2023_01_01_071222_salary_tds_company_table',3),(151,'2023_03_31_071222_expenses_id_column_in_salary_slip_table',3),(152,'2023_04_04_090201_add_column_fixed_allowance_in_employee_monthly_salaries_table',3),(153,'2021_11_30_070320_create_recruit_skills',4),(154,'2022_07_18_082515_add_column_in_recruit_job_applications_table',4),(155,'2022_09_01_000000_create_recruit_global_settings',4),(156,'2022_09_15_061628_create_recruit_job_category',4),(157,'2022_10_01_000000_add_company_id_recruit_module_table',4),(158,'2023_01_10_100953_create_custom_questions_table',4),(159,'2023_01_23_082501_add_column_in_recruit_settings_table',4),(160,'2023_02_02_112041_add_column_in_recruit_settings_table',4),(161,'2023_02_03_121345_create_recruit_salary_structure_table',4),(162,'2023_04_25_112258_add_column_in_recruit_interview_comments',4),(163,'2023_06_12_094140_fix_file_upload_to_s3',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `module_settings`
--

DROP TABLE IF EXISTS `module_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `module_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `module_name` varchar(191) NOT NULL,
  `status` enum('active','deactive') NOT NULL,
  `type` enum('admin','employee','client') NOT NULL DEFAULT 'admin',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `module_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `module_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=459 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module_settings`
--

LOCK TABLES `module_settings` WRITE;
/*!40000 ALTER TABLE `module_settings` DISABLE KEYS */;
INSERT INTO `module_settings` VALUES (1,1,'clients','active','admin',NULL,'2023-08-21 05:42:40',1),(2,1,'projects','active','admin',NULL,'2023-08-21 05:42:40',1),(3,1,'tickets','active','admin',NULL,'2023-08-21 05:42:40',1),(4,1,'invoices','active','admin',NULL,'2023-08-21 05:42:40',1),(5,1,'estimates','active','admin',NULL,'2023-08-21 05:42:40',1),(6,1,'events','active','admin',NULL,'2023-08-21 05:42:40',1),(7,1,'messages','active','admin',NULL,'2023-08-21 05:42:40',1),(8,1,'tasks','active','admin',NULL,'2023-08-21 05:42:40',1),(9,1,'timelogs','active','admin',NULL,'2023-08-21 05:42:40',1),(10,1,'contracts','active','admin',NULL,'2023-08-21 05:42:40',1),(11,1,'notices','active','admin',NULL,'2023-08-21 05:42:40',1),(12,1,'payments','active','admin',NULL,'2023-08-21 05:42:40',1),(13,1,'orders','active','admin',NULL,'2023-08-21 05:42:40',1),(14,1,'knowledgebase','active','admin',NULL,'2023-08-21 05:42:40',1),(15,1,'employees','active','admin',NULL,'2023-08-21 05:42:40',1),(16,1,'attendance','active','admin',NULL,'2023-08-21 05:42:40',1),(17,1,'expenses','active','admin',NULL,'2023-08-21 05:42:40',1),(18,1,'leaves','active','admin',NULL,'2023-08-21 05:42:40',1),(19,1,'leads','active','admin',NULL,'2023-08-21 05:42:40',1),(20,1,'holidays','active','admin',NULL,'2023-08-21 05:42:40',1),(21,1,'products','active','admin',NULL,'2023-08-21 05:42:40',1),(22,1,'reports','active','admin',NULL,'2023-08-21 05:42:40',1),(23,1,'settings','deactive','admin',NULL,'2023-08-21 05:42:40',0),(24,1,'bankaccount','active','admin',NULL,'2023-08-21 05:42:40',1),(25,1,'clients','active','employee',NULL,'2023-08-21 05:42:40',1),(26,1,'projects','active','employee',NULL,'2023-08-21 05:42:40',1),(27,1,'tickets','active','employee',NULL,'2023-08-21 05:42:40',1),(28,1,'invoices','active','employee',NULL,'2023-08-21 05:42:40',1),(29,1,'estimates','active','employee',NULL,'2023-08-21 05:42:40',1),(30,1,'events','active','employee',NULL,'2023-08-21 05:42:40',1),(31,1,'messages','active','employee',NULL,'2023-08-21 05:42:40',1),(32,1,'tasks','active','employee',NULL,'2023-08-21 05:42:40',1),(33,1,'timelogs','active','employee',NULL,'2023-08-21 05:42:40',1),(34,1,'contracts','active','employee',NULL,'2023-08-21 05:42:40',1),(35,1,'notices','active','employee',NULL,'2023-08-21 05:42:40',1),(36,1,'payments','active','employee',NULL,'2023-08-21 05:42:40',1),(37,1,'orders','active','employee',NULL,'2023-08-21 05:42:40',1),(38,1,'knowledgebase','active','employee',NULL,'2023-08-21 05:42:40',1),(39,1,'employees','active','employee',NULL,'2023-08-21 05:42:40',1),(40,1,'attendance','active','employee',NULL,'2023-08-21 05:42:40',1),(41,1,'expenses','active','employee',NULL,'2023-08-21 05:42:40',1),(42,1,'leaves','active','employee',NULL,'2023-08-21 05:42:40',1),(43,1,'leads','active','employee',NULL,'2023-08-21 05:42:40',1),(44,1,'holidays','active','employee',NULL,'2023-08-21 05:42:40',1),(45,1,'products','active','employee',NULL,'2023-08-21 05:42:40',1),(46,1,'reports','active','employee',NULL,'2023-08-21 05:42:40',1),(47,1,'settings','deactive','employee',NULL,'2023-08-21 05:42:40',0),(48,1,'bankaccount','active','employee',NULL,'2023-08-21 05:42:40',1),(49,1,'clients','active','client',NULL,'2023-08-21 05:42:40',1),(50,1,'projects','active','client',NULL,'2023-08-21 05:42:40',1),(51,1,'tickets','active','client',NULL,'2023-08-21 05:42:40',1),(52,1,'invoices','active','client',NULL,'2023-08-21 05:42:40',1),(53,1,'estimates','active','client',NULL,'2023-08-21 05:42:40',1),(54,1,'events','active','client',NULL,'2023-08-21 05:42:40',1),(55,1,'messages','active','client',NULL,'2023-08-21 05:42:40',1),(56,1,'tasks','active','client',NULL,'2023-08-21 05:42:40',1),(57,1,'timelogs','active','client',NULL,'2023-08-21 05:42:40',1),(58,1,'contracts','active','client',NULL,'2023-08-21 05:42:40',1),(59,1,'notices','active','client',NULL,'2023-08-21 05:42:40',1),(60,1,'payments','active','client',NULL,'2023-08-21 05:42:40',1),(61,1,'orders','active','client',NULL,'2023-08-21 05:42:40',1),(62,1,'knowledgebase','active','client',NULL,'2023-08-21 05:42:40',1),(125,3,'clients','active','admin',NULL,'2023-08-21 16:08:31',1),(126,3,'projects','active','admin',NULL,'2023-08-21 16:08:31',1),(127,3,'tickets','active','admin',NULL,'2023-08-21 16:08:31',1),(128,3,'invoices','active','admin',NULL,'2023-08-21 16:08:31',1),(129,3,'estimates','active','admin',NULL,'2023-08-21 16:08:31',1),(130,3,'events','active','admin',NULL,'2023-08-21 16:08:31',1),(131,3,'messages','active','admin',NULL,'2023-08-21 16:08:31',1),(132,3,'tasks','active','admin',NULL,'2023-08-21 16:08:31',1),(133,3,'timelogs','active','admin',NULL,'2023-08-21 16:08:31',1),(134,3,'contracts','active','admin',NULL,'2023-08-21 16:08:31',1),(135,3,'notices','active','admin',NULL,'2023-08-21 16:08:31',1),(136,3,'payments','active','admin',NULL,'2023-08-21 16:08:31',1),(137,3,'orders','active','admin',NULL,'2023-08-21 16:08:31',1),(138,3,'knowledgebase','active','admin',NULL,'2023-08-21 16:08:31',1),(139,3,'employees','active','admin',NULL,'2023-08-21 16:08:31',1),(140,3,'attendance','active','admin',NULL,'2023-08-21 16:08:31',1),(141,3,'expenses','active','admin',NULL,'2023-08-21 16:08:31',1),(142,3,'leaves','active','admin',NULL,'2023-08-21 16:08:31',1),(143,3,'leads','active','admin',NULL,'2023-08-21 16:08:31',1),(144,3,'holidays','active','admin',NULL,'2023-08-21 16:08:31',1),(145,3,'products','active','admin',NULL,'2023-08-21 16:08:31',1),(146,3,'reports','active','admin',NULL,'2023-08-21 16:08:31',1),(147,3,'settings','deactive','admin',NULL,'2023-08-21 16:08:31',0),(148,3,'bankaccount','active','admin',NULL,'2023-08-21 16:08:31',1),(149,3,'clients','active','employee',NULL,'2023-08-21 16:08:31',1),(150,3,'projects','active','employee',NULL,'2023-08-21 16:08:31',1),(151,3,'tickets','active','employee',NULL,'2023-08-21 16:08:31',1),(152,3,'invoices','active','employee',NULL,'2023-08-21 16:08:31',1),(153,3,'estimates','active','employee',NULL,'2023-08-21 16:08:31',1),(154,3,'events','active','employee',NULL,'2023-08-21 16:08:31',1),(155,3,'messages','active','employee',NULL,'2023-08-21 16:08:31',1),(156,3,'tasks','active','employee',NULL,'2023-08-21 16:08:31',1),(157,3,'timelogs','active','employee',NULL,'2023-08-21 16:08:31',1),(158,3,'contracts','active','employee',NULL,'2023-08-21 16:08:31',1),(159,3,'notices','active','employee',NULL,'2023-08-21 16:08:31',1),(160,3,'payments','active','employee',NULL,'2023-08-21 16:08:31',1),(161,3,'orders','active','employee',NULL,'2023-08-21 16:08:31',1),(162,3,'knowledgebase','active','employee',NULL,'2023-08-21 16:08:31',1),(163,3,'employees','active','employee',NULL,'2023-08-21 16:08:31',1),(164,3,'attendance','active','employee',NULL,'2023-08-21 16:08:31',1),(165,3,'expenses','active','employee',NULL,'2023-08-21 16:08:31',1),(166,3,'leaves','active','employee',NULL,'2023-08-21 16:08:31',1),(167,3,'leads','active','employee',NULL,'2023-08-21 16:08:31',1),(168,3,'holidays','active','employee',NULL,'2023-08-21 16:08:31',1),(169,3,'products','active','employee',NULL,'2023-08-21 16:08:31',1),(170,3,'reports','active','employee',NULL,'2023-08-21 16:08:31',1),(171,3,'settings','deactive','employee',NULL,'2023-08-21 16:08:31',0),(172,3,'bankaccount','active','employee',NULL,'2023-08-21 16:08:31',1),(173,3,'clients','active','client',NULL,'2023-08-21 16:08:31',1),(174,3,'projects','active','client',NULL,'2023-08-21 16:08:31',1),(175,3,'tickets','active','client',NULL,'2023-08-21 16:08:31',1),(176,3,'invoices','active','client',NULL,'2023-08-21 16:08:31',1),(177,3,'estimates','active','client',NULL,'2023-08-21 16:08:31',1),(178,3,'events','active','client',NULL,'2023-08-21 16:08:31',1),(179,3,'messages','active','client',NULL,'2023-08-21 16:08:31',1),(180,3,'tasks','active','client',NULL,'2023-08-21 16:08:31',1),(181,3,'timelogs','active','client',NULL,'2023-08-21 16:08:31',1),(182,3,'contracts','active','client',NULL,'2023-08-21 16:08:31',1),(183,3,'notices','active','client',NULL,'2023-08-21 16:08:31',1),(184,3,'payments','active','client',NULL,'2023-08-21 16:08:31',1),(185,3,'orders','active','client',NULL,'2023-08-21 16:08:31',1),(186,3,'knowledgebase','active','client',NULL,'2023-08-21 16:08:31',1),(187,1,'payroll','active','admin','2023-08-21 05:36:55','2023-08-21 05:42:40',1),(188,1,'payroll','active','employee','2023-08-21 05:36:55','2023-08-21 05:42:40',1),(189,3,'payroll','active','admin','2023-08-21 05:36:56','2023-08-21 16:08:31',1),(190,3,'payroll','active','employee','2023-08-21 05:36:56','2023-08-21 16:08:31',1),(191,1,'recruit','active','employee','2023-08-21 05:41:24','2023-08-21 05:42:40',1),(192,1,'recruit','active','admin','2023-08-21 05:41:24','2023-08-21 05:42:40',1),(193,3,'recruit','active','employee','2023-08-21 05:41:25','2023-08-21 16:08:31',1),(194,3,'recruit','active','admin','2023-08-21 05:41:25','2023-08-21 16:08:31',1),(393,7,'clients','active','admin',NULL,NULL,1),(394,7,'projects','active','admin',NULL,NULL,1),(395,7,'tickets','active','admin',NULL,NULL,1),(396,7,'invoices','active','admin',NULL,NULL,1),(397,7,'estimates','active','admin',NULL,NULL,1),(398,7,'events','active','admin',NULL,NULL,1),(399,7,'messages','active','admin',NULL,NULL,1),(400,7,'tasks','active','admin',NULL,NULL,1),(401,7,'timelogs','active','admin',NULL,NULL,1),(402,7,'contracts','active','admin',NULL,NULL,1),(403,7,'notices','active','admin',NULL,NULL,1),(404,7,'payments','active','admin',NULL,NULL,1),(405,7,'orders','active','admin',NULL,NULL,1),(406,7,'knowledgebase','active','admin',NULL,NULL,1),(407,7,'employees','active','admin',NULL,NULL,1),(408,7,'attendance','active','admin',NULL,NULL,1),(409,7,'expenses','active','admin',NULL,NULL,1),(410,7,'leaves','active','admin',NULL,NULL,1),(411,7,'leads','active','admin',NULL,NULL,1),(412,7,'holidays','active','admin',NULL,NULL,1),(413,7,'products','active','admin',NULL,NULL,1),(414,7,'reports','active','admin',NULL,NULL,1),(415,7,'settings','deactive','admin',NULL,NULL,0),(416,7,'bankaccount','active','admin',NULL,NULL,1),(417,7,'clients','active','employee',NULL,NULL,1),(418,7,'projects','active','employee',NULL,NULL,1),(419,7,'tickets','active','employee',NULL,NULL,1),(420,7,'invoices','active','employee',NULL,NULL,1),(421,7,'estimates','active','employee',NULL,NULL,1),(422,7,'events','active','employee',NULL,NULL,1),(423,7,'messages','active','employee',NULL,NULL,1),(424,7,'tasks','active','employee',NULL,NULL,1),(425,7,'timelogs','active','employee',NULL,NULL,1),(426,7,'contracts','active','employee',NULL,NULL,1),(427,7,'notices','active','employee',NULL,NULL,1),(428,7,'payments','active','employee',NULL,NULL,1),(429,7,'orders','active','employee',NULL,NULL,1),(430,7,'knowledgebase','active','employee',NULL,NULL,1),(431,7,'employees','active','employee',NULL,NULL,1),(432,7,'attendance','active','employee',NULL,NULL,1),(433,7,'expenses','active','employee',NULL,NULL,1),(434,7,'leaves','active','employee',NULL,NULL,1),(435,7,'leads','active','employee',NULL,NULL,1),(436,7,'holidays','active','employee',NULL,NULL,1),(437,7,'products','active','employee',NULL,NULL,1),(438,7,'reports','active','employee',NULL,NULL,1),(439,7,'settings','deactive','employee',NULL,NULL,0),(440,7,'bankaccount','active','employee',NULL,NULL,1),(441,7,'clients','active','client',NULL,NULL,1),(442,7,'projects','active','client',NULL,NULL,1),(443,7,'tickets','active','client',NULL,NULL,1),(444,7,'invoices','active','client',NULL,NULL,1),(445,7,'estimates','active','client',NULL,NULL,1),(446,7,'events','active','client',NULL,NULL,1),(447,7,'messages','active','client',NULL,NULL,1),(448,7,'tasks','active','client',NULL,NULL,1),(449,7,'timelogs','active','client',NULL,NULL,1),(450,7,'contracts','active','client',NULL,NULL,1),(451,7,'notices','active','client',NULL,NULL,1),(452,7,'payments','active','client',NULL,NULL,1),(453,7,'orders','active','client',NULL,NULL,1),(454,7,'knowledgebase','active','client',NULL,NULL,1),(455,7,'payroll','active','admin','2023-08-21 16:25:19','2023-08-21 16:25:19',1),(456,7,'payroll','active','employee','2023-08-21 16:25:19','2023-08-21 16:25:19',1),(457,7,'recruit','active','employee','2023-08-21 16:25:19','2023-08-21 16:25:19',1),(458,7,'recruit','active','admin','2023-08-21 16:25:19','2023-08-21 16:25:19',1);
/*!40000 ALTER TABLE `module_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_name` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `is_superadmin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'clients',NULL,0,'2023-08-10 14:06:28','2023-08-10 14:06:54'),(2,'employees',NULL,0,'2023-08-10 14:06:28','2023-08-10 14:06:54'),(3,'projects','User can view the basic details of projects assigned to him even without any permission.',0,'2023-08-10 14:06:28','2023-08-10 14:06:54'),(4,'attendance','User can view his own attendance even without any permission.',0,'2023-08-10 14:06:28','2023-08-10 14:06:54'),(5,'tasks','User can view the tasks assigned to him even without any permission.',0,'2023-08-10 14:06:28','2023-08-10 14:06:54'),(6,'estimates',NULL,0,'2023-08-10 14:06:28','2023-08-10 14:06:54'),(7,'invoices',NULL,0,'2023-08-10 14:06:28','2023-08-10 14:06:54'),(8,'payments',NULL,0,'2023-08-10 14:06:28','2023-08-10 14:06:54'),(9,'timelogs',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(10,'tickets','User can view the tickets generated by him as default even without any permission.',0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(11,'events','User can view the events to be attended by him as default even without any permission.',0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(12,'notices',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(13,'leaves','User can view the leaves applied by him as default even without any permission.',0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(14,'leads',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(15,'holidays',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(16,'products',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(17,'expenses','User can view and add(self expenses) the expenses as default even without any permission.',0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(18,'contracts','User can view all contracts',0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(19,'reports','User can manage permission of particular report',0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(20,'settings','User can manage settings',0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(21,'dashboards',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(22,'orders',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(23,'knowledgebase',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(24,'bankaccount',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(25,'messages',NULL,0,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(26,'packages',NULL,1,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(27,'companies',NULL,1,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(28,'billing',NULL,1,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(29,'offlinerequest',NULL,1,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(30,'admin_faq',NULL,1,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(31,'superadmin',NULL,1,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(32,'superadmin_ticket',NULL,1,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(33,'superadmin_settings',NULL,1,'2023-08-10 14:06:29','2023-08-10 14:06:54'),(34,'payroll',NULL,0,'2023-08-21 05:36:54','2023-08-21 05:36:54'),(35,'recruit',NULL,0,'2023-08-21 05:41:19','2023-08-21 05:41:19');
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mollie_invoices`
--

DROP TABLE IF EXISTS `mollie_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mollie_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `package_id` bigint(20) unsigned NOT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `amount` varchar(191) DEFAULT NULL,
  `package_type` varchar(191) DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `next_pay_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mollie_invoices_company_id_foreign` (`company_id`),
  KEY `mollie_invoices_package_id_foreign` (`package_id`),
  CONSTRAINT `mollie_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `mollie_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mollie_invoices`
--

LOCK TABLES `mollie_invoices` WRITE;
/*!40000 ALTER TABLE `mollie_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `mollie_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mollie_subscriptions`
--

DROP TABLE IF EXISTS `mollie_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mollie_subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `customer_id` varchar(191) DEFAULT NULL,
  `subscription_id` varchar(191) DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mollie_subscriptions_company_id_foreign` (`company_id`),
  CONSTRAINT `mollie_subscriptions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mollie_subscriptions`
--

LOCK TABLES `mollie_subscriptions` WRITE;
/*!40000 ALTER TABLE `mollie_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `mollie_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice_views`
--

DROP TABLE IF EXISTS `notice_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice_views` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `notice_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notice_views_company_id_foreign` (`company_id`),
  KEY `notice_views_notice_id_foreign` (`notice_id`),
  KEY `notice_views_user_id_foreign` (`user_id`),
  CONSTRAINT `notice_views_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notice_views_notice_id_foreign` FOREIGN KEY (`notice_id`) REFERENCES `notices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notice_views_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_views`
--

LOCK TABLES `notice_views` WRITE;
/*!40000 ALTER TABLE `notice_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `notice_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `to` varchar(191) NOT NULL DEFAULT 'employee',
  `heading` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notices_company_id_foreign` (`company_id`),
  KEY `notices_department_id_foreign` (`department_id`),
  KEY `notices_added_by_foreign` (`added_by`),
  KEY `notices_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `notices_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `notices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notices_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notices_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(191) NOT NULL,
  `notifiable_type` varchar(191) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('04010cb8-48b6-42b9-bdb5-330febe64813','App\\Notifications\\SuperAdmin\\CompanyUpdatedPlan','App\\Models\\User',3,'{\"id\":3,\"company_id\":3,\"user_auth_id\":3,\"is_superadmin\":0,\"name\":\"Medium\",\"email\":\"ascothill21k@gmail.com\",\"image\":null,\"country_phonecode\":null,\"mobile\":null,\"gender\":\"male\",\"salutation\":null,\"locale\":\"en\",\"status\":\"active\",\"login\":\"enable\",\"onesignal_player_id\":null,\"last_login\":\"2023-08-11T02:03:27+00:00\",\"email_notifications\":1,\"country_id\":null,\"dark_theme\":0,\"rtl\":0,\"admin_approval\":1,\"permission_sync\":1,\"google_calendar_status\":1,\"customised_permissions\":0,\"stripe_id\":null,\"pm_type\":null,\"pm_last_four\":null,\"trial_ends_at\":null,\"image_url\":\"https:\\/\\/www.gravatar.com\\/avatar\\/1ef151df3722affc64857738fc7fce1d.png?s=200&d=mp\",\"modules\":[\"clients\",\"projects\",\"tickets\",\"invoices\",\"estimates\",\"events\",\"messages\",\"tasks\",\"timelogs\",\"contracts\",\"notices\",\"payments\",\"orders\",\"knowledgebase\",\"employees\",\"attendance\",\"expenses\",\"leaves\",\"leads\",\"holidays\",\"products\",\"reports\",\"bankaccount\"],\"mobile_with_phonecode\":\"--\",\"client_details\":null,\"employee_detail\":{\"id\":2,\"company_id\":3,\"user_id\":3,\"employee_id\":\"EMP-1\",\"address\":null,\"hourly_rate\":null,\"slack_username\":null,\"department_id\":null,\"designation_id\":null,\"joining_date\":\"2023-08-10T14:17:29+00:00\",\"last_date\":null,\"added_by\":null,\"last_updated_by\":null,\"attendance_reminder\":null,\"date_of_birth\":null,\"calendar_view\":null,\"about_me\":null,\"reporting_to\":null,\"contract_end_date\":null,\"internship_end_date\":null,\"employment_type\":null,\"marriage_anniversary_date\":null,\"marital_status\":\"unmarried\",\"notice_period_end_date\":null,\"notice_period_start_date\":null,\"probation_end_date\":null,\"upcoming_birthday\":null,\"designation\":null,\"company\":{\"id\":3,\"company_name\":\"Ascot Hill\",\"app_name\":\"Ascot Hill\",\"company_email\":\"ascothill21k@gmail.com\",\"company_phone\":null,\"logo\":null,\"light_logo\":null,\"favicon\":null,\"auth_theme\":\"light\",\"auth_theme_text\":\"dark\",\"sidebar_logo_style\":\"square\",\"login_background\":null,\"address\":\"Ascot Hill\",\"website\":null,\"currency_id\":9,\"package_id\":4,\"package_type\":\"monthly\",\"timezone\":\"Asia\\/Kolkata\",\"date_format\":\"d-m-Y\",\"date_picker_format\":\"dd-mm-yyyy\",\"year_starts_from\":\"1\",\"moment_format\":\"DD-MM-YYYY\",\"time_format\":\"h:i a\",\"locale\":\"en\",\"latitude\":\"26.91243360\",\"longitude\":\"75.78727090\",\"leaves_start_from\":\"joining_date\",\"active_theme\":\"default\",\"status\":\"active\",\"last_updated_by\":3,\"currency_converter_key\":null,\"google_map_key\":null,\"task_self\":\"yes\",\"purchase_code\":null,\"license_type\":null,\"supported_until\":null,\"google_recaptcha_status\":\"deactive\",\"google_recaptcha_v2_status\":\"deactive\",\"google_recaptcha_v2_site_key\":null,\"google_recaptcha_v2_secret_key\":null,\"google_recaptcha_v3_status\":\"deactive\",\"google_recaptcha_v3_site_key\":null,\"google_recaptcha_v3_secret_key\":null,\"app_debug\":0,\"rounded_theme\":1,\"hide_cron_message\":0,\"system_update\":1,\"logo_background_color\":\"#ffffff\",\"header_color\":\"#1D82F5\",\"before_days\":0,\"after_days\":0,\"on_deadline\":\"yes\",\"default_task_status\":9,\"show_review_modal\":1,\"dashboard_clock\":1,\"ticket_form_google_captcha\":0,\"lead_form_google_captcha\":0,\"taskboard_length\":10,\"datatable_row_limit\":10,\"last_cron_run\":null,\"session_driver\":\"file\",\"allow_client_signup\":0,\"admin_client_signup_approval\":0,\"allowed_file_types\":null,\"google_calendar_status\":\"inactive\",\"google_client_id\":null,\"google_client_secret\":null,\"google_calendar_verification_status\":\"non_verified\",\"google_id\":null,\"name\":null,\"token\":null,\"hash\":\"7b5eda6bc7e40e3125395bc8b590d3e3\",\"allowed_file_size\":10,\"currency_key_version\":\"free\",\"last_login\":\"2023-08-11T02:03:27+00:00\",\"rtl\":0,\"stripe_id\":\"cus_OQbsuE96dFZSjm\",\"card_brand\":null,\"card_last_four\":null,\"trial_ends_at\":null,\"licence_expire_on\":null,\"license_updated_at\":null,\"subscription_updated_at\":\"2023-08-11T02:03:31+00:00\",\"approved\":1,\"approved_by\":null,\"show_new_webhook_alert\":0,\"pm_type\":\"visa\",\"pm_last_four\":\"4242\",\"logo_url\":\"https:\\/\\/wst.avts.com.my\\/img\\/worksuite-logo.png\",\"login_background_url\":null,\"moment_date_format\":\"DD-MM-YYYY\",\"favicon_url\":\"https:\\/\\/wst.avts.com.my\\/favicon.png\",\"package\":{\"id\":4,\"currency_id\":1,\"name\":\"Medium\",\"description\":\"Quidem deserunt nobis asperiores fuga Ullamco corporis culpa\",\"max_storage_size\":500,\"max_file_size\":50,\"annual_price\":1000,\"monthly_price\":100,\"billing_cycle\":10,\"max_employees\":100,\"sort\":\"3\",\"module_in_package\":\"{\\\"1\\\":\\\"clients\\\",\\\"2\\\":\\\"employees\\\",\\\"3\\\":\\\"projects\\\",\\\"4\\\":\\\"attendance\\\",\\\"5\\\":\\\"tasks\\\",\\\"6\\\":\\\"estimates\\\",\\\"7\\\":\\\"invoices\\\",\\\"8\\\":\\\"payments\\\",\\\"9\\\":\\\"timelogs\\\",\\\"10\\\":\\\"tickets\\\",\\\"11\\\":\\\"events\\\",\\\"12\\\":\\\"notices\\\",\\\"13\\\":\\\"leaves\\\",\\\"14\\\":\\\"leads\\\",\\\"15\\\":\\\"holidays\\\",\\\"16\\\":\\\"products\\\",\\\"17\\\":\\\"expenses\\\",\\\"18\\\":\\\"contracts\\\",\\\"19\\\":\\\"reports\\\",\\\"22\\\":\\\"orders\\\",\\\"23\\\":\\\"knowledgebase\\\",\\\"24\\\":\\\"bankaccount\\\",\\\"25\\\":\\\"messages\\\"}\",\"stripe_annual_plan_id\":\"medium_annual\",\"stripe_monthly_plan_id\":\"price_1NdkgMCC83aJafqlXrqqBBXG\",\"razorpay_annual_plan_id\":null,\"razorpay_monthly_plan_id\":null,\"default\":\"no\",\"paystack_monthly_plan_id\":null,\"paystack_annual_plan_id\":null,\"is_private\":0,\"storage_unit\":\"mb\",\"is_recommended\":0,\"is_free\":0,\"is_auto_renew\":0,\"monthly_status\":\"1\",\"annual_status\":\"1\",\"formatted_annual_price\":\"$1,000.00\",\"formatted_monthly_price\":\"$100.00\"}},\"department\":null},\"company_name\":\"Ascot Hill\"}',NULL,'2023-08-11 02:03:35','2023-08-11 02:03:35'),('4c52d71f-9dba-4097-9fd2-a713eb77bfad','App\\Notifications\\SuperAdmin\\CompanyUpdatedPlan','App\\Models\\User',1,'{\"id\":1,\"company_id\":null,\"user_auth_id\":1,\"is_superadmin\":1,\"name\":\"Larger\",\"email\":\"avtssb@gmail.com\",\"image\":null,\"country_phonecode\":null,\"mobile\":null,\"gender\":\"male\",\"salutation\":null,\"locale\":\"en\",\"status\":\"active\",\"login\":\"enable\",\"onesignal_player_id\":null,\"last_login\":\"2023-08-11T01:54:38+00:00\",\"email_notifications\":1,\"country_id\":null,\"dark_theme\":0,\"rtl\":0,\"admin_approval\":1,\"permission_sync\":1,\"google_calendar_status\":1,\"customised_permissions\":0,\"stripe_id\":null,\"pm_type\":null,\"pm_last_four\":null,\"trial_ends_at\":null,\"image_url\":\"https:\\/\\/www.gravatar.com\\/avatar\\/e69474603519901ce77b7037b1d14ab9.png?s=200&d=mp\",\"modules\":[\"clients\",\"projects\",\"tickets\",\"invoices\",\"estimates\",\"events\",\"messages\",\"tasks\",\"timelogs\",\"contracts\",\"notices\",\"payments\",\"orders\",\"knowledgebase\",\"employees\",\"attendance\",\"expenses\",\"leaves\",\"leads\",\"holidays\",\"products\",\"reports\",\"bankaccount\"],\"mobile_with_phonecode\":\"--\",\"client_details\":null,\"employee_detail\":null,\"company_name\":\"Ascot Hill\"}','2023-08-21 06:58:19','2023-08-11 02:10:35','2023-08-21 06:58:19'),('671da233-e71d-4070-9601-84c85d997f26','App\\Notifications\\NewProposal','App\\Models\\Lead',1,'{\"id\":1,\"company_id\":7,\"lead_id\":1,\"valid_till\":\"2023-09-20T00:00:00+00:00\",\"sub_total\":5000,\"total\":5000,\"currency_id\":33,\"discount_type\":\"percent\",\"discount\":0,\"invoice_convert\":0,\"status\":\"waiting\",\"note\":\"\",\"description\":\"\",\"client_comment\":null,\"signature_approval\":1,\"added_by\":8,\"last_updated_by\":8,\"hash\":\"d1f5d54129a217d75ed2557daf4fafad\",\"calculate_tax\":\"after_discount\",\"last_viewed\":null,\"ip_address\":null,\"send_status\":1,\"lead\":{\"id\":1,\"company_id\":7,\"client_id\":null,\"source_id\":null,\"status_id\":19,\"column_priority\":0,\"agent_id\":null,\"company_name\":null,\"website\":null,\"address\":null,\"salutation\":\"mr\",\"client_name\":\"Shahrul Nizam\",\"client_email\":\"nafasdoa2023@gmail.com\",\"mobile\":null,\"cell\":null,\"office\":null,\"city\":null,\"state\":null,\"country\":null,\"postal_code\":null,\"note\":\"\",\"next_follow_up\":\"yes\",\"value\":5000,\"currency_id\":33,\"category_id\":null,\"added_by\":8,\"last_updated_by\":8,\"hash\":\"95c2cc8b8403de31510be5effce85dc5\",\"image_url\":\"https:\\/\\/www.gravatar.com\\/avatar\\/d89c756051360d91cf5123ab2bce7493.png?s=200&d=mp\"},\"company\":{\"id\":7,\"company_name\":\"IBFIM\",\"app_name\":\"IBFIM\",\"company_email\":\"subscribe@ibfimonline.com\",\"company_phone\":null,\"logo\":\"550faa7ddb91b7ffdc3edac0fe2ff6f7.png\",\"light_logo\":\"df2663071c9899bcb6223c4c6337cae6.png\",\"favicon\":\"e8760d3da65f7d0949f92fcb457d3c16.png\",\"auth_theme\":\"light\",\"auth_theme_text\":\"dark\",\"sidebar_logo_style\":\"square\",\"login_background\":null,\"address\":\"IBFIM\",\"website\":null,\"currency_id\":33,\"package_id\":1,\"package_type\":\"monthly\",\"timezone\":\"Asia\\/Kuala_Lumpur\",\"date_format\":\"d-m-Y\",\"date_picker_format\":\"dd-mm-yyyy\",\"year_starts_from\":\"1\",\"moment_format\":\"DD-MM-YYYY\",\"time_format\":\"h:i a\",\"locale\":\"en\",\"latitude\":\"26.91243360\",\"longitude\":\"75.78727090\",\"leaves_start_from\":\"joining_date\",\"active_theme\":\"default\",\"status\":\"active\",\"last_updated_by\":null,\"currency_converter_key\":null,\"google_map_key\":null,\"task_self\":\"yes\",\"purchase_code\":null,\"license_type\":null,\"supported_until\":null,\"google_recaptcha_status\":\"deactive\",\"google_recaptcha_v2_status\":\"deactive\",\"google_recaptcha_v2_site_key\":null,\"google_recaptcha_v2_secret_key\":null,\"google_recaptcha_v3_status\":\"deactive\",\"google_recaptcha_v3_site_key\":null,\"google_recaptcha_v3_secret_key\":null,\"app_debug\":0,\"rounded_theme\":1,\"hide_cron_message\":0,\"system_update\":1,\"logo_background_color\":\"#FFFFFF\",\"header_color\":\"#1D82F5\",\"before_days\":0,\"after_days\":0,\"on_deadline\":\"yes\",\"default_task_status\":25,\"show_review_modal\":1,\"dashboard_clock\":1,\"ticket_form_google_captcha\":0,\"lead_form_google_captcha\":0,\"taskboard_length\":10,\"datatable_row_limit\":10,\"last_cron_run\":null,\"session_driver\":\"file\",\"allow_client_signup\":0,\"admin_client_signup_approval\":0,\"allowed_file_types\":null,\"google_calendar_status\":\"inactive\",\"google_client_id\":null,\"google_client_secret\":null,\"google_calendar_verification_status\":\"non_verified\",\"google_id\":null,\"name\":null,\"token\":null,\"hash\":\"6a9d28ca3c801f42fbc89d71fb21dde6\",\"allowed_file_size\":10,\"currency_key_version\":\"free\",\"last_login\":\"2023-08-21T16:37:38+00:00\",\"rtl\":0,\"stripe_id\":null,\"card_brand\":null,\"card_last_four\":null,\"trial_ends_at\":null,\"licence_expire_on\":null,\"license_updated_at\":null,\"subscription_updated_at\":null,\"approved\":1,\"approved_by\":null,\"show_new_webhook_alert\":0,\"pm_type\":null,\"pm_last_four\":null,\"logo_url\":\"https:\\/\\/my.ibfimonline.com\\/user-uploads\\/app-logo\\/df2663071c9899bcb6223c4c6337cae6.png\",\"login_background_url\":null,\"moment_date_format\":\"DD-MM-YYYY\",\"favicon_url\":\"https:\\/\\/my.ibfimonline.com\\/user-uploads\\/favicon\\/e8760d3da65f7d0949f92fcb457d3c16.png\",\"package\":{\"id\":1,\"currency_id\":5,\"name\":\"Default\",\"description\":\"Its a default package and cannot be deleted\",\"max_storage_size\":0,\"max_file_size\":0,\"annual_price\":0,\"monthly_price\":0,\"billing_cycle\":0,\"max_employees\":20,\"sort\":\"1\",\"module_in_package\":\"{\\\"1\\\":\\\"clients\\\",\\\"2\\\":\\\"employees\\\",\\\"3\\\":\\\"projects\\\",\\\"4\\\":\\\"attendance\\\",\\\"5\\\":\\\"tasks\\\",\\\"6\\\":\\\"estimates\\\",\\\"7\\\":\\\"invoices\\\",\\\"8\\\":\\\"payments\\\",\\\"9\\\":\\\"timelogs\\\",\\\"10\\\":\\\"tickets\\\",\\\"11\\\":\\\"events\\\",\\\"12\\\":\\\"notices\\\",\\\"13\\\":\\\"leaves\\\",\\\"14\\\":\\\"leads\\\",\\\"15\\\":\\\"holidays\\\",\\\"16\\\":\\\"products\\\",\\\"17\\\":\\\"expenses\\\",\\\"18\\\":\\\"contracts\\\",\\\"19\\\":\\\"reports\\\",\\\"22\\\":\\\"orders\\\",\\\"23\\\":\\\"knowledgebase\\\",\\\"24\\\":\\\"bankaccount\\\",\\\"25\\\":\\\"messages\\\",\\\"34\\\":\\\"payroll\\\",\\\"35\\\":\\\"recruit\\\"}\",\"stripe_annual_plan_id\":null,\"stripe_monthly_plan_id\":null,\"razorpay_annual_plan_id\":null,\"razorpay_monthly_plan_id\":null,\"default\":\"yes\",\"paystack_monthly_plan_id\":null,\"paystack_annual_plan_id\":null,\"is_private\":0,\"storage_unit\":\"mb\",\"is_recommended\":0,\"is_free\":1,\"is_auto_renew\":0,\"monthly_status\":\"1\",\"annual_status\":\"1\",\"formatted_annual_price\":\"RM0.00\",\"formatted_monthly_price\":\"RM0.00\"}}}',NULL,'2023-08-21 16:37:38','2023-08-21 16:37:38'),('6b2c03d9-2b4f-4a21-b8f5-d4aca8058d4b','App\\Notifications\\SuperAdmin\\OfflinePackageChangeConfirmation','App\\Models\\User',3,'{\"id\":1,\"company_id\":3,\"package_id\":3,\"package_type\":\"monthly\",\"amount\":50,\"pay_date\":\"2023-08-10T00:00:00+00:00\",\"next_pay_date\":\"2023-09-10T00:00:00+00:00\",\"invoice_id\":null,\"offline_method_id\":1,\"file_name\":\"6cf9b1f9953589f509f7a0de63cbd98c.jpg\",\"status\":\"verified\",\"remark\":null,\"description\":\"detail of receipt\",\"file\":\"https:\\/\\/wst.avts.com.my\\/user-uploads\\/offline-invoice\\/6cf9b1f9953589f509f7a0de63cbd98c.jpg\",\"package\":{\"id\":3,\"currency_id\":1,\"name\":\"Starter\",\"description\":\"Quidem deserunt nobis asperiores fuga Ullamco corporis culpa\",\"max_storage_size\":500,\"max_file_size\":30,\"annual_price\":500,\"monthly_price\":50,\"billing_cycle\":10,\"max_employees\":50,\"sort\":\"2\",\"module_in_package\":\"[\\\"clients\\\",\\\"employees\\\",\\\"projects\\\",\\\"attendance\\\",\\\"tasks\\\",\\\"estimates\\\",\\\"invoices\\\",\\\"payments\\\",\\\"timelogs\\\",\\\"tickets\\\",\\\"events\\\",\\\"notices\\\",\\\"leaves\\\",\\\"leads\\\",\\\"holidays\\\",\\\"products\\\",\\\"expenses\\\",\\\"contracts\\\",\\\"reports\\\",\\\"orders\\\",\\\"knowledgebase\\\",\\\"bankaccount\\\",\\\"messages\\\"]\",\"stripe_annual_plan_id\":\"starter_annual\",\"stripe_monthly_plan_id\":\"starter_monthly\",\"razorpay_annual_plan_id\":null,\"razorpay_monthly_plan_id\":null,\"default\":\"no\",\"paystack_monthly_plan_id\":null,\"paystack_annual_plan_id\":null,\"is_private\":0,\"storage_unit\":\"mb\",\"is_recommended\":0,\"is_free\":0,\"is_auto_renew\":0,\"monthly_status\":\"1\",\"annual_status\":\"1\",\"formatted_annual_price\":\"$500.00\",\"formatted_monthly_price\":\"$50.00\"},\"company\":{\"id\":3,\"company_name\":\"Ascot Hill\",\"app_name\":\"Ascot Hill\",\"company_email\":\"ascothill21k@gmail.com\",\"company_phone\":null,\"logo\":null,\"light_logo\":null,\"favicon\":null,\"auth_theme\":\"light\",\"auth_theme_text\":\"dark\",\"sidebar_logo_style\":\"square\",\"login_background\":null,\"address\":\"Ascot Hill\",\"website\":null,\"currency_id\":9,\"package_id\":3,\"package_type\":\"monthly\",\"timezone\":\"Asia\\/Kolkata\",\"date_format\":\"d-m-Y\",\"date_picker_format\":\"dd-mm-yyyy\",\"year_starts_from\":\"1\",\"moment_format\":\"DD-MM-YYYY\",\"time_format\":\"h:i a\",\"locale\":\"en\",\"latitude\":\"26.91243360\",\"longitude\":\"75.78727090\",\"leaves_start_from\":\"joining_date\",\"active_theme\":\"default\",\"status\":\"active\",\"last_updated_by\":1,\"currency_converter_key\":null,\"google_map_key\":null,\"task_self\":\"yes\",\"purchase_code\":null,\"license_type\":null,\"supported_until\":null,\"google_recaptcha_status\":\"deactive\",\"google_recaptcha_v2_status\":\"deactive\",\"google_recaptcha_v2_site_key\":null,\"google_recaptcha_v2_secret_key\":null,\"google_recaptcha_v3_status\":\"deactive\",\"google_recaptcha_v3_site_key\":null,\"google_recaptcha_v3_secret_key\":null,\"app_debug\":0,\"rounded_theme\":1,\"hide_cron_message\":0,\"system_update\":1,\"logo_background_color\":\"#ffffff\",\"header_color\":\"#1D82F5\",\"before_days\":0,\"after_days\":0,\"on_deadline\":\"yes\",\"default_task_status\":9,\"show_review_modal\":1,\"dashboard_clock\":1,\"ticket_form_google_captcha\":0,\"lead_form_google_captcha\":0,\"taskboard_length\":10,\"datatable_row_limit\":10,\"last_cron_run\":null,\"session_driver\":\"file\",\"allow_client_signup\":0,\"admin_client_signup_approval\":0,\"allowed_file_types\":null,\"google_calendar_status\":\"inactive\",\"google_client_id\":null,\"google_client_secret\":null,\"google_calendar_verification_status\":\"non_verified\",\"google_id\":null,\"name\":null,\"token\":null,\"hash\":\"7b5eda6bc7e40e3125395bc8b590d3e3\",\"allowed_file_size\":10,\"currency_key_version\":\"free\",\"last_login\":\"2023-08-10T14:20:53+00:00\",\"rtl\":0,\"stripe_id\":null,\"card_brand\":null,\"card_last_four\":null,\"trial_ends_at\":null,\"licence_expire_on\":null,\"license_updated_at\":null,\"subscription_updated_at\":\"2023-08-10T14:21:42+00:00\",\"approved\":1,\"approved_by\":null,\"show_new_webhook_alert\":0,\"pm_type\":null,\"pm_last_four\":null,\"logo_url\":\"https:\\/\\/wst.avts.com.my\\/img\\/worksuite-logo.png\",\"login_background_url\":null,\"moment_date_format\":\"DD-MM-YYYY\",\"favicon_url\":\"https:\\/\\/wst.avts.com.my\\/favicon.png\",\"package\":{\"id\":3,\"currency_id\":1,\"name\":\"Starter\",\"description\":\"Quidem deserunt nobis asperiores fuga Ullamco corporis culpa\",\"max_storage_size\":500,\"max_file_size\":30,\"annual_price\":500,\"monthly_price\":50,\"billing_cycle\":10,\"max_employees\":50,\"sort\":\"2\",\"module_in_package\":\"[\\\"clients\\\",\\\"employees\\\",\\\"projects\\\",\\\"attendance\\\",\\\"tasks\\\",\\\"estimates\\\",\\\"invoices\\\",\\\"payments\\\",\\\"timelogs\\\",\\\"tickets\\\",\\\"events\\\",\\\"notices\\\",\\\"leaves\\\",\\\"leads\\\",\\\"holidays\\\",\\\"products\\\",\\\"expenses\\\",\\\"contracts\\\",\\\"reports\\\",\\\"orders\\\",\\\"knowledgebase\\\",\\\"bankaccount\\\",\\\"messages\\\"]\",\"stripe_annual_plan_id\":\"starter_annual\",\"stripe_monthly_plan_id\":\"starter_monthly\",\"razorpay_annual_plan_id\":null,\"razorpay_monthly_plan_id\":null,\"default\":\"no\",\"paystack_monthly_plan_id\":null,\"paystack_annual_plan_id\":null,\"is_private\":0,\"storage_unit\":\"mb\",\"is_recommended\":0,\"is_free\":0,\"is_auto_renew\":0,\"monthly_status\":\"1\",\"annual_status\":\"1\",\"formatted_annual_price\":\"$500.00\",\"formatted_monthly_price\":\"$50.00\"}},\"company_name\":\"Ascot Hill\",\"package_name\":\"Starter (monthly)\"}',NULL,'2023-08-10 14:21:42','2023-08-10 14:21:42'),('80662481-2431-4844-826c-9ddb03355963','App\\Notifications\\NewUser','App\\Models\\User',3,'{\"id\":3,\"company_id\":3,\"user_auth_id\":3,\"is_superadmin\":0,\"name\":\"Ascot Hill\",\"email\":\"ascothill21k@gmail.com\",\"image\":null,\"country_phonecode\":null,\"mobile\":null,\"gender\":\"male\",\"salutation\":null,\"locale\":\"en\",\"status\":\"active\",\"login\":\"enable\",\"onesignal_player_id\":null,\"last_login\":null,\"email_notifications\":1,\"country_id\":null,\"dark_theme\":0,\"rtl\":0,\"admin_approval\":1,\"permission_sync\":1,\"google_calendar_status\":1,\"customised_permissions\":0,\"stripe_id\":null,\"pm_type\":null,\"pm_last_four\":null,\"trial_ends_at\":null,\"image_url\":\"https:\\/\\/www.gravatar.com\\/avatar\\/1ef151df3722affc64857738fc7fce1d.png?s=200&d=mp\",\"modules\":[],\"mobile_with_phonecode\":\"--\",\"client_details\":null,\"employee_detail\":null}',NULL,'2023-08-10 14:17:26','2023-08-10 14:17:26'),('9fae83c4-af82-413e-9dbc-f3f2900bf776','App\\Notifications\\SuperAdmin\\OfflinePackageChangeRequest','App\\Models\\User',1,'{\"id\":1,\"company_id\":3,\"package_id\":3,\"package_type\":\"monthly\",\"amount\":50,\"pay_date\":\"2023-08-10T00:00:00+00:00\",\"next_pay_date\":\"2023-09-10T00:00:00+00:00\",\"invoice_id\":null,\"offline_method_id\":1,\"file_name\":\"6cf9b1f9953589f509f7a0de63cbd98c.jpg\",\"status\":\"pending\",\"remark\":null,\"description\":\"detail of receipt\",\"file\":\"https:\\/\\/wst.avts.com.my\\/user-uploads\\/offline-invoice\\/6cf9b1f9953589f509f7a0de63cbd98c.jpg\",\"company_name\":\"Ascot Hill\"}',NULL,'2023-08-10 14:20:41','2023-08-10 14:20:41'),('cc276018-fbd9-44bd-a43b-2e0265d64072','App\\Notifications\\SuperAdmin\\NewCompanyRegister','App\\Models\\User',1,'{\"id\":3,\"company_name\":\"Ascot Hill\",\"app_name\":\"Ascot Hill\",\"company_email\":\"ascothill21k@gmail.com\",\"company_phone\":null,\"logo\":null,\"light_logo\":null,\"favicon\":null,\"auth_theme\":\"light\",\"auth_theme_text\":\"dark\",\"sidebar_logo_style\":\"square\",\"login_background\":null,\"address\":\"Ascot Hill\",\"website\":null,\"currency_id\":9,\"package_id\":1,\"package_type\":\"monthly\",\"timezone\":\"Asia\\/Kolkata\",\"date_format\":\"d-m-Y\",\"date_picker_format\":\"dd-mm-yyyy\",\"year_starts_from\":\"1\",\"moment_format\":\"DD-MM-YYYY\",\"time_format\":\"h:i a\",\"locale\":\"en\",\"latitude\":\"26.91243360\",\"longitude\":\"75.78727090\",\"leaves_start_from\":\"joining_date\",\"active_theme\":\"default\",\"status\":\"active\",\"last_updated_by\":null,\"currency_converter_key\":null,\"google_map_key\":null,\"task_self\":\"yes\",\"purchase_code\":null,\"license_type\":null,\"supported_until\":null,\"google_recaptcha_status\":\"deactive\",\"google_recaptcha_v2_status\":\"deactive\",\"google_recaptcha_v2_site_key\":null,\"google_recaptcha_v2_secret_key\":null,\"google_recaptcha_v3_status\":\"deactive\",\"google_recaptcha_v3_site_key\":null,\"google_recaptcha_v3_secret_key\":null,\"app_debug\":0,\"rounded_theme\":1,\"hide_cron_message\":0,\"system_update\":1,\"logo_background_color\":\"#ffffff\",\"header_color\":\"#1D82F5\",\"before_days\":0,\"after_days\":0,\"on_deadline\":\"yes\",\"default_task_status\":9,\"show_review_modal\":1,\"dashboard_clock\":1,\"ticket_form_google_captcha\":0,\"lead_form_google_captcha\":0,\"taskboard_length\":10,\"datatable_row_limit\":10,\"last_cron_run\":null,\"session_driver\":\"file\",\"allow_client_signup\":0,\"admin_client_signup_approval\":0,\"allowed_file_types\":null,\"google_calendar_status\":\"inactive\",\"google_client_id\":null,\"google_client_secret\":null,\"google_calendar_verification_status\":\"non_verified\",\"google_id\":null,\"name\":null,\"token\":null,\"hash\":\"7b5eda6bc7e40e3125395bc8b590d3e3\",\"allowed_file_size\":10,\"currency_key_version\":\"free\",\"last_login\":null,\"rtl\":0,\"stripe_id\":null,\"card_brand\":null,\"card_last_four\":null,\"trial_ends_at\":null,\"licence_expire_on\":null,\"license_updated_at\":null,\"subscription_updated_at\":null,\"approved\":1,\"approved_by\":null,\"show_new_webhook_alert\":0,\"pm_type\":null,\"pm_last_four\":null,\"logo_url\":\"https:\\/\\/wst.avts.com.my\\/img\\/worksuite-logo.png\",\"login_background_url\":null,\"moment_date_format\":\"DD-MM-YYYY\",\"favicon_url\":\"https:\\/\\/wst.avts.com.my\\/favicon.png\",\"package\":{\"id\":1,\"currency_id\":1,\"name\":\"Default\",\"description\":\"Its a default package and cannot be deleted\",\"max_storage_size\":0,\"max_file_size\":0,\"annual_price\":0,\"monthly_price\":0,\"billing_cycle\":0,\"max_employees\":20,\"sort\":\"1\",\"module_in_package\":\"[\\\"clients\\\",\\\"employees\\\",\\\"projects\\\",\\\"attendance\\\",\\\"tasks\\\",\\\"estimates\\\",\\\"invoices\\\",\\\"payments\\\",\\\"timelogs\\\",\\\"tickets\\\",\\\"events\\\",\\\"notices\\\",\\\"leaves\\\",\\\"leads\\\",\\\"holidays\\\",\\\"products\\\",\\\"expenses\\\",\\\"contracts\\\",\\\"reports\\\",\\\"orders\\\",\\\"knowledgebase\\\",\\\"bankaccount\\\",\\\"messages\\\"]\",\"stripe_annual_plan_id\":null,\"stripe_monthly_plan_id\":null,\"razorpay_annual_plan_id\":null,\"razorpay_monthly_plan_id\":null,\"default\":\"yes\",\"paystack_monthly_plan_id\":null,\"paystack_annual_plan_id\":null,\"is_private\":0,\"storage_unit\":\"mb\",\"is_recommended\":0,\"is_free\":1,\"is_auto_renew\":0,\"monthly_status\":\"1\",\"annual_status\":\"1\",\"formatted_annual_price\":\"$0.00\",\"formatted_monthly_price\":\"$0.00\"}}',NULL,'2023-08-10 14:17:22','2023-08-10 14:17:22'),('cc8473b5-c190-4b8c-95d0-834dbe5ad5ec','App\\Notifications\\SuperAdmin\\CompanyUpdatedPlan','App\\Models\\User',3,'{\"id\":3,\"company_id\":3,\"user_auth_id\":3,\"is_superadmin\":0,\"name\":\"Larger\",\"email\":\"ascothill21k@gmail.com\",\"image\":null,\"country_phonecode\":null,\"mobile\":null,\"gender\":\"male\",\"salutation\":null,\"locale\":\"en\",\"status\":\"active\",\"login\":\"enable\",\"onesignal_player_id\":null,\"last_login\":\"2023-08-11T02:10:34+00:00\",\"email_notifications\":1,\"country_id\":null,\"dark_theme\":0,\"rtl\":0,\"admin_approval\":1,\"permission_sync\":1,\"google_calendar_status\":1,\"customised_permissions\":0,\"stripe_id\":null,\"pm_type\":null,\"pm_last_four\":null,\"trial_ends_at\":null,\"image_url\":\"https:\\/\\/www.gravatar.com\\/avatar\\/1ef151df3722affc64857738fc7fce1d.png?s=200&d=mp\",\"modules\":[\"clients\",\"projects\",\"tickets\",\"invoices\",\"estimates\",\"events\",\"messages\",\"tasks\",\"timelogs\",\"contracts\",\"notices\",\"payments\",\"orders\",\"knowledgebase\",\"employees\",\"attendance\",\"expenses\",\"leaves\",\"leads\",\"holidays\",\"products\",\"reports\",\"bankaccount\"],\"mobile_with_phonecode\":\"--\",\"client_details\":null,\"employee_detail\":{\"id\":2,\"company_id\":3,\"user_id\":3,\"employee_id\":\"EMP-1\",\"address\":null,\"hourly_rate\":null,\"slack_username\":null,\"department_id\":null,\"designation_id\":null,\"joining_date\":\"2023-08-10T14:17:29+00:00\",\"last_date\":null,\"added_by\":null,\"last_updated_by\":null,\"attendance_reminder\":null,\"date_of_birth\":null,\"calendar_view\":null,\"about_me\":null,\"reporting_to\":null,\"contract_end_date\":null,\"internship_end_date\":null,\"employment_type\":null,\"marriage_anniversary_date\":null,\"marital_status\":\"unmarried\",\"notice_period_end_date\":null,\"notice_period_start_date\":null,\"probation_end_date\":null,\"upcoming_birthday\":null,\"designation\":null,\"company\":{\"id\":3,\"company_name\":\"Ascot Hill\",\"app_name\":\"Ascot Hill\",\"company_email\":\"ascothill21k@gmail.com\",\"company_phone\":null,\"logo\":null,\"light_logo\":null,\"favicon\":null,\"auth_theme\":\"light\",\"auth_theme_text\":\"dark\",\"sidebar_logo_style\":\"square\",\"login_background\":null,\"address\":\"Ascot Hill\",\"website\":null,\"currency_id\":9,\"package_id\":5,\"package_type\":\"monthly\",\"timezone\":\"Asia\\/Kolkata\",\"date_format\":\"d-m-Y\",\"date_picker_format\":\"dd-mm-yyyy\",\"year_starts_from\":\"1\",\"moment_format\":\"DD-MM-YYYY\",\"time_format\":\"h:i a\",\"locale\":\"en\",\"latitude\":\"26.91243360\",\"longitude\":\"75.78727090\",\"leaves_start_from\":\"joining_date\",\"active_theme\":\"default\",\"status\":\"active\",\"last_updated_by\":3,\"currency_converter_key\":null,\"google_map_key\":null,\"task_self\":\"yes\",\"purchase_code\":null,\"license_type\":null,\"supported_until\":null,\"google_recaptcha_status\":\"deactive\",\"google_recaptcha_v2_status\":\"deactive\",\"google_recaptcha_v2_site_key\":null,\"google_recaptcha_v2_secret_key\":null,\"google_recaptcha_v3_status\":\"deactive\",\"google_recaptcha_v3_site_key\":null,\"google_recaptcha_v3_secret_key\":null,\"app_debug\":0,\"rounded_theme\":1,\"hide_cron_message\":0,\"system_update\":1,\"logo_background_color\":\"#ffffff\",\"header_color\":\"#1D82F5\",\"before_days\":0,\"after_days\":0,\"on_deadline\":\"yes\",\"default_task_status\":9,\"show_review_modal\":1,\"dashboard_clock\":1,\"ticket_form_google_captcha\":0,\"lead_form_google_captcha\":0,\"taskboard_length\":10,\"datatable_row_limit\":10,\"last_cron_run\":null,\"session_driver\":\"file\",\"allow_client_signup\":0,\"admin_client_signup_approval\":0,\"allowed_file_types\":null,\"google_calendar_status\":\"inactive\",\"google_client_id\":null,\"google_client_secret\":null,\"google_calendar_verification_status\":\"non_verified\",\"google_id\":null,\"name\":null,\"token\":null,\"hash\":\"7b5eda6bc7e40e3125395bc8b590d3e3\",\"allowed_file_size\":10,\"currency_key_version\":\"free\",\"last_login\":\"2023-08-11T02:10:34+00:00\",\"rtl\":0,\"stripe_id\":\"cus_OQbsuE96dFZSjm\",\"card_brand\":null,\"card_last_four\":null,\"trial_ends_at\":null,\"licence_expire_on\":null,\"license_updated_at\":null,\"subscription_updated_at\":\"2023-08-11T02:10:35+00:00\",\"approved\":1,\"approved_by\":null,\"show_new_webhook_alert\":0,\"pm_type\":\"visa\",\"pm_last_four\":\"4242\",\"logo_url\":\"https:\\/\\/wst.avts.com.my\\/img\\/worksuite-logo.png\",\"login_background_url\":null,\"moment_date_format\":\"DD-MM-YYYY\",\"favicon_url\":\"https:\\/\\/wst.avts.com.my\\/favicon.png\",\"package\":{\"id\":5,\"currency_id\":1,\"name\":\"Larger\",\"description\":\"Quidem deserunt nobis asperiores fuga Ullamco corporis culpa\",\"max_storage_size\":500,\"max_file_size\":100,\"annual_price\":5000,\"monthly_price\":500,\"billing_cycle\":10,\"max_employees\":500,\"sort\":\"4\",\"module_in_package\":\"{\\\"1\\\":\\\"clients\\\",\\\"2\\\":\\\"employees\\\",\\\"3\\\":\\\"projects\\\",\\\"4\\\":\\\"attendance\\\",\\\"5\\\":\\\"tasks\\\",\\\"6\\\":\\\"estimates\\\",\\\"7\\\":\\\"invoices\\\",\\\"8\\\":\\\"payments\\\",\\\"9\\\":\\\"timelogs\\\",\\\"10\\\":\\\"tickets\\\",\\\"11\\\":\\\"events\\\",\\\"12\\\":\\\"notices\\\",\\\"13\\\":\\\"leaves\\\",\\\"14\\\":\\\"leads\\\",\\\"15\\\":\\\"holidays\\\",\\\"16\\\":\\\"products\\\",\\\"17\\\":\\\"expenses\\\",\\\"18\\\":\\\"contracts\\\",\\\"19\\\":\\\"reports\\\",\\\"22\\\":\\\"orders\\\",\\\"23\\\":\\\"knowledgebase\\\",\\\"24\\\":\\\"bankaccount\\\",\\\"25\\\":\\\"messages\\\"}\",\"stripe_annual_plan_id\":\"larger_annual\",\"stripe_monthly_plan_id\":\"price_1Ndkn7CC83aJafql1dMH3QqC\",\"razorpay_annual_plan_id\":null,\"razorpay_monthly_plan_id\":null,\"default\":\"no\",\"paystack_monthly_plan_id\":null,\"paystack_annual_plan_id\":null,\"is_private\":0,\"storage_unit\":\"mb\",\"is_recommended\":0,\"is_free\":0,\"is_auto_renew\":0,\"monthly_status\":\"1\",\"annual_status\":\"1\",\"formatted_annual_price\":\"RM5,000.00\",\"formatted_monthly_price\":\"RM500.00\"}},\"department\":null},\"company_name\":\"Ascot Hill\"}',NULL,'2023-08-11 02:10:40','2023-08-11 02:10:40'),('db8c223b-11e1-4005-ae56-4d2c0ae90d17','App\\Notifications\\NewUser','App\\Models\\User',4,'{\"id\":4,\"company_id\":1,\"user_auth_id\":4,\"is_superadmin\":0,\"name\":\"Ali\",\"email\":\"ali@mail.com\",\"image\":null,\"country_phonecode\":93,\"mobile\":null,\"gender\":\"male\",\"salutation\":null,\"locale\":\"en\",\"status\":\"active\",\"login\":\"disable\",\"onesignal_player_id\":null,\"last_login\":null,\"email_notifications\":1,\"country_id\":1,\"dark_theme\":0,\"rtl\":0,\"admin_approval\":1,\"permission_sync\":1,\"google_calendar_status\":1,\"customised_permissions\":0,\"stripe_id\":null,\"pm_type\":null,\"pm_last_four\":null,\"trial_ends_at\":null,\"image_url\":\"https:\\/\\/www.gravatar.com\\/avatar\\/c8c304157fdaa53a4c969dff04870fdc.png?s=200&d=mp\",\"modules\":[\"clients\",\"projects\",\"tickets\",\"invoices\",\"estimates\",\"events\",\"messages\",\"tasks\",\"timelogs\",\"contracts\",\"notices\",\"payments\",\"orders\",\"knowledgebase\",\"employees\",\"attendance\",\"expenses\",\"leaves\",\"leads\",\"holidays\",\"products\",\"reports\",\"bankaccount\",\"payroll\",\"recruit\"],\"mobile_with_phonecode\":\"--\",\"client_details\":null,\"employee_detail\":null}',NULL,'2023-08-21 05:44:55','2023-08-21 05:44:55'),('ef4239b0-d719-4900-9269-1dff7f5d3419','App\\Notifications\\SuperAdmin\\CompanyUpdatedPlan','App\\Models\\User',1,'{\"id\":1,\"company_id\":null,\"user_auth_id\":1,\"is_superadmin\":1,\"name\":\"Medium\",\"email\":\"avtssb@gmail.com\",\"image\":null,\"country_phonecode\":null,\"mobile\":null,\"gender\":\"male\",\"salutation\":null,\"locale\":\"en\",\"status\":\"active\",\"login\":\"enable\",\"onesignal_player_id\":null,\"last_login\":\"2023-08-11T01:54:38+00:00\",\"email_notifications\":1,\"country_id\":null,\"dark_theme\":0,\"rtl\":0,\"admin_approval\":1,\"permission_sync\":1,\"google_calendar_status\":1,\"customised_permissions\":0,\"stripe_id\":null,\"pm_type\":null,\"pm_last_four\":null,\"trial_ends_at\":null,\"image_url\":\"https:\\/\\/www.gravatar.com\\/avatar\\/e69474603519901ce77b7037b1d14ab9.png?s=200&d=mp\",\"modules\":[\"clients\",\"projects\",\"tickets\",\"invoices\",\"estimates\",\"events\",\"messages\",\"tasks\",\"timelogs\",\"contracts\",\"notices\",\"payments\",\"orders\",\"knowledgebase\",\"employees\",\"attendance\",\"expenses\",\"leaves\",\"leads\",\"holidays\",\"products\",\"reports\",\"bankaccount\"],\"mobile_with_phonecode\":\"--\",\"client_details\":null,\"employee_detail\":null,\"company_name\":\"Ascot Hill\"}',NULL,'2023-08-11 02:03:32','2023-08-11 02:03:32');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_letter_histories`
--

DROP TABLE IF EXISTS `offer_letter_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer_letter_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_offer_letter_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `recruit_job_offer_file_id` int(10) unsigned DEFAULT NULL,
  `details` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offer_letter_histories_user_id_foreign` (`user_id`),
  KEY `offer_letter_histories_recruit_job_offer_letter_id_foreign` (`recruit_job_offer_letter_id`),
  KEY `offer_letter_histories_recruit_job_offer_file_id_foreign` (`recruit_job_offer_file_id`),
  CONSTRAINT `offer_letter_histories_recruit_job_offer_file_id_foreign` FOREIGN KEY (`recruit_job_offer_file_id`) REFERENCES `recruit_job_offer_files` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offer_letter_histories_recruit_job_offer_letter_id_foreign` FOREIGN KEY (`recruit_job_offer_letter_id`) REFERENCES `recruit_job_offer_letter` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offer_letter_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_letter_histories`
--

LOCK TABLES `offer_letter_histories` WRITE;
/*!40000 ALTER TABLE `offer_letter_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_letter_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_invoices`
--

DROP TABLE IF EXISTS `offline_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `package_id` bigint(20) unsigned NOT NULL,
  `package_type` varchar(191) DEFAULT NULL,
  `offline_method_id` int(10) unsigned DEFAULT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `amount` decimal(12,2) unsigned NOT NULL,
  `pay_date` date NOT NULL,
  `next_pay_date` date DEFAULT NULL,
  `status` enum('paid','unpaid','pending') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offline_invoices_company_id_foreign` (`company_id`),
  KEY `offline_invoices_package_id_foreign` (`package_id`),
  KEY `offline_invoices_offline_method_id_foreign` (`offline_method_id`),
  CONSTRAINT `offline_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offline_invoices_offline_method_id_foreign` FOREIGN KEY (`offline_method_id`) REFERENCES `offline_payment_methods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `offline_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_invoices`
--

LOCK TABLES `offline_invoices` WRITE;
/*!40000 ALTER TABLE `offline_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `offline_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_payment_methods`
--

DROP TABLE IF EXISTS `offline_payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_payment_methods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `description` longtext DEFAULT NULL,
  `status` enum('yes','no') DEFAULT 'yes',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offline_payment_methods_company_id_foreign` (`company_id`),
  CONSTRAINT `offline_payment_methods_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_payment_methods`
--

LOCK TABLES `offline_payment_methods` WRITE;
/*!40000 ALTER TABLE `offline_payment_methods` DISABLE KEYS */;
INSERT INTO `offline_payment_methods` VALUES (1,NULL,'cash','online transfer','yes','2023-08-10 14:20:05','2023-08-10 14:20:05');
/*!40000 ALTER TABLE `offline_payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offline_plan_changes`
--

DROP TABLE IF EXISTS `offline_plan_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offline_plan_changes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `package_id` bigint(20) unsigned NOT NULL,
  `package_type` varchar(191) NOT NULL,
  `amount` double DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `next_pay_date` date DEFAULT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `offline_method_id` int(10) unsigned NOT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `status` enum('verified','pending','rejected') NOT NULL DEFAULT 'pending',
  `remark` text DEFAULT NULL,
  `description` mediumtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `offline_plan_changes_company_id_foreign` (`company_id`),
  KEY `offline_plan_changes_package_id_foreign` (`package_id`),
  KEY `offline_plan_changes_invoice_id_foreign` (`invoice_id`),
  KEY `offline_plan_changes_offline_method_id_foreign` (`offline_method_id`),
  CONSTRAINT `offline_plan_changes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offline_plan_changes_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `offline_invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offline_plan_changes_offline_method_id_foreign` FOREIGN KEY (`offline_method_id`) REFERENCES `offline_payment_methods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `offline_plan_changes_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_plan_changes`
--

LOCK TABLES `offline_plan_changes` WRITE;
/*!40000 ALTER TABLE `offline_plan_changes` DISABLE KEYS */;
/*!40000 ALTER TABLE `offline_plan_changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_carts`
--

DROP TABLE IF EXISTS `order_carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_carts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `item_name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `quantity` double(16,2) NOT NULL,
  `unit_price` double(16,2) NOT NULL,
  `amount` double(16,2) NOT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_carts_product_id_foreign` (`product_id`),
  KEY `order_carts_client_id_foreign` (`client_id`),
  KEY `order_carts_unit_id_foreign` (`unit_id`),
  CONSTRAINT `order_carts_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_carts_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_carts_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_carts`
--

LOCK TABLES `order_carts` WRITE;
/*!40000 ALTER TABLE `order_carts` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item_images`
--

DROP TABLE IF EXISTS `order_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_item_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_item_images_order_item_id_index` (`order_item_id`),
  CONSTRAINT `order_item_images_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item_images`
--

LOCK TABLES `order_item_images` WRITE;
/*!40000 ALTER TABLE `order_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  `item_name` varchar(191) NOT NULL,
  `item_summary` text DEFAULT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `quantity` double(16,2) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `amount` double(8,2) NOT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  KEY `order_items_unit_id_foreign` (`unit_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `order_items_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` bigint(20) DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `order_date` date NOT NULL,
  `sub_total` double(8,2) NOT NULL,
  `discount` double NOT NULL DEFAULT 0,
  `discount_type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `total` double(8,2) NOT NULL,
  `status` enum('pending','on-hold','failed','processing','completed','canceled','refunded') NOT NULL DEFAULT 'pending',
  `currency_id` int(10) unsigned DEFAULT NULL,
  `show_shipping_address` enum('yes','no') NOT NULL DEFAULT 'no',
  `note` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `company_address_id` bigint(20) unsigned DEFAULT NULL,
  `custom_order_number` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_company_id_foreign` (`company_id`),
  KEY `orders_client_id_foreign` (`client_id`),
  KEY `orders_currency_id_foreign` (`currency_id`),
  KEY `orders_added_by_foreign` (`added_by`),
  KEY `orders_last_updated_by_foreign` (`last_updated_by`),
  KEY `orders_company_address_id_foreign` (`company_address_id`),
  CONSTRAINT `orders_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_company_address_id_foreign` FOREIGN KEY (`company_address_id`) REFERENCES `company_addresses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_settings`
--

DROP TABLE IF EXISTS `package_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `no_of_days` int(11) DEFAULT 30,
  `modules` varchar(1000) DEFAULT NULL,
  `trial_message` text DEFAULT NULL,
  `notification_before` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_settings`
--

LOCK TABLES `package_settings` WRITE;
/*!40000 ALTER TABLE `package_settings` DISABLE KEYS */;
INSERT INTO `package_settings` VALUES (1,'inactive',30,'[\"clients\",\"employees\",\"projects\",\"attendance\",\"tasks\",\"estimates\",\"invoices\",\"payments\",\"timelogs\",\"tickets\",\"events\",\"notices\",\"leaves\",\"leads\",\"holidays\",\"products\",\"expenses\",\"contracts\",\"reports\",\"orders\",\"knowledgebase\",\"bankaccount\",\"messages\"]','Start 30 days free trial',NULL,'2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `package_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_update_notifies`
--

DROP TABLE IF EXISTS `package_update_notifies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_update_notifies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `package_update_notifies_company_id_foreign` (`company_id`),
  KEY `package_update_notifies_user_id_foreign` (`user_id`),
  CONSTRAINT `package_update_notifies_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `package_update_notifies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_update_notifies`
--

LOCK TABLES `package_update_notifies` WRITE;
/*!40000 ALTER TABLE `package_update_notifies` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_update_notifies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `currency_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `max_storage_size` int(11) NOT NULL,
  `max_file_size` int(10) unsigned NOT NULL DEFAULT 0,
  `annual_price` double DEFAULT 0,
  `monthly_price` double DEFAULT 0,
  `billing_cycle` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `max_employees` int(10) unsigned NOT NULL DEFAULT 0,
  `sort` varchar(191) NOT NULL,
  `module_in_package` varchar(1000) NOT NULL,
  `stripe_annual_plan_id` varchar(255) DEFAULT NULL,
  `stripe_monthly_plan_id` varchar(255) DEFAULT NULL,
  `razorpay_annual_plan_id` varchar(191) DEFAULT NULL,
  `razorpay_monthly_plan_id` varchar(191) DEFAULT NULL,
  `default` enum('yes','no','trial') DEFAULT 'no',
  `paystack_monthly_plan_id` varchar(191) DEFAULT NULL,
  `paystack_annual_plan_id` varchar(191) DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL,
  `storage_unit` enum('gb','mb') NOT NULL DEFAULT 'mb',
  `is_recommended` tinyint(1) NOT NULL DEFAULT 0,
  `is_free` tinyint(1) NOT NULL DEFAULT 0,
  `is_auto_renew` tinyint(1) NOT NULL DEFAULT 0,
  `monthly_status` varchar(191) DEFAULT '1',
  `annual_status` varchar(191) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `packages_currency_id_foreign` (`currency_id`),
  CONSTRAINT `packages_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `global_currencies` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,5,'Default','Its a default package and cannot be deleted',0,0,0,0,0,20,'1','{\"1\":\"clients\",\"2\":\"employees\",\"3\":\"projects\",\"4\":\"attendance\",\"5\":\"tasks\",\"6\":\"estimates\",\"7\":\"invoices\",\"8\":\"payments\",\"9\":\"timelogs\",\"10\":\"tickets\",\"11\":\"events\",\"12\":\"notices\",\"13\":\"leaves\",\"14\":\"leads\",\"15\":\"holidays\",\"16\":\"products\",\"17\":\"expenses\",\"18\":\"contracts\",\"19\":\"reports\",\"22\":\"orders\",\"23\":\"knowledgebase\",\"24\":\"bankaccount\",\"25\":\"messages\",\"34\":\"payroll\",\"35\":\"recruit\"}',NULL,NULL,NULL,NULL,'yes',NULL,NULL,0,'mb',0,1,0,'1','1','2023-08-10 14:06:55','2023-08-21 05:42:40'),(2,1,'Trial','Its a trial package',500,0,0,0,0,20,'','[\"clients\",\"employees\",\"projects\",\"attendance\",\"tasks\",\"estimates\",\"invoices\",\"payments\",\"timelogs\",\"tickets\",\"events\",\"notices\",\"leaves\",\"leads\",\"holidays\",\"products\",\"expenses\",\"contracts\",\"reports\",\"orders\",\"knowledgebase\",\"bankaccount\",\"messages\"]','trial_plan','trial_plan',NULL,NULL,'trial',NULL,NULL,0,'mb',0,0,0,'1','1','2023-08-10 14:06:55','2023-08-10 14:06:55'),(6,5,'Basic','Thank you for your business',500,0,100,10,0,50,'5','{\"1\":\"clients\",\"2\":\"employees\",\"3\":\"projects\",\"4\":\"attendance\",\"5\":\"tasks\",\"6\":\"estimates\",\"7\":\"invoices\",\"8\":\"payments\",\"9\":\"timelogs\",\"10\":\"tickets\",\"11\":\"events\",\"12\":\"notices\",\"13\":\"leaves\",\"14\":\"leads\",\"15\":\"holidays\",\"16\":\"products\",\"17\":\"expenses\",\"18\":\"contracts\",\"19\":\"reports\",\"22\":\"orders\",\"23\":\"knowledgebase\",\"24\":\"bankaccount\",\"25\":\"messages\"}','annually','monthly',NULL,NULL,'no',NULL,NULL,0,'mb',0,0,0,'1','1','2023-08-14 12:23:52','2023-08-21 16:08:16');
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passport_details`
--

DROP TABLE IF EXISTS `passport_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passport_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `country_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `passport_number` varchar(191) NOT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `file` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `passport_details_company_id_foreign` (`company_id`),
  KEY `passport_details_user_id_foreign` (`user_id`),
  KEY `passport_details_added_by_foreign` (`added_by`),
  KEY `passport_details_country_id_foreign` (`country_id`),
  CONSTRAINT `passport_details_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `passport_details_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `passport_details_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `passport_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passport_details`
--

LOCK TABLES `passport_details` WRITE;
/*!40000 ALTER TABLE `passport_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `passport_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payfast_invoices`
--

DROP TABLE IF EXISTS `payfast_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payfast_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `package_id` bigint(20) unsigned DEFAULT NULL,
  `m_payment_id` varchar(191) DEFAULT NULL,
  `pf_payment_id` varchar(191) DEFAULT NULL,
  `payfast_plan` varchar(191) DEFAULT NULL,
  `amount` varchar(191) DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `next_pay_date` date DEFAULT NULL,
  `signature` varchar(191) DEFAULT NULL,
  `token` varchar(191) DEFAULT NULL,
  `status` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payfast_invoices_company_id_foreign` (`company_id`),
  KEY `payfast_invoices_package_id_foreign` (`package_id`),
  CONSTRAINT `payfast_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payfast_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payfast_invoices`
--

LOCK TABLES `payfast_invoices` WRITE;
/*!40000 ALTER TABLE `payfast_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `payfast_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payfast_subscriptions`
--

DROP TABLE IF EXISTS `payfast_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payfast_subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `payfast_plan` varchar(191) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `payfast_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `ends_at` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payfast_subscriptions_company_id_foreign` (`company_id`),
  CONSTRAINT `payfast_subscriptions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payfast_subscriptions`
--

LOCK TABLES `payfast_subscriptions` WRITE;
/*!40000 ALTER TABLE `payfast_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `payfast_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateway_credentials`
--

DROP TABLE IF EXISTS `payment_gateway_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_gateway_credentials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `paypal_client_id` varchar(191) DEFAULT NULL,
  `paypal_secret` varchar(191) DEFAULT NULL,
  `paypal_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `live_stripe_client_id` varchar(191) DEFAULT NULL,
  `live_stripe_secret` varchar(191) DEFAULT NULL,
  `live_stripe_webhook_secret` varchar(191) DEFAULT NULL,
  `stripe_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `live_razorpay_key` varchar(191) DEFAULT NULL,
  `live_razorpay_secret` varchar(191) DEFAULT NULL,
  `razorpay_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `paypal_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `sandbox_paypal_client_id` varchar(191) DEFAULT NULL,
  `sandbox_paypal_secret` varchar(191) DEFAULT NULL,
  `test_stripe_client_id` varchar(191) DEFAULT NULL,
  `test_stripe_secret` varchar(191) DEFAULT NULL,
  `test_stripe_webhook_secret` varchar(191) DEFAULT NULL,
  `test_razorpay_key` varchar(191) DEFAULT NULL,
  `test_razorpay_secret` varchar(191) DEFAULT NULL,
  `stripe_mode` enum('test','live') NOT NULL DEFAULT 'test',
  `razorpay_mode` enum('test','live') NOT NULL DEFAULT 'test',
  `paystack_key` varchar(191) DEFAULT NULL,
  `paystack_secret` varchar(191) DEFAULT NULL,
  `paystack_merchant_email` varchar(191) DEFAULT NULL,
  `paystack_status` enum('active','deactive') DEFAULT 'deactive',
  `paystack_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `test_paystack_key` varchar(191) DEFAULT NULL,
  `test_paystack_secret` varchar(191) DEFAULT NULL,
  `test_paystack_merchant_email` varchar(191) DEFAULT NULL,
  `paystack_payment_url` varchar(191) DEFAULT 'https://api.paystack.co',
  `mollie_api_key` varchar(191) DEFAULT NULL,
  `mollie_status` enum('active','deactive') DEFAULT 'deactive',
  `payfast_merchant_id` varchar(191) DEFAULT NULL,
  `payfast_merchant_key` varchar(191) DEFAULT NULL,
  `payfast_passphrase` varchar(191) DEFAULT NULL,
  `payfast_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `payfast_status` enum('active','deactive') DEFAULT 'deactive',
  `authorize_api_login_id` varchar(191) DEFAULT NULL,
  `authorize_transaction_key` varchar(191) DEFAULT NULL,
  `authorize_environment` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `authorize_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `square_application_id` varchar(191) DEFAULT NULL,
  `square_access_token` varchar(191) DEFAULT NULL,
  `square_location_id` varchar(191) DEFAULT NULL,
  `square_environment` enum('sandbox','production') NOT NULL DEFAULT 'sandbox',
  `square_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `flutterwave_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `flutterwave_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `test_flutterwave_key` varchar(191) DEFAULT NULL,
  `test_flutterwave_secret` varchar(191) DEFAULT NULL,
  `test_flutterwave_hash` varchar(191) DEFAULT NULL,
  `live_flutterwave_key` varchar(191) DEFAULT NULL,
  `live_flutterwave_secret` varchar(191) DEFAULT NULL,
  `live_flutterwave_hash` varchar(191) DEFAULT NULL,
  `flutterwave_webhook_secret_hash` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `test_payfast_merchant_id` varchar(191) DEFAULT NULL,
  `test_payfast_merchant_key` varchar(191) DEFAULT NULL,
  `test_payfast_passphrase` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_gateway_credentials_company_id_foreign` (`company_id`),
  CONSTRAINT `payment_gateway_credentials_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateway_credentials`
--

LOCK TABLES `payment_gateway_credentials` WRITE;
/*!40000 ALTER TABLE `payment_gateway_credentials` DISABLE KEYS */;
INSERT INTO `payment_gateway_credentials` VALUES (1,1,NULL,NULL,'deactive',NULL,NULL,NULL,'deactive',NULL,NULL,'inactive','sandbox',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'test','test',NULL,NULL,NULL,'deactive','sandbox',NULL,NULL,NULL,'https://api.paystack.co',NULL,'deactive',NULL,NULL,NULL,'sandbox','deactive',NULL,NULL,'sandbox','deactive',NULL,NULL,NULL,'sandbox','deactive','deactive','sandbox',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-08-10 14:06:55','2023-08-10 14:06:55',NULL,NULL,NULL),(3,3,NULL,NULL,'deactive',NULL,NULL,NULL,'deactive',NULL,NULL,'inactive','sandbox',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'test','test',NULL,NULL,NULL,'deactive','sandbox',NULL,NULL,NULL,'https://api.paystack.co',NULL,'deactive',NULL,NULL,NULL,'sandbox','deactive',NULL,NULL,'sandbox','deactive',NULL,NULL,NULL,'sandbox','deactive','deactive','sandbox',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-08-10 14:17:22','2023-08-10 14:17:22',NULL,NULL,NULL),(7,7,NULL,NULL,'deactive',NULL,NULL,NULL,'deactive',NULL,NULL,'inactive','sandbox',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'test','test',NULL,NULL,NULL,'deactive','sandbox',NULL,NULL,NULL,'https://api.paystack.co',NULL,'deactive',NULL,NULL,NULL,'sandbox','deactive',NULL,NULL,'sandbox','deactive',NULL,NULL,NULL,'sandbox','deactive','deactive','sandbox',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-08-21 16:25:19','2023-08-21 16:25:19',NULL,NULL,NULL);
/*!40000 ALTER TABLE `payment_gateway_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `credit_notes_id` int(10) unsigned DEFAULT NULL,
  `amount` double NOT NULL,
  `gateway` varchar(191) DEFAULT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `default_currency_id` int(10) unsigned DEFAULT NULL,
  `exchange_rate` double DEFAULT NULL,
  `plan_id` varchar(191) DEFAULT NULL,
  `customer_id` varchar(191) DEFAULT NULL,
  `event_id` varchar(191) DEFAULT NULL,
  `status` enum('complete','pending','failed') NOT NULL DEFAULT 'pending',
  `paid_on` datetime DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `offline_method_id` int(10) unsigned DEFAULT NULL,
  `bill` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `payment_gateway_response` text DEFAULT NULL COMMENT 'null = success',
  `payload_id` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bank_account_id` int(10) unsigned DEFAULT NULL,
  `quickbooks_payment_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_plan_id_unique` (`plan_id`),
  UNIQUE KEY `payments_event_id_company_id_unique` (`event_id`,`company_id`),
  UNIQUE KEY `payments_transaction_id_company_id_unique` (`transaction_id`,`company_id`),
  KEY `payments_company_id_foreign` (`company_id`),
  KEY `payments_project_id_foreign` (`project_id`),
  KEY `payments_invoice_id_foreign` (`invoice_id`),
  KEY `payments_order_id_foreign` (`order_id`),
  KEY `payments_credit_notes_id_foreign` (`credit_notes_id`),
  KEY `payments_currency_id_foreign` (`currency_id`),
  KEY `payments_paid_on_index` (`paid_on`),
  KEY `payments_offline_method_id_foreign` (`offline_method_id`),
  KEY `payments_added_by_foreign` (`added_by`),
  KEY `payments_last_updated_by_foreign` (`last_updated_by`),
  KEY `payments_bank_account_id_foreign` (`bank_account_id`),
  KEY `payments_default_currency_id_foreign` (`default_currency_id`),
  CONSTRAINT `payments_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payments_bank_account_id_foreign` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payments_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_credit_notes_id_foreign` FOREIGN KEY (`credit_notes_id`) REFERENCES `credit_notes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_default_currency_id_foreign` FOREIGN KEY (`default_currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payments_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payments_offline_method_id_foreign` FOREIGN KEY (`offline_method_id`) REFERENCES `offline_payment_methods` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `payments_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paypal_invoices`
--

DROP TABLE IF EXISTS `paypal_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paypal_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `package_id` bigint(20) unsigned DEFAULT NULL,
  `sub_total` double DEFAULT NULL,
  `total` double DEFAULT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `remarks` varchar(191) DEFAULT NULL,
  `billing_frequency` varchar(191) DEFAULT NULL,
  `billing_interval` int(11) DEFAULT NULL,
  `paid_on` datetime DEFAULT NULL,
  `next_pay_date` datetime DEFAULT NULL,
  `recurring` enum('yes','no') DEFAULT 'no',
  `status` enum('paid','unpaid','pending') DEFAULT 'pending',
  `plan_id` varchar(191) DEFAULT NULL,
  `event_id` varchar(191) DEFAULT NULL,
  `end_on` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paypal_invoices_company_id_foreign` (`company_id`),
  KEY `paypal_invoices_currency_id_foreign` (`currency_id`),
  KEY `paypal_invoices_package_id_foreign` (`package_id`),
  CONSTRAINT `paypal_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `paypal_invoices_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `paypal_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paypal_invoices`
--

LOCK TABLES `paypal_invoices` WRITE;
/*!40000 ALTER TABLE `paypal_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `paypal_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_cycles`
--

DROP TABLE IF EXISTS `payroll_cycles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_cycles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cycle` varchar(191) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_cycles`
--

LOCK TABLES `payroll_cycles` WRITE;
/*!40000 ALTER TABLE `payroll_cycles` DISABLE KEYS */;
INSERT INTO `payroll_cycles` VALUES (1,'monthly','active','2023-08-21 05:36:54','2023-08-21 05:36:54'),(2,'weekly','active','2023-08-21 05:36:54','2023-08-21 05:36:54'),(3,'biweekly','active','2023-08-21 05:36:54','2023-08-21 05:36:54'),(4,'semimonthly','active','2023-08-21 05:36:54','2023-08-21 05:36:54');
/*!40000 ALTER TABLE `payroll_cycles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_global_settings`
--

DROP TABLE IF EXISTS `payroll_global_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_global_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_code` varchar(191) DEFAULT NULL,
  `license_type` varchar(20) DEFAULT NULL,
  `supported_until` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_global_settings`
--

LOCK TABLES `payroll_global_settings` WRITE;
/*!40000 ALTER TABLE `payroll_global_settings` DISABLE KEYS */;
INSERT INTO `payroll_global_settings` VALUES (1,NULL,NULL,NULL,'2023-08-21 05:36:54','2023-08-21 05:36:54');
/*!40000 ALTER TABLE `payroll_global_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_settings`
--

DROP TABLE IF EXISTS `payroll_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `tds_salary` varchar(191) NOT NULL,
  `tds_status` tinyint(1) NOT NULL,
  `finance_month` varchar(191) NOT NULL DEFAULT '04',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `extra_fields` text DEFAULT NULL,
  `semi_monthly_start` int(11) DEFAULT 1,
  `semi_monthly_end` int(11) DEFAULT 30,
  `currency_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payroll_settings_company_id_foreign` (`company_id`),
  KEY `payroll_settings_currency_id_foreign` (`currency_id`),
  CONSTRAINT `payroll_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payroll_settings_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_settings`
--

LOCK TABLES `payroll_settings` WRITE;
/*!40000 ALTER TABLE `payroll_settings` DISABLE KEYS */;
INSERT INTO `payroll_settings` VALUES (1,1,'',0,'04','2023-08-21 05:36:56','2023-08-21 05:36:56',NULL,1,30,1),(2,3,'',0,'04','2023-08-21 05:36:56','2023-08-21 05:36:56',NULL,1,30,NULL),(6,7,'',0,'04','2023-08-21 16:25:19','2023-08-21 16:25:19',NULL,1,30,NULL);
/*!40000 ALTER TABLE `payroll_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paystack_invoices`
--

DROP TABLE IF EXISTS `paystack_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paystack_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `package_id` bigint(20) unsigned NOT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `amount` varchar(191) DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `next_pay_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paystack_invoices_company_id_foreign` (`company_id`),
  KEY `paystack_invoices_package_id_foreign` (`package_id`),
  CONSTRAINT `paystack_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `paystack_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paystack_invoices`
--

LOCK TABLES `paystack_invoices` WRITE;
/*!40000 ALTER TABLE `paystack_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `paystack_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paystack_subscriptions`
--

DROP TABLE IF EXISTS `paystack_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paystack_subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `subscription_id` varchar(191) DEFAULT NULL,
  `customer_id` varchar(191) DEFAULT NULL,
  `token` varchar(191) NOT NULL,
  `plan_id` varchar(191) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `paystack_subscriptions_company_id_foreign` (`company_id`),
  CONSTRAINT `paystack_subscriptions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paystack_subscriptions`
--

LOCK TABLES `paystack_subscriptions` WRITE;
/*!40000 ALTER TABLE `paystack_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `paystack_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_role` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `permission_type_id` bigint(20) unsigned NOT NULL DEFAULT 5,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `permission_role_role_id_foreign` (`role_id`),
  KEY `permission_role_permission_type_id_foreign` (`permission_type_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `permission_role_permission_type_id_foreign` FOREIGN KEY (`permission_type_id`) REFERENCES `permission_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES (58,2,1),(58,3,1),(58,9,1),(58,10,1),(58,21,1),(58,22,1),(61,2,1),(61,3,1),(61,9,1),(61,10,1),(61,21,1),(61,22,1),(62,2,1),(62,3,1),(62,9,1),(62,10,1),(62,21,1),(62,22,1),(99,2,1),(99,9,1),(99,21,1),(101,2,1),(101,9,1),(101,21,1),(102,2,1),(102,9,1),(102,21,1),(109,2,1),(109,9,1),(109,21,1),(112,2,1),(112,9,1),(112,21,1),(113,2,1),(113,9,1),(113,21,1),(116,2,1),(116,3,1),(116,9,1),(116,10,1),(116,21,1),(116,22,1),(117,2,1),(117,3,1),(117,9,1),(117,10,1),(117,21,1),(117,22,1),(120,2,1),(120,3,1),(120,9,1),(120,10,1),(120,21,1),(120,22,1),(121,2,1),(121,3,1),(121,9,1),(121,10,1),(121,21,1),(121,22,1),(144,2,1),(144,9,1),(144,21,1),(146,2,1),(146,9,1),(146,21,1),(151,2,1),(151,3,1),(151,9,1),(151,10,1),(151,21,1),(151,22,1),(153,3,1),(153,10,1),(153,22,1),(154,2,1),(154,3,1),(154,9,1),(154,10,1),(154,21,1),(154,22,1),(168,2,1),(168,9,1),(168,21,1),(174,2,1),(174,9,1),(174,21,1),(176,2,1),(176,9,1),(176,21,1),(187,2,1),(187,9,1),(187,21,1),(192,2,1),(192,9,1),(192,21,1),(193,2,1),(193,9,1),(193,21,1),(219,2,1),(219,9,1),(219,21,1),(221,2,1),(221,9,1),(221,21,1),(222,2,1),(222,9,1),(222,21,1),(44,2,2),(44,9,2),(44,21,2),(47,2,2),(47,9,2),(47,21,2),(48,2,2),(48,9,2),(48,21,2),(49,2,2),(49,9,2),(49,21,2),(50,2,2),(50,9,2),(50,21,2),(52,2,2),(52,3,2),(52,9,2),(52,10,2),(52,21,2),(52,22,2),(96,2,2),(96,9,2),(96,21,2),(100,3,2),(100,10,2),(100,22,2),(129,3,2),(129,10,2),(129,22,2),(133,3,2),(133,10,2),(133,22,2),(140,3,2),(140,10,2),(140,22,2),(145,3,2),(145,10,2),(145,22,2),(161,2,2),(161,3,2),(161,9,2),(161,10,2),(161,21,2),(161,22,2),(165,2,2),(165,3,2),(165,9,2),(165,10,2),(165,21,2),(165,22,2),(228,3,2),(228,10,2),(228,22,2),(283,3,2),(283,10,2),(283,22,2),(100,2,3),(100,9,3),(100,21,3),(145,2,3),(145,9,3),(145,21,3),(152,2,3),(152,3,3),(152,9,3),(152,10,3),(152,21,3),(152,22,3),(153,2,3),(153,9,3),(153,21,3),(169,2,3),(169,9,3),(169,21,3),(175,2,3),(175,9,3),(175,21,3),(203,2,3),(203,9,3),(203,21,3),(220,2,3),(220,9,3),(220,21,3),(1,1,4),(1,8,4),(1,20,4),(2,1,4),(2,8,4),(2,20,4),(3,1,4),(3,8,4),(3,20,4),(4,1,4),(4,8,4),(4,20,4),(5,1,4),(5,8,4),(5,20,4),(6,1,4),(6,8,4),(6,20,4),(7,1,4),(7,8,4),(7,20,4),(8,1,4),(8,8,4),(8,20,4),(9,1,4),(9,8,4),(9,20,4),(10,1,4),(10,8,4),(10,20,4),(11,1,4),(11,8,4),(11,20,4),(12,1,4),(12,8,4),(12,20,4),(13,1,4),(13,8,4),(13,20,4),(14,1,4),(14,8,4),(14,20,4),(15,1,4),(15,8,4),(15,20,4),(16,1,4),(16,8,4),(16,20,4),(17,1,4),(17,8,4),(17,20,4),(18,1,4),(18,8,4),(18,20,4),(19,1,4),(19,8,4),(19,20,4),(20,1,4),(20,8,4),(20,20,4),(21,1,4),(21,8,4),(21,20,4),(22,1,4),(22,8,4),(22,20,4),(23,1,4),(23,8,4),(23,20,4),(24,1,4),(24,8,4),(24,20,4),(25,1,4),(25,8,4),(25,20,4),(26,1,4),(26,8,4),(26,20,4),(27,1,4),(27,8,4),(27,20,4),(28,1,4),(28,8,4),(28,20,4),(29,1,4),(29,8,4),(29,20,4),(30,1,4),(30,8,4),(30,20,4),(31,1,4),(31,8,4),(31,20,4),(32,1,4),(32,8,4),(32,20,4),(33,1,4),(33,8,4),(33,20,4),(34,1,4),(34,8,4),(34,20,4),(35,1,4),(35,2,4),(35,8,4),(35,9,4),(35,20,4),(35,21,4),(36,1,4),(36,8,4),(36,20,4),(37,1,4),(37,8,4),(37,20,4),(38,1,4),(38,8,4),(38,20,4),(39,1,4),(39,8,4),(39,20,4),(40,1,4),(40,8,4),(40,20,4),(41,1,4),(41,8,4),(41,20,4),(42,1,4),(42,8,4),(42,20,4),(43,1,4),(43,8,4),(43,20,4),(44,1,4),(44,8,4),(44,20,4),(45,1,4),(45,8,4),(45,20,4),(46,1,4),(46,8,4),(46,20,4),(47,1,4),(47,8,4),(47,20,4),(48,1,4),(48,8,4),(48,20,4),(49,1,4),(49,8,4),(49,20,4),(50,1,4),(50,8,4),(50,20,4),(51,1,4),(51,8,4),(51,20,4),(52,1,4),(52,8,4),(52,20,4),(53,1,4),(53,8,4),(53,20,4),(54,1,4),(54,8,4),(54,20,4),(55,1,4),(55,8,4),(55,20,4),(56,1,4),(56,2,4),(56,3,4),(56,8,4),(56,9,4),(56,10,4),(56,20,4),(56,21,4),(56,22,4),(57,1,4),(57,2,4),(57,3,4),(57,8,4),(57,9,4),(57,10,4),(57,20,4),(57,21,4),(57,22,4),(58,1,4),(58,8,4),(58,20,4),(59,1,4),(59,2,4),(59,3,4),(59,8,4),(59,9,4),(59,10,4),(59,20,4),(59,21,4),(59,22,4),(60,1,4),(60,2,4),(60,3,4),(60,8,4),(60,9,4),(60,10,4),(60,20,4),(60,21,4),(60,22,4),(61,1,4),(61,8,4),(61,20,4),(62,1,4),(62,8,4),(62,20,4),(63,1,4),(63,8,4),(63,20,4),(64,1,4),(64,8,4),(64,20,4),(65,1,4),(65,8,4),(65,20,4),(66,1,4),(66,8,4),(66,20,4),(67,1,4),(67,8,4),(67,20,4),(68,1,4),(68,2,4),(68,3,4),(68,8,4),(68,9,4),(68,10,4),(68,20,4),(68,21,4),(68,22,4),(69,1,4),(69,8,4),(69,20,4),(70,1,4),(70,8,4),(70,20,4),(71,1,4),(71,8,4),(71,20,4),(72,1,4),(72,8,4),(72,20,4),(73,1,4),(73,8,4),(73,20,4),(74,1,4),(74,8,4),(74,20,4),(75,1,4),(75,8,4),(75,20,4),(76,1,4),(76,8,4),(76,20,4),(77,1,4),(77,2,4),(77,3,4),(77,8,4),(77,9,4),(77,10,4),(77,20,4),(77,21,4),(77,22,4),(78,1,4),(78,8,4),(78,20,4),(79,1,4),(79,2,4),(79,3,4),(79,8,4),(79,9,4),(79,10,4),(79,20,4),(79,21,4),(79,22,4),(80,1,4),(80,3,4),(80,8,4),(80,10,4),(80,20,4),(80,22,4),(81,1,4),(81,8,4),(81,20,4),(82,1,4),(82,3,4),(82,8,4),(82,10,4),(82,20,4),(82,22,4),(83,1,4),(83,8,4),(83,20,4),(84,1,4),(84,8,4),(84,20,4),(85,1,4),(85,2,4),(85,3,4),(85,8,4),(85,9,4),(85,10,4),(85,20,4),(85,21,4),(85,22,4),(86,1,4),(86,8,4),(86,20,4),(87,1,4),(87,8,4),(87,20,4),(88,1,4),(88,8,4),(88,20,4),(89,1,4),(89,8,4),(89,20,4),(90,1,4),(90,8,4),(90,20,4),(91,1,4),(91,8,4),(91,20,4),(92,1,4),(92,8,4),(92,20,4),(93,1,4),(93,8,4),(93,20,4),(94,1,4),(94,8,4),(94,20,4),(95,1,4),(95,8,4),(95,20,4),(96,1,4),(96,8,4),(96,20,4),(97,1,4),(97,8,4),(97,20,4),(98,1,4),(98,8,4),(98,20,4),(99,1,4),(99,8,4),(99,20,4),(100,1,4),(100,8,4),(100,20,4),(101,1,4),(101,8,4),(101,20,4),(102,1,4),(102,8,4),(102,20,4),(103,1,4),(103,8,4),(103,20,4),(104,1,4),(104,8,4),(104,20,4),(105,1,4),(105,8,4),(105,20,4),(106,1,4),(106,8,4),(106,20,4),(107,1,4),(107,2,4),(107,3,4),(107,8,4),(107,9,4),(107,10,4),(107,20,4),(107,21,4),(107,22,4),(108,1,4),(108,2,4),(108,8,4),(108,9,4),(108,20,4),(108,21,4),(109,1,4),(109,8,4),(109,20,4),(110,1,4),(110,2,4),(110,3,4),(110,8,4),(110,9,4),(110,10,4),(110,20,4),(110,21,4),(110,22,4),(111,1,4),(111,2,4),(111,8,4),(111,9,4),(111,20,4),(111,21,4),(112,1,4),(112,8,4),(112,20,4),(113,1,4),(113,8,4),(113,20,4),(114,1,4),(114,2,4),(114,3,4),(114,8,4),(114,9,4),(114,10,4),(114,20,4),(114,21,4),(114,22,4),(115,1,4),(115,2,4),(115,3,4),(115,8,4),(115,9,4),(115,10,4),(115,20,4),(115,21,4),(115,22,4),(116,1,4),(116,8,4),(116,20,4),(117,1,4),(117,8,4),(117,20,4),(118,1,4),(118,2,4),(118,3,4),(118,8,4),(118,9,4),(118,10,4),(118,20,4),(118,21,4),(118,22,4),(119,1,4),(119,2,4),(119,3,4),(119,8,4),(119,9,4),(119,10,4),(119,20,4),(119,21,4),(119,22,4),(120,1,4),(120,8,4),(120,20,4),(121,1,4),(121,8,4),(121,20,4),(122,1,4),(122,8,4),(122,20,4),(123,1,4),(123,8,4),(123,20,4),(124,1,4),(124,8,4),(124,20,4),(125,1,4),(125,8,4),(125,20,4),(126,1,4),(126,8,4),(126,20,4),(127,1,4),(127,8,4),(127,20,4),(128,1,4),(128,8,4),(128,20,4),(129,1,4),(129,8,4),(129,20,4),(130,1,4),(130,8,4),(130,20,4),(131,1,4),(131,8,4),(131,20,4),(132,1,4),(132,8,4),(132,20,4),(133,1,4),(133,8,4),(133,20,4),(134,1,4),(134,8,4),(134,20,4),(135,1,4),(135,8,4),(135,20,4),(136,1,4),(136,8,4),(136,20,4),(137,1,4),(137,8,4),(137,20,4),(138,1,4),(138,8,4),(138,20,4),(139,1,4),(139,8,4),(139,20,4),(140,1,4),(140,8,4),(140,20,4),(141,1,4),(141,8,4),(141,20,4),(142,1,4),(142,8,4),(142,20,4),(143,1,4),(143,8,4),(143,20,4),(144,1,4),(144,8,4),(144,20,4),(145,1,4),(145,8,4),(145,20,4),(146,1,4),(146,8,4),(146,20,4),(147,1,4),(147,8,4),(147,20,4),(148,1,4),(148,8,4),(148,20,4),(149,1,4),(149,8,4),(149,20,4),(150,1,4),(150,8,4),(150,20,4),(151,1,4),(151,8,4),(151,20,4),(152,1,4),(152,8,4),(152,20,4),(153,1,4),(153,8,4),(153,20,4),(154,1,4),(154,8,4),(154,20,4),(155,1,4),(155,8,4),(155,20,4),(156,1,4),(156,8,4),(156,20,4),(157,1,4),(157,8,4),(157,20,4),(158,1,4),(158,8,4),(158,20,4),(159,1,4),(159,8,4),(159,20,4),(160,1,4),(160,8,4),(160,20,4),(161,1,4),(161,8,4),(161,20,4),(162,1,4),(162,8,4),(162,20,4),(163,1,4),(163,8,4),(163,20,4),(164,1,4),(164,8,4),(164,20,4),(165,1,4),(165,8,4),(165,20,4),(166,1,4),(166,8,4),(166,20,4),(167,1,4),(167,8,4),(167,20,4),(168,1,4),(168,8,4),(168,20,4),(169,1,4),(169,8,4),(169,20,4),(170,1,4),(170,8,4),(170,20,4),(171,1,4),(171,8,4),(171,20,4),(172,1,4),(172,8,4),(172,20,4),(173,1,4),(173,8,4),(173,20,4),(174,1,4),(174,8,4),(174,20,4),(175,1,4),(175,8,4),(175,20,4),(176,1,4),(176,8,4),(176,20,4),(177,1,4),(177,8,4),(177,20,4),(178,1,4),(178,8,4),(178,20,4),(179,1,4),(179,8,4),(179,20,4),(180,1,4),(180,8,4),(180,20,4),(181,1,4),(181,8,4),(181,20,4),(182,1,4),(182,8,4),(182,20,4),(183,1,4),(183,8,4),(183,20,4),(184,1,4),(184,8,4),(184,20,4),(185,1,4),(185,8,4),(185,20,4),(186,1,4),(186,8,4),(186,20,4),(187,1,4),(187,8,4),(187,20,4),(188,1,4),(188,2,4),(188,8,4),(188,9,4),(188,20,4),(188,21,4),(189,1,4),(189,8,4),(189,20,4),(190,1,4),(190,2,4),(190,8,4),(190,9,4),(190,20,4),(190,21,4),(191,1,4),(191,2,4),(191,8,4),(191,9,4),(191,20,4),(191,21,4),(192,1,4),(192,8,4),(192,20,4),(193,1,4),(193,8,4),(193,20,4),(194,1,4),(194,8,4),(194,20,4),(195,1,4),(195,8,4),(195,20,4),(196,1,4),(196,8,4),(196,20,4),(197,1,4),(197,8,4),(197,20,4),(198,1,4),(198,8,4),(198,20,4),(199,1,4),(199,8,4),(199,20,4),(200,1,4),(200,8,4),(200,20,4),(201,1,4),(201,8,4),(201,20,4),(202,1,4),(202,8,4),(202,20,4),(203,1,4),(203,8,4),(203,20,4),(204,1,4),(204,8,4),(204,20,4),(205,1,4),(205,8,4),(205,20,4),(206,1,4),(206,8,4),(206,20,4),(207,1,4),(207,8,4),(207,20,4),(208,1,4),(208,8,4),(208,20,4),(209,1,4),(209,8,4),(209,20,4),(210,1,4),(210,2,4),(210,8,4),(210,9,4),(210,20,4),(210,21,4),(211,1,4),(211,8,4),(211,20,4),(212,1,4),(212,8,4),(212,20,4),(213,1,4),(213,8,4),(213,20,4),(214,1,4),(214,3,4),(214,8,4),(214,10,4),(214,20,4),(214,22,4),(215,1,4),(215,8,4),(215,20,4),(216,1,4),(216,8,4),(216,20,4),(217,1,4),(217,8,4),(217,20,4),(218,1,4),(218,8,4),(218,20,4),(219,1,4),(219,8,4),(219,20,4),(220,1,4),(220,8,4),(220,20,4),(221,1,4),(221,8,4),(221,20,4),(222,1,4),(222,8,4),(222,20,4),(223,1,4),(223,8,4),(223,20,4),(224,1,4),(224,8,4),(224,20,4),(225,1,4),(225,8,4),(225,20,4),(226,1,4),(226,8,4),(226,20,4),(227,1,4),(227,8,4),(227,20,4),(228,1,4),(228,8,4),(228,20,4),(229,1,4),(229,8,4),(229,20,4),(230,1,4),(230,8,4),(230,20,4),(231,1,4),(231,8,4),(231,20,4),(232,1,4),(232,8,4),(232,20,4),(233,1,4),(233,3,4),(233,8,4),(233,10,4),(233,20,4),(233,22,4),(234,1,4),(234,8,4),(234,20,4),(235,1,4),(235,3,4),(235,8,4),(235,10,4),(235,20,4),(235,22,4),(236,1,4),(236,8,4),(236,20,4),(237,1,4),(237,8,4),(237,20,4),(238,1,4),(238,3,4),(238,8,4),(238,10,4),(238,20,4),(238,22,4),(239,1,4),(239,8,4),(239,20,4),(240,1,4),(240,8,4),(240,20,4),(241,1,4),(241,8,4),(241,20,4),(242,1,4),(242,8,4),(242,20,4),(243,1,4),(243,8,4),(243,20,4),(244,1,4),(244,8,4),(244,20,4),(245,1,4),(245,8,4),(245,20,4),(246,1,4),(246,8,4),(246,20,4),(247,1,4),(247,8,4),(247,20,4),(248,1,4),(248,8,4),(248,20,4),(249,1,4),(249,8,4),(249,20,4),(250,1,4),(250,8,4),(250,20,4),(251,1,4),(251,8,4),(251,20,4),(252,1,4),(252,8,4),(252,20,4),(253,1,4),(253,8,4),(253,20,4),(254,1,4),(254,8,4),(254,20,4),(255,1,4),(255,8,4),(255,20,4),(256,1,4),(256,8,4),(256,20,4),(257,1,4),(257,8,4),(257,20,4),(258,1,4),(258,8,4),(258,20,4),(259,1,4),(259,8,4),(259,20,4),(260,1,4),(260,8,4),(260,20,4),(261,1,4),(261,8,4),(261,20,4),(262,1,4),(262,8,4),(262,20,4),(263,1,4),(263,8,4),(263,20,4),(264,1,4),(264,8,4),(264,20,4),(265,1,4),(265,8,4),(265,20,4),(266,1,4),(266,8,4),(266,20,4),(267,1,4),(267,8,4),(267,20,4),(268,1,4),(268,8,4),(268,20,4),(269,1,4),(269,8,4),(269,20,4),(270,1,4),(270,8,4),(270,20,4),(271,1,4),(271,8,4),(271,20,4),(272,1,4),(272,8,4),(272,20,4),(273,1,4),(273,8,4),(273,20,4),(274,1,4),(274,8,4),(274,20,4),(275,1,4),(275,8,4),(275,20,4),(276,1,4),(276,8,4),(276,20,4),(277,1,4),(277,8,4),(277,20,4),(278,1,4),(278,8,4),(278,20,4),(279,1,4),(279,8,4),(279,20,4),(280,1,4),(280,8,4),(280,20,4),(281,1,4),(281,8,4),(281,20,4),(282,1,4),(282,3,4),(282,8,4),(282,10,4),(282,20,4),(282,22,4),(283,1,4),(283,8,4),(283,20,4),(284,1,4),(284,8,4),(284,20,4),(285,1,4),(285,8,4),(285,20,4),(286,1,4),(286,8,4),(286,20,4),(287,1,4),(287,8,4),(287,20,4),(288,1,4),(288,8,4),(288,20,4),(289,1,4),(289,8,4),(289,20,4),(290,1,4),(290,8,4),(290,20,4),(291,1,4),(291,8,4),(291,20,4),(292,1,4),(292,8,4),(292,20,4),(293,1,4),(293,8,4),(293,20,4),(294,1,4),(294,8,4),(294,20,4),(295,1,4),(295,8,4),(295,20,4),(296,1,4),(296,8,4),(296,20,4),(297,4,4),(298,4,4),(299,4,4),(300,4,4),(301,4,4),(302,4,4),(303,4,4),(304,4,4),(305,4,4),(306,4,4),(307,4,4),(308,4,4),(309,4,4),(310,4,4),(311,4,4),(312,4,4),(313,4,4),(314,4,4),(315,4,4),(316,4,4),(317,4,4),(318,4,4),(319,4,4),(320,4,4),(321,4,4),(322,4,4),(323,4,4),(324,4,4),(325,4,4),(326,4,4),(327,4,4),(328,4,4),(329,4,4),(330,4,4),(331,4,4),(332,4,4),(333,4,4),(334,4,4),(335,4,4),(336,4,4),(337,4,4),(338,4,4),(339,4,4),(340,4,4),(341,1,4),(341,8,4),(341,20,4),(342,1,4),(342,8,4),(342,20,4),(343,1,4),(343,8,4),(343,20,4),(344,1,4),(344,8,4),(344,20,4),(345,1,4),(345,8,4),(345,20,4),(346,1,4),(346,8,4),(346,20,4),(347,1,4),(347,8,4),(347,20,4),(348,1,4),(348,8,4),(348,20,4),(349,1,4),(349,8,4),(349,20,4),(350,1,4),(350,8,4),(350,20,4),(351,1,4),(351,8,4),(351,20,4),(352,1,4),(352,8,4),(352,20,4),(353,1,4),(353,8,4),(353,20,4),(354,1,4),(354,8,4),(354,20,4),(355,1,4),(355,8,4),(355,20,4),(356,1,4),(356,8,4),(356,20,4),(357,1,4),(357,8,4),(357,20,4),(358,1,4),(358,8,4),(358,20,4),(359,1,4),(359,8,4),(359,20,4),(360,1,4),(360,8,4),(360,20,4),(361,1,4),(361,8,4),(361,20,4),(362,1,4),(362,8,4),(362,20,4),(363,1,4),(363,8,4),(363,20,4),(364,1,4),(364,8,4),(364,20,4),(365,1,4),(365,8,4),(365,20,4),(366,1,4),(366,8,4),(366,20,4),(367,1,4),(367,8,4),(367,20,4),(368,1,4),(368,8,4),(368,20,4),(369,1,4),(369,8,4),(369,20,4),(370,1,4),(370,8,4),(370,20,4),(371,1,4),(371,8,4),(371,20,4),(372,1,4),(372,8,4),(372,20,4),(373,1,4),(373,8,4),(373,20,4),(374,1,4),(374,8,4),(374,20,4),(375,1,4),(375,8,4),(375,20,4),(376,1,4),(376,8,4),(376,20,4),(377,1,4),(377,8,4),(377,20,4),(378,1,4),(378,8,4),(378,20,4),(379,1,4),(379,8,4),(379,20,4),(380,1,4),(380,8,4),(380,20,4),(381,1,4),(381,8,4),(381,20,4),(382,1,4),(382,8,4),(382,20,4),(383,1,4),(383,8,4),(383,20,4),(384,1,4),(384,8,4),(384,20,4),(385,1,4),(385,8,4),(385,20,4),(386,1,4),(386,8,4),(386,20,4),(387,1,4),(387,8,4),(387,20,4),(388,1,4),(388,8,4),(388,20,4),(1,2,5),(1,3,5),(1,9,5),(1,10,5),(1,21,5),(1,22,5),(2,2,5),(2,3,5),(2,9,5),(2,10,5),(2,21,5),(2,22,5),(3,2,5),(3,3,5),(3,9,5),(3,10,5),(3,21,5),(3,22,5),(4,2,5),(4,3,5),(4,9,5),(4,10,5),(4,21,5),(4,22,5),(5,2,5),(5,3,5),(5,9,5),(5,10,5),(5,21,5),(5,22,5),(6,2,5),(6,3,5),(6,9,5),(6,10,5),(6,21,5),(6,22,5),(7,2,5),(7,3,5),(7,9,5),(7,10,5),(7,21,5),(7,22,5),(8,2,5),(8,3,5),(8,9,5),(8,10,5),(8,21,5),(8,22,5),(9,2,5),(9,3,5),(9,9,5),(9,10,5),(9,21,5),(9,22,5),(10,2,5),(10,3,5),(10,9,5),(10,10,5),(10,21,5),(10,22,5),(11,2,5),(11,3,5),(11,9,5),(11,10,5),(11,21,5),(11,22,5),(12,2,5),(12,3,5),(12,9,5),(12,10,5),(12,21,5),(12,22,5),(13,2,5),(13,3,5),(13,9,5),(13,10,5),(13,21,5),(13,22,5),(14,2,5),(14,3,5),(14,9,5),(14,10,5),(14,21,5),(14,22,5),(15,2,5),(15,3,5),(15,9,5),(15,10,5),(15,21,5),(15,22,5),(16,2,5),(16,3,5),(16,9,5),(16,10,5),(16,21,5),(16,22,5),(17,2,5),(17,3,5),(17,9,5),(17,10,5),(17,21,5),(17,22,5),(18,2,5),(18,3,5),(18,9,5),(18,10,5),(18,21,5),(18,22,5),(19,2,5),(19,3,5),(19,9,5),(19,10,5),(19,21,5),(19,22,5),(20,2,5),(20,3,5),(20,9,5),(20,10,5),(20,21,5),(20,22,5),(21,2,5),(21,3,5),(21,9,5),(21,10,5),(21,21,5),(21,22,5),(22,2,5),(22,3,5),(22,9,5),(22,10,5),(22,21,5),(22,22,5),(23,2,5),(23,3,5),(23,9,5),(23,10,5),(23,21,5),(23,22,5),(24,2,5),(24,3,5),(24,9,5),(24,10,5),(24,21,5),(24,22,5),(25,2,5),(25,3,5),(25,9,5),(25,10,5),(25,21,5),(25,22,5),(26,2,5),(26,3,5),(26,9,5),(26,10,5),(26,21,5),(26,22,5),(27,2,5),(27,3,5),(27,9,5),(27,10,5),(27,21,5),(27,22,5),(28,2,5),(28,3,5),(28,9,5),(28,10,5),(28,21,5),(28,22,5),(29,2,5),(29,3,5),(29,9,5),(29,10,5),(29,21,5),(29,22,5),(30,2,5),(30,3,5),(30,9,5),(30,10,5),(30,21,5),(30,22,5),(31,2,5),(31,3,5),(31,9,5),(31,10,5),(31,21,5),(31,22,5),(32,2,5),(32,3,5),(32,9,5),(32,10,5),(32,21,5),(32,22,5),(33,2,5),(33,3,5),(33,9,5),(33,10,5),(33,21,5),(33,22,5),(34,2,5),(34,3,5),(34,9,5),(34,10,5),(34,21,5),(34,22,5),(35,3,5),(35,10,5),(35,22,5),(36,2,5),(36,3,5),(36,9,5),(36,10,5),(36,21,5),(36,22,5),(37,2,5),(37,3,5),(37,9,5),(37,10,5),(37,21,5),(37,22,5),(38,2,5),(38,3,5),(38,9,5),(38,10,5),(38,21,5),(38,22,5),(39,2,5),(39,3,5),(39,9,5),(39,10,5),(39,21,5),(39,22,5),(40,2,5),(40,3,5),(40,9,5),(40,10,5),(40,21,5),(40,22,5),(41,2,5),(41,3,5),(41,9,5),(41,10,5),(41,21,5),(41,22,5),(42,2,5),(42,3,5),(42,9,5),(42,10,5),(42,21,5),(42,22,5),(43,2,5),(43,3,5),(43,9,5),(43,10,5),(43,21,5),(43,22,5),(44,3,5),(44,10,5),(44,22,5),(45,2,5),(45,3,5),(45,9,5),(45,10,5),(45,21,5),(45,22,5),(46,2,5),(46,3,5),(46,9,5),(46,10,5),(46,21,5),(46,22,5),(47,3,5),(47,10,5),(47,22,5),(48,3,5),(48,10,5),(48,22,5),(49,3,5),(49,10,5),(49,22,5),(50,3,5),(50,10,5),(50,22,5),(51,2,5),(51,3,5),(51,9,5),(51,10,5),(51,21,5),(51,22,5),(53,2,5),(53,3,5),(53,9,5),(53,10,5),(53,21,5),(53,22,5),(54,2,5),(54,3,5),(54,9,5),(54,10,5),(54,21,5),(54,22,5),(55,2,5),(55,3,5),(55,9,5),(55,10,5),(55,21,5),(55,22,5),(63,2,5),(63,3,5),(63,9,5),(63,10,5),(63,21,5),(63,22,5),(64,2,5),(64,3,5),(64,9,5),(64,10,5),(64,21,5),(64,22,5),(65,2,5),(65,3,5),(65,9,5),(65,10,5),(65,21,5),(65,22,5),(66,2,5),(66,3,5),(66,9,5),(66,10,5),(66,21,5),(66,22,5),(67,2,5),(67,3,5),(67,9,5),(67,10,5),(67,21,5),(67,22,5),(69,2,5),(69,3,5),(69,9,5),(69,10,5),(69,21,5),(69,22,5),(70,2,5),(70,3,5),(70,9,5),(70,10,5),(70,21,5),(70,22,5),(71,2,5),(71,3,5),(71,9,5),(71,10,5),(71,21,5),(71,22,5),(72,2,5),(72,3,5),(72,9,5),(72,10,5),(72,21,5),(72,22,5),(73,2,5),(73,3,5),(73,9,5),(73,10,5),(73,21,5),(73,22,5),(74,2,5),(74,3,5),(74,9,5),(74,10,5),(74,21,5),(74,22,5),(75,2,5),(75,3,5),(75,9,5),(75,10,5),(75,21,5),(75,22,5),(76,2,5),(76,3,5),(76,9,5),(76,10,5),(76,21,5),(76,22,5),(78,2,5),(78,3,5),(78,9,5),(78,10,5),(78,21,5),(78,22,5),(80,2,5),(80,9,5),(80,21,5),(81,2,5),(81,3,5),(81,9,5),(81,10,5),(81,21,5),(81,22,5),(82,2,5),(82,9,5),(82,21,5),(83,2,5),(83,3,5),(83,9,5),(83,10,5),(83,21,5),(83,22,5),(84,2,5),(84,3,5),(84,9,5),(84,10,5),(84,21,5),(84,22,5),(86,2,5),(86,3,5),(86,9,5),(86,10,5),(86,21,5),(86,22,5),(87,2,5),(87,3,5),(87,9,5),(87,10,5),(87,21,5),(87,22,5),(88,2,5),(88,3,5),(88,9,5),(88,10,5),(88,21,5),(88,22,5),(89,2,5),(89,3,5),(89,9,5),(89,10,5),(89,21,5),(89,22,5),(90,2,5),(90,3,5),(90,9,5),(90,10,5),(90,21,5),(90,22,5),(91,2,5),(91,3,5),(91,9,5),(91,10,5),(91,21,5),(91,22,5),(92,2,5),(92,3,5),(92,9,5),(92,10,5),(92,21,5),(92,22,5),(93,2,5),(93,3,5),(93,9,5),(93,10,5),(93,21,5),(93,22,5),(94,2,5),(94,3,5),(94,9,5),(94,10,5),(94,21,5),(94,22,5),(95,2,5),(95,3,5),(95,9,5),(95,10,5),(95,21,5),(95,22,5),(96,3,5),(96,10,5),(96,22,5),(97,2,5),(97,3,5),(97,9,5),(97,10,5),(97,21,5),(97,22,5),(98,2,5),(98,3,5),(98,9,5),(98,10,5),(98,21,5),(98,22,5),(99,3,5),(99,10,5),(99,22,5),(101,3,5),(101,10,5),(101,22,5),(102,3,5),(102,10,5),(102,22,5),(103,2,5),(103,3,5),(103,9,5),(103,10,5),(103,21,5),(103,22,5),(104,2,5),(104,3,5),(104,9,5),(104,10,5),(104,21,5),(104,22,5),(105,2,5),(105,3,5),(105,9,5),(105,10,5),(105,21,5),(105,22,5),(106,2,5),(106,3,5),(106,9,5),(106,10,5),(106,21,5),(106,22,5),(108,3,5),(108,10,5),(108,22,5),(109,3,5),(109,10,5),(109,22,5),(111,3,5),(111,10,5),(111,22,5),(112,3,5),(112,10,5),(112,22,5),(113,3,5),(113,10,5),(113,22,5),(122,2,5),(122,3,5),(122,9,5),(122,10,5),(122,21,5),(122,22,5),(123,2,5),(123,3,5),(123,9,5),(123,10,5),(123,21,5),(123,22,5),(124,2,5),(124,3,5),(124,9,5),(124,10,5),(124,21,5),(124,22,5),(125,2,5),(125,3,5),(125,9,5),(125,10,5),(125,21,5),(125,22,5),(126,2,5),(126,3,5),(126,9,5),(126,10,5),(126,21,5),(126,22,5),(127,2,5),(127,3,5),(127,9,5),(127,10,5),(127,21,5),(127,22,5),(128,2,5),(128,3,5),(128,9,5),(128,10,5),(128,21,5),(128,22,5),(129,2,5),(129,9,5),(129,21,5),(130,2,5),(130,3,5),(130,9,5),(130,10,5),(130,21,5),(130,22,5),(131,2,5),(131,3,5),(131,9,5),(131,10,5),(131,21,5),(131,22,5),(132,2,5),(132,3,5),(132,9,5),(132,10,5),(132,21,5),(132,22,5),(133,2,5),(133,9,5),(133,21,5),(134,2,5),(134,3,5),(134,9,5),(134,10,5),(134,21,5),(134,22,5),(135,2,5),(135,3,5),(135,9,5),(135,10,5),(135,21,5),(135,22,5),(136,2,5),(136,3,5),(136,9,5),(136,10,5),(136,21,5),(136,22,5),(137,2,5),(137,3,5),(137,9,5),(137,10,5),(137,21,5),(137,22,5),(138,2,5),(138,3,5),(138,9,5),(138,10,5),(138,21,5),(138,22,5),(139,2,5),(139,3,5),(139,9,5),(139,10,5),(139,21,5),(139,22,5),(140,2,5),(140,9,5),(140,21,5),(141,2,5),(141,3,5),(141,9,5),(141,10,5),(141,21,5),(141,22,5),(142,2,5),(142,3,5),(142,9,5),(142,10,5),(142,21,5),(142,22,5),(143,2,5),(143,3,5),(143,9,5),(143,10,5),(143,21,5),(143,22,5),(144,3,5),(144,10,5),(144,22,5),(146,3,5),(146,10,5),(146,22,5),(147,2,5),(147,3,5),(147,9,5),(147,10,5),(147,21,5),(147,22,5),(148,2,5),(148,3,5),(148,9,5),(148,10,5),(148,21,5),(148,22,5),(149,2,5),(149,3,5),(149,9,5),(149,10,5),(149,21,5),(149,22,5),(150,2,5),(150,3,5),(150,9,5),(150,10,5),(150,21,5),(150,22,5),(155,2,5),(155,3,5),(155,9,5),(155,10,5),(155,21,5),(155,22,5),(156,2,5),(156,3,5),(156,9,5),(156,10,5),(156,21,5),(156,22,5),(157,2,5),(157,3,5),(157,9,5),(157,10,5),(157,21,5),(157,22,5),(158,2,5),(158,3,5),(158,9,5),(158,10,5),(158,21,5),(158,22,5),(159,2,5),(159,3,5),(159,9,5),(159,10,5),(159,21,5),(159,22,5),(160,2,5),(160,3,5),(160,9,5),(160,10,5),(160,21,5),(160,22,5),(162,2,5),(162,3,5),(162,9,5),(162,10,5),(162,21,5),(162,22,5),(163,2,5),(163,3,5),(163,9,5),(163,10,5),(163,21,5),(163,22,5),(164,2,5),(164,3,5),(164,9,5),(164,10,5),(164,21,5),(164,22,5),(166,2,5),(166,3,5),(166,9,5),(166,10,5),(166,21,5),(166,22,5),(167,2,5),(167,3,5),(167,9,5),(167,10,5),(167,21,5),(167,22,5),(168,3,5),(168,10,5),(168,22,5),(169,3,5),(169,10,5),(169,22,5),(170,2,5),(170,3,5),(170,9,5),(170,10,5),(170,21,5),(170,22,5),(171,2,5),(171,3,5),(171,9,5),(171,10,5),(171,21,5),(171,22,5),(172,2,5),(172,3,5),(172,9,5),(172,10,5),(172,21,5),(172,22,5),(173,2,5),(173,3,5),(173,9,5),(173,10,5),(173,21,5),(173,22,5),(174,3,5),(174,10,5),(174,22,5),(175,3,5),(175,10,5),(175,22,5),(176,3,5),(176,10,5),(176,22,5),(177,2,5),(177,3,5),(177,9,5),(177,10,5),(177,21,5),(177,22,5),(178,2,5),(178,3,5),(178,9,5),(178,10,5),(178,21,5),(178,22,5),(179,2,5),(179,3,5),(179,9,5),(179,10,5),(179,21,5),(179,22,5),(180,2,5),(180,3,5),(180,9,5),(180,10,5),(180,21,5),(180,22,5),(181,2,5),(181,3,5),(181,9,5),(181,10,5),(181,21,5),(181,22,5),(182,2,5),(182,3,5),(182,9,5),(182,10,5),(182,21,5),(182,22,5),(183,2,5),(183,3,5),(183,9,5),(183,10,5),(183,21,5),(183,22,5),(184,2,5),(184,3,5),(184,9,5),(184,10,5),(184,21,5),(184,22,5),(185,2,5),(185,3,5),(185,9,5),(185,10,5),(185,21,5),(185,22,5),(186,2,5),(186,3,5),(186,9,5),(186,10,5),(186,21,5),(186,22,5),(187,3,5),(187,10,5),(187,22,5),(188,3,5),(188,10,5),(188,22,5),(189,2,5),(189,3,5),(189,9,5),(189,10,5),(189,21,5),(189,22,5),(190,3,5),(190,10,5),(190,22,5),(191,3,5),(191,10,5),(191,22,5),(192,3,5),(192,10,5),(192,22,5),(193,3,5),(193,10,5),(193,22,5),(194,2,5),(194,3,5),(194,9,5),(194,10,5),(194,21,5),(194,22,5),(195,2,5),(195,3,5),(195,9,5),(195,10,5),(195,21,5),(195,22,5),(196,2,5),(196,3,5),(196,9,5),(196,10,5),(196,21,5),(196,22,5),(197,2,5),(197,3,5),(197,9,5),(197,10,5),(197,21,5),(197,22,5),(198,2,5),(198,3,5),(198,9,5),(198,10,5),(198,21,5),(198,22,5),(199,2,5),(199,3,5),(199,9,5),(199,10,5),(199,21,5),(199,22,5),(200,2,5),(200,3,5),(200,9,5),(200,10,5),(200,21,5),(200,22,5),(201,2,5),(201,3,5),(201,9,5),(201,10,5),(201,21,5),(201,22,5),(202,2,5),(202,3,5),(202,9,5),(202,10,5),(202,21,5),(202,22,5),(203,3,5),(203,10,5),(203,22,5),(204,2,5),(204,3,5),(204,9,5),(204,10,5),(204,21,5),(204,22,5),(205,2,5),(205,3,5),(205,9,5),(205,10,5),(205,21,5),(205,22,5),(206,2,5),(206,3,5),(206,9,5),(206,10,5),(206,21,5),(206,22,5),(207,2,5),(207,3,5),(207,9,5),(207,10,5),(207,21,5),(207,22,5),(208,2,5),(208,3,5),(208,9,5),(208,10,5),(208,21,5),(208,22,5),(209,2,5),(209,3,5),(209,9,5),(209,10,5),(209,21,5),(209,22,5),(210,3,5),(210,10,5),(210,22,5),(211,2,5),(211,3,5),(211,9,5),(211,10,5),(211,21,5),(211,22,5),(212,2,5),(212,3,5),(212,9,5),(212,10,5),(212,21,5),(212,22,5),(213,2,5),(213,3,5),(213,9,5),(213,10,5),(213,21,5),(213,22,5),(214,2,5),(214,9,5),(214,21,5),(215,2,5),(215,3,5),(215,9,5),(215,10,5),(215,21,5),(215,22,5),(216,2,5),(216,3,5),(216,9,5),(216,10,5),(216,21,5),(216,22,5),(217,2,5),(217,3,5),(217,9,5),(217,10,5),(217,21,5),(217,22,5),(218,2,5),(218,3,5),(218,9,5),(218,10,5),(218,21,5),(218,22,5),(219,3,5),(219,10,5),(219,22,5),(220,3,5),(220,10,5),(220,22,5),(221,3,5),(221,10,5),(221,22,5),(222,3,5),(222,10,5),(222,22,5),(223,2,5),(223,3,5),(223,9,5),(223,10,5),(223,21,5),(223,22,5),(224,2,5),(224,3,5),(224,9,5),(224,10,5),(224,21,5),(224,22,5),(225,2,5),(225,3,5),(225,9,5),(225,10,5),(225,21,5),(225,22,5),(226,2,5),(226,3,5),(226,9,5),(226,10,5),(226,21,5),(226,22,5),(227,2,5),(227,3,5),(227,9,5),(227,10,5),(227,21,5),(227,22,5),(228,2,5),(228,9,5),(228,21,5),(229,2,5),(229,3,5),(229,9,5),(229,10,5),(229,21,5),(229,22,5),(230,2,5),(230,3,5),(230,9,5),(230,10,5),(230,21,5),(230,22,5),(231,2,5),(231,3,5),(231,9,5),(231,10,5),(231,21,5),(231,22,5),(232,2,5),(232,3,5),(232,9,5),(232,10,5),(232,21,5),(232,22,5),(233,2,5),(233,9,5),(233,21,5),(234,2,5),(234,3,5),(234,9,5),(234,10,5),(234,21,5),(234,22,5),(235,2,5),(235,9,5),(235,21,5),(236,2,5),(236,3,5),(236,9,5),(236,10,5),(236,21,5),(236,22,5),(237,2,5),(237,3,5),(237,9,5),(237,10,5),(237,21,5),(237,22,5),(238,2,5),(238,9,5),(238,21,5),(239,2,5),(239,3,5),(239,9,5),(239,10,5),(239,21,5),(239,22,5),(240,2,5),(240,3,5),(240,9,5),(240,10,5),(240,21,5),(240,22,5),(241,2,5),(241,3,5),(241,9,5),(241,10,5),(241,21,5),(241,22,5),(242,2,5),(242,3,5),(242,9,5),(242,10,5),(242,21,5),(242,22,5),(243,2,5),(243,3,5),(243,9,5),(243,10,5),(243,21,5),(243,22,5),(244,2,5),(244,3,5),(244,9,5),(244,10,5),(244,21,5),(244,22,5),(245,2,5),(245,3,5),(245,9,5),(245,10,5),(245,21,5),(245,22,5),(246,2,5),(246,3,5),(246,9,5),(246,10,5),(246,21,5),(246,22,5),(247,2,5),(247,3,5),(247,9,5),(247,10,5),(247,21,5),(247,22,5),(248,2,5),(248,3,5),(248,9,5),(248,10,5),(248,21,5),(248,22,5),(249,2,5),(249,3,5),(249,9,5),(249,10,5),(249,21,5),(249,22,5),(250,2,5),(250,3,5),(250,9,5),(250,10,5),(250,21,5),(250,22,5),(251,2,5),(251,3,5),(251,9,5),(251,10,5),(251,21,5),(251,22,5),(252,2,5),(252,3,5),(252,9,5),(252,10,5),(252,21,5),(252,22,5),(253,2,5),(253,3,5),(253,9,5),(253,10,5),(253,21,5),(253,22,5),(254,2,5),(254,3,5),(254,9,5),(254,10,5),(254,21,5),(254,22,5),(255,2,5),(255,3,5),(255,9,5),(255,10,5),(255,21,5),(255,22,5),(256,2,5),(256,3,5),(256,9,5),(256,10,5),(256,21,5),(256,22,5),(257,2,5),(257,3,5),(257,9,5),(257,10,5),(257,21,5),(257,22,5),(258,2,5),(258,3,5),(258,9,5),(258,10,5),(258,21,5),(258,22,5),(259,2,5),(259,3,5),(259,9,5),(259,10,5),(259,21,5),(259,22,5),(260,2,5),(260,3,5),(260,9,5),(260,10,5),(260,21,5),(260,22,5),(261,2,5),(261,3,5),(261,9,5),(261,10,5),(261,21,5),(261,22,5),(262,2,5),(262,3,5),(262,9,5),(262,10,5),(262,21,5),(262,22,5),(263,2,5),(263,3,5),(263,9,5),(263,10,5),(263,21,5),(263,22,5),(264,2,5),(264,3,5),(264,9,5),(264,10,5),(264,21,5),(264,22,5),(265,2,5),(265,3,5),(265,9,5),(265,10,5),(265,21,5),(265,22,5),(266,2,5),(266,3,5),(266,9,5),(266,10,5),(266,21,5),(266,22,5),(267,2,5),(267,3,5),(267,9,5),(267,10,5),(267,21,5),(267,22,5),(268,2,5),(268,3,5),(268,9,5),(268,10,5),(268,21,5),(268,22,5),(269,2,5),(269,3,5),(269,9,5),(269,10,5),(269,21,5),(269,22,5),(270,2,5),(270,3,5),(270,9,5),(270,10,5),(270,21,5),(270,22,5),(271,2,5),(271,3,5),(271,9,5),(271,10,5),(271,21,5),(271,22,5),(272,2,5),(272,3,5),(272,9,5),(272,10,5),(272,21,5),(272,22,5),(273,2,5),(273,3,5),(273,9,5),(273,10,5),(273,21,5),(273,22,5),(274,2,5),(274,3,5),(274,9,5),(274,10,5),(274,21,5),(274,22,5),(275,2,5),(275,3,5),(275,9,5),(275,10,5),(275,21,5),(275,22,5),(276,2,5),(276,3,5),(276,9,5),(276,10,5),(276,21,5),(276,22,5),(277,2,5),(277,3,5),(277,9,5),(277,10,5),(277,21,5),(277,22,5),(278,2,5),(278,3,5),(278,9,5),(278,10,5),(278,21,5),(278,22,5),(279,2,5),(279,3,5),(279,9,5),(279,10,5),(279,21,5),(279,22,5),(280,2,5),(280,3,5),(280,9,5),(280,10,5),(280,21,5),(280,22,5),(281,2,5),(281,3,5),(281,9,5),(281,10,5),(281,21,5),(281,22,5),(282,2,5),(282,9,5),(282,21,5),(283,2,5),(283,9,5),(283,21,5),(284,2,5),(284,3,5),(284,9,5),(284,10,5),(284,21,5),(284,22,5),(285,2,5),(285,3,5),(285,9,5),(285,10,5),(285,21,5),(285,22,5),(286,2,5),(286,3,5),(286,9,5),(286,10,5),(286,21,5),(286,22,5),(287,2,5),(287,3,5),(287,9,5),(287,10,5),(287,21,5),(287,22,5),(288,2,5),(288,3,5),(288,9,5),(288,10,5),(288,21,5),(288,22,5),(289,2,5),(289,3,5),(289,9,5),(289,10,5),(289,21,5),(289,22,5),(290,2,5),(290,3,5),(290,9,5),(290,10,5),(290,21,5),(290,22,5),(291,2,5),(291,3,5),(291,9,5),(291,10,5),(291,21,5),(291,22,5),(292,2,5),(292,3,5),(292,9,5),(292,10,5),(292,21,5),(292,22,5),(293,2,5),(293,3,5),(293,9,5),(293,10,5),(293,21,5),(293,22,5),(294,2,5),(294,3,5),(294,9,5),(294,10,5),(294,21,5),(294,22,5),(295,2,5),(295,3,5),(295,9,5),(295,10,5),(295,21,5),(295,22,5),(296,2,5),(296,3,5),(296,9,5),(296,10,5),(296,21,5),(296,22,5),(341,2,5),(341,3,5),(341,9,5),(341,10,5),(341,21,5),(341,22,5),(342,2,5),(342,3,5),(342,9,5),(342,10,5),(342,21,5),(342,22,5),(343,2,5),(343,3,5),(343,9,5),(343,10,5),(343,21,5),(343,22,5),(344,2,5),(344,3,5),(344,9,5),(344,10,5),(344,21,5),(344,22,5),(345,2,5),(345,3,5),(345,9,5),(345,10,5),(345,21,5),(345,22,5),(346,2,5),(346,3,5),(346,9,5),(346,10,5),(346,21,5),(346,22,5),(347,2,5),(347,3,5),(347,9,5),(347,10,5),(347,21,5),(347,22,5),(348,2,5),(348,3,5),(348,9,5),(348,10,5),(348,21,5),(348,22,5),(349,2,5),(349,3,5),(349,9,5),(349,10,5),(349,21,5),(349,22,5),(350,2,5),(350,3,5),(350,9,5),(350,10,5),(350,21,5),(350,22,5),(351,2,5),(351,3,5),(351,9,5),(351,10,5),(351,21,5),(351,22,5),(352,2,5),(352,3,5),(352,9,5),(352,10,5),(352,21,5),(352,22,5),(353,2,5),(353,3,5),(353,9,5),(353,10,5),(353,21,5),(353,22,5),(354,2,5),(354,3,5),(354,9,5),(354,10,5),(354,21,5),(354,22,5),(355,2,5),(355,3,5),(355,9,5),(355,10,5),(355,21,5),(355,22,5),(356,2,5),(356,3,5),(356,9,5),(356,10,5),(356,21,5),(356,22,5),(357,2,5),(357,3,5),(357,9,5),(357,10,5),(357,21,5),(357,22,5),(358,2,5),(358,3,5),(358,9,5),(358,10,5),(358,21,5),(358,22,5),(359,2,5),(359,3,5),(359,9,5),(359,10,5),(359,21,5),(359,22,5),(360,2,5),(360,3,5),(360,9,5),(360,10,5),(360,21,5),(360,22,5),(361,2,5),(361,3,5),(361,9,5),(361,10,5),(361,21,5),(361,22,5),(362,2,5),(362,3,5),(362,9,5),(362,10,5),(362,21,5),(362,22,5),(363,2,5),(363,3,5),(363,9,5),(363,10,5),(363,21,5),(363,22,5),(364,2,5),(364,3,5),(364,9,5),(364,10,5),(364,21,5),(364,22,5),(365,2,5),(365,3,5),(365,9,5),(365,10,5),(365,21,5),(365,22,5),(366,2,5),(366,3,5),(366,9,5),(366,10,5),(366,21,5),(366,22,5),(367,2,5),(367,3,5),(367,9,5),(367,10,5),(367,21,5),(367,22,5),(368,2,5),(368,3,5),(368,9,5),(368,10,5),(368,21,5),(368,22,5),(369,2,5),(369,3,5),(369,9,5),(369,10,5),(369,21,5),(369,22,5),(370,2,5),(370,3,5),(370,9,5),(370,10,5),(370,21,5),(370,22,5),(371,2,5),(371,3,5),(371,9,5),(371,10,5),(371,21,5),(371,22,5),(372,2,5),(372,3,5),(372,9,5),(372,10,5),(372,21,5),(372,22,5),(373,2,5),(373,3,5),(373,9,5),(373,10,5),(373,21,5),(373,22,5),(374,2,5),(374,3,5),(374,9,5),(374,10,5),(374,21,5),(374,22,5),(375,2,5),(375,3,5),(375,9,5),(375,10,5),(375,21,5),(375,22,5),(376,2,5),(376,3,5),(376,9,5),(376,10,5),(376,21,5),(376,22,5),(377,2,5),(377,3,5),(377,9,5),(377,10,5),(377,21,5),(377,22,5),(378,2,5),(378,3,5),(378,9,5),(378,10,5),(378,21,5),(378,22,5),(379,2,5),(379,3,5),(379,9,5),(379,10,5),(379,21,5),(379,22,5),(380,2,5),(380,3,5),(380,9,5),(380,10,5),(380,21,5),(380,22,5),(381,2,5),(381,3,5),(381,9,5),(381,10,5),(381,21,5),(381,22,5),(382,2,5),(382,3,5),(382,9,5),(382,10,5),(382,21,5),(382,22,5),(383,2,5),(383,3,5),(383,9,5),(383,10,5),(383,21,5),(383,22,5),(384,2,5),(384,3,5),(384,9,5),(384,10,5),(384,21,5),(384,22,5),(385,2,5),(385,3,5),(385,9,5),(385,10,5),(385,21,5),(385,22,5),(386,2,5),(386,3,5),(386,9,5),(386,10,5),(386,21,5),(386,22,5),(387,2,5),(387,3,5),(387,9,5),(387,10,5),(387,21,5),(387,22,5),(388,2,5),(388,3,5),(388,9,5),(388,10,5),(388,21,5),(388,22,5);
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_types`
--

DROP TABLE IF EXISTS `permission_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_types`
--

LOCK TABLES `permission_types` WRITE;
/*!40000 ALTER TABLE `permission_types` DISABLE KEYS */;
INSERT INTO `permission_types` VALUES (1,'added',NULL,NULL),(2,'owned',NULL,NULL),(3,'both',NULL,NULL),(4,'all',NULL,NULL),(5,'none',NULL,NULL),(6,'added',NULL,NULL),(7,'owned',NULL,NULL),(8,'both',NULL,NULL),(9,'all',NULL,NULL),(10,'none',NULL,NULL);
/*!40000 ALTER TABLE `permission_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `display_name` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `module_id` int(10) unsigned NOT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `allowed_permissions` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_module_id_unique` (`name`,`module_id`),
  KEY `permissions_module_id_foreign` (`module_id`),
  CONSTRAINT `permissions_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=389 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'add_clients','Add Clients',NULL,1,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(2,'view_clients','View Clients',NULL,1,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(3,'edit_clients','Edit Clients',NULL,1,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(4,'delete_clients','Delete Clients',NULL,1,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(5,'manage_client_category','Manage Client Category',NULL,1,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(6,'manage_client_subcategory','Manage Client Subcategory',NULL,1,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(7,'add_client_contacts','Add Client Contacts',NULL,1,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(8,'view_client_contacts','View Client Contacts',NULL,1,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(9,'edit_client_contacts','Edit Client Contacts',NULL,1,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(10,'delete_client_contacts','Delete Client Contacts',NULL,1,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(11,'add_client_note','Add Client Note',NULL,1,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(12,'view_client_note','View Client Note',NULL,1,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:33'),(13,'edit_client_note','Edit Client Note',NULL,1,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(14,'delete_client_note','Delete Client Note',NULL,1,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(15,'add_client_document','Add Client Document',NULL,1,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(16,'view_client_document','View Client Document',NULL,1,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:33'),(17,'edit_client_document','Edit Client Document',NULL,1,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:33'),(18,'delete_client_document','Delete Client Document',NULL,1,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:33'),(19,'add_employees','Add Employees',NULL,2,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(20,'view_employees','View Employees',NULL,2,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(21,'edit_employees','Edit Employees',NULL,2,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(22,'delete_employees','Delete Employees',NULL,2,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(23,'add_designation','Add Designation',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(24,'view_designation','View Designation',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(25,'edit_designation','Edit Designation',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(26,'delete_designation','Delete Designation',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(27,'add_department','Add Department',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(28,'view_department','View Department',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(29,'edit_department','Edit Department',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(30,'delete_department','Delete Department',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(31,'add_documents','Add Documents',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(32,'view_documents','View Documents',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:33'),(33,'edit_documents','Edit Documents',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:33'),(34,'delete_documents','Delete Documents',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:33'),(35,'view_leaves_taken','View Leaves Taken',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(36,'update_leaves_quota','Update Leaves Quota',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(37,'view_employee_tasks','View Employee Tasks',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(38,'view_employee_projects','View Employee Projects',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(39,'view_employee_timelogs','View Employee Timelogs',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(40,'change_employee_role','Change Employee Role',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(41,'manage_emergency_contact','Manage Emergency Contact',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(42,'manage_award','Manage Award',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(43,'add_appreciation','Add Appreciation',NULL,2,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(44,'view_appreciation','View Appreciation',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(45,'edit_appreciation','Edit Appreciation',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(46,'delete_appreciation','Delete Appreciation',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(47,'add_immigration','Add Immigration',NULL,2,1,'{\"all\":4, \"owned\":2, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(48,'view_immigration','View Immigration',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(49,'edit_immigration','Edit Immigration',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(50,'delete_immigration','Delete Immigration',NULL,2,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(51,'add_projects','Add Projects',NULL,3,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(52,'view_projects','View Projects',NULL,3,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(53,'edit_projects','Edit Projects',NULL,3,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(54,'delete_projects','Delete Projects',NULL,3,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(55,'manage_project_category','Manage Project Category',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(56,'view_project_files','View Project Files',NULL,3,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(57,'add_project_files','Add Project Files',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(58,'delete_project_files','Delete Project Files',NULL,3,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(59,'view_project_discussions','View Project Discussions',NULL,3,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(60,'add_project_discussions','Add Project Discussions',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(61,'edit_project_discussions','Edit Project Discussions',NULL,3,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(62,'delete_project_discussions','Delete Project Discussions',NULL,3,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(63,'manage_discussion_category','Manage Discussion Category',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(64,'view_project_milestones','View Project Milestones',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(65,'add_project_milestones','Add Project Milestones',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(66,'edit_project_milestones','Edit Project Milestones',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(67,'delete_project_milestones','Delete Project Milestones',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(68,'view_project_members','View Project Members',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(69,'add_project_members','Add Project Members',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(70,'edit_project_members','Edit Project Members',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(71,'delete_project_members','Delete Project Members',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(72,'view_project_rating','View Project Rating',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(73,'add_project_rating','Add Project Rating',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(74,'edit_project_rating','Edit Project Rating',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(75,'delete_project_rating','Delete Project Rating',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(76,'view_project_budget','View Project Budget',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(77,'view_project_timelogs','View Project Timelogs',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(78,'view_project_expenses','View Project Expenses',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(79,'view_project_tasks','View Project Tasks',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(80,'view_project_invoices','View Project Invoices',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(81,'view_project_burndown_chart','View Project Burndown Chart',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(82,'view_project_payments','View Project Payments',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(83,'view_project_gantt_chart','View Project Gantt Chart',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(84,'add_project_note','Add Project Note',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(85,'view_project_note','View Project Note',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(86,'edit_project_note','Edit Project Note',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(87,'delete_project_note','Delete Project Note',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(88,'manage_project_template','Manage Project Template',NULL,3,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(89,'view_project_template','View Project Template',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(90,'view_project_hourly_rates','View Project Hourly Rates',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(91,'create_public_project','Create Public Project',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(92,'view_miroboard','View Miroboard',NULL,3,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:55'),(93,'manage_employee_shifts','Manage Employee Shifts',NULL,4,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(94,'view_shift_roster','View Shift Roster',NULL,4,1,'{\"all\":4, \"owned\":2, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(95,'add_attendance','Add Attendance',NULL,4,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(96,'view_attendance','View Attendance',NULL,4,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(97,'edit_attendance','Edit Attendance',NULL,4,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(98,'delete_attendance','Delete Attendance',NULL,4,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(99,'add_tasks','Add Tasks',NULL,5,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(100,'view_tasks','View Tasks',NULL,5,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(101,'edit_tasks','Edit Tasks',NULL,5,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(102,'delete_tasks','Delete Tasks',NULL,5,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(103,'view_task_category','View Task Category',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(104,'add_task_category','Add Task Category',NULL,5,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(105,'edit_task_category','Edit Task Category',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(106,'delete_task_category','Delete Task Category',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(107,'view_task_files','View Task Files',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(108,'add_task_files','Add Task Files',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(109,'delete_task_files','Delete Task Files',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(110,'view_sub_tasks','View Sub Tasks',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(111,'add_sub_tasks','Add Sub Tasks',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(112,'edit_sub_tasks','Edit Sub Tasks',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(113,'delete_sub_tasks','Delete Sub Tasks',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(114,'view_task_comments','View Task Comments',NULL,5,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(115,'add_task_comments','Add Task Comments',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(116,'edit_task_comments','Edit Task Comments',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(117,'delete_task_comments','Delete Task Comments',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(118,'view_task_notes','View Task Notes',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(119,'add_task_notes','Add Task Notes',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(120,'edit_task_notes','Edit Task Notes',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(121,'delete_task_notes','Delete Task Notes',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(122,'task_labels','Task Labels',NULL,5,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(123,'change_status','Change Status',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(124,'send_reminder','Send Reminder',NULL,5,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(125,'add_status','Add Status',NULL,5,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(126,'view_unassigned_tasks','View Unassigned Tasks',NULL,5,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(127,'create_unassigned_tasks','Create Unassigned Tasks',NULL,5,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(128,'add_estimates','Add Estimates',NULL,6,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(129,'view_estimates','View Estimates',NULL,6,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(130,'edit_estimates','Edit Estimates',NULL,6,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(131,'delete_estimates','Delete Estimates',NULL,6,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(132,'add_invoices','Add Invoices',NULL,7,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(133,'view_invoices','View Invoices',NULL,7,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(134,'edit_invoices','Edit Invoices',NULL,7,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(135,'delete_invoices','Delete Invoices',NULL,7,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(136,'manage_tax','Manage Tax',NULL,7,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(137,'link_invoice_bank_account','Link Invoice Bank Account',NULL,7,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(138,'manage_recurring_invoice','Manage Recurring Invoice',NULL,7,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:43'),(139,'add_payments','Add Payments',NULL,8,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(140,'view_payments','View Payments',NULL,8,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:28','2023-08-10 14:06:28'),(141,'edit_payments','Edit Payments',NULL,8,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(142,'delete_payments','Delete Payments',NULL,8,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(143,'link_payment_bank_account','Link Payment Bank Account',NULL,8,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(144,'add_timelogs','Add Timelogs',NULL,9,0,'{\"all\":4,\"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(145,'view_timelogs','View Timelogs',NULL,9,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(146,'edit_timelogs','Edit Timelogs',NULL,9,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(147,'delete_timelogs','Delete Timelogs',NULL,9,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(148,'approve_timelogs','Approve Timelogs',NULL,9,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(149,'manage_active_timelogs','Manage Active Timelogs',NULL,9,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(150,'view_timelog_earnings','View Timelog Earnings',NULL,9,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(151,'add_tickets','Add Tickets',NULL,10,0,'{\"all\":4,\"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(152,'view_tickets','View Tickets',NULL,10,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(153,'edit_tickets','Edit Tickets',NULL,10,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(154,'delete_tickets','Delete Tickets',NULL,10,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(155,'manage_ticket_type','Manage Ticket Type',NULL,10,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(156,'manage_ticket_agent','Manage Ticket Agent',NULL,10,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(157,'manage_ticket_channel','Manage Ticket Channel',NULL,10,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(158,'manage_ticket_tags','Manage Ticket Tags',NULL,10,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(159,'manage_ticket_groups','Manage Ticket Groups',NULL,10,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(160,'add_events','Add Events',NULL,11,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(161,'view_events','View Events',NULL,11,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(162,'edit_events','Edit Events',NULL,11,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(163,'delete_events','Delete Events',NULL,11,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(164,'add_notice','Add Notice',NULL,12,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(165,'view_notice','View Notice',NULL,12,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(166,'edit_notice','Edit Notice',NULL,12,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(167,'delete_notice','Delete Notice',NULL,12,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(168,'add_leave','Add Leave',NULL,13,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(169,'view_leave','View Leave',NULL,13,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(170,'edit_leave','Edit Leave',NULL,13,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(171,'delete_leave','Delete Leave',NULL,13,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(172,'approve_or_reject_leaves','Approve Or Reject Leaves',NULL,13,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(173,'delete_approve_leaves','Delete Approve Leaves',NULL,13,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:55'),(174,'add_lead','Add Lead',NULL,14,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(175,'view_lead','View Lead',NULL,14,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(176,'edit_lead','Edit Lead',NULL,14,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(177,'delete_lead','Delete Lead',NULL,14,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(178,'view_lead_agents','View Lead Agents',NULL,14,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(179,'add_lead_agent','Add Lead Agent',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(180,'edit_lead_agent','Edit Lead Agent',NULL,14,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(181,'delete_lead_agent','Delete Lead Agent',NULL,14,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(182,'view_lead_category','View Lead Category',NULL,14,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(183,'add_lead_category','Add Lead Category',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(184,'edit_lead_category','Edit Lead Category',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(185,'delete_lead_category','Delete Lead Category',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(186,'manage_lead_custom_forms','Manage Lead Custom Forms',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(187,'view_lead_files','View Lead Files',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(188,'add_lead_files','Add Lead Files',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(189,'delete_lead_files','Delete Lead Files',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(190,'view_lead_follow_up','View Lead Follow Up',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(191,'add_lead_follow_up','Add Lead Follow Up',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(192,'edit_lead_follow_up','Edit Lead Follow Up',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(193,'delete_lead_follow_up','Delete Lead Follow Up',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(194,'view_lead_sources','View Lead Sources',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(195,'add_lead_sources','Add Lead Sources',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(196,'edit_lead_sources','Edit Lead Sources',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(197,'delete_lead_sources','Delete Lead Sources',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(198,'view_lead_proposals','View Lead Proposals',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(199,'add_lead_proposals','Add Lead Proposals',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(200,'edit_lead_proposals','Edit Lead Proposals',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(201,'delete_lead_proposals','Delete Lead Proposals',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(202,'manage_proposal_template','Manage Proposal Template',NULL,14,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(203,'change_lead_status','Change Lead Status',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(204,'add_lead_note','Add Lead Note',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(205,'view_lead_note','View Lead Note',NULL,14,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(206,'edit_lead_note','Edit Lead Note',NULL,14,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(207,'delete_lead_note','Delete Lead Note',NULL,14,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(208,'manage_lead_status','Manage Lead Status',NULL,14,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(209,'add_holiday','Add Holiday',NULL,15,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(210,'view_holiday','View Holiday',NULL,15,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(211,'edit_holiday','Edit Holiday',NULL,15,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(212,'delete_holiday','Delete Holiday',NULL,15,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(213,'add_product','Add Product',NULL,16,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(214,'view_product','View Product',NULL,16,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(215,'edit_product','Edit Product',NULL,16,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(216,'delete_product','Delete Product',NULL,16,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(217,'manage_product_category','Manage Product Category',NULL,16,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(218,'manage_product_sub_category','Manage Product Sub Category',NULL,16,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(219,'add_expenses','Add Expenses',NULL,17,0,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(220,'view_expenses','View Expenses',NULL,17,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(221,'edit_expenses','Edit Expenses',NULL,17,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(222,'delete_expenses','Delete Expenses',NULL,17,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(223,'manage_expense_category','Manage Expense Category',NULL,17,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(224,'manage_recurring_expense','Manage Recurring Expense',NULL,17,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(225,'approve_expenses','Approve Expenses',NULL,17,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(226,'link_expense_bank_account','Link Expense Bank Account',NULL,17,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(227,'add_contract','Add Contract',NULL,18,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(228,'view_contract','View Contract',NULL,18,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(229,'edit_contract','Edit Contract',NULL,18,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(230,'delete_contract','Delete Contract',NULL,18,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(231,'manage_contract_type','Manage Contract Type',NULL,18,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(232,'renew_contract','Renew Contract',NULL,18,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(233,'add_contract_discussion','Add Contract Discussion',NULL,18,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(234,'edit_contract_discussion','Edit Contract Discussion',NULL,18,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(235,'view_contract_discussion','View Contract Discussion',NULL,18,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(236,'delete_contract_discussion','Delete Contract Discussion',NULL,18,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(237,'add_contract_files','Add Contract Files',NULL,18,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(238,'view_contract_files','View Contract Files',NULL,18,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(239,'delete_contract_files','Delete Contract Files',NULL,18,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(240,'manage_contract_template','Manage Contract Template',NULL,18,1,'{\"all\":4, \"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(241,'view_task_report','View Task Report',NULL,19,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(242,'view_time_log_report','View Time Log Report',NULL,19,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(243,'view_finance_report','View Finance Report',NULL,19,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(244,'view_income_expense_report','View Income Vs Expense Report',NULL,19,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(245,'view_leave_report','View Leave Report',NULL,19,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(246,'view_attendance_report','View Attendance Report',NULL,19,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(247,'view_expense_report','View Expense Report',NULL,19,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(248,'view_lead_report','View Lead Report',NULL,19,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(249,'view_sales_report','View Sales Report',NULL,19,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(250,'manage_company_setting','Manage Company Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(251,'manage_app_setting','Manage App Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(252,'manage_notification_setting','Manage Notification Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(253,'manage_currency_setting','Manage Currency Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(254,'manage_payment_setting','Manage Payment Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(255,'manage_finance_setting','Manage Finance Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(256,'manage_ticket_setting','Manage Ticket Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(257,'manage_project_setting','Manage Project Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(258,'manage_attendance_setting','Manage Attendance Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(259,'manage_leave_setting','Manage Leave Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(260,'manage_custom_field_setting','Manage Custom Field Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(261,'manage_message_setting','Manage Message Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(262,'manage_storage_setting','Manage Storage Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(263,'manage_language_setting','Manage Language Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(264,'manage_lead_setting','Manage Lead Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(265,'manage_time_log_setting','Manage Time Log Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(266,'manage_task_setting','Manage Task Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(267,'manage_social_login_setting','Manage Social Login Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(268,'manage_security_setting','Manage Security Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(269,'manage_gdpr_setting','Manage Gdpr Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(270,'manage_theme_setting','Manage Theme Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(271,'manage_role_permission_setting','Manage Role Permission Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(272,'manage_module_setting','Manage Module Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(273,'manage_google_calendar_setting','Manage Google Calendar Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(274,'manage_contract_setting','Manage Contract Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(275,'manage_custom_link_setting','Manage Custom Link Setting',NULL,20,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(276,'view_overview_dashboard','View Overview Dashboard',NULL,21,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(277,'view_project_dashboard','View Project Dashboard',NULL,21,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(278,'view_client_dashboard','View Client Dashboard',NULL,21,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(279,'view_hr_dashboard','View Hr Dashboard',NULL,21,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(280,'view_ticket_dashboard','View Ticket Dashboard',NULL,21,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(281,'view_finance_dashboard','View Finance Dashboard',NULL,21,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(282,'add_order','Add Order',NULL,22,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(283,'view_order','View Order',NULL,22,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(284,'edit_order','Edit Order',NULL,22,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(285,'delete_order','Delete Order',NULL,22,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(286,'add_knowledgebase','Add Knowledgebase',NULL,23,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(287,'view_knowledgebase','View Knowledgebase',NULL,23,0,'{\"all\":4,\"added\":1,\"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(288,'edit_knowledgebase','Edit Knowledgebase',NULL,23,0,'{\"all\":4,\"added\":1,\"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(289,'delete_knowledgebase','Delete Knowledgebase',NULL,23,0,'{\"all\":4,\"added\":1,\"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(290,'add_bankaccount','Add Bankaccount',NULL,24,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(291,'view_bankaccount','View Bankaccount',NULL,24,0,'{\"all\":4,\"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(292,'edit_bankaccount','Edit Bankaccount',NULL,24,0,'{\"all\":4,\"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(293,'delete_bankaccount','Delete Bankaccount',NULL,24,0,'{\"all\":4,\"added\":1, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(294,'add_bank_transfer','Add Bank Transfer',NULL,24,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(295,'add_bank_deposit','Add Bank Deposit',NULL,24,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(296,'add_bank_withdraw','Add Bank Withdraw',NULL,24,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(297,'add_packages','Add Packages',NULL,26,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(298,'view_packages','View Packages',NULL,26,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(299,'edit_packages','Edit Packages',NULL,26,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(300,'delete_packages','Delete Packages',NULL,26,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(301,'add_companies','Add Companies',NULL,27,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(302,'view_companies','View Companies',NULL,27,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(303,'edit_companies','Edit Companies',NULL,27,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(304,'delete_companies','Delete Companies',NULL,27,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(305,'update_company_package','Update Company Package',NULL,27,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(306,'manage_company_impersonate','Manage Company Impersonate',NULL,27,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(307,'manage_billing','Manage Billing',NULL,28,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(308,'view_request','View Request',NULL,29,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(309,'accept_reject_request','Accept Reject Request',NULL,29,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(310,'add_admin_faq','Add Admin Faq',NULL,30,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(311,'view_admin_faq','View Admin Faq',NULL,30,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(312,'edit_admin_faq','Edit Admin Faq',NULL,30,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(313,'delete_admin_faq','Delete Admin Faq',NULL,30,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(314,'manage_faq_category','Manage Faq Category',NULL,30,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(315,'add_superadmin','Add Superadmin',NULL,31,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(316,'view_superadmin','View Superadmin',NULL,31,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(317,'edit_superadmin','Edit Superadmin',NULL,31,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(318,'delete_superadmin','Delete Superadmin',NULL,31,0,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(319,'change_superadmin_role','Change Superadmin Role',NULL,31,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(320,'add_superadmin_ticket','Add Superadmin Ticket',NULL,32,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(321,'view_superadmin_ticket','View Superadmin Ticket',NULL,32,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(322,'edit_superadmin_ticket','Edit Superadmin Ticket',NULL,32,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(323,'delete_superadmin_ticket','Delete Superadmin Ticket',NULL,32,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(324,'manage_superadmin_front_settings','Manage Superadmin Front Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(325,'manage_superadmin_app_settings','Manage Superadmin App Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(326,'manage_superadmin_notification_settings','Manage Superadmin Notification Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(327,'manage_superadmin_language_settings','Manage Superadmin Language Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(328,'manage_superadmin_currency_settings','Manage Superadmin Currency Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(329,'manage_superadmin_payment_settings','Manage Superadmin Payment Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(330,'manage_superadmin_finance_settings','Manage Superadmin Finance Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(331,'manage_superadmin_custom_field_settings','Manage Superadmin Custom Field Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(332,'manage_superadmin_permission_settings','Manage Superadmin Permission Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(333,'manage_superadmin_storage_settings','Manage Superadmin Storage Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(334,'manage_superadmin_social_settings','Manage Superadmin Social Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(335,'manage_superadmin_security_settings','Manage Superadmin Security Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(336,'manage_superadmin_calendar_settings','Manage Superadmin Calendar Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(337,'manage_superadmin_theme_settings','Manage Superadmin Theme Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(338,'manage_superadmin_custom_module_settings','Manage Superadmin Custom Module Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(339,'manage_superadmin_database_backup_settings','Manage Superadmin Database Backup Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(340,'manage_superadmin_update_settings','Manage Superadmin Update Settings',NULL,33,1,'{\"all\":4, \"none\":5}','2023-08-10 14:06:29','2023-08-10 14:06:29'),(341,'manage_salary_payment_method','Manage Salary Payment Method',NULL,34,1,'{\"all\":4, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(342,'manage_salary_component','Manage Salary Component',NULL,34,1,'{\"all\":4, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(343,'manage_salary_group','Manage Salary Group',NULL,34,1,'{\"all\":4, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(344,'manage_salary_tds','Manage Salary Tds',NULL,34,1,'{\"all\":4, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(345,'manage_employee_salary','Manage Employee Salary',NULL,34,1,'{\"all\":4, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(346,'add_payroll','Add Payroll',NULL,34,0,'{\"all\":4, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(347,'view_payroll','View Payroll',NULL,34,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(348,'edit_payroll','Edit Payroll',NULL,34,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(349,'delete_payroll','Delete Payroll',NULL,34,0,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}','2023-08-21 05:36:55','2023-08-21 05:36:55'),(350,'manage_skill','Manage Skills',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(351,'add_job','Add Job',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(352,'view_job','View Job',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(353,'edit_job','Edit Job',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(354,'delete_job','Delete Job',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(355,'add_job_application','Add Job Application',NULL,35,1,'{\"all\":4,\"added\":1, \"none\":5}',NULL,NULL),(356,'view_job_application','View Job Application',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(357,'edit_job_application','Edit Job Application',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(358,'delete_job_application','Delete Job Application',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(359,'add_notes','Add Notes',NULL,35,1,'{\"all\":4,\"added\":1, \"none\":5}',NULL,NULL),(360,'edit_notes','Edit Notes',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(361,'delete_notes','Delete Notes',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(362,'add_application_status','Add Application Status',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(363,'edit_application_status','Edit Application Status',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(364,'delete_application_status','Delete Application Status',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(365,'change_application_status','Change Application Status',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(366,'add_interview_schedule','Add Interview Schedule',NULL,35,1,'{\"all\":4,\"added\":1, \"none\":5}',NULL,NULL),(367,'view_interview_schedule','View Interview Schedule',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(368,'edit_interview_schedule','Edit Interview Schedule',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(369,'delete_interview_schedule','Delete Interview Schedule',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(370,'reschedule_interview','Reschedule Interview',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(371,'add_recommendation_status','Add Recommendation Status',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(372,'edit_recommendation_status','Edit Recommendation Status',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(373,'delete_recommendation_status','Delete Recommendation Status',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(374,'add_recruiter','Add Recruiter',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(375,'edit_recruiter','Edit Recruiter',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(376,'delete_recruiter','Delete Recruiter',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(377,'add_offer_letter','Add Offer Letter',NULL,35,1,'{\"all\":4,\"added\":1, \"none\":5}',NULL,NULL),(378,'view_offer_letter','View Offer Letter',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(379,'edit_offer_letter','Edit Offer Letter',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(380,'delete_offer_letter','Delete Offer Letter',NULL,35,1,'{\"all\":4, \"added\":1, \"owned\":2,\"both\":3, \"none\":5}',NULL,NULL),(381,'add_footer_link','Add Footer Link',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(382,'edit_footer_link','Edit Footer Link',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(383,'delete_footer_link','Delete Footer Link',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(384,'view_report','View Report',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(385,'recruit_settings','Recruit Settings',NULL,35,1,'{\"all\":4, \"none\":5}',NULL,NULL),(386,'manage_job_category','Manage Job Category',NULL,35,1,'{\"all\":4, \"none\":5}','2023-08-21 05:41:23','2023-08-21 05:41:23'),(387,'manage_job_sub_category','Manage Job Sub Category',NULL,35,1,'{\"all\":4, \"none\":5}','2023-08-21 05:41:23','2023-08-21 05:41:23'),(388,'view_dashboard','View Dashboard',NULL,35,1,'{\"all\":4, \"none\":5}','2023-08-21 05:41:26','2023-08-21 05:41:26');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pinned`
--

DROP TABLE IF EXISTS `pinned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pinned` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `task_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pinned_company_id_foreign` (`company_id`),
  KEY `pinned_project_id_foreign` (`project_id`),
  KEY `pinned_task_id_foreign` (`task_id`),
  KEY `pinned_user_id_foreign` (`user_id`),
  CONSTRAINT `pinned_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pinned_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pinned_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pinned_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pinned`
--

LOCK TABLES `pinned` WRITE;
/*!40000 ALTER TABLE `pinned` DISABLE KEYS */;
/*!40000 ALTER TABLE `pinned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_category_company_id_foreign` (`company_id`),
  CONSTRAINT `product_category_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
INSERT INTO `product_category` VALUES (1,7,'LMS','2023-08-21 16:32:17','2023-08-21 16:32:17');
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_files`
--

DROP TABLE IF EXISTS `product_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `hashname` varchar(200) DEFAULT NULL,
  `size` varchar(200) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_files_product_id_foreign` (`product_id`),
  KEY `product_files_added_by_foreign` (`added_by`),
  KEY `product_files_last_updated_by_foreign` (`last_updated_by`),
  KEY `product_files_company_id_foreign` (`company_id`),
  CONSTRAINT `product_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `product_files_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `product_files_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_files`
--

LOCK TABLES `product_files` WRITE;
/*!40000 ALTER TABLE `product_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_sub_category`
--

DROP TABLE IF EXISTS `product_sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_sub_category` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `category_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_sub_category_company_id_foreign` (`company_id`),
  KEY `product_sub_category_category_id_foreign` (`category_id`),
  CONSTRAINT `product_sub_category_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `product_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `product_sub_category_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_sub_category`
--

LOCK TABLES `product_sub_category` WRITE;
/*!40000 ALTER TABLE `product_sub_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_sub_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `price` varchar(191) NOT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `allow_purchase` tinyint(1) NOT NULL DEFAULT 0,
  `downloadable` tinyint(1) NOT NULL DEFAULT 0,
  `downloadable_file` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `category_id` bigint(20) unsigned DEFAULT NULL,
  `sub_category_id` bigint(20) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `default_image` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_company_id_foreign` (`company_id`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_sub_category_id_foreign` (`sub_category_id`),
  KEY `products_added_by_foreign` (`added_by`),
  KEY `products_last_updated_by_foreign` (`last_updated_by`),
  KEY `products_unit_id_foreign` (`unit_id`),
  CONSTRAINT `products_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `product_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `products_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `products_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `product_sub_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,7,'Subscribtion LMS','5000',NULL,0,0,NULL,'',1,NULL,8,8,NULL,NULL,'2023-08-21 16:32:42','2023-08-21 16:32:42',7);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_activity`
--

DROP TABLE IF EXISTS `project_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_activity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `activity` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_activity_project_id_foreign` (`project_id`),
  KEY `project_activity_created_at_index` (`created_at`),
  CONSTRAINT `project_activity_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_activity`
--

LOCK TABLES `project_activity` WRITE;
/*!40000 ALTER TABLE `project_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_category`
--

DROP TABLE IF EXISTS `project_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_name` varchar(191) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_category_company_id_foreign` (`company_id`),
  KEY `project_category_added_by_foreign` (`added_by`),
  KEY `project_category_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `project_category_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_category_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_category_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_category`
--

LOCK TABLES `project_category` WRITE;
/*!40000 ALTER TABLE `project_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_files`
--

DROP TABLE IF EXISTS `project_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `external_link` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_files_company_id_foreign` (`company_id`),
  KEY `project_files_user_id_foreign` (`user_id`),
  KEY `project_files_project_id_foreign` (`project_id`),
  KEY `project_files_added_by_foreign` (`added_by`),
  KEY `project_files_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `project_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_files_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_files_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_files`
--

LOCK TABLES `project_files` WRITE;
/*!40000 ALTER TABLE `project_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_members`
--

DROP TABLE IF EXISTS `project_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `hourly_rate` double NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_members_user_id_foreign` (`user_id`),
  KEY `project_members_project_id_foreign` (`project_id`),
  KEY `project_members_added_by_foreign` (`added_by`),
  KEY `project_members_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `project_members_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_members_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_members_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_members`
--

LOCK TABLES `project_members` WRITE;
/*!40000 ALTER TABLE `project_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_milestones`
--

DROP TABLE IF EXISTS `project_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_milestones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `milestone_title` varchar(191) NOT NULL,
  `summary` mediumtext NOT NULL,
  `cost` double(16,2) NOT NULL,
  `status` enum('complete','incomplete') NOT NULL DEFAULT 'incomplete',
  `invoice_created` tinyint(1) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_milestones_project_id_foreign` (`project_id`),
  KEY `project_milestones_currency_id_foreign` (`currency_id`),
  KEY `project_milestones_added_by_foreign` (`added_by`),
  KEY `project_milestones_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `project_milestones_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_milestones_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_milestones_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_milestones_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_milestones`
--

LOCK TABLES `project_milestones` WRITE;
/*!40000 ALTER TABLE `project_milestones` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_notes`
--

DROP TABLE IF EXISTS `project_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `client_id` int(10) unsigned DEFAULT NULL,
  `is_client_show` tinyint(1) NOT NULL DEFAULT 0,
  `ask_password` tinyint(1) NOT NULL DEFAULT 0,
  `details` longtext NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_notes_project_id_foreign` (`project_id`),
  KEY `project_notes_client_id_foreign` (`client_id`),
  KEY `project_notes_added_by_foreign` (`added_by`),
  KEY `project_notes_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `project_notes_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_notes_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_notes_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_notes_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_notes`
--

LOCK TABLES `project_notes` WRITE;
/*!40000 ALTER TABLE `project_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_ratings`
--

DROP TABLE IF EXISTS `project_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_ratings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `rating` double NOT NULL DEFAULT 0,
  `comment` text DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_ratings_project_id_foreign` (`project_id`),
  KEY `project_ratings_user_id_foreign` (`user_id`),
  KEY `project_ratings_added_by_foreign` (`added_by`),
  KEY `project_ratings_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `project_ratings_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_ratings_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_ratings_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_ratings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_ratings`
--

LOCK TABLES `project_ratings` WRITE;
/*!40000 ALTER TABLE `project_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_settings`
--

DROP TABLE IF EXISTS `project_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `send_reminder` enum('yes','no') NOT NULL,
  `remind_time` int(11) NOT NULL,
  `remind_type` varchar(191) NOT NULL,
  `remind_to` varchar(191) NOT NULL DEFAULT '["admins","members"]',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `project_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_settings`
--

LOCK TABLES `project_settings` WRITE;
/*!40000 ALTER TABLE `project_settings` DISABLE KEYS */;
INSERT INTO `project_settings` VALUES (1,1,'no',5,'days','[\"admins\",\"members\"]','2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,'no',5,'days','[\"admins\",\"members\"]','2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,'no',5,'days','[\"admins\",\"members\"]','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `project_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_status_settings`
--

DROP TABLE IF EXISTS `project_status_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_status_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `status_name` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `default_status` enum('1','0') NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_status_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `project_status_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_status_settings`
--

LOCK TABLES `project_status_settings` WRITE;
/*!40000 ALTER TABLE `project_status_settings` DISABLE KEYS */;
INSERT INTO `project_status_settings` VALUES (1,1,'in progress','#00b5ff','active','1',NULL,NULL),(2,1,'not started','#616e80','active','0',NULL,NULL),(3,1,'on hold','#f5c308','active','0',NULL,NULL),(4,1,'canceled','#d21010','active','0',NULL,NULL),(5,1,'finished','#679c0d','active','0',NULL,NULL),(11,3,'in progress','#00b5ff','active','1',NULL,NULL),(12,3,'not started','#616e80','active','0',NULL,NULL),(13,3,'on hold','#f5c308','active','0',NULL,NULL),(14,3,'canceled','#d21010','active','0',NULL,NULL),(15,3,'finished','#679c0d','active','0',NULL,NULL),(31,7,'in progress','#00b5ff','active','1',NULL,NULL),(32,7,'not started','#616e80','active','0',NULL,NULL),(33,7,'on hold','#f5c308','active','0',NULL,NULL),(34,7,'canceled','#d21010','active','0',NULL,NULL),(35,7,'finished','#679c0d','active','0',NULL,NULL);
/*!40000 ALTER TABLE `project_status_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_template_members`
--

DROP TABLE IF EXISTS `project_template_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_template_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `project_template_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_template_members_user_id_foreign` (`user_id`),
  KEY `project_template_members_project_template_id_foreign` (`project_template_id`),
  CONSTRAINT `project_template_members_project_template_id_foreign` FOREIGN KEY (`project_template_id`) REFERENCES `project_templates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_template_members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_template_members`
--

LOCK TABLES `project_template_members` WRITE;
/*!40000 ALTER TABLE `project_template_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_template_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_template_sub_tasks`
--

DROP TABLE IF EXISTS `project_template_sub_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_template_sub_tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_template_task_id` int(10) unsigned NOT NULL,
  `title` text NOT NULL,
  `start_date` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `status` enum('incomplete','complete') NOT NULL DEFAULT 'incomplete',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_template_sub_tasks_project_template_task_id_foreign` (`project_template_task_id`),
  CONSTRAINT `project_template_sub_tasks_project_template_task_id_foreign` FOREIGN KEY (`project_template_task_id`) REFERENCES `project_template_tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_template_sub_tasks`
--

LOCK TABLES `project_template_sub_tasks` WRITE;
/*!40000 ALTER TABLE `project_template_sub_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_template_sub_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_template_task_users`
--

DROP TABLE IF EXISTS `project_template_task_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_template_task_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_template_task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_template_task_users_project_template_task_id_foreign` (`project_template_task_id`),
  KEY `project_template_task_users_user_id_foreign` (`user_id`),
  CONSTRAINT `project_template_task_users_project_template_task_id_foreign` FOREIGN KEY (`project_template_task_id`) REFERENCES `project_template_tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_template_task_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_template_task_users`
--

LOCK TABLES `project_template_task_users` WRITE;
/*!40000 ALTER TABLE `project_template_task_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_template_task_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_template_tasks`
--

DROP TABLE IF EXISTS `project_template_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_template_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `heading` varchar(191) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `project_template_id` int(10) unsigned NOT NULL,
  `priority` enum('low','medium','high') NOT NULL DEFAULT 'medium',
  `project_template_task_category_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_template_tasks_project_template_id_foreign` (`project_template_id`),
  KEY `project_template_tasks_project_template_task_category_id_foreign` (`project_template_task_category_id`),
  CONSTRAINT `project_template_tasks_project_template_id_foreign` FOREIGN KEY (`project_template_id`) REFERENCES `project_templates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_template_tasks_project_template_task_category_id_foreign` FOREIGN KEY (`project_template_task_category_id`) REFERENCES `task_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_template_tasks`
--

LOCK TABLES `project_template_tasks` WRITE;
/*!40000 ALTER TABLE `project_template_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_template_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_templates`
--

DROP TABLE IF EXISTS `project_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_name` varchar(191) NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `project_summary` mediumtext DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `feedback` mediumtext DEFAULT NULL,
  `client_view_task` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `allow_client_notification` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `manual_timelog` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `project_templates_company_id_foreign` (`company_id`),
  KEY `project_templates_category_id_foreign` (`category_id`),
  KEY `project_templates_client_id_foreign` (`client_id`),
  CONSTRAINT `project_templates_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `project_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_templates_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_templates_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_templates`
--

LOCK TABLES `project_templates` WRITE;
/*!40000 ALTER TABLE `project_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_time_log_breaks`
--

DROP TABLE IF EXISTS `project_time_log_breaks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_time_log_breaks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_time_log_id` int(10) unsigned DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `reason` text NOT NULL,
  `total_hours` varchar(191) DEFAULT NULL,
  `total_minutes` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_time_log_breaks_company_id_foreign` (`company_id`),
  KEY `project_time_log_breaks_project_time_log_id_foreign` (`project_time_log_id`),
  KEY `project_time_log_breaks_start_time_index` (`start_time`),
  KEY `project_time_log_breaks_end_time_index` (`end_time`),
  KEY `project_time_log_breaks_added_by_foreign` (`added_by`),
  KEY `project_time_log_breaks_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `project_time_log_breaks_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_time_log_breaks_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_time_log_breaks_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_time_log_breaks_project_time_log_id_foreign` FOREIGN KEY (`project_time_log_id`) REFERENCES `project_time_logs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_time_log_breaks`
--

LOCK TABLES `project_time_log_breaks` WRITE;
/*!40000 ALTER TABLE `project_time_log_breaks` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_time_log_breaks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_time_logs`
--

DROP TABLE IF EXISTS `project_time_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_time_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `task_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `memo` text NOT NULL,
  `total_hours` varchar(191) DEFAULT NULL,
  `total_minutes` varchar(191) DEFAULT NULL,
  `edited_by_user` int(10) unsigned DEFAULT NULL,
  `hourly_rate` int(11) NOT NULL,
  `earnings` int(11) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT 1,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `invoice_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `total_break_minutes` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_time_logs_company_id_foreign` (`company_id`),
  KEY `project_time_logs_project_id_foreign` (`project_id`),
  KEY `project_time_logs_task_id_foreign` (`task_id`),
  KEY `project_time_logs_user_id_foreign` (`user_id`),
  KEY `project_time_logs_start_time_index` (`start_time`),
  KEY `project_time_logs_end_time_index` (`end_time`),
  KEY `project_time_logs_edited_by_user_foreign` (`edited_by_user`),
  KEY `project_time_logs_approved_by_foreign` (`approved_by`),
  KEY `project_time_logs_invoice_id_foreign` (`invoice_id`),
  KEY `project_time_logs_added_by_foreign` (`added_by`),
  KEY `project_time_logs_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `project_time_logs_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_time_logs_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_time_logs_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_time_logs_edited_by_user_foreign` FOREIGN KEY (`edited_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_time_logs_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_time_logs_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `project_time_logs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_time_logs_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_time_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_time_logs`
--

LOCK TABLES `project_time_logs` WRITE;
/*!40000 ALTER TABLE `project_time_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_time_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_user_notes`
--

DROP TABLE IF EXISTS `project_user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `project_note_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_user_notes_user_id_foreign` (`user_id`),
  KEY `project_user_notes_project_note_id_foreign` (`project_note_id`),
  CONSTRAINT `project_user_notes_project_note_id_foreign` FOREIGN KEY (`project_note_id`) REFERENCES `project_notes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_user_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_user_notes`
--

LOCK TABLES `project_user_notes` WRITE;
/*!40000 ALTER TABLE `project_user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_name` varchar(191) NOT NULL,
  `project_short_code` varchar(191) DEFAULT NULL,
  `project_summary` longtext DEFAULT NULL,
  `project_admin` int(10) unsigned DEFAULT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `team_id` int(10) unsigned DEFAULT NULL,
  `feedback` mediumtext DEFAULT NULL,
  `manual_timelog` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `client_view_task` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `allow_client_notification` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `completion_percent` tinyint(4) NOT NULL,
  `calculate_task_progress` enum('true','false') NOT NULL DEFAULT 'true',
  `project_budget` double(20,2) DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `hours_allocated` double(8,2) DEFAULT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'in progress',
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `hash` text DEFAULT NULL,
  `public` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `enable_miroboard` tinyint(1) NOT NULL DEFAULT 0,
  `miro_board_id` varchar(191) DEFAULT NULL,
  `client_access` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `projects_company_id_foreign` (`company_id`),
  KEY `projects_project_admin_foreign` (`project_admin`),
  KEY `projects_category_id_foreign` (`category_id`),
  KEY `projects_client_id_foreign` (`client_id`),
  KEY `projects_team_id_foreign` (`team_id`),
  KEY `projects_currency_id_foreign` (`currency_id`),
  KEY `projects_added_by_foreign` (`added_by`),
  KEY `projects_last_updated_by_foreign` (`last_updated_by`),
  KEY `projects_deleted_at_index` (`deleted_at`),
  CONSTRAINT `projects_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `projects_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `project_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `projects_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `projects_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `projects_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `projects_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `projects_project_admin_foreign` FOREIGN KEY (`project_admin`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `projects_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proposal_item_images`
--

DROP TABLE IF EXISTS `proposal_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposal_item_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `proposal_item_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proposal_item_images_proposal_item_id_foreign` (`proposal_item_id`),
  CONSTRAINT `proposal_item_images_proposal_item_id_foreign` FOREIGN KEY (`proposal_item_id`) REFERENCES `proposal_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposal_item_images`
--

LOCK TABLES `proposal_item_images` WRITE;
/*!40000 ALTER TABLE `proposal_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `proposal_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proposal_items`
--

DROP TABLE IF EXISTS `proposal_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposal_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `proposal_id` int(10) unsigned NOT NULL,
  `item_name` varchar(191) NOT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `quantity` double(16,2) NOT NULL,
  `unit_price` double(16,2) NOT NULL,
  `amount` double(16,2) NOT NULL,
  `item_summary` text DEFAULT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proposal_items_proposal_id_foreign` (`proposal_id`),
  KEY `proposal_items_unit_id_foreign` (`unit_id`),
  KEY `proposal_items_product_id_foreign` (`product_id`),
  CONSTRAINT `proposal_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `proposal_items_proposal_id_foreign` FOREIGN KEY (`proposal_id`) REFERENCES `proposals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proposal_items_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposal_items`
--

LOCK TABLES `proposal_items` WRITE;
/*!40000 ALTER TABLE `proposal_items` DISABLE KEYS */;
INSERT INTO `proposal_items` VALUES (1,1,'Subscribtion LMS','item',1.00,5000.00,5000.00,NULL,NULL,NULL,'2023-08-21 16:35:53','2023-08-21 16:35:53',7,1);
/*!40000 ALTER TABLE `proposal_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proposal_signs`
--

DROP TABLE IF EXISTS `proposal_signs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposal_signs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `proposal_id` int(10) unsigned NOT NULL,
  `full_name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `signature` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proposal_signs_proposal_id_foreign` (`proposal_id`),
  CONSTRAINT `proposal_signs_proposal_id_foreign` FOREIGN KEY (`proposal_id`) REFERENCES `proposals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposal_signs`
--

LOCK TABLES `proposal_signs` WRITE;
/*!40000 ALTER TABLE `proposal_signs` DISABLE KEYS */;
/*!40000 ALTER TABLE `proposal_signs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proposal_template_item_images`
--

DROP TABLE IF EXISTS `proposal_template_item_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposal_template_item_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `proposal_template_item_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proposal_template_item_images_company_id_foreign` (`company_id`),
  KEY `proposal_template_item_images_proposal_template_item_id_foreign` (`proposal_template_item_id`),
  CONSTRAINT `proposal_template_item_images_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proposal_template_item_images_proposal_template_item_id_foreign` FOREIGN KEY (`proposal_template_item_id`) REFERENCES `proposal_template_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposal_template_item_images`
--

LOCK TABLES `proposal_template_item_images` WRITE;
/*!40000 ALTER TABLE `proposal_template_item_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `proposal_template_item_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proposal_template_items`
--

DROP TABLE IF EXISTS `proposal_template_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposal_template_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `proposal_template_id` bigint(20) unsigned NOT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `item_name` varchar(191) NOT NULL,
  `type` enum('item','discount','tax') NOT NULL DEFAULT 'item',
  `quantity` tinyint(4) NOT NULL,
  `unit_price` double NOT NULL,
  `amount` double NOT NULL,
  `item_summary` text DEFAULT NULL,
  `taxes` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unit_id` bigint(20) unsigned DEFAULT NULL,
  `product_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proposal_template_items_company_id_foreign` (`company_id`),
  KEY `proposal_template_items_proposal_template_id_foreign` (`proposal_template_id`),
  KEY `proposal_template_items_unit_id_foreign` (`unit_id`),
  KEY `proposal_template_items_product_id_foreign` (`product_id`),
  CONSTRAINT `proposal_template_items_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proposal_template_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `proposal_template_items_proposal_template_id_foreign` FOREIGN KEY (`proposal_template_id`) REFERENCES `proposal_templates` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proposal_template_items_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `unit_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposal_template_items`
--

LOCK TABLES `proposal_template_items` WRITE;
/*!40000 ALTER TABLE `proposal_template_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `proposal_template_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proposal_templates`
--

DROP TABLE IF EXISTS `proposal_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposal_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `sub_total` double NOT NULL,
  `total` double NOT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `discount_type` enum('percent','fixed') NOT NULL,
  `discount` double NOT NULL,
  `invoice_convert` tinyint(1) NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `client_comment` text DEFAULT NULL,
  `signature_approval` tinyint(1) NOT NULL DEFAULT 1,
  `hash` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proposal_templates_company_id_foreign` (`company_id`),
  KEY `proposal_templates_currency_id_foreign` (`currency_id`),
  KEY `proposal_templates_added_by_foreign` (`added_by`),
  KEY `proposal_templates_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `proposal_templates_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `proposal_templates_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proposal_templates_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proposal_templates_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposal_templates`
--

LOCK TABLES `proposal_templates` WRITE;
/*!40000 ALTER TABLE `proposal_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `proposal_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proposals`
--

DROP TABLE IF EXISTS `proposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `lead_id` int(10) unsigned NOT NULL,
  `valid_till` date NOT NULL,
  `sub_total` double(16,2) NOT NULL,
  `total` double(16,2) NOT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `discount_type` enum('percent','fixed') NOT NULL,
  `discount` double NOT NULL,
  `invoice_convert` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('declined','accepted','waiting') NOT NULL DEFAULT 'waiting',
  `note` mediumtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `client_comment` text DEFAULT NULL,
  `signature_approval` tinyint(1) NOT NULL DEFAULT 1,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `hash` text DEFAULT NULL,
  `calculate_tax` enum('after_discount','before_discount') NOT NULL DEFAULT 'after_discount',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_viewed` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  `send_status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `proposals_company_id_foreign` (`company_id`),
  KEY `proposals_lead_id_foreign` (`lead_id`),
  KEY `proposals_currency_id_foreign` (`currency_id`),
  KEY `proposals_added_by_foreign` (`added_by`),
  KEY `proposals_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `proposals_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `proposals_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proposals_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proposals_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `proposals_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposals`
--

LOCK TABLES `proposals` WRITE;
/*!40000 ALTER TABLE `proposals` DISABLE KEYS */;
INSERT INTO `proposals` VALUES (1,7,1,'2023-09-20',5000.00,5000.00,33,'percent',0,0,'waiting','','',NULL,1,8,8,'d1f5d54129a217d75ed2557daf4fafad','after_discount','2023-08-21 16:35:53','2023-08-21 16:37:48','2023-08-21 16:37:48','210.195.155.20',1);
/*!40000 ALTER TABLE `proposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purpose_consent`
--

DROP TABLE IF EXISTS `purpose_consent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purpose_consent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purpose_consent`
--

LOCK TABLES `purpose_consent` WRITE;
/*!40000 ALTER TABLE `purpose_consent` DISABLE KEYS */;
/*!40000 ALTER TABLE `purpose_consent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purpose_consent_leads`
--

DROP TABLE IF EXISTS `purpose_consent_leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purpose_consent_leads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `purpose_consent_id` int(10) unsigned NOT NULL,
  `status` enum('agree','disagree') NOT NULL DEFAULT 'agree',
  `ip` varchar(191) DEFAULT NULL,
  `updated_by_id` int(10) unsigned DEFAULT NULL,
  `additional_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purpose_consent_leads_lead_id_foreign` (`lead_id`),
  KEY `purpose_consent_leads_purpose_consent_id_foreign` (`purpose_consent_id`),
  KEY `purpose_consent_leads_updated_by_id_foreign` (`updated_by_id`),
  CONSTRAINT `purpose_consent_leads_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purpose_consent_leads_purpose_consent_id_foreign` FOREIGN KEY (`purpose_consent_id`) REFERENCES `purpose_consent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purpose_consent_leads_updated_by_id_foreign` FOREIGN KEY (`updated_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purpose_consent_leads`
--

LOCK TABLES `purpose_consent_leads` WRITE;
/*!40000 ALTER TABLE `purpose_consent_leads` DISABLE KEYS */;
/*!40000 ALTER TABLE `purpose_consent_leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purpose_consent_users`
--

DROP TABLE IF EXISTS `purpose_consent_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purpose_consent_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `purpose_consent_id` int(10) unsigned NOT NULL,
  `status` enum('agree','disagree') NOT NULL DEFAULT 'agree',
  `ip` varchar(191) DEFAULT NULL,
  `updated_by_id` int(10) unsigned NOT NULL,
  `additional_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purpose_consent_users_client_id_foreign` (`client_id`),
  KEY `purpose_consent_users_purpose_consent_id_foreign` (`purpose_consent_id`),
  KEY `purpose_consent_users_updated_by_id_foreign` (`updated_by_id`),
  CONSTRAINT `purpose_consent_users_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purpose_consent_users_purpose_consent_id_foreign` FOREIGN KEY (`purpose_consent_id`) REFERENCES `purpose_consent` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purpose_consent_users_updated_by_id_foreign` FOREIGN KEY (`updated_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purpose_consent_users`
--

LOCK TABLES `purpose_consent_users` WRITE;
/*!40000 ALTER TABLE `purpose_consent_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `purpose_consent_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notification_settings`
--

DROP TABLE IF EXISTS `push_notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_notification_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `onesignal_app_id` text DEFAULT NULL,
  `onesignal_rest_api_key` text DEFAULT NULL,
  `notification_logo` varchar(191) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notification_settings`
--

LOCK TABLES `push_notification_settings` WRITE;
/*!40000 ALTER TABLE `push_notification_settings` DISABLE KEYS */;
INSERT INTO `push_notification_settings` VALUES (1,NULL,NULL,NULL,'inactive','2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `push_notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_subscriptions`
--

DROP TABLE IF EXISTS `push_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `endpoint` varchar(191) NOT NULL,
  `public_key` varchar(191) DEFAULT NULL,
  `auth_token` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `push_subscriptions_endpoint_company_id_unique` (`endpoint`,`company_id`),
  KEY `push_subscriptions_company_id_foreign` (`company_id`),
  KEY `push_subscriptions_user_id_index` (`user_id`),
  CONSTRAINT `push_subscriptions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `push_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_subscriptions`
--

LOCK TABLES `push_subscriptions` WRITE;
/*!40000 ALTER TABLE `push_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pusher_settings`
--

DROP TABLE IF EXISTS `pusher_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pusher_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pusher_app_id` varchar(191) DEFAULT NULL,
  `pusher_app_key` varchar(191) DEFAULT NULL,
  `pusher_app_secret` varchar(191) DEFAULT NULL,
  `pusher_cluster` varchar(191) DEFAULT NULL,
  `force_tls` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `taskboard` tinyint(1) NOT NULL DEFAULT 1,
  `messages` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pusher_settings`
--

LOCK TABLES `pusher_settings` WRITE;
/*!40000 ALTER TABLE `pusher_settings` DISABLE KEYS */;
INSERT INTO `pusher_settings` VALUES (1,NULL,NULL,NULL,NULL,0,0,1,0,'2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `pusher_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quick_books_settings`
--

DROP TABLE IF EXISTS `quick_books_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quick_books_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `sandbox_client_id` varchar(191) NOT NULL,
  `sandbox_client_secret` varchar(191) NOT NULL,
  `client_id` varchar(191) NOT NULL,
  `client_secret` varchar(191) NOT NULL,
  `access_token` varchar(191) NOT NULL,
  `refresh_token` varchar(191) NOT NULL,
  `realmid` varchar(191) NOT NULL,
  `sync_type` enum('one_way','two_way') NOT NULL DEFAULT 'one_way',
  `environment` enum('Development','Production') NOT NULL DEFAULT 'Production',
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quick_books_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `quick_books_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quick_books_settings`
--

LOCK TABLES `quick_books_settings` WRITE;
/*!40000 ALTER TABLE `quick_books_settings` DISABLE KEYS */;
INSERT INTO `quick_books_settings` VALUES (1,1,'','','','','','','','one_way','Production',0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,'','','','','','','','one_way','Production',0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,'','','','','','','','one_way','Production',0,'2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `quick_books_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_items`
--

DROP TABLE IF EXISTS `quotation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotation_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` int(10) unsigned NOT NULL,
  `item_name` varchar(191) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `amount` double(8,2) NOT NULL,
  `hsn_sac_code` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_items_quotation_id_foreign` (`quotation_id`),
  CONSTRAINT `quotation_items_quotation_id_foreign` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_items`
--

LOCK TABLES `quotation_items` WRITE;
/*!40000 ALTER TABLE `quotation_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `business_name` varchar(191) NOT NULL,
  `client_name` varchar(191) NOT NULL,
  `client_email` varchar(191) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `sub_total` double(8,2) NOT NULL,
  `total` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotations_company_id_foreign` (`company_id`),
  CONSTRAINT `quotations_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `razorpay_invoices`
--

DROP TABLE IF EXISTS `razorpay_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `razorpay_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `invoice_id` varchar(191) NOT NULL,
  `subscription_id` varchar(191) NOT NULL,
  `order_id` varchar(191) DEFAULT NULL,
  `package_id` bigint(20) unsigned NOT NULL,
  `transaction_id` varchar(191) NOT NULL,
  `amount` decimal(12,2) unsigned NOT NULL,
  `pay_date` date NOT NULL,
  `next_pay_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `razorpay_invoices_company_id_foreign` (`company_id`),
  KEY `razorpay_invoices_package_id_foreign` (`package_id`),
  CONSTRAINT `razorpay_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `razorpay_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `razorpay_invoices`
--

LOCK TABLES `razorpay_invoices` WRITE;
/*!40000 ALTER TABLE `razorpay_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `razorpay_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `razorpay_subscriptions`
--

DROP TABLE IF EXISTS `razorpay_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `razorpay_subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `subscription_id` varchar(191) DEFAULT NULL,
  `customer_id` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `razorpay_id` varchar(191) NOT NULL,
  `razorpay_plan` varchar(191) NOT NULL,
  `quantity` int(11) NOT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `razorpay_subscriptions`
--

LOCK TABLES `razorpay_subscriptions` WRITE;
/*!40000 ALTER TABLE `razorpay_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `razorpay_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_applicant_notes`
--

DROP TABLE IF EXISTS `recruit_applicant_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_applicant_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `recruit_job_application_id` int(10) unsigned NOT NULL,
  `note_text` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_applicant_notes_user_id_foreign` (`user_id`),
  KEY `recruit_applicant_notes_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  CONSTRAINT `recruit_applicant_notes_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_applicant_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_applicant_notes`
--

LOCK TABLES `recruit_applicant_notes` WRITE;
/*!40000 ALTER TABLE `recruit_applicant_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_applicant_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_application_files`
--

DROP TABLE IF EXISTS `recruit_application_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_application_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_application_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) NOT NULL,
  `size` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_application_files_added_by_foreign` (`added_by`),
  KEY `recruit_application_files_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruit_application_files_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  CONSTRAINT `recruit_application_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_application_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_application_files_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_application_files`
--

LOCK TABLES `recruit_application_files` WRITE;
/*!40000 ALTER TABLE `recruit_application_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_application_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_application_skills`
--

DROP TABLE IF EXISTS `recruit_application_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_application_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_application_id` int(10) unsigned NOT NULL,
  `recruit_skill_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_application_skills_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  KEY `recruit_application_skills_recruit_skill_id_foreign` (`recruit_skill_id`),
  CONSTRAINT `recruit_application_skills_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_application_skills_recruit_skill_id_foreign` FOREIGN KEY (`recruit_skill_id`) REFERENCES `recruit_skills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_application_skills`
--

LOCK TABLES `recruit_application_skills` WRITE;
/*!40000 ALTER TABLE `recruit_application_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_application_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_application_status`
--

DROP TABLE IF EXISTS `recruit_application_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_application_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  `position` int(11) NOT NULL,
  `recruit_application_status_category_id` bigint(20) unsigned DEFAULT NULL,
  `action` enum('yes','no') NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ras_recruit_application_status_category_id_foreign` (`recruit_application_status_category_id`),
  KEY `recruit_application_status_company_id_foreign` (`company_id`),
  CONSTRAINT `ras_recruit_application_status_category_id_foreign` FOREIGN KEY (`recruit_application_status_category_id`) REFERENCES `recruit_application_status_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_application_status_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_application_status`
--

LOCK TABLES `recruit_application_status` WRITE;
/*!40000 ALTER TABLE `recruit_application_status` DISABLE KEYS */;
INSERT INTO `recruit_application_status` VALUES (1,1,'applied','applied','#2b2b2b',1,1,'yes','2023-08-21 05:41:24','2023-08-21 05:41:24'),(2,1,'phone screen','phone_screen','#f1e52e',2,2,'yes','2023-08-21 05:41:24','2023-08-21 05:41:24'),(3,1,'interview','interview','#3d8ee8',3,3,'yes','2023-08-21 05:41:24','2023-08-21 05:41:24'),(4,1,'hired','hired','#32ac16',4,4,'yes','2023-08-21 05:41:24','2023-08-21 05:41:24'),(5,1,'rejected','rejected','#ee1127',5,5,'yes','2023-08-21 05:41:24','2023-08-21 05:41:24'),(6,3,'applied','applied','#2b2b2b',1,7,'yes','2023-08-21 05:41:25','2023-08-21 05:41:25'),(7,3,'phone screen','phone_screen','#f1e52e',2,8,'yes','2023-08-21 05:41:25','2023-08-21 05:41:25'),(8,3,'interview','interview','#3d8ee8',3,9,'yes','2023-08-21 05:41:25','2023-08-21 05:41:25'),(9,3,'hired','hired','#32ac16',4,10,'yes','2023-08-21 05:41:25','2023-08-21 05:41:25'),(10,3,'rejected','rejected','#ee1127',5,11,'yes','2023-08-21 05:41:25','2023-08-21 05:41:25'),(26,7,'applied','applied','#2b2b2b',1,31,'yes','2023-08-21 16:25:19','2023-08-21 16:25:19'),(27,7,'phone screen','phone_screen','#f1e52e',2,32,'yes','2023-08-21 16:25:19','2023-08-21 16:25:19'),(28,7,'interview','interview','#3d8ee8',3,33,'yes','2023-08-21 16:25:19','2023-08-21 16:25:19'),(29,7,'hired','hired','#32ac16',4,34,'yes','2023-08-21 16:25:19','2023-08-21 16:25:19'),(30,7,'rejected','rejected','#ee1127',5,35,'yes','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `recruit_application_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_application_status_categories`
--

DROP TABLE IF EXISTS `recruit_application_status_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_application_status_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_application_status_categories_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_application_status_categories_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_application_status_categories`
--

LOCK TABLES `recruit_application_status_categories` WRITE;
/*!40000 ALTER TABLE `recruit_application_status_categories` DISABLE KEYS */;
INSERT INTO `recruit_application_status_categories` VALUES (1,1,'applied','2023-08-21 05:41:24','2023-08-21 05:41:24'),(2,1,'shortlist','2023-08-21 05:41:24','2023-08-21 05:41:24'),(3,1,'interview','2023-08-21 05:41:24','2023-08-21 05:41:24'),(4,1,'hired','2023-08-21 05:41:24','2023-08-21 05:41:24'),(5,1,'rejected','2023-08-21 05:41:24','2023-08-21 05:41:24'),(6,1,'others','2023-08-21 05:41:24','2023-08-21 05:41:24'),(7,3,'applied','2023-08-21 05:41:25','2023-08-21 05:41:25'),(8,3,'shortlist','2023-08-21 05:41:25','2023-08-21 05:41:25'),(9,3,'interview','2023-08-21 05:41:25','2023-08-21 05:41:25'),(10,3,'hired','2023-08-21 05:41:25','2023-08-21 05:41:25'),(11,3,'rejected','2023-08-21 05:41:25','2023-08-21 05:41:25'),(12,3,'others','2023-08-21 05:41:25','2023-08-21 05:41:25'),(31,7,'applied','2023-08-21 16:25:19','2023-08-21 16:25:19'),(32,7,'shortlist','2023-08-21 16:25:19','2023-08-21 16:25:19'),(33,7,'interview','2023-08-21 16:25:19','2023-08-21 16:25:19'),(34,7,'hired','2023-08-21 16:25:19','2023-08-21 16:25:19'),(35,7,'rejected','2023-08-21 16:25:19','2023-08-21 16:25:19'),(36,7,'others','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `recruit_application_status_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_candidate_database`
--

DROP TABLE IF EXISTS `recruit_candidate_database`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_candidate_database` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `recruit_job_id` bigint(20) unsigned NOT NULL,
  `location_id` bigint(20) unsigned NOT NULL,
  `Job_applied_on` date NOT NULL,
  `skills` longtext NOT NULL,
  `job_application_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_candidate_database_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_candidate_database_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_candidate_database`
--

LOCK TABLES `recruit_candidate_database` WRITE;
/*!40000 ALTER TABLE `recruit_candidate_database` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_candidate_database` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_candidate_follow_ups`
--

DROP TABLE IF EXISTS `recruit_candidate_follow_ups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_candidate_follow_ups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_application_id` int(10) unsigned DEFAULT NULL,
  `remark` longtext DEFAULT NULL,
  `next_follow_up_date` datetime DEFAULT NULL,
  `send_reminder` enum('yes','no') DEFAULT 'no',
  `remind_time` text DEFAULT NULL,
  `remind_type` enum('minute','hour','day') DEFAULT NULL,
  `status` varchar(191) DEFAULT 'incomplete',
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_candidate_follow_ups_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  KEY `recruit_candidate_follow_ups_added_by_foreign` (`added_by`),
  KEY `recruit_candidate_follow_ups_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `recruit_candidate_follow_ups_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_candidate_follow_ups_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_candidate_follow_ups_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_candidate_follow_ups`
--

LOCK TABLES `recruit_candidate_follow_ups` WRITE;
/*!40000 ALTER TABLE `recruit_candidate_follow_ups` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_candidate_follow_ups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_custom_questions`
--

DROP TABLE IF EXISTS `recruit_custom_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_custom_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category` enum('job_application','job_offer') NOT NULL DEFAULT 'job_application',
  `question` varchar(191) NOT NULL,
  `status` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `type` enum('text','number','password','textarea','select','radio','date','checkbox','file') NOT NULL DEFAULT 'text',
  `required` enum('yes','no') NOT NULL DEFAULT 'no',
  `values` varchar(5000) DEFAULT NULL,
  `column_priority` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_custom_questions_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_custom_questions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_custom_questions`
--

LOCK TABLES `recruit_custom_questions` WRITE;
/*!40000 ALTER TABLE `recruit_custom_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_custom_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_email_notification_settings`
--

DROP TABLE IF EXISTS `recruit_email_notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_email_notification_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `setting_name` varchar(191) NOT NULL,
  `send_email` enum('yes','no') NOT NULL DEFAULT 'no',
  `slug` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_email_notification_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_email_notification_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_email_notification_settings`
--

LOCK TABLES `recruit_email_notification_settings` WRITE;
/*!40000 ALTER TABLE `recruit_email_notification_settings` DISABLE KEYS */;
INSERT INTO `recruit_email_notification_settings` VALUES (1,1,'New Job/Added by Admin','yes','new-jobadded-by-admin','2023-08-21 05:41:25','2023-08-21 05:41:25'),(2,1,'New Job Application/Added by Admin','yes','new-job-applicationadded-by-admin','2023-08-21 05:41:25','2023-08-21 05:41:25'),(3,1,'New Interview Schedule/Added by Admin','yes','new-interview-scheduleadded-by-admin','2023-08-21 05:41:25','2023-08-21 05:41:25'),(4,1,'New Offer Letter/Added by Admin','yes','new-offer-letteradded-by-admin','2023-08-21 05:41:25','2023-08-21 05:41:25'),(5,1,'Notification to Recruiter','yes','notification-to-recruiter','2023-08-21 05:41:25','2023-08-21 05:41:25'),(6,3,'New Job/Added by Admin','yes','new-jobadded-by-admin','2023-08-21 05:41:25','2023-08-21 05:41:25'),(7,3,'New Job Application/Added by Admin','yes','new-job-applicationadded-by-admin','2023-08-21 05:41:25','2023-08-21 05:41:25'),(8,3,'New Interview Schedule/Added by Admin','yes','new-interview-scheduleadded-by-admin','2023-08-21 05:41:25','2023-08-21 05:41:25'),(9,3,'New Offer Letter/Added by Admin','yes','new-offer-letteradded-by-admin','2023-08-21 05:41:25','2023-08-21 05:41:25'),(10,3,'Notification to Recruiter','yes','notification-to-recruiter','2023-08-21 05:41:25','2023-08-21 05:41:25'),(26,7,'New Job/Added by Admin','yes','new-jobadded-by-admin','2023-08-21 16:25:19','2023-08-21 16:25:19'),(27,7,'New Job Application/Added by Admin','yes','new-job-applicationadded-by-admin','2023-08-21 16:25:19','2023-08-21 16:25:19'),(28,7,'New Interview Schedule/Added by Admin','yes','new-interview-scheduleadded-by-admin','2023-08-21 16:25:19','2023-08-21 16:25:19'),(29,7,'New Offer Letter/Added by Admin','yes','new-offer-letteradded-by-admin','2023-08-21 16:25:19','2023-08-21 16:25:19'),(30,7,'Notification to Recruiter','yes','notification-to-recruiter','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `recruit_email_notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_footer_links`
--

DROP TABLE IF EXISTS `recruit_footer_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_footer_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` longtext DEFAULT NULL,
  `status` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_footer_links_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_footer_links_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_footer_links`
--

LOCK TABLES `recruit_footer_links` WRITE;
/*!40000 ALTER TABLE `recruit_footer_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_footer_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_global_settings`
--

DROP TABLE IF EXISTS `recruit_global_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_global_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `purchase_code` varchar(191) DEFAULT NULL,
  `license_type` varchar(20) DEFAULT NULL,
  `supported_until` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_global_settings`
--

LOCK TABLES `recruit_global_settings` WRITE;
/*!40000 ALTER TABLE `recruit_global_settings` DISABLE KEYS */;
INSERT INTO `recruit_global_settings` VALUES (1,NULL,NULL,NULL,'2023-08-21 05:41:19','2023-08-21 05:41:19');
/*!40000 ALTER TABLE `recruit_global_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_interview_comments`
--

DROP TABLE IF EXISTS `recruit_interview_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_interview_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_interview_schedule_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `comment` text DEFAULT NULL,
  `candidate_comment` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_interview_comments_user_id_foreign` (`user_id`),
  KEY `recruit_interview_comments_recruit_interview_schedule_id_foreign` (`recruit_interview_schedule_id`),
  CONSTRAINT `recruit_interview_comments_recruit_interview_schedule_id_foreign` FOREIGN KEY (`recruit_interview_schedule_id`) REFERENCES `recruit_interview_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_interview_comments`
--

LOCK TABLES `recruit_interview_comments` WRITE;
/*!40000 ALTER TABLE `recruit_interview_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_interview_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_interview_employees`
--

DROP TABLE IF EXISTS `recruit_interview_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_interview_employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_interview_schedule_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `user_accept_status` enum('accept','refuse','waiting') NOT NULL DEFAULT 'waiting',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_interview_employees_user_id_foreign` (`user_id`),
  KEY `rie_recruit_interview_schedule_id_foreign` (`recruit_interview_schedule_id`),
  CONSTRAINT `recruit_interview_employees_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rie_recruit_interview_schedule_id_foreign` FOREIGN KEY (`recruit_interview_schedule_id`) REFERENCES `recruit_interview_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_interview_employees`
--

LOCK TABLES `recruit_interview_employees` WRITE;
/*!40000 ALTER TABLE `recruit_interview_employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_interview_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_interview_evaluations`
--

DROP TABLE IF EXISTS `recruit_interview_evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_interview_evaluations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `recruit_recommendation_status_id` int(10) unsigned DEFAULT NULL,
  `recruit_interview_schedule_id` int(10) unsigned DEFAULT NULL,
  `recruit_interview_stage_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_application_id` int(10) unsigned DEFAULT NULL,
  `submitted_by` int(10) unsigned DEFAULT NULL,
  `details` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_interview_evaluations_submitted_by_foreign` (`submitted_by`),
  KEY `rie_recruit_recommendation_status_id_foreign` (`recruit_recommendation_status_id`),
  KEY `riev_recruit_interview_schedule_id_foreign` (`recruit_interview_schedule_id`),
  KEY `rie_recruit_interview_stage_id_foreign` (`recruit_interview_stage_id`),
  KEY `rie_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  KEY `recruit_interview_evaluations_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_interview_evaluations_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_evaluations_submitted_by_foreign` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `rie_recruit_interview_stage_id_foreign` FOREIGN KEY (`recruit_interview_stage_id`) REFERENCES `recruit_interview_stages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rie_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rie_recruit_recommendation_status_id_foreign` FOREIGN KEY (`recruit_recommendation_status_id`) REFERENCES `recruit_recommendation_statuses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `riev_recruit_interview_schedule_id_foreign` FOREIGN KEY (`recruit_interview_schedule_id`) REFERENCES `recruit_interview_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_interview_evaluations`
--

LOCK TABLES `recruit_interview_evaluations` WRITE;
/*!40000 ALTER TABLE `recruit_interview_evaluations` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_interview_evaluations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_interview_files`
--

DROP TABLE IF EXISTS `recruit_interview_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_interview_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `recruit_interview_schedule_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_interview_files_user_id_foreign` (`user_id`),
  KEY `recruit_interview_files_added_by_foreign` (`added_by`),
  KEY `recruit_interview_files_last_updated_by_foreign` (`last_updated_by`),
  KEY `rif_recruit_interview_schedule_id_foreign` (`recruit_interview_schedule_id`),
  CONSTRAINT `recruit_interview_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rif_recruit_interview_schedule_id_foreign` FOREIGN KEY (`recruit_interview_schedule_id`) REFERENCES `recruit_interview_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_interview_files`
--

LOCK TABLES `recruit_interview_files` WRITE;
/*!40000 ALTER TABLE `recruit_interview_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_interview_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_interview_histories`
--

DROP TABLE IF EXISTS `recruit_interview_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_interview_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_interview_schedule_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `recruit_interview_file_id` int(10) unsigned DEFAULT NULL,
  `details` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_interview_histories_user_id_foreign` (`user_id`),
  KEY `rih_recruit_interview_schedule_id_foreign` (`recruit_interview_schedule_id`),
  KEY `recruit_interview_histories_recruit_interview_file_id_foreign` (`recruit_interview_file_id`),
  CONSTRAINT `recruit_interview_histories_recruit_interview_file_id_foreign` FOREIGN KEY (`recruit_interview_file_id`) REFERENCES `recruit_interview_files` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rih_recruit_interview_schedule_id_foreign` FOREIGN KEY (`recruit_interview_schedule_id`) REFERENCES `recruit_interview_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_interview_histories`
--

LOCK TABLES `recruit_interview_histories` WRITE;
/*!40000 ALTER TABLE `recruit_interview_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_interview_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_interview_schedules`
--

DROP TABLE IF EXISTS `recruit_interview_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_interview_schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_application_id` int(10) unsigned NOT NULL,
  `interview_type` enum('in person','video','phone') NOT NULL DEFAULT 'in person',
  `schedule_date` datetime DEFAULT NULL,
  `status` enum('rejected','hired','pending','canceled','completed') NOT NULL DEFAULT 'pending',
  `user_accept_status` enum('accept','refuse','waiting') NOT NULL DEFAULT 'waiting',
  `meeting_id` int(11) DEFAULT NULL,
  `video_type` enum('zoom','other') DEFAULT 'other',
  `remind_type_all` enum('day','hour','minute') NOT NULL,
  `notify_c` tinyint(1) NOT NULL DEFAULT 0,
  `remind_time_all` int(11) DEFAULT NULL,
  `send_reminder_all` tinyint(1) NOT NULL DEFAULT 0,
  `phone` varchar(191) DEFAULT NULL,
  `other_link` varchar(191) DEFAULT NULL,
  `remarks` varchar(191) DEFAULT NULL,
  `recruit_interview_stage_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_interview_schedules_parent_id_foreign` (`parent_id`),
  KEY `recruit_interview_schedules_added_by_foreign` (`added_by`),
  KEY `recruit_interview_schedules_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruit_interview_schedules_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  KEY `recruit_interview_schedules_recruit_interview_stage_id_foreign` (`recruit_interview_stage_id`),
  KEY `recruit_interview_schedules_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_interview_schedules_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_schedules_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_schedules_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_schedules_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `recruit_interview_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_schedules_recruit_interview_stage_id_foreign` FOREIGN KEY (`recruit_interview_stage_id`) REFERENCES `recruit_interview_stages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_interview_schedules_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_interview_schedules`
--

LOCK TABLES `recruit_interview_schedules` WRITE;
/*!40000 ALTER TABLE `recruit_interview_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_interview_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_interview_stages`
--

DROP TABLE IF EXISTS `recruit_interview_stages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_interview_stages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_interview_stages_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_interview_stages_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_interview_stages`
--

LOCK TABLES `recruit_interview_stages` WRITE;
/*!40000 ALTER TABLE `recruit_interview_stages` DISABLE KEYS */;
INSERT INTO `recruit_interview_stages` VALUES (1,1,'HR round','2023-08-21 05:41:25','2023-08-21 05:41:25'),(2,1,'Technical round','2023-08-21 05:41:25','2023-08-21 05:41:25'),(3,1,'Manager round','2023-08-21 05:41:25','2023-08-21 05:41:25'),(4,3,'HR round','2023-08-21 05:41:25','2023-08-21 05:41:25'),(5,3,'Technical round','2023-08-21 05:41:25','2023-08-21 05:41:25'),(6,3,'Manager round','2023-08-21 05:41:25','2023-08-21 05:41:25'),(16,7,'HR round','2023-08-21 16:25:19','2023-08-21 16:25:19'),(17,7,'Technical round','2023-08-21 16:25:19','2023-08-21 16:25:19'),(18,7,'Manager round','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `recruit_interview_stages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_addresses`
--

DROP TABLE IF EXISTS `recruit_job_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_addresses` (
  `recruit_job_id` bigint(20) unsigned NOT NULL,
  `company_address_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `recruit_job_addresses_recruit_job_id_foreign` (`recruit_job_id`),
  KEY `recruit_job_addresses_company_address_id_foreign` (`company_address_id`),
  CONSTRAINT `recruit_job_addresses_company_address_id_foreign` FOREIGN KEY (`company_address_id`) REFERENCES `company_addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_addresses_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_addresses`
--

LOCK TABLES `recruit_job_addresses` WRITE;
/*!40000 ALTER TABLE `recruit_job_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_alerts`
--

DROP TABLE IF EXISTS `recruit_job_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_alerts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `recruit_work_experience_id` bigint(20) unsigned DEFAULT NULL,
  `recruit_job_type_id` bigint(20) unsigned DEFAULT NULL,
  `recruit_job_category_id` int(10) unsigned NOT NULL,
  `location_id` bigint(20) unsigned DEFAULT NULL,
  `status` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_alerts_company_id_foreign` (`company_id`),
  KEY `recruit_job_alerts_recruit_work_experience_id_foreign` (`recruit_work_experience_id`),
  KEY `recruit_job_alerts_recruit_job_type_id_foreign` (`recruit_job_type_id`),
  KEY `recruit_job_alerts_recruit_job_category_id_foreign` (`recruit_job_category_id`),
  KEY `recruit_job_alerts_location_id_foreign` (`location_id`),
  CONSTRAINT `recruit_job_alerts_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_alerts_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `company_addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_alerts_recruit_job_category_id_foreign` FOREIGN KEY (`recruit_job_category_id`) REFERENCES `recruit_job_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_alerts_recruit_job_type_id_foreign` FOREIGN KEY (`recruit_job_type_id`) REFERENCES `recruit_job_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_alerts_recruit_work_experience_id_foreign` FOREIGN KEY (`recruit_work_experience_id`) REFERENCES `recruit_work_experiences` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_alerts`
--

LOCK TABLES `recruit_job_alerts` WRITE;
/*!40000 ALTER TABLE `recruit_job_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_applications`
--

DROP TABLE IF EXISTS `recruit_job_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_applications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `full_name` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(191) DEFAULT NULL,
  `total_experience` enum('fresher','0-1','1-2','2-3','3-4','4-5','5-6','6-7','7-8','8-9','9-10','10-11','11-12','12-13','13-14','over-15') DEFAULT NULL,
  `current_location` varchar(191) DEFAULT NULL,
  `current_ctc` double DEFAULT NULL,
  `currenct_ctc_rate` varchar(191) DEFAULT NULL,
  `expected_ctc` double DEFAULT NULL,
  `expected_ctc_rate` varchar(191) DEFAULT NULL,
  `notice_period` enum('15','30','45','60','75','90','over-90') DEFAULT NULL,
  `photo` varchar(191) DEFAULT NULL,
  `resume` text NOT NULL,
  `column_priority` int(11) DEFAULT NULL,
  `remark` varchar(191) NOT NULL,
  `rejection_remark` varchar(191) DEFAULT NULL,
  `cover_letter` mediumtext DEFAULT NULL,
  `job_type` enum('part time','full time','internship') DEFAULT 'full time',
  `recruit_job_id` bigint(20) unsigned NOT NULL,
  `recruit_application_status_id` int(10) unsigned DEFAULT NULL,
  `location_id` bigint(20) unsigned NOT NULL,
  `application_sources` enum('careerWebsite','addedByUser') NOT NULL,
  `application_source_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_file_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_applications_location_id_foreign` (`location_id`),
  KEY `recruit_job_applications_added_by_foreign` (`added_by`),
  KEY `recruit_job_applications_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruit_job_applications_recruit_job_id_foreign` (`recruit_job_id`),
  KEY `recruit_job_applications_recruit_application_status_id_foreign` (`recruit_application_status_id`),
  KEY `recruit_job_applications_application_source_id_foreign` (`application_source_id`),
  KEY `recruit_job_applications_recruit_job_file_id_foreign` (`recruit_job_file_id`),
  KEY `recruit_job_applications_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_job_applications_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_applications_application_source_id_foreign` FOREIGN KEY (`application_source_id`) REFERENCES `application_sources` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_applications_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_applications_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_applications_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `company_addresses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_applications_recruit_application_status_id_foreign` FOREIGN KEY (`recruit_application_status_id`) REFERENCES `recruit_application_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_applications_recruit_job_file_id_foreign` FOREIGN KEY (`recruit_job_file_id`) REFERENCES `recruit_job_files` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_applications_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_applications`
--

LOCK TABLES `recruit_job_applications` WRITE;
/*!40000 ALTER TABLE `recruit_job_applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_categories`
--

DROP TABLE IF EXISTS `recruit_job_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_name` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_categories_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_job_categories_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_categories`
--

LOCK TABLES `recruit_job_categories` WRITE;
/*!40000 ALTER TABLE `recruit_job_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_custom_answers`
--

DROP TABLE IF EXISTS `recruit_job_custom_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_custom_answers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_offer_letter_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_application_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_id` bigint(20) unsigned NOT NULL,
  `recruit_job_question_id` int(10) unsigned NOT NULL,
  `answer` varchar(191) DEFAULT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_custom_answers_recruit_job_offer_letter_id_foreign` (`recruit_job_offer_letter_id`),
  KEY `recruit_job_custom_answers_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  KEY `recruit_job_custom_answers_recruit_job_id_foreign` (`recruit_job_id`),
  KEY `recruit_job_custom_answers_recruit_job_question_id_foreign` (`recruit_job_question_id`),
  CONSTRAINT `recruit_job_custom_answers_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_custom_answers_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_custom_answers_recruit_job_offer_letter_id_foreign` FOREIGN KEY (`recruit_job_offer_letter_id`) REFERENCES `recruit_job_offer_letter` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_custom_answers_recruit_job_question_id_foreign` FOREIGN KEY (`recruit_job_question_id`) REFERENCES `recruit_custom_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_custom_answers`
--

LOCK TABLES `recruit_job_custom_answers` WRITE;
/*!40000 ALTER TABLE `recruit_job_custom_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_custom_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_files`
--

DROP TABLE IF EXISTS `recruit_job_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `recruit_job_id` bigint(20) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_files_user_id_foreign` (`user_id`),
  KEY `recruit_job_files_added_by_foreign` (`added_by`),
  KEY `recruit_job_files_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruit_job_files_recruit_job_id_foreign` (`recruit_job_id`),
  CONSTRAINT `recruit_job_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_files_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_files`
--

LOCK TABLES `recruit_job_files` WRITE;
/*!40000 ALTER TABLE `recruit_job_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_histories`
--

DROP TABLE IF EXISTS `recruit_job_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_id` bigint(20) unsigned DEFAULT NULL,
  `recruit_job_application_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_offer_letter_id` int(10) unsigned DEFAULT NULL,
  `recruit_interview_schedule_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `details` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_histories_user_id_foreign` (`user_id`),
  KEY `recruit_job_histories_recruit_job_id_foreign` (`recruit_job_id`),
  KEY `recruit_job_histories_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  KEY `recruit_job_histories_recruit_job_offer_letter_id_foreign` (`recruit_job_offer_letter_id`),
  KEY `recruit_job_histories_recruit_interview_schedule_id_foreign` (`recruit_interview_schedule_id`),
  CONSTRAINT `recruit_job_histories_recruit_interview_schedule_id_foreign` FOREIGN KEY (`recruit_interview_schedule_id`) REFERENCES `recruit_interview_schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_histories_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_histories_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_histories_recruit_job_offer_letter_id_foreign` FOREIGN KEY (`recruit_job_offer_letter_id`) REFERENCES `recruit_job_offer_letter` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_histories`
--

LOCK TABLES `recruit_job_histories` WRITE;
/*!40000 ALTER TABLE `recruit_job_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_offer_files`
--

DROP TABLE IF EXISTS `recruit_job_offer_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_offer_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_offer_letter_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_offer_files_added_by_foreign` (`added_by`),
  KEY `recruit_job_offer_files_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruit_job_offer_files_recruit_job_offer_letter_id_foreign` (`recruit_job_offer_letter_id`),
  CONSTRAINT `recruit_job_offer_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_offer_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_offer_files_recruit_job_offer_letter_id_foreign` FOREIGN KEY (`recruit_job_offer_letter_id`) REFERENCES `recruit_job_offer_letter` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_offer_files`
--

LOCK TABLES `recruit_job_offer_files` WRITE;
/*!40000 ALTER TABLE `recruit_job_offer_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_offer_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_offer_letter`
--

DROP TABLE IF EXISTS `recruit_job_offer_letter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_offer_letter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_application_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_id` bigint(20) unsigned DEFAULT NULL,
  `employee_id` int(10) unsigned DEFAULT NULL,
  `job_expire` date NOT NULL,
  `expected_joining_date` date NOT NULL,
  `comp_amount` double DEFAULT NULL,
  `status` varchar(191) NOT NULL,
  `pay_according` enum('hour','day','week','month','year') NOT NULL,
  `sign_require` varchar(191) DEFAULT NULL,
  `add_structure` int(11) NOT NULL DEFAULT 0,
  `sign_image` varchar(191) DEFAULT NULL,
  `decline_reason` varchar(191) DEFAULT NULL,
  `hash` varchar(191) DEFAULT NULL,
  `ip_address` varchar(191) DEFAULT NULL,
  `offer_accept_at` timestamp NULL DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_offer_letter_added_by_foreign` (`added_by`),
  KEY `recruit_job_offer_letter_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruit_job_offer_letter_employee_id_foreign` (`employee_id`),
  KEY `recruit_job_offer_letter_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  KEY `recruit_job_offer_letter_recruit_job_id_foreign` (`recruit_job_id`),
  KEY `recruit_job_offer_letter_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_job_offer_letter_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_offer_letter_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_offer_letter_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_offer_letter_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_offer_letter_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_offer_letter_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_offer_letter`
--

LOCK TABLES `recruit_job_offer_letter` WRITE;
/*!40000 ALTER TABLE `recruit_job_offer_letter` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_offer_letter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_offer_questions`
--

DROP TABLE IF EXISTS `recruit_job_offer_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_offer_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_custom_question_id` int(10) unsigned NOT NULL,
  `recruit_job_offer_letter_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_offer_questions_recruit_custom_question_id_foreign` (`recruit_custom_question_id`),
  KEY `recruit_job_offer_questions_recruit_job_offer_letter_id_foreign` (`recruit_job_offer_letter_id`),
  CONSTRAINT `recruit_job_offer_questions_recruit_custom_question_id_foreign` FOREIGN KEY (`recruit_custom_question_id`) REFERENCES `recruit_custom_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_offer_questions_recruit_job_offer_letter_id_foreign` FOREIGN KEY (`recruit_job_offer_letter_id`) REFERENCES `recruit_job_offer_letter` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_offer_questions`
--

LOCK TABLES `recruit_job_offer_questions` WRITE;
/*!40000 ALTER TABLE `recruit_job_offer_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_offer_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_questions`
--

DROP TABLE IF EXISTS `recruit_job_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_custom_question_id` int(10) unsigned NOT NULL,
  `recruit_job_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_questions_recruit_custom_question_id_foreign` (`recruit_custom_question_id`),
  KEY `recruit_job_questions_recruit_job_id_foreign` (`recruit_job_id`),
  CONSTRAINT `recruit_job_questions_recruit_custom_question_id_foreign` FOREIGN KEY (`recruit_custom_question_id`) REFERENCES `recruit_custom_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_questions_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_questions`
--

LOCK TABLES `recruit_job_questions` WRITE;
/*!40000 ALTER TABLE `recruit_job_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_skills`
--

DROP TABLE IF EXISTS `recruit_job_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recruit_job_id` bigint(20) unsigned NOT NULL,
  `recruit_skill_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_skills_recruit_job_id_foreign` (`recruit_job_id`),
  KEY `recruit_job_skills_recruit_skill_id_foreign` (`recruit_skill_id`),
  CONSTRAINT `recruit_job_skills_recruit_job_id_foreign` FOREIGN KEY (`recruit_job_id`) REFERENCES `recruit_jobs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_skills_recruit_skill_id_foreign` FOREIGN KEY (`recruit_skill_id`) REFERENCES `recruit_skills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_skills`
--

LOCK TABLES `recruit_job_skills` WRITE;
/*!40000 ALTER TABLE `recruit_job_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_sub_categories`
--

DROP TABLE IF EXISTS `recruit_job_sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_sub_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_category_id` int(10) unsigned NOT NULL,
  `sub_category_name` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_sub_categories_company_id_foreign` (`company_id`),
  KEY `recruit_job_sub_categories_recruit_job_category_id_foreign` (`recruit_job_category_id`),
  CONSTRAINT `recruit_job_sub_categories_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_job_sub_categories_recruit_job_category_id_foreign` FOREIGN KEY (`recruit_job_category_id`) REFERENCES `recruit_job_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_sub_categories`
--

LOCK TABLES `recruit_job_sub_categories` WRITE;
/*!40000 ALTER TABLE `recruit_job_sub_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_job_sub_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_job_types`
--

DROP TABLE IF EXISTS `recruit_job_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_job_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `job_type` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_job_types_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_job_types_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_job_types`
--

LOCK TABLES `recruit_job_types` WRITE;
/*!40000 ALTER TABLE `recruit_job_types` DISABLE KEYS */;
INSERT INTO `recruit_job_types` VALUES (1,1,'Full time','2023-08-21 05:41:25','2023-08-21 05:41:25'),(2,1,'Part time','2023-08-21 05:41:25','2023-08-21 05:41:25'),(3,1,'On Contract','2023-08-21 05:41:25','2023-08-21 05:41:25'),(4,1,'Internship','2023-08-21 05:41:25','2023-08-21 05:41:25'),(5,1,'Trainee','2023-08-21 05:41:25','2023-08-21 05:41:25'),(6,3,'Full time','2023-08-21 05:41:25','2023-08-21 05:41:25'),(7,3,'Part time','2023-08-21 05:41:25','2023-08-21 05:41:25'),(8,3,'On Contract','2023-08-21 05:41:25','2023-08-21 05:41:25'),(9,3,'Internship','2023-08-21 05:41:25','2023-08-21 05:41:25'),(10,3,'Trainee','2023-08-21 05:41:25','2023-08-21 05:41:25'),(26,7,'Full time','2023-08-21 16:25:19','2023-08-21 16:25:19'),(27,7,'Part time','2023-08-21 16:25:19','2023-08-21 16:25:19'),(28,7,'On Contract','2023-08-21 16:25:19','2023-08-21 16:25:19'),(29,7,'Internship','2023-08-21 16:25:19','2023-08-21 16:25:19'),(30,7,'Trainee','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `recruit_job_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_jobboard_settings`
--

DROP TABLE IF EXISTS `recruit_jobboard_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_jobboard_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `recruit_application_status_id` int(10) unsigned NOT NULL,
  `collapsed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_jobboard_settings_user_id_foreign` (`user_id`),
  KEY `recruit_jobboard_settings_recruit_application_status_id_foreign` (`recruit_application_status_id`),
  CONSTRAINT `recruit_jobboard_settings_recruit_application_status_id_foreign` FOREIGN KEY (`recruit_application_status_id`) REFERENCES `recruit_application_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobboard_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_jobboard_settings`
--

LOCK TABLES `recruit_jobboard_settings` WRITE;
/*!40000 ALTER TABLE `recruit_jobboard_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_jobboard_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_jobs`
--

DROP TABLE IF EXISTS `recruit_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `title` text NOT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `recruit_job_type_id` bigint(20) unsigned DEFAULT NULL,
  `job_description` longtext DEFAULT NULL,
  `total_positions` int(11) NOT NULL,
  `remaining_openings` int(11) NOT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `recruiter_id` int(11) NOT NULL,
  `job_type` enum('part time','full time') NOT NULL DEFAULT 'full time',
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  `currency_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_category_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_sub_category_id` int(10) unsigned DEFAULT NULL,
  `remote_job` enum('yes','no') DEFAULT 'no',
  `disclose_salary` enum('yes','no') DEFAULT 'no',
  `meta_details` text NOT NULL,
  `is_photo_require` tinyint(1) NOT NULL DEFAULT 0,
  `is_resume_require` tinyint(1) NOT NULL DEFAULT 0,
  `is_dob_require` tinyint(1) NOT NULL DEFAULT 0,
  `is_gender_require` tinyint(1) NOT NULL DEFAULT 0,
  `recruit_work_experience_id` bigint(20) unsigned DEFAULT NULL,
  `pay_type` varchar(191) NOT NULL,
  `start_amount` double NOT NULL,
  `end_amount` double DEFAULT NULL,
  `pay_according` enum('hour','day','week','month','year') NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_jobs_department_id_foreign` (`department_id`),
  KEY `recruit_jobs_added_by_foreign` (`added_by`),
  KEY `recruit_jobs_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruit_jobs_recruit_job_sub_category_id_foreign` (`recruit_job_sub_category_id`),
  KEY `recruit_jobs_recruit_job_category_id_foreign` (`recruit_job_category_id`),
  KEY `recruit_jobs_currency_id_foreign` (`currency_id`),
  KEY `recruit_jobs_recruit_job_type_id_foreign` (`recruit_job_type_id`),
  KEY `recruit_jobs_recruit_work_experience_id_foreign` (`recruit_work_experience_id`),
  KEY `recruit_jobs_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_jobs_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobs_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobs_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobs_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobs_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobs_recruit_job_category_id_foreign` FOREIGN KEY (`recruit_job_category_id`) REFERENCES `recruit_job_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobs_recruit_job_sub_category_id_foreign` FOREIGN KEY (`recruit_job_sub_category_id`) REFERENCES `recruit_job_sub_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobs_recruit_job_type_id_foreign` FOREIGN KEY (`recruit_job_type_id`) REFERENCES `recruit_job_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_jobs_recruit_work_experience_id_foreign` FOREIGN KEY (`recruit_work_experience_id`) REFERENCES `recruit_work_experiences` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_jobs`
--

LOCK TABLES `recruit_jobs` WRITE;
/*!40000 ALTER TABLE `recruit_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_recommendation_statuses`
--

DROP TABLE IF EXISTS `recruit_recommendation_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_recommendation_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(191) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_recommendation_statuses_added_by_foreign` (`added_by`),
  KEY `recruit_recommendation_statuses_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruit_recommendation_statuses_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_recommendation_statuses_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruit_recommendation_statuses_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_recommendation_statuses_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_recommendation_statuses`
--

LOCK TABLES `recruit_recommendation_statuses` WRITE;
/*!40000 ALTER TABLE `recruit_recommendation_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_recommendation_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_salary_structures`
--

DROP TABLE IF EXISTS `recruit_salary_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_salary_structures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_application_id` int(10) unsigned DEFAULT NULL,
  `recruit_job_offer_letter_id` int(10) unsigned DEFAULT NULL,
  `salary_json` text DEFAULT NULL,
  `annual_salary` varchar(191) DEFAULT NULL,
  `basic_salary` varchar(191) DEFAULT NULL,
  `basic_value_type` enum('fixed','ctc_percent') DEFAULT NULL,
  `amount` varchar(191) NOT NULL DEFAULT '0',
  `fixed_allowance` double NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_salary_structures_company_id_foreign` (`company_id`),
  KEY `recruit_salary_structures_recruit_job_application_id_foreign` (`recruit_job_application_id`),
  KEY `recruit_salary_structures_recruit_job_offer_letter_id_foreign` (`recruit_job_offer_letter_id`),
  CONSTRAINT `recruit_salary_structures_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_salary_structures_recruit_job_application_id_foreign` FOREIGN KEY (`recruit_job_application_id`) REFERENCES `recruit_job_applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_salary_structures_recruit_job_offer_letter_id_foreign` FOREIGN KEY (`recruit_job_offer_letter_id`) REFERENCES `recruit_job_offer_letter` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_salary_structures`
--

LOCK TABLES `recruit_salary_structures` WRITE;
/*!40000 ALTER TABLE `recruit_salary_structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_salary_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_selected_salary_components`
--

DROP TABLE IF EXISTS `recruit_selected_salary_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_selected_salary_components` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `rss_id` int(10) unsigned DEFAULT NULL,
  `salary_component_id` int(10) unsigned DEFAULT NULL,
  `component_name` varchar(191) DEFAULT NULL,
  `component_type` enum('earning','deduction') DEFAULT NULL,
  `component_value` varchar(191) DEFAULT NULL,
  `value_type` enum('fixed','percent','basic_percent','variable') NOT NULL DEFAULT 'variable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_selected_salary_components_company_id_foreign` (`company_id`),
  KEY `recruit_selected_salary_components_rss_id_foreign` (`rss_id`),
  CONSTRAINT `recruit_selected_salary_components_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruit_selected_salary_components_rss_id_foreign` FOREIGN KEY (`rss_id`) REFERENCES `recruit_salary_structures` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_selected_salary_components`
--

LOCK TABLES `recruit_selected_salary_components` WRITE;
/*!40000 ALTER TABLE `recruit_selected_salary_components` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_selected_salary_components` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_settings`
--

DROP TABLE IF EXISTS `recruit_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `about` longtext DEFAULT NULL,
  `type` varchar(191) DEFAULT 'bg-image',
  `background_image` varchar(191) DEFAULT NULL,
  `background_color` varchar(191) DEFAULT NULL,
  `mail_setting` longtext NOT NULL,
  `form_settings` longtext DEFAULT NULL,
  `legal_term` longtext DEFAULT NULL,
  `logo` varchar(191) DEFAULT NULL,
  `favicon` varchar(191) DEFAULT NULL,
  `company_name` varchar(191) DEFAULT NULL,
  `company_website` varchar(191) DEFAULT NULL,
  `career_site` enum('yes','no') NOT NULL DEFAULT 'yes',
  `offer_letter_reminder` int(11) NOT NULL,
  `job_alert_status` enum('yes','no') NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `application_restriction` int(11) NOT NULL DEFAULT 180,
  `google_recaptcha_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_settings`
--

LOCK TABLES `recruit_settings` WRITE;
/*!40000 ALTER TABLE `recruit_settings` DISABLE KEYS */;
INSERT INTO `recruit_settings` VALUES (1,1,'<header>\n      <h5 >Dummy Company</h5>\n      <p>A leader in innovative solutions</p>\n    </header>\n    <main class=\"mt-2\">\n      <h5 class=\"mt-2\">About Us</h5>\n      <p>Dummy Company was founded in 2020 with a mission to provide innovative solutions for a better tomorrow. We have a team of experts in various fields who work together to bring cutting-edge products and services to market. Our focus on quality and customer satisfaction has made us a trusted name in the industry.</p>\n      <h5 class=\"mt-2\">Our Products and Services</h5>\n      <ul>\n        <li>Product 1: A revolutionary new technology that improves efficiency and productivity</li>\n        <li>Product 2: A user-friendly platform that simplifies complex processes</li>\n        <li>Service 1: Customized consulting services to help businesses stay ahead of the curve</li>\n        <li>Service 2: Training and support to ensure the successful adoption of our products</li>\n      </ul>\n      <h5 class=\"mt-2\">Our Team</h5>\n      <p>Dummy Company is powered by a talented and dedicated team of professionals. Our team members bring a diverse set of skills and experiences to the table, allowing us to tackle complex challenges and deliver solutions that truly make a difference. We are committed to fostering a positive and collaborative work environment where everyone has the opportunity to grow and succeed.</p>\n    </main>\n    <footer>','bg-image',NULL,NULL,'{\"1\":{\"id\":1,\"name\":\"applied\",\"status\":true},\"2\":{\"id\":2,\"name\":\"phone screen\",\"status\":true},\"3\":{\"id\":3,\"name\":\"interview\",\"status\":true},\"4\":{\"id\":4,\"name\":\"hired\",\"status\":true},\"5\":{\"id\":5,\"name\":\"rejected\",\"status\":true}}','{\"1\":{\"id\":1,\"name\":\"email\",\"slug\":\"Email\",\"status\":false},\"2\":{\"id\":2,\"name\":\"phone\",\"slug\":\"Phone\",\"status\":false},\"3\":{\"id\":3,\"name\":\"gender\",\"slug\":\"Gender\",\"status\":false},\"4\":{\"id\":4,\"name\":\"total_experience\",\"slug\":\"Total Experience\",\"status\":false},\"5\":{\"id\":5,\"name\":\"current_location\",\"slug\":\"Current location\",\"status\":false},\"6\":{\"id\":6,\"name\":\"current_ctc\",\"slug\":\"Current Ctc\",\"status\":false},\"7\":{\"id\":7,\"name\":\"expected_ctc\",\"slug\":\"Expected Ctc\",\"status\":false},\"8\":{\"id\":8,\"name\":\"notice_period\",\"slug\":\"Notice Period\",\"status\":false},\"9\":{\"id\":9,\"name\":\"application_source\",\"slug\":\"Source\",\"status\":false},\"10\":{\"id\":10,\"name\":\"status\",\"slug\":\"Status\",\"status\":false},\"11\":{\"id\":11,\"name\":\"cover_letter\",\"slug\":\"Cover letter\",\"status\":false}}','If any provision of these Terms and Conditions is held to be invalid or unenforceable, the provision shall be removed (or interpreted, if possible, in a manner as to be enforceable), and the remaining provisions shall be enforced. Headings are for reference purposes only and in no way define, limit, construe or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. These Terms and Conditions set forth the entire understanding and agreement between us with respect to the subject matter contained herein and supersede any other agreement, proposals and communications, written or oral, between our representatives and you with respect to the subject matter hereof, including any terms and conditions on any of customer\'s documents or purchase orders.<br>No Joint Venture, No Derogation of Rights. You agree that no joint venture, partnership, employment, or agency relationship exists between you and us as a result of these Terms and Conditions or your use of the Site. Our performance of these Terms and Conditions is subject to existing laws and legal process, and nothing contained herein is in derogation of our right to comply with governmental, court and law enforcement requests or requirements relating to your use of the Site or information provided to or gathered by us with respect to such use.',NULL,NULL,'Demo Company','https://worksuite.biz','yes',0,'no','2023-08-21 05:41:24','2023-08-21 05:41:24',180,'deactive'),(2,3,'<header>\n      <h5 >Dummy Company</h5>\n      <p>A leader in innovative solutions</p>\n    </header>\n    <main class=\"mt-2\">\n      <h5 class=\"mt-2\">About Us</h5>\n      <p>Dummy Company was founded in 2020 with a mission to provide innovative solutions for a better tomorrow. We have a team of experts in various fields who work together to bring cutting-edge products and services to market. Our focus on quality and customer satisfaction has made us a trusted name in the industry.</p>\n      <h5 class=\"mt-2\">Our Products and Services</h5>\n      <ul>\n        <li>Product 1: A revolutionary new technology that improves efficiency and productivity</li>\n        <li>Product 2: A user-friendly platform that simplifies complex processes</li>\n        <li>Service 1: Customized consulting services to help businesses stay ahead of the curve</li>\n        <li>Service 2: Training and support to ensure the successful adoption of our products</li>\n      </ul>\n      <h5 class=\"mt-2\">Our Team</h5>\n      <p>Dummy Company is powered by a talented and dedicated team of professionals. Our team members bring a diverse set of skills and experiences to the table, allowing us to tackle complex challenges and deliver solutions that truly make a difference. We are committed to fostering a positive and collaborative work environment where everyone has the opportunity to grow and succeed.</p>\n    </main>\n    <footer>','bg-image',NULL,NULL,'{\"6\":{\"id\":6,\"name\":\"applied\",\"status\":true},\"7\":{\"id\":7,\"name\":\"phone screen\",\"status\":true},\"8\":{\"id\":8,\"name\":\"interview\",\"status\":true},\"9\":{\"id\":9,\"name\":\"hired\",\"status\":true},\"10\":{\"id\":10,\"name\":\"rejected\",\"status\":true}}','{\"1\":{\"id\":1,\"name\":\"email\",\"slug\":\"Email\",\"status\":false},\"2\":{\"id\":2,\"name\":\"phone\",\"slug\":\"Phone\",\"status\":false},\"3\":{\"id\":3,\"name\":\"gender\",\"slug\":\"Gender\",\"status\":false},\"4\":{\"id\":4,\"name\":\"total_experience\",\"slug\":\"Total Experience\",\"status\":false},\"5\":{\"id\":5,\"name\":\"current_location\",\"slug\":\"Current location\",\"status\":false},\"6\":{\"id\":6,\"name\":\"current_ctc\",\"slug\":\"Current Ctc\",\"status\":false},\"7\":{\"id\":7,\"name\":\"expected_ctc\",\"slug\":\"Expected Ctc\",\"status\":false},\"8\":{\"id\":8,\"name\":\"notice_period\",\"slug\":\"Notice Period\",\"status\":false},\"9\":{\"id\":9,\"name\":\"application_source\",\"slug\":\"Source\",\"status\":false},\"10\":{\"id\":10,\"name\":\"status\",\"slug\":\"Status\",\"status\":false},\"11\":{\"id\":11,\"name\":\"cover_letter\",\"slug\":\"Cover letter\",\"status\":false}}','If any provision of these Terms and Conditions is held to be invalid or unenforceable, the provision shall be removed (or interpreted, if possible, in a manner as to be enforceable), and the remaining provisions shall be enforced. Headings are for reference purposes only and in no way define, limit, construe or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. These Terms and Conditions set forth the entire understanding and agreement between us with respect to the subject matter contained herein and supersede any other agreement, proposals and communications, written or oral, between our representatives and you with respect to the subject matter hereof, including any terms and conditions on any of customer\'s documents or purchase orders.<br>No Joint Venture, No Derogation of Rights. You agree that no joint venture, partnership, employment, or agency relationship exists between you and us as a result of these Terms and Conditions or your use of the Site. Our performance of these Terms and Conditions is subject to existing laws and legal process, and nothing contained herein is in derogation of our right to comply with governmental, court and law enforcement requests or requirements relating to your use of the Site or information provided to or gathered by us with respect to such use.',NULL,NULL,'Ascot Hill',NULL,'yes',0,'no','2023-08-21 05:41:25','2023-08-21 05:41:25',180,'deactive'),(6,7,'Dummy CompanyA leader in innovative solutionsAbout UsDummy Company was founded in 2020 with a mission to provide innovative solutions for a better tomorrow. We have a team of experts in various fields who work together to bring cutting-edge products and services to market. Our focus on quality and customer satisfaction has made us a trusted name in the industry.Our Products and ServicesProduct 1: A revolutionary new technology that improves efficiency and productivityProduct 2: A user-friendly platform that simplifies complex processesService 1: Customized consulting services to help businesses stay ahead of the curveService 2: Training and support to ensure the successful adoption of our productsOur TeamDummy Company is powered by a talented and dedicated team of professionals. Our team members bring a diverse set of skills and experiences to the table, allowing us to tackle complex challenges and deliver solutions that truly make a difference. We are committed to fostering a positive and collaborative work environment where everyone has the opportunity to grow and succeed.','bg-image',NULL,NULL,'{\"26\":{\"id\":26,\"name\":\"applied\",\"status\":true},\"27\":{\"id\":27,\"name\":\"phone screen\",\"status\":true},\"28\":{\"id\":28,\"name\":\"interview\",\"status\":true},\"29\":{\"id\":29,\"name\":\"hired\",\"status\":true},\"30\":{\"id\":30,\"name\":\"rejected\",\"status\":true}}','{\"1\":{\"id\":1,\"name\":\"email\",\"slug\":\"Email\",\"status\":false},\"2\":{\"id\":2,\"name\":\"phone\",\"slug\":\"Phone\",\"status\":false},\"3\":{\"id\":3,\"name\":\"gender\",\"slug\":\"Gender\",\"status\":false},\"4\":{\"id\":4,\"name\":\"total_experience\",\"slug\":\"Total Experience\",\"status\":false},\"5\":{\"id\":5,\"name\":\"current_location\",\"slug\":\"Current location\",\"status\":false},\"6\":{\"id\":6,\"name\":\"current_ctc\",\"slug\":\"Current Ctc\",\"status\":false},\"7\":{\"id\":7,\"name\":\"expected_ctc\",\"slug\":\"Expected Ctc\",\"status\":false},\"8\":{\"id\":8,\"name\":\"notice_period\",\"slug\":\"Notice Period\",\"status\":false},\"9\":{\"id\":9,\"name\":\"application_source\",\"slug\":\"Source\",\"status\":false},\"10\":{\"id\":10,\"name\":\"status\",\"slug\":\"Status\",\"status\":false},\"11\":{\"id\":11,\"name\":\"cover_letter\",\"slug\":\"Cover letter\",\"status\":false}}','<p>If any provision of these Terms and Conditions is held to be invalid or unenforceable, the provision shall be removed (or interpreted, if possible, in a manner as to be enforceable), and the remaining provisions shall be enforced. Headings are for reference purposes only and in no way define, limit, construe or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. These Terms and Conditions set forth the entire understanding and agreement between us with respect to the subject matter contained herein and supersede any other agreement, proposals and communications, written or oral, between our representatives and you with respect to the subject matter hereof, including any terms and conditions on any of customer\'s documents or purchase orders.</p><p>No Joint Venture, No Derogation of Rights. You agree that no joint venture, partnership, employment, or agency relationship exists between you and us as a result of these Terms and Conditions or your use of the Site. Our performance of these Terms and Conditions is subject to existing laws and legal process, and nothing contained herein is in derogation of our right to comply with governmental, court and law enforcement requests or requirements relating to your use of the Site or information provided to or gathered by us with respect to such use.</p>',NULL,NULL,'SmartKerja',NULL,'yes',0,'no','2023-08-21 16:25:19','2024-07-15 00:23:38',180,'deactive');
/*!40000 ALTER TABLE `recruit_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_skills`
--

DROP TABLE IF EXISTS `recruit_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_skills_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_skills_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_skills`
--

LOCK TABLES `recruit_skills` WRITE;
/*!40000 ALTER TABLE `recruit_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruit_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruit_work_experiences`
--

DROP TABLE IF EXISTS `recruit_work_experiences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruit_work_experiences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `work_experience` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruit_work_experiences_company_id_foreign` (`company_id`),
  CONSTRAINT `recruit_work_experiences_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruit_work_experiences`
--

LOCK TABLES `recruit_work_experiences` WRITE;
/*!40000 ALTER TABLE `recruit_work_experiences` DISABLE KEYS */;
INSERT INTO `recruit_work_experiences` VALUES (1,1,'fresher','2023-08-21 05:41:25','2023-08-21 05:41:25'),(2,1,'0-1 years','2023-08-21 05:41:25','2023-08-21 05:41:25'),(3,1,'1-3 years','2023-08-21 05:41:25','2023-08-21 05:41:25'),(4,1,'3-5 years','2023-08-21 05:41:25','2023-08-21 05:41:25'),(5,1,'5+ years','2023-08-21 05:41:25','2023-08-21 05:41:25'),(6,3,'fresher','2023-08-21 05:41:25','2023-08-21 05:41:25'),(7,3,'0-1 years','2023-08-21 05:41:25','2023-08-21 05:41:25'),(8,3,'1-3 years','2023-08-21 05:41:25','2023-08-21 05:41:25'),(9,3,'3-5 years','2023-08-21 05:41:25','2023-08-21 05:41:25'),(10,3,'5+ years','2023-08-21 05:41:25','2023-08-21 05:41:25'),(26,7,'fresher','2023-08-21 16:25:19','2023-08-21 16:25:19'),(27,7,'0-1 years','2023-08-21 16:25:19','2023-08-21 16:25:19'),(28,7,'1-3 years','2023-08-21 16:25:19','2023-08-21 16:25:19'),(29,7,'3-5 years','2023-08-21 16:25:19','2023-08-21 16:25:19'),(30,7,'5+ years','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `recruit_work_experiences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recruiters`
--

DROP TABLE IF EXISTS `recruiters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recruiters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'enabled',
  `added_by` int(10) unsigned NOT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recruiters_user_id_foreign` (`user_id`),
  KEY `recruiters_added_by_foreign` (`added_by`),
  KEY `recruiters_last_updated_by_foreign` (`last_updated_by`),
  KEY `recruiters_company_id_foreign` (`company_id`),
  CONSTRAINT `recruiters_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruiters_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `recruiters_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `recruiters_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recruiters`
--

LOCK TABLES `recruiters` WRITE;
/*!40000 ALTER TABLE `recruiters` DISABLE KEYS */;
/*!40000 ALTER TABLE `recruiters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `removal_requests`
--

DROP TABLE IF EXISTS `removal_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `removal_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `description` varchar(191) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `removal_requests_company_id_foreign` (`company_id`),
  KEY `removal_requests_user_id_foreign` (`user_id`),
  CONSTRAINT `removal_requests_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `removal_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `removal_requests`
--

LOCK TABLES `removal_requests` WRITE;
/*!40000 ALTER TABLE `removal_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `removal_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `removal_requests_lead`
--

DROP TABLE IF EXISTS `removal_requests_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `removal_requests_lead` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `description` varchar(191) NOT NULL,
  `lead_id` int(10) unsigned DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `removal_requests_lead_company_id_foreign` (`company_id`),
  KEY `removal_requests_lead_lead_id_foreign` (`lead_id`),
  CONSTRAINT `removal_requests_lead_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `removal_requests_lead_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `removal_requests_lead`
--

LOCK TABLES `removal_requests_lead` WRITE;
/*!40000 ALTER TABLE `removal_requests_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `removal_requests_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,4),(2,1),(2,2),(3,8),(3,9),(4,2),(8,20),(8,21),(9,22);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `display_name` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_company_id_unique` (`name`,`company_id`),
  KEY `roles_company_id_foreign` (`company_id`),
  CONSTRAINT `roles_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,1,'admin','App Administrator','Admin is allowed to manage everything of the app.','2023-08-10 14:06:55','2023-08-10 14:06:55'),(2,1,'employee','Employee','Employee can see tasks and projects assigned to him.','2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,1,'client','Client','Client can see own tasks and projects.','2023-08-10 14:06:55','2023-08-10 14:06:55'),(4,NULL,'superadmin','Superadmin',NULL,'2023-08-10 14:06:56','2023-08-10 14:06:56'),(8,3,'admin','App Administrator','Admin is allowed to manage everything of the app.','2023-08-10 14:17:22','2023-08-10 14:17:22'),(9,3,'employee','Employee','Employee can see tasks and projects assigned to him.','2023-08-10 14:17:22','2023-08-10 14:17:22'),(10,3,'client','Client','Client can see own tasks and projects.','2023-08-10 14:17:22','2023-08-10 14:17:22'),(20,7,'admin','App Administrator','Admin is allowed to manage everything of the app.','2023-08-21 16:25:19','2023-08-21 16:25:19'),(21,7,'employee','Employee','Employee can see tasks and projects assigned to him.','2023-08-21 16:25:19','2023-08-21 16:25:19'),(22,7,'client','Client','Client can see own tasks and projects.','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_components`
--

DROP TABLE IF EXISTS `salary_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_components` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `component_name` varchar(191) NOT NULL,
  `component_type` enum('earning','deduction') NOT NULL,
  `component_value` varchar(191) NOT NULL,
  `value_type` enum('fixed','percent','basic_percent','variable') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `weekly_value` double NOT NULL DEFAULT 0,
  `biweekly_value` double NOT NULL DEFAULT 0,
  `semimonthly_value` double NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `salary_components_company_id_foreign` (`company_id`),
  CONSTRAINT `salary_components_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_components`
--

LOCK TABLES `salary_components` WRITE;
/*!40000 ALTER TABLE `salary_components` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_components` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_group_components`
--

DROP TABLE IF EXISTS `salary_group_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_group_components` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `salary_group_id` bigint(20) unsigned NOT NULL,
  `salary_component_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salary_group_components_salary_group_id_foreign` (`salary_group_id`),
  KEY `salary_group_components_salary_component_id_foreign` (`salary_component_id`),
  KEY `salary_group_components_company_id_foreign` (`company_id`),
  CONSTRAINT `salary_group_components_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `salary_group_components_salary_component_id_foreign` FOREIGN KEY (`salary_component_id`) REFERENCES `salary_components` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_group_components_salary_group_id_foreign` FOREIGN KEY (`salary_group_id`) REFERENCES `salary_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_group_components`
--

LOCK TABLES `salary_group_components` WRITE;
/*!40000 ALTER TABLE `salary_group_components` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_group_components` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_groups`
--

DROP TABLE IF EXISTS `salary_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `group_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salary_groups_company_id_foreign` (`company_id`),
  CONSTRAINT `salary_groups_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_groups`
--

LOCK TABLES `salary_groups` WRITE;
/*!40000 ALTER TABLE `salary_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_payment_methods`
--

DROP TABLE IF EXISTS `salary_payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_payment_methods` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `payment_method` varchar(191) NOT NULL,
  `default` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salary_payment_methods_company_id_foreign` (`company_id`),
  CONSTRAINT `salary_payment_methods_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_payment_methods`
--

LOCK TABLES `salary_payment_methods` WRITE;
/*!40000 ALTER TABLE `salary_payment_methods` DISABLE KEYS */;
INSERT INTO `salary_payment_methods` VALUES (1,1,'Bank Transfer',1,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(2,1,'Cash',0,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(3,1,'Cheque',0,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(4,1,'PayPal',0,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(5,3,'Bank Transfer',1,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(6,3,'Cash',0,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(7,3,'Cheque',0,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(8,3,'PayPal',0,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(21,7,'Bank Transfer',1,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(22,7,'Cash',0,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(23,7,'Cheque',0,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(24,7,'PayPal',0,'2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `salary_payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_slips`
--

DROP TABLE IF EXISTS `salary_slips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_slips` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `currency_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `salary_group_id` bigint(20) unsigned DEFAULT NULL,
  `basic_salary` varchar(191) NOT NULL DEFAULT '0',
  `net_salary` varchar(191) NOT NULL DEFAULT '0',
  `month` varchar(191) NOT NULL,
  `year` varchar(191) NOT NULL,
  `paid_on` date DEFAULT NULL,
  `status` enum('generated','review','locked','paid') NOT NULL DEFAULT 'generated',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `salary_json` text DEFAULT NULL,
  `extra_json` text DEFAULT NULL,
  `expense_claims` varchar(191) NOT NULL DEFAULT '0',
  `pay_days` int(11) NOT NULL,
  `salary_payment_method_id` bigint(20) unsigned DEFAULT NULL,
  `tds` double(16,2) NOT NULL,
  `monthly_salary` double(16,2) NOT NULL,
  `gross_salary` double(16,2) NOT NULL,
  `total_deductions` double(16,2) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `salary_from` datetime DEFAULT NULL,
  `salary_to` datetime DEFAULT NULL,
  `payroll_cycle_id` bigint(20) unsigned DEFAULT NULL,
  `fixed_allowance` double NOT NULL DEFAULT 0,
  `expenses_created` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `salary_slips_user_id_foreign` (`user_id`),
  KEY `salary_slips_salary_group_id_foreign` (`salary_group_id`),
  KEY `salary_slips_salary_payment_method_id_foreign` (`salary_payment_method_id`),
  KEY `salary_slips_added_by_foreign` (`added_by`),
  KEY `salary_slips_last_updated_by_foreign` (`last_updated_by`),
  KEY `salary_slips_payroll_cycle_id_foreign` (`payroll_cycle_id`),
  KEY `salary_slips_company_id_foreign` (`company_id`),
  KEY `salary_slips_currency_id_foreign` (`currency_id`),
  CONSTRAINT `salary_slips_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `salary_slips_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `salary_slips_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `salary_slips_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `salary_slips_payroll_cycle_id_foreign` FOREIGN KEY (`payroll_cycle_id`) REFERENCES `payroll_cycles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `salary_slips_salary_group_id_foreign` FOREIGN KEY (`salary_group_id`) REFERENCES `salary_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `salary_slips_salary_payment_method_id_foreign` FOREIGN KEY (`salary_payment_method_id`) REFERENCES `salary_payment_methods` (`id`) ON DELETE SET NULL,
  CONSTRAINT `salary_slips_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_slips`
--

LOCK TABLES `salary_slips` WRITE;
/*!40000 ALTER TABLE `salary_slips` DISABLE KEYS */;
INSERT INTO `salary_slips` VALUES (1,1,1,2,NULL,'20.83','42','8','2023',NULL,'generated','2023-08-21 05:46:32','2023-08-21 05:46:32','{\"earnings\":[],\"deductions\":[]}',NULL,'0',31,NULL,0.00,41.67,41.67,0.00,2,NULL,'2023-08-01 00:00:00','2023-08-31 00:00:00',1,0,0),(2,1,1,4,NULL,'20.83','42','8','2023',NULL,'generated','2023-08-21 05:46:32','2023-08-21 05:46:32','{\"earnings\":[],\"deductions\":[]}',NULL,'0',31,NULL,0.00,41.67,41.67,0.00,2,NULL,'2023-08-01 00:00:00','2023-08-31 00:00:00',1,0,0);
/*!40000 ALTER TABLE `salary_slips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salary_tds`
--

DROP TABLE IF EXISTS `salary_tds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_tds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `salary_from` double(16,2) NOT NULL,
  `salary_to` double(16,2) NOT NULL,
  `salary_percent` double(5,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salary_tds_company_id_foreign` (`company_id`),
  CONSTRAINT `salary_tds_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salary_tds`
--

LOCK TABLES `salary_tds` WRITE;
/*!40000 ALTER TABLE `salary_tds` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_tds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_details`
--

DROP TABLE IF EXISTS `seo_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page_name` varchar(191) NOT NULL,
  `seo_title` varchar(191) DEFAULT NULL,
  `seo_keywords` text DEFAULT NULL,
  `seo_description` varchar(191) DEFAULT NULL,
  `seo_author` varchar(191) DEFAULT NULL,
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `og_image` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_details_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `seo_details_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_details`
--

LOCK TABLES `seo_details` WRITE;
/*!40000 ALTER TABLE `seo_details` DISABLE KEYS */;
INSERT INTO `seo_details` VALUES (1,'home','Home','best crm,hr management software, web hr software, hr software online, free hr software, hr software for sme, hr management software for small business, cloud hr software, online hr management software','Worksuite saas is easy to use CRM software that is designed for B2B. It include  everything you need to run your businesses. like manage customers, projects, invoices, estimates, timelogs, co','Worksuite',1,NULL,NULL,NULL),(2,'feature','Features','best crm,hr management software, web hr software, hr software online, free hr software, hr software for sme, hr management software for small business, cloud hr software, online hr management software','Worksuite saas is easy to use CRM software that is designed for B2B. It include  everything you need to run your businesses. like manage customers, projects, invoices, estimates, timelogs, co','Worksuite',1,NULL,NULL,NULL),(3,'pricing','Pricing','best crm,hr management software, web hr software, hr software online, free hr software, hr software for sme, hr management software for small business, cloud hr software, online hr management software','Worksuite saas is easy to use CRM software that is designed for B2B. It include  everything you need to run your businesses. like manage customers, projects, invoices, estimates, timelogs, co','Worksuite',1,NULL,NULL,NULL),(4,'contact','Contact','best crm,hr management software, web hr software, hr software online, free hr software, hr software for sme, hr management software for small business, cloud hr software, online hr management software','Worksuite saas is easy to use CRM software that is designed for B2B. It include  everything you need to run your businesses. like manage customers, projects, invoices, estimates, timelogs, co','Worksuite',1,NULL,NULL,NULL),(5,'terms-of-use','Terms of use','best crm,hr management software, web hr software, hr software online, free hr software, hr software for sme, hr management software for small business, cloud hr software, online hr management software','Worksuite saas is easy to use CRM software that is designed for B2B. It include  everything you need to run your businesses. like manage customers, projects, invoices, estimates, timelogs, co','Worksuite',1,NULL,NULL,NULL),(6,'privacy-policy','Privacy Policy','best crm,hr management software, web hr software, hr software online, free hr software, hr software for sme, hr management software for small business, cloud hr software, online hr management software','Worksuite saas is easy to use CRM software that is designed for B2B. It include  everything you need to run your businesses. like manage customers, projects, invoices, estimates, timelogs, co','Worksuite',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `seo_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` mediumtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sign_up_settings`
--

DROP TABLE IF EXISTS `sign_up_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sign_up_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sign_up_settings_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `sign_up_settings_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sign_up_settings`
--

LOCK TABLES `sign_up_settings` WRITE;
/*!40000 ALTER TABLE `sign_up_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `sign_up_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skills`
--

DROP TABLE IF EXISTS `skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `skills_company_id_foreign` (`company_id`),
  CONSTRAINT `skills_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skills`
--

LOCK TABLES `skills` WRITE;
/*!40000 ALTER TABLE `skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slack_settings`
--

DROP TABLE IF EXISTS `slack_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slack_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `slack_webhook` text DEFAULT NULL,
  `slack_logo` varchar(191) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slack_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `slack_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slack_settings`
--

LOCK TABLES `slack_settings` WRITE;
/*!40000 ALTER TABLE `slack_settings` DISABLE KEYS */;
INSERT INTO `slack_settings` VALUES (1,1,NULL,NULL,'inactive','2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,NULL,NULL,'inactive','2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,NULL,NULL,'inactive','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `slack_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `smtp_settings`
--

DROP TABLE IF EXISTS `smtp_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `smtp_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mail_driver` varchar(191) NOT NULL DEFAULT 'smtp',
  `mail_host` varchar(191) NOT NULL DEFAULT 'smtp.gmail.com',
  `mail_port` varchar(191) NOT NULL DEFAULT '587',
  `mail_username` varchar(191) NOT NULL DEFAULT 'youremail@gmail.com',
  `mail_password` varchar(191) NOT NULL DEFAULT 'your password',
  `mail_from_name` varchar(191) NOT NULL DEFAULT 'your name',
  `mail_from_email` varchar(191) NOT NULL DEFAULT 'from@email.com',
  `mail_encryption` enum('ssl','tls','starttls') DEFAULT 'tls',
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `mail_connection` enum('sync','database') NOT NULL DEFAULT 'sync',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smtp_settings`
--

LOCK TABLES `smtp_settings` WRITE;
/*!40000 ALTER TABLE `smtp_settings` DISABLE KEYS */;
INSERT INTO `smtp_settings` VALUES (1,'smtp','smtp-mail.outlook.com','587','no-reply@ibfim.com','EAU@2022','Smartkerja','no-reply@ibfim.com','starttls',1,'database','2023-08-10 14:06:55','2024-07-14 16:11:38');
/*!40000 ALTER TABLE `smtp_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_auth_settings`
--

DROP TABLE IF EXISTS `social_auth_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `social_auth_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `facebook_client_id` varchar(191) DEFAULT NULL,
  `facebook_secret_id` varchar(191) DEFAULT NULL,
  `facebook_status` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `google_client_id` varchar(191) DEFAULT NULL,
  `google_secret_id` varchar(191) DEFAULT NULL,
  `google_status` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `twitter_client_id` varchar(191) DEFAULT NULL,
  `twitter_secret_id` varchar(191) DEFAULT NULL,
  `twitter_status` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `linkedin_client_id` varchar(191) DEFAULT NULL,
  `linkedin_secret_id` varchar(191) DEFAULT NULL,
  `linkedin_status` enum('enable','disable') NOT NULL DEFAULT 'disable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_auth_settings`
--

LOCK TABLES `social_auth_settings` WRITE;
/*!40000 ALTER TABLE `social_auth_settings` DISABLE KEYS */;
INSERT INTO `social_auth_settings` VALUES (1,NULL,NULL,'disable',NULL,NULL,'disable',NULL,NULL,'disable',NULL,NULL,'disable','2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `social_auth_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `socials`
--

DROP TABLE IF EXISTS `socials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `socials` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `social_id` text NOT NULL,
  `social_service` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `socials`
--

LOCK TABLES `socials` WRITE;
/*!40000 ALTER TABLE `socials` DISABLE KEYS */;
/*!40000 ALTER TABLE `socials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sticky_notes`
--

DROP TABLE IF EXISTS `sticky_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sticky_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `note_text` mediumtext NOT NULL,
  `colour` enum('blue','yellow','red','gray','purple','green') NOT NULL DEFAULT 'blue',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sticky_notes_company_id_foreign` (`company_id`),
  KEY `sticky_notes_user_id_foreign` (`user_id`),
  CONSTRAINT `sticky_notes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sticky_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sticky_notes`
--

LOCK TABLES `sticky_notes` WRITE;
/*!40000 ALTER TABLE `sticky_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `sticky_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_invoices`
--

DROP TABLE IF EXISTS `stripe_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `invoice_id` varchar(191) DEFAULT NULL,
  `package_id` bigint(20) unsigned NOT NULL,
  `transaction_id` varchar(191) DEFAULT NULL,
  `amount` decimal(12,2) unsigned NOT NULL,
  `pay_date` date NOT NULL,
  `next_pay_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stripe_invoices_company_id_foreign` (`company_id`),
  KEY `stripe_invoices_package_id_foreign` (`package_id`),
  CONSTRAINT `stripe_invoices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `stripe_invoices_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_invoices`
--

LOCK TABLES `stripe_invoices` WRITE;
/*!40000 ALTER TABLE `stripe_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_setting`
--

DROP TABLE IF EXISTS `stripe_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `api_key` varchar(191) DEFAULT NULL,
  `api_secret` varchar(191) DEFAULT NULL,
  `webhook_key` varchar(191) DEFAULT NULL,
  `paypal_client_id` varchar(191) DEFAULT NULL,
  `paypal_secret` varchar(191) DEFAULT NULL,
  `paypal_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `stripe_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `razorpay_key` varchar(191) DEFAULT NULL,
  `razorpay_secret` varchar(191) DEFAULT NULL,
  `razorpay_webhook_secret` varchar(191) DEFAULT NULL,
  `razorpay_status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `paypal_mode` enum('sandbox','live') NOT NULL,
  `paystack_client_id` varchar(191) DEFAULT NULL,
  `paystack_secret` varchar(191) DEFAULT NULL,
  `paystack_status` enum('active','inactive') DEFAULT 'inactive',
  `paystack_merchant_email` varchar(191) DEFAULT NULL,
  `paystack_payment_url` varchar(191) DEFAULT 'https://api.paystack.co',
  `mollie_api_key` varchar(191) NOT NULL,
  `mollie_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `authorize_api_login_id` varchar(191) DEFAULT NULL,
  `authorize_transaction_key` varchar(191) DEFAULT NULL,
  `authorize_signature_key` varchar(191) DEFAULT NULL,
  `authorize_environment` varchar(191) DEFAULT NULL,
  `authorize_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `payfast_key` varchar(191) DEFAULT NULL,
  `payfast_secret` varchar(191) DEFAULT NULL,
  `payfast_status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `payfast_salt_passphrase` varchar(191) DEFAULT NULL,
  `payfast_mode` enum('sandbox','live') NOT NULL DEFAULT 'sandbox',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_setting`
--

LOCK TABLES `stripe_setting` WRITE;
/*!40000 ALTER TABLE `stripe_setting` DISABLE KEYS */;
INSERT INTO `stripe_setting` VALUES (1,NULL,NULL,NULL,NULL,NULL,'inactive','inactive',NULL,NULL,NULL,'deactive','sandbox',NULL,NULL,'inactive',NULL,'https://api.paystack.co','','inactive',NULL,NULL,NULL,NULL,'inactive',NULL,NULL,'inactive',NULL,'sandbox','2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `stripe_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_task_files`
--

DROP TABLE IF EXISTS `sub_task_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_task_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `sub_task_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_task_files_user_id_foreign` (`user_id`),
  KEY `sub_task_files_sub_task_id_foreign` (`sub_task_id`),
  CONSTRAINT `sub_task_files_sub_task_id_foreign` FOREIGN KEY (`sub_task_id`) REFERENCES `sub_tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sub_task_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_task_files`
--

LOCK TABLES `sub_task_files` WRITE;
/*!40000 ALTER TABLE `sub_task_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `sub_task_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_tasks`
--

DROP TABLE IF EXISTS `sub_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `title` text NOT NULL,
  `due_date` datetime DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `status` enum('incomplete','complete') NOT NULL DEFAULT 'incomplete',
  `assigned_to` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_tasks_task_id_foreign` (`task_id`),
  KEY `sub_tasks_assigned_to_foreign` (`assigned_to`),
  KEY `sub_tasks_added_by_foreign` (`added_by`),
  KEY `sub_tasks_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `sub_tasks_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sub_tasks_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sub_tasks_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sub_tasks_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_tasks`
--

LOCK TABLES `sub_tasks` WRITE;
/*!40000 ALTER TABLE `sub_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `sub_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_items`
--

DROP TABLE IF EXISTS `subscription_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint(20) unsigned NOT NULL,
  `stripe_id` varchar(191) NOT NULL,
  `stripe_product` varchar(191) NOT NULL,
  `stripe_price` varchar(191) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscription_items_subscription_id_stripe_price_unique` (`subscription_id`,`stripe_price`),
  UNIQUE KEY `subscription_items_stripe_id_unique` (`stripe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_items`
--

LOCK TABLES `subscription_items` WRITE;
/*!40000 ALTER TABLE `subscription_items` DISABLE KEYS */;
INSERT INTO `subscription_items` VALUES (2,1,'si_OQc2sedIOSFeGz','prod_OQc1rQxInwiIoy','price_1Ndkn7CC83aJafql1dMH3QqC',1,'2023-08-11 02:10:35','2023-08-11 02:10:35');
/*!40000 ALTER TABLE `subscription_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `stripe_id` varchar(191) NOT NULL,
  `stripe_status` varchar(191) NOT NULL,
  `stripe_price` varchar(191) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscriptions_stripe_id_unique` (`stripe_id`),
  KEY `subscriptions_company_id_foreign` (`company_id`),
  KEY `subscriptions_user_id_stripe_status_index` (`user_id`,`stripe_status`),
  CONSTRAINT `subscriptions_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,3,NULL,'primary','sub_1NdkhJCC83aJafqlY5EX45mC','active','price_1Ndkn7CC83aJafql1dMH3QqC',1,NULL,NULL,'2023-08-11 02:03:29','2023-08-11 02:10:35');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_ticket_files`
--

DROP TABLE IF EXISTS `support_ticket_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `support_ticket_reply_id` bigint(20) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_ticket_files_user_id_foreign` (`user_id`),
  KEY `support_ticket_files_support_ticket_reply_id_foreign` (`support_ticket_reply_id`),
  CONSTRAINT `support_ticket_files_support_ticket_reply_id_foreign` FOREIGN KEY (`support_ticket_reply_id`) REFERENCES `support_ticket_replies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `support_ticket_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_files`
--

LOCK TABLES `support_ticket_files` WRITE;
/*!40000 ALTER TABLE `support_ticket_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_ticket_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_ticket_replies`
--

DROP TABLE IF EXISTS `support_ticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_replies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `support_ticket_id` bigint(20) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message` longtext NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_ticket_replies_support_ticket_id_foreign` (`support_ticket_id`),
  KEY `support_ticket_replies_user_id_foreign` (`user_id`),
  CONSTRAINT `support_ticket_replies_support_ticket_id_foreign` FOREIGN KEY (`support_ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `support_ticket_replies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_replies`
--

LOCK TABLES `support_ticket_replies` WRITE;
/*!40000 ALTER TABLE `support_ticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_ticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_ticket_types`
--

DROP TABLE IF EXISTS `support_ticket_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `support_ticket_types_type_unique` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_ticket_types`
--

LOCK TABLES `support_ticket_types` WRITE;
/*!40000 ALTER TABLE `support_ticket_types` DISABLE KEYS */;
INSERT INTO `support_ticket_types` VALUES (1,'Question',NULL,NULL),(2,'Problem',NULL,NULL),(3,'General Query',NULL,NULL);
/*!40000 ALTER TABLE `support_ticket_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `subject` text NOT NULL,
  `description` longtext NOT NULL,
  `status` enum('open','pending','resolved','closed') NOT NULL DEFAULT 'open',
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `agent_id` int(10) unsigned DEFAULT NULL,
  `support_ticket_type_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `support_tickets_company_id_foreign` (`company_id`),
  KEY `support_tickets_user_id_foreign` (`user_id`),
  KEY `support_tickets_created_by_foreign` (`created_by`),
  KEY `support_tickets_agent_id_foreign` (`agent_id`),
  KEY `support_tickets_support_ticket_type_id_foreign` (`support_ticket_type_id`),
  CONSTRAINT `support_tickets_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `support_tickets_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `support_tickets_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `support_tickets_support_ticket_type_id_foreign` FOREIGN KEY (`support_ticket_type_id`) REFERENCES `support_ticket_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `support_tickets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_category`
--

DROP TABLE IF EXISTS `task_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `category_name` varchar(191) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_category_company_id_foreign` (`company_id`),
  KEY `task_category_added_by_foreign` (`added_by`),
  KEY `task_category_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `task_category_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `task_category_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_category_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_category`
--

LOCK TABLES `task_category` WRITE;
/*!40000 ALTER TABLE `task_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_comment_emoji`
--

DROP TABLE IF EXISTS `task_comment_emoji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_comment_emoji` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `comment_id` int(10) unsigned DEFAULT NULL,
  `emoji_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_comment_emoji_user_id_foreign` (`user_id`),
  KEY `task_comment_emoji_comment_id_foreign` (`comment_id`),
  CONSTRAINT `task_comment_emoji_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `task_comments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_comment_emoji_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_comment_emoji`
--

LOCK TABLES `task_comment_emoji` WRITE;
/*!40000 ALTER TABLE `task_comment_emoji` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_comment_emoji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_comments`
--

DROP TABLE IF EXISTS `task_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comment` text NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_comments_user_id_foreign` (`user_id`),
  KEY `task_comments_task_id_foreign` (`task_id`),
  KEY `task_comments_added_by_foreign` (`added_by`),
  KEY `task_comments_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `task_comments_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `task_comments_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `task_comments_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_comments`
--

LOCK TABLES `task_comments` WRITE;
/*!40000 ALTER TABLE `task_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_files`
--

DROP TABLE IF EXISTS `task_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_files_user_id_foreign` (`user_id`),
  KEY `task_files_task_id_foreign` (`task_id`),
  KEY `task_files_added_by_foreign` (`added_by`),
  KEY `task_files_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `task_files_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `task_files_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `task_files_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_files`
--

LOCK TABLES `task_files` WRITE;
/*!40000 ALTER TABLE `task_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_history`
--

DROP TABLE IF EXISTS `task_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `sub_task_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `details` text NOT NULL,
  `board_column_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_history_task_id_foreign` (`task_id`),
  KEY `task_history_sub_task_id_foreign` (`sub_task_id`),
  KEY `task_history_user_id_foreign` (`user_id`),
  KEY `task_history_board_column_id_foreign` (`board_column_id`),
  CONSTRAINT `task_history_board_column_id_foreign` FOREIGN KEY (`board_column_id`) REFERENCES `taskboard_columns` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `task_history_sub_task_id_foreign` FOREIGN KEY (`sub_task_id`) REFERENCES `sub_tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_history_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_history`
--

LOCK TABLES `task_history` WRITE;
/*!40000 ALTER TABLE `task_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_label_list`
--

DROP TABLE IF EXISTS `task_label_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_label_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `label_name` varchar(191) NOT NULL,
  `color` varchar(191) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_label_list_company_id_foreign` (`company_id`),
  KEY `task_label_list_project_id_foreign` (`project_id`),
  CONSTRAINT `task_label_list_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_label_list_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_label_list`
--

LOCK TABLES `task_label_list` WRITE;
/*!40000 ALTER TABLE `task_label_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_label_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_labels`
--

DROP TABLE IF EXISTS `task_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_labels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_labels_label_id_foreign` (`label_id`),
  KEY `task_tags_task_id_foreign` (`task_id`),
  CONSTRAINT `task_labels_label_id_foreign` FOREIGN KEY (`label_id`) REFERENCES `task_label_list` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_tags_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_labels`
--

LOCK TABLES `task_labels` WRITE;
/*!40000 ALTER TABLE `task_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_notes`
--

DROP TABLE IF EXISTS `task_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_notes_task_id_foreign` (`task_id`),
  KEY `task_notes_added_by_foreign` (`added_by`),
  KEY `task_notes_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `task_notes_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `task_notes_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `task_notes_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_notes`
--

LOCK TABLES `task_notes` WRITE;
/*!40000 ALTER TABLE `task_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_settings`
--

DROP TABLE IF EXISTS `task_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `task_category` enum('yes','no') NOT NULL DEFAULT 'yes',
  `project` enum('yes','no') NOT NULL DEFAULT 'yes',
  `start_date` enum('yes','no') NOT NULL DEFAULT 'yes',
  `due_date` enum('yes','no') NOT NULL DEFAULT 'yes',
  `assigned_to` enum('yes','no') NOT NULL DEFAULT 'yes',
  `assigned_by` enum('yes','no') NOT NULL DEFAULT 'yes',
  `description` enum('yes','no') NOT NULL DEFAULT 'yes',
  `label` enum('yes','no') NOT NULL DEFAULT 'yes',
  `status` enum('yes','no') NOT NULL DEFAULT 'yes',
  `priority` enum('yes','no') NOT NULL DEFAULT 'yes',
  `make_private` enum('yes','no') NOT NULL DEFAULT 'yes',
  `time_estimate` enum('yes','no') NOT NULL DEFAULT 'yes',
  `hours_logged` enum('yes','no') NOT NULL DEFAULT 'yes',
  `custom_fields` enum('yes','no') NOT NULL DEFAULT 'yes',
  `copy_task_link` enum('yes','no') NOT NULL DEFAULT 'yes',
  `files` enum('yes','no') NOT NULL DEFAULT 'yes',
  `sub_task` enum('yes','no') NOT NULL DEFAULT 'yes',
  `comments` enum('yes','no') NOT NULL DEFAULT 'yes',
  `time_logs` enum('yes','no') NOT NULL DEFAULT 'yes',
  `notes` enum('yes','no') NOT NULL DEFAULT 'yes',
  `history` enum('yes','no') NOT NULL DEFAULT 'yes',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `task_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_settings`
--

LOCK TABLES `task_settings` WRITE;
/*!40000 ALTER TABLE `task_settings` DISABLE KEYS */;
INSERT INTO `task_settings` VALUES (1,1,'yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,'yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,'yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','yes','2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `task_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_users`
--

DROP TABLE IF EXISTS `task_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_users_task_id_foreign` (`task_id`),
  KEY `task_users_user_id_foreign` (`user_id`),
  CONSTRAINT `task_users_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `task_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_users`
--

LOCK TABLES `task_users` WRITE;
/*!40000 ALTER TABLE `task_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taskboard_columns`
--

DROP TABLE IF EXISTS `taskboard_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taskboard_columns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `column_name` varchar(191) NOT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `label_color` varchar(191) NOT NULL,
  `priority` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `taskboard_columns_column_name_company_id_unique` (`column_name`,`company_id`),
  KEY `taskboard_columns_company_id_foreign` (`company_id`),
  CONSTRAINT `taskboard_columns_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taskboard_columns`
--

LOCK TABLES `taskboard_columns` WRITE;
/*!40000 ALTER TABLE `taskboard_columns` DISABLE KEYS */;
INSERT INTO `taskboard_columns` VALUES (1,1,'Incomplete','incomplete','#d21010',1,NULL,NULL),(2,1,'To Do','to_do','#f5c308',2,NULL,NULL),(3,1,'Doing','doing','#00b5ff',3,NULL,NULL),(4,1,'Completed','completed','#679c0d',4,NULL,NULL),(9,3,'Incomplete','incomplete','#d21010',1,NULL,NULL),(10,3,'To Do','to_do','#f5c308',2,NULL,NULL),(11,3,'Doing','doing','#00b5ff',3,NULL,NULL),(12,3,'Completed','completed','#679c0d',4,NULL,NULL),(25,7,'Incomplete','incomplete','#d21010',1,NULL,NULL),(26,7,'To Do','to_do','#f5c308',2,NULL,NULL),(27,7,'Doing','doing','#00b5ff',3,NULL,NULL),(28,7,'Completed','completed','#679c0d',4,NULL,NULL);
/*!40000 ALTER TABLE `taskboard_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_short_code` varchar(191) DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `heading` varchar(191) NOT NULL,
  `description` longtext DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `project_id` int(10) unsigned DEFAULT NULL,
  `task_category_id` int(10) unsigned DEFAULT NULL,
  `priority` enum('low','medium','high') NOT NULL DEFAULT 'medium',
  `status` enum('incomplete','completed') NOT NULL DEFAULT 'incomplete',
  `board_column_id` int(10) unsigned DEFAULT 1,
  `column_priority` int(11) NOT NULL,
  `completed_on` datetime DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `recurring_task_id` int(10) unsigned DEFAULT NULL,
  `dependent_task_id` int(10) unsigned DEFAULT NULL,
  `milestone_id` int(10) unsigned DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_hours` int(11) NOT NULL,
  `estimate_minutes` int(11) NOT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `hash` varchar(64) DEFAULT NULL,
  `repeat` tinyint(1) NOT NULL DEFAULT 0,
  `repeat_complete` tinyint(1) NOT NULL DEFAULT 0,
  `repeat_count` int(11) DEFAULT NULL,
  `repeat_type` enum('day','week','month','year') NOT NULL DEFAULT 'day',
  `repeat_cycles` int(11) DEFAULT NULL,
  `event_id` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tasks_company_id_foreign` (`company_id`),
  KEY `tasks_due_date_index` (`due_date`),
  KEY `tasks_project_id_foreign` (`project_id`),
  KEY `tasks_task_category_id_foreign` (`task_category_id`),
  KEY `tasks_board_column_id_foreign` (`board_column_id`),
  KEY `tasks_created_by_foreign` (`created_by`),
  KEY `tasks_recurring_task_id_foreign` (`recurring_task_id`),
  KEY `tasks_dependent_task_id_foreign` (`dependent_task_id`),
  KEY `tasks_milestone_id_foreign` (`milestone_id`),
  KEY `tasks_added_by_foreign` (`added_by`),
  KEY `tasks_last_updated_by_foreign` (`last_updated_by`),
  KEY `tasks_deleted_at_index` (`deleted_at`),
  CONSTRAINT `tasks_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tasks_board_column_id_foreign` FOREIGN KEY (`board_column_id`) REFERENCES `taskboard_columns` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tasks_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tasks_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tasks_dependent_task_id_foreign` FOREIGN KEY (`dependent_task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tasks_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tasks_milestone_id_foreign` FOREIGN KEY (`milestone_id`) REFERENCES `project_milestones` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tasks_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tasks_recurring_task_id_foreign` FOREIGN KEY (`recurring_task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tasks_task_category_id_foreign` FOREIGN KEY (`task_category_id`) REFERENCES `task_category` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `tax_name` varchar(191) NOT NULL,
  `rate_percent` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taxes_company_id_foreign` (`company_id`),
  CONSTRAINT `taxes_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxes`
--

LOCK TABLES `taxes` WRITE;
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `team_name` varchar(191) NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teams_company_id_foreign` (`company_id`),
  KEY `teams_added_by_foreign` (`added_by`),
  KEY `teams_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `teams_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `teams_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `teams_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,1,'Operation',NULL,NULL,NULL,'2023-08-21 05:44:21','2023-08-21 05:44:21');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testimonials`
--

DROP TABLE IF EXISTS `testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testimonials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `comment` text DEFAULT NULL,
  `rating` double(8,2) DEFAULT NULL,
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `testimonials_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `testimonials_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimonials`
--

LOCK TABLES `testimonials` WRITE;
/*!40000 ALTER TABLE `testimonials` DISABLE KEYS */;
INSERT INTO `testimonials` VALUES (1,'theon salvatore','The application is user-friendly and has made my work easier.',5.00,1,NULL,NULL),(2,'jenna gilbert','The application is efficient and has improved my productivity.',4.00,1,NULL,NULL),(3,'Redh gilbert','The application has a good design and is easy to navigate.',3.00,1,NULL,NULL),(4,'whatson angela','The application has made my life much easier by automating my tasks.',2.00,1,NULL,NULL),(5,'Megan Lee','I was skeptical at first, but after using the application for a few weeks, I\'m sold! It\'s incredibly intuitive and user-friendly.',5.00,1,NULL,NULL),(6,'Jacob Thompson','I\'ve tried a lot of productivity tools, but this one stands out. It has all the features I need and none of the clutter.',4.00,1,NULL,NULL),(7,'Maria Rodriguez','As a small business owner, this application has been a game-changer. It saves me so much time and keeps me organized.',5.00,1,NULL,NULL),(8,'Samantha Patel','I appreciate the attention to detail in the design of this application. It\'s clear that the developers put a lot of thought into the user experience.',4.00,1,NULL,NULL),(9,'Ethan Kim','Overall, I\'m happy with the application. It\'s not perfect, but it gets the job done.',3.00,1,NULL,NULL);
/*!40000 ALTER TABLE `testimonials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_settings`
--

DROP TABLE IF EXISTS `theme_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `theme_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `panel` varchar(191) NOT NULL,
  `header_color` varchar(191) NOT NULL,
  `sidebar_color` varchar(191) NOT NULL,
  `sidebar_text_color` varchar(191) NOT NULL,
  `link_color` varchar(191) NOT NULL DEFAULT '#ffffff',
  `user_css` longtext DEFAULT NULL,
  `sidebar_theme` enum('dark','light') NOT NULL DEFAULT 'dark',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `enable_rounded_theme` tinyint(1) NOT NULL DEFAULT 0,
  `login_background` varchar(191) DEFAULT NULL,
  `restrict_admin_theme_change` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `theme_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `theme_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_settings`
--

LOCK TABLES `theme_settings` WRITE;
/*!40000 ALTER TABLE `theme_settings` DISABLE KEYS */;
INSERT INTO `theme_settings` VALUES (1,NULL,'superadmin','#ED4040','#292929','#cbcbcb','#ffffff',NULL,'dark','2023-08-10 14:06:55','2024-07-14 16:11:11',0,NULL,0),(2,1,'admin','#ed4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(3,1,'project_admin','#ed4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(4,1,'employee','#ed4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(5,1,'client','#ed4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(10,3,'admin','#ed4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(11,3,'project_admin','#ed4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(12,3,'employee','#ed4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(13,3,'client','#ed4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(26,7,'admin','#ED4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(27,7,'project_admin','#ED4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(28,7,'employee','#ED4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0),(29,7,'client','#ED4040','#292929','#cbcbcb','#ffffff',NULL,'dark',NULL,'2024-07-14 16:11:11',0,NULL,0);
/*!40000 ALTER TABLE `theme_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_agent_groups`
--

DROP TABLE IF EXISTS `ticket_agent_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_agent_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `agent_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'enabled',
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_agent_groups_company_id_foreign` (`company_id`),
  KEY `ticket_agent_groups_agent_id_foreign` (`agent_id`),
  KEY `ticket_agent_groups_group_id_foreign` (`group_id`),
  KEY `ticket_agent_groups_added_by_foreign` (`added_by`),
  KEY `ticket_agent_groups_last_updated_by_foreign` (`last_updated_by`),
  CONSTRAINT `ticket_agent_groups_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ticket_agent_groups_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_agent_groups_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_agent_groups_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `ticket_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_agent_groups_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_agent_groups`
--

LOCK TABLES `ticket_agent_groups` WRITE;
/*!40000 ALTER TABLE `ticket_agent_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_agent_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_channels`
--

DROP TABLE IF EXISTS `ticket_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_channels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `channel_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_channels_channel_name_company_id_unique` (`channel_name`,`company_id`),
  KEY `ticket_channels_company_id_foreign` (`company_id`),
  CONSTRAINT `ticket_channels_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_channels`
--

LOCK TABLES `ticket_channels` WRITE;
/*!40000 ALTER TABLE `ticket_channels` DISABLE KEYS */;
INSERT INTO `ticket_channels` VALUES (1,1,'Email',NULL,NULL),(2,1,'Phone',NULL,NULL),(3,1,'Twitter',NULL,NULL),(4,1,'Facebook',NULL,NULL),(9,3,'Email',NULL,NULL),(10,3,'Phone',NULL,NULL),(11,3,'Twitter',NULL,NULL),(12,3,'Facebook',NULL,NULL),(25,7,'Email',NULL,NULL),(26,7,'Phone',NULL,NULL),(27,7,'Twitter',NULL,NULL),(28,7,'Facebook',NULL,NULL);
/*!40000 ALTER TABLE `ticket_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_custom_forms`
--

DROP TABLE IF EXISTS `ticket_custom_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_custom_forms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `custom_fields_id` int(10) unsigned DEFAULT NULL,
  `field_display_name` varchar(191) NOT NULL,
  `field_name` varchar(191) NOT NULL,
  `field_type` varchar(191) NOT NULL DEFAULT 'text',
  `field_order` int(11) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_custom_forms_company_id_foreign` (`company_id`),
  KEY `ticket_custom_forms_custom_fields_id_foreign` (`custom_fields_id`),
  CONSTRAINT `ticket_custom_forms_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_custom_forms_custom_fields_id_foreign` FOREIGN KEY (`custom_fields_id`) REFERENCES `custom_fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_custom_forms`
--

LOCK TABLES `ticket_custom_forms` WRITE;
/*!40000 ALTER TABLE `ticket_custom_forms` DISABLE KEYS */;
INSERT INTO `ticket_custom_forms` VALUES (1,1,NULL,'Name','name','text',1,'active',0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(2,1,NULL,'Email','email','text',2,'active',0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,1,NULL,'Ticket Subject','ticket_subject','text',3,'active',0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(4,1,NULL,'Ticket Description','ticket_description','textarea',4,'active',0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(5,1,NULL,'Type','type','select',5,'active',0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(6,1,NULL,'Priority','priority','select',6,'active',0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(7,1,NULL,'Assign Group','assign_group','select',7,'active',0,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(15,3,NULL,'Name','name','text',1,'active',0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(16,3,NULL,'Email','email','text',2,'active',0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(17,3,NULL,'Ticket Subject','ticket_subject','text',3,'active',0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(18,3,NULL,'Ticket Description','ticket_description','textarea',4,'active',0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(19,3,NULL,'Type','type','select',5,'active',0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(20,3,NULL,'Priority','priority','select',6,'active',0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(21,3,NULL,'Assign Group','assign_group','select',7,'active',0,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(43,7,NULL,'Name','name','text',1,'active',0,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(44,7,NULL,'Email','email','text',2,'active',0,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(45,7,NULL,'Ticket Subject','ticket_subject','text',3,'active',0,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(46,7,NULL,'Ticket Description','ticket_description','textarea',4,'active',0,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(47,7,NULL,'Type','type','select',5,'active',0,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(48,7,NULL,'Priority','priority','select',6,'active',0,'2023-08-21 16:25:19','2023-08-21 16:25:19'),(49,7,NULL,'Assign Group','assign_group','select',7,'active',0,'2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `ticket_custom_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_email_settings`
--

DROP TABLE IF EXISTS `ticket_email_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_email_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `mail_username` varchar(191) DEFAULT NULL,
  `mail_password` varchar(191) DEFAULT NULL,
  `mail_from_name` varchar(191) DEFAULT NULL,
  `mail_from_email` varchar(191) DEFAULT NULL,
  `imap_host` varchar(191) DEFAULT NULL,
  `imap_port` varchar(191) DEFAULT NULL,
  `imap_encryption` varchar(191) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `verified` tinyint(1) NOT NULL,
  `sync_interval` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_email_settings_company_id_foreign` (`company_id`),
  CONSTRAINT `ticket_email_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_email_settings`
--

LOCK TABLES `ticket_email_settings` WRITE;
/*!40000 ALTER TABLE `ticket_email_settings` DISABLE KEYS */;
INSERT INTO `ticket_email_settings` VALUES (1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,'2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `ticket_email_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_files`
--

DROP TABLE IF EXISTS `ticket_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ticket_reply_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `dropbox_link` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_files_user_id_foreign` (`user_id`),
  KEY `ticket_files_ticket_reply_id_foreign` (`ticket_reply_id`),
  CONSTRAINT `ticket_files_ticket_reply_id_foreign` FOREIGN KEY (`ticket_reply_id`) REFERENCES `ticket_replies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_files`
--

LOCK TABLES `ticket_files` WRITE;
/*!40000 ALTER TABLE `ticket_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_groups`
--

DROP TABLE IF EXISTS `ticket_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `group_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_groups_company_id_foreign` (`company_id`),
  CONSTRAINT `ticket_groups_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_groups`
--

LOCK TABLES `ticket_groups` WRITE;
/*!40000 ALTER TABLE `ticket_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_replies`
--

DROP TABLE IF EXISTS `ticket_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_replies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `imap_message_id` varchar(191) DEFAULT NULL,
  `imap_message_uid` varchar(191) DEFAULT NULL,
  `imap_in_reply_to` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_replies_ticket_id_foreign` (`ticket_id`),
  KEY `ticket_replies_user_id_foreign` (`user_id`),
  CONSTRAINT `ticket_replies_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_replies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_replies`
--

LOCK TABLES `ticket_replies` WRITE;
/*!40000 ALTER TABLE `ticket_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_reply_templates`
--

DROP TABLE IF EXISTS `ticket_reply_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_reply_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `reply_heading` mediumtext NOT NULL,
  `reply_text` mediumtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_reply_templates_company_id_foreign` (`company_id`),
  CONSTRAINT `ticket_reply_templates_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_reply_templates`
--

LOCK TABLES `ticket_reply_templates` WRITE;
/*!40000 ALTER TABLE `ticket_reply_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_reply_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_tag_list`
--

DROP TABLE IF EXISTS `ticket_tag_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_tag_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `tag_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_tag_list_company_id_foreign` (`company_id`),
  CONSTRAINT `ticket_tag_list_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_tag_list`
--

LOCK TABLES `ticket_tag_list` WRITE;
/*!40000 ALTER TABLE `ticket_tag_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_tag_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_tags`
--

DROP TABLE IF EXISTS `ticket_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `ticket_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_tags_company_id_foreign` (`company_id`),
  KEY `ticket_tags_tag_id_foreign` (`tag_id`),
  KEY `ticket_tags_ticket_id_foreign` (`ticket_id`),
  CONSTRAINT `ticket_tags_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `ticket_tag_list` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ticket_tags_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_tags`
--

LOCK TABLES `ticket_tags` WRITE;
/*!40000 ALTER TABLE `ticket_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_types`
--

DROP TABLE IF EXISTS `ticket_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_types_type_company_id_unique` (`type`,`company_id`),
  KEY `ticket_types_company_id_foreign` (`company_id`),
  CONSTRAINT `ticket_types_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_types`
--

LOCK TABLES `ticket_types` WRITE;
/*!40000 ALTER TABLE `ticket_types` DISABLE KEYS */;
INSERT INTO `ticket_types` VALUES (1,1,'Bug',NULL,NULL),(2,1,'Suggestion',NULL,NULL),(3,1,'Question',NULL,NULL),(4,1,'Sales',NULL,NULL),(5,1,'Code',NULL,NULL),(6,1,'Management',NULL,NULL),(7,1,'Problem',NULL,NULL),(8,1,'Incident',NULL,NULL),(9,1,'Feature Request',NULL,NULL),(19,3,'Bug',NULL,NULL),(20,3,'Suggestion',NULL,NULL),(21,3,'Question',NULL,NULL),(22,3,'Sales',NULL,NULL),(23,3,'Code',NULL,NULL),(24,3,'Management',NULL,NULL),(25,3,'Problem',NULL,NULL),(26,3,'Incident',NULL,NULL),(27,3,'Feature Request',NULL,NULL),(55,7,'Bug',NULL,NULL),(56,7,'Suggestion',NULL,NULL),(57,7,'Question',NULL,NULL),(58,7,'Sales',NULL,NULL),(59,7,'Code',NULL,NULL),(60,7,'Management',NULL,NULL),(61,7,'Problem',NULL,NULL),(62,7,'Incident',NULL,NULL),(63,7,'Feature Request',NULL,NULL);
/*!40000 ALTER TABLE `ticket_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_number` bigint(20) DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `subject` text NOT NULL,
  `status` enum('open','pending','resolved','closed') NOT NULL DEFAULT 'open',
  `priority` enum('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  `agent_id` int(10) unsigned DEFAULT NULL,
  `channel_id` int(10) unsigned DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `close_date` date DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `country_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `last_updated_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tickets_company_id_foreign` (`company_id`),
  KEY `tickets_user_id_foreign` (`user_id`),
  KEY `tickets_agent_id_foreign` (`agent_id`),
  KEY `tickets_channel_id_foreign` (`channel_id`),
  KEY `tickets_type_id_foreign` (`type_id`),
  KEY `tickets_country_id_foreign` (`country_id`),
  KEY `tickets_added_by_foreign` (`added_by`),
  KEY `tickets_last_updated_by_foreign` (`last_updated_by`),
  KEY `tickets_updated_at_index` (`updated_at`),
  KEY `tickets_group_id_foreign` (`group_id`),
  CONSTRAINT `tickets_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tickets_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tickets_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `ticket_channels` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tickets_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tickets_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tickets_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `ticket_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tickets_last_updated_by_foreign` FOREIGN KEY (`last_updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tickets_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `ticket_types` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tickets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tr_front_details`
--

DROP TABLE IF EXISTS `tr_front_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tr_front_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `language_setting_id` int(10) unsigned DEFAULT NULL,
  `header_title` varchar(200) NOT NULL,
  `header_description` text NOT NULL,
  `image` varchar(200) NOT NULL,
  `feature_title` varchar(191) DEFAULT NULL,
  `feature_description` varchar(191) DEFAULT NULL,
  `price_title` varchar(191) DEFAULT NULL,
  `price_description` varchar(191) DEFAULT NULL,
  `task_management_title` varchar(191) DEFAULT NULL,
  `task_management_detail` text DEFAULT NULL,
  `manage_bills_title` varchar(191) DEFAULT NULL,
  `manage_bills_detail` text DEFAULT NULL,
  `teamates_title` varchar(191) DEFAULT NULL,
  `teamates_detail` text DEFAULT NULL,
  `favourite_apps_title` varchar(191) DEFAULT NULL,
  `favourite_apps_detail` text DEFAULT NULL,
  `cta_title` varchar(191) DEFAULT NULL,
  `cta_detail` text DEFAULT NULL,
  `client_title` varchar(191) DEFAULT NULL,
  `client_detail` text DEFAULT NULL,
  `testimonial_title` varchar(191) DEFAULT NULL,
  `testimonial_detail` text DEFAULT NULL,
  `faq_title` varchar(191) DEFAULT NULL,
  `faq_detail` text DEFAULT NULL,
  `footer_copyright_text` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tr_front_details_language_setting_id_foreign` (`language_setting_id`),
  CONSTRAINT `tr_front_details_language_setting_id_foreign` FOREIGN KEY (`language_setting_id`) REFERENCES `language_settings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tr_front_details`
--

LOCK TABLES `tr_front_details` WRITE;
/*!40000 ALTER TABLE `tr_front_details` DISABLE KEYS */;
INSERT INTO `tr_front_details` VALUES (1,1,'SmartKerja - HR, CRM, and Project Management System','The simplest and most powerful way to collaborate with your team.','b90b2941691945f890f54a2a8f26fd39.png','Team Communication for the 21st Century',NULL,'Affordable Pricing','MyIBFIM for Teams is a single workspace for your small- to medium-sized company or team.','Task Management','Manage your projects and talent in one system for empowered teams, satisfied clients, and increased profitability.','Manage All Bills','Automate billing and revenue recognition to streamline the contract-to-cash cycle.',NULL,NULL,'Integrate with Favorite Apps','Our app integrates with other third-party apps for added advantage.','Easier Business Management','Our experts will show you how our app can streamline your team’s work.','Trusted by the World’s Best Teams','Over 700 people use our product.','Loved by Businesses and Individuals Worldwide',NULL,'FAQs',NULL,'Copyright MyIBFIM © 2023. All Rights Reserved','2023-08-10 14:06:56','2024-07-14 15:57:21');
/*!40000 ALTER TABLE `tr_front_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translate_settings`
--

DROP TABLE IF EXISTS `translate_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translate_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `google_key` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translate_settings`
--

LOCK TABLES `translate_settings` WRITE;
/*!40000 ALTER TABLE `translate_settings` DISABLE KEYS */;
INSERT INTO `translate_settings` VALUES (1,NULL,'2023-08-10 14:06:55','2023-08-10 14:06:55');
/*!40000 ALTER TABLE `translate_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit_types`
--

DROP TABLE IF EXISTS `unit_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unit_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `unit_type` varchar(191) NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit_types_company_id_foreign` (`company_id`),
  CONSTRAINT `unit_types_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit_types`
--

LOCK TABLES `unit_types` WRITE;
/*!40000 ALTER TABLE `unit_types` DISABLE KEYS */;
INSERT INTO `unit_types` VALUES (1,1,'Pcs',1,'2023-08-10 14:06:55','2023-08-10 14:06:55'),(3,3,'Pcs',1,'2023-08-10 14:17:22','2023-08-10 14:17:22'),(7,7,'Pcs',1,'2023-08-21 16:25:19','2023-08-21 16:25:19');
/*!40000 ALTER TABLE `unit_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `universal_search`
--

DROP TABLE IF EXISTS `universal_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `universal_search` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `searchable_id` int(11) NOT NULL,
  `module_type` enum('ticket','invoice','notice','proposal','task','creditNote','client','employee','project','estimate','lead') DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `route_name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `universal_search_company_id_foreign` (`company_id`),
  CONSTRAINT `universal_search_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `universal_search`
--

LOCK TABLES `universal_search` WRITE;
/*!40000 ALTER TABLE `universal_search` DISABLE KEYS */;
INSERT INTO `universal_search` VALUES (1,NULL,2,NULL,'Admin','employees.show','2023-08-10 14:07:33','2023-08-10 14:07:33'),(2,3,3,NULL,'Ascot Hill','employees.show','2023-08-10 14:17:29','2023-08-10 14:17:29'),(3,1,4,'employee','Ali','employees.show','2023-08-21 05:44:55','2023-08-21 05:44:55'),(4,7,8,NULL,'Admin IBFIM','employees.show','2023-08-21 16:25:20','2023-08-21 16:25:20'),(5,7,9,'client','Zulkifli','clients.show','2023-08-21 16:31:15','2023-08-21 16:31:15'),(6,7,9,'client','zkief2010@gmail.com','clients.show','2023-08-21 16:31:15','2023-08-21 16:31:15'),(7,7,1,'lead','Shahrul Nizam','leads.show','2023-08-21 16:35:21','2023-08-21 16:35:21'),(8,7,1,'lead','nafasdoa2023@gmail.com','leads.show','2023-08-21 16:35:21','2023-08-21 16:35:21'),(9,7,1,'proposal','Proposal #1','proposals.show','2023-08-21 16:35:53','2023-08-21 16:35:53');
/*!40000 ALTER TABLE `universal_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activities`
--

DROP TABLE IF EXISTS `user_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `activity` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_activities_company_id_foreign` (`company_id`),
  KEY `user_activities_user_id_foreign` (`user_id`),
  KEY `user_activities_created_at_index` (`created_at`),
  CONSTRAINT `user_activities_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activities`
--

LOCK TABLES `user_activities` WRITE;
/*!40000 ALTER TABLE `user_activities` DISABLE KEYS */;
INSERT INTO `user_activities` VALUES (1,NULL,1,'messages.updatedProfile','2023-08-21 15:49:36','2023-08-21 15:49:36'),(2,NULL,1,'messages.updatedProfile','2023-08-21 15:52:48','2023-08-21 15:52:48'),(3,7,8,'messages.updatedProfile','2024-07-14 15:48:09','2024-07-14 15:48:09'),(4,7,8,'messages.updatedProfile','2024-07-14 15:50:34','2024-07-14 15:50:34'),(5,NULL,1,'messages.updatedProfile','2024-07-14 15:56:22','2024-07-14 15:56:22'),(6,7,8,'messages.updatedProfile','2024-07-15 00:24:03','2024-07-15 00:24:03'),(7,NULL,1,'messages.updatedProfile','2024-07-15 13:24:02','2024-07-15 13:24:02');
/*!40000 ALTER TABLE `user_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_auths`
--

DROP TABLE IF EXISTS `user_auths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_auths` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(191) DEFAULT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed` tinyint(1) NOT NULL DEFAULT 0,
  `two_factor_email_confirmed` tinyint(1) NOT NULL DEFAULT 0,
  `two_fa_verify_via` enum('email','google_authenticator','both') DEFAULT NULL,
  `two_factor_code` varchar(191) DEFAULT NULL COMMENT 'when authenticator is email',
  `two_factor_expires_at` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_code` varchar(191) DEFAULT NULL,
  `email_code_expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_auths_email_unique` (`email`),
  KEY `user_auths_email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_auths`
--

LOCK TABLES `user_auths` WRITE;
/*!40000 ALTER TABLE `user_auths` DISABLE KEYS */;
INSERT INTO `user_auths` VALUES (1,'avtsventures@gmail.com','$2y$10$O4xzITFzJB/.07dStk.douQ5e1GP.8oiPNnb5efnmpZfe85k10QEK',NULL,NULL,NULL,0,0,NULL,NULL,NULL,'2023-08-10 14:07:32',NULL,NULL,'2023-08-10 14:07:32','2024-07-15 13:24:02'),(2,'admin@example.com','$2y$10$FWiD7oI0VrGitRA0sqxmwO1rP86PxFC4LtSO1lYEL2J3dYmXkHzU.',NULL,NULL,NULL,0,0,NULL,NULL,NULL,'2023-08-10 14:07:33',NULL,NULL,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(3,'ascothill21k@gmail.com','$2y$10$O4xzITFzJB/.07dStk.douQ5e1GP.8oiPNnb5efnmpZfe85k10QEK',NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,'2023-08-10 14:17:26','2023-08-10 14:17:26'),(4,'ali@mail.com','$2y$10$h7oSUEf57SV/ZfXj/I50ouu33yGs1z5Vd32G76eYtyHkEhd/XLhI2',NULL,NULL,NULL,0,0,NULL,NULL,NULL,'2023-08-21 05:44:54',NULL,NULL,'2023-08-21 05:44:54','2023-08-21 05:44:54'),(8,'sm4rtkerja@gmail.com','$2y$10$O4xzITFzJB/.07dStk.douQ5e1GP.8oiPNnb5efnmpZfe85k10QEK',NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,'2023-08-21 16:25:19','2024-07-15 00:24:03'),(9,'zkief2010@gmail.com','$2y$10$kSfj1yCepwhret3LTC5r..wtWkGS9fp0gzyOUeyUmngQFNydDV.NC',NULL,NULL,NULL,0,0,NULL,NULL,NULL,'2023-08-21 16:31:15',NULL,NULL,'2023-08-21 16:31:15','2023-08-21 16:31:15');
/*!40000 ALTER TABLE `user_auths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_invitations`
--

DROP TABLE IF EXISTS `user_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_invitations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `invitation_type` enum('email','link') NOT NULL DEFAULT 'email',
  `email` varchar(191) DEFAULT NULL,
  `invitation_code` varchar(191) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `email_restriction` varchar(191) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_invitations_company_id_foreign` (`company_id`),
  KEY `user_invitations_user_id_foreign` (`user_id`),
  CONSTRAINT `user_invitations_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_invitations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_invitations`
--

LOCK TABLES `user_invitations` WRITE;
/*!40000 ALTER TABLE `user_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_leadboard_settings`
--

DROP TABLE IF EXISTS `user_leadboard_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_leadboard_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `board_column_id` int(10) unsigned NOT NULL,
  `collapsed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_leadboard_settings_company_id_foreign` (`company_id`),
  KEY `user_leadboard_settings_user_id_foreign` (`user_id`),
  KEY `user_leadboard_settings_board_column_id_foreign` (`board_column_id`),
  CONSTRAINT `user_leadboard_settings_board_column_id_foreign` FOREIGN KEY (`board_column_id`) REFERENCES `lead_status` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `user_leadboard_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_leadboard_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_leadboard_settings`
--

LOCK TABLES `user_leadboard_settings` WRITE;
/*!40000 ALTER TABLE `user_leadboard_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_leadboard_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_permissions`
--

DROP TABLE IF EXISTS `user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  `permission_type_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_permissions_user_id_foreign` (`user_id`),
  KEY `user_permissions_permission_id_foreign` (`permission_id`),
  KEY `user_permissions_permission_type_id_foreign` (`permission_type_id`),
  CONSTRAINT `user_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_permissions_permission_type_id_foreign` FOREIGN KEY (`permission_type_id`) REFERENCES `permission_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1809 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_permissions`
--

LOCK TABLES `user_permissions` WRITE;
/*!40000 ALTER TABLE `user_permissions` DISABLE KEYS */;
INSERT INTO `user_permissions` VALUES (1,1,297,4,NULL,NULL),(2,1,298,4,NULL,NULL),(3,1,299,4,NULL,NULL),(4,1,300,4,NULL,NULL),(5,1,301,4,NULL,NULL),(6,1,302,4,NULL,NULL),(7,1,303,4,NULL,NULL),(8,1,304,4,NULL,NULL),(9,1,305,4,NULL,NULL),(10,1,306,4,NULL,NULL),(11,1,307,4,NULL,NULL),(12,1,308,4,NULL,NULL),(13,1,309,4,NULL,NULL),(14,1,310,4,NULL,NULL),(15,1,311,4,NULL,NULL),(16,1,312,4,NULL,NULL),(17,1,313,4,NULL,NULL),(18,1,314,4,NULL,NULL),(19,1,315,4,NULL,NULL),(20,1,316,4,NULL,NULL),(21,1,317,4,NULL,NULL),(22,1,318,4,NULL,NULL),(23,1,319,4,NULL,NULL),(24,1,320,4,NULL,NULL),(25,1,321,4,NULL,NULL),(26,1,322,4,NULL,NULL),(27,1,323,4,NULL,NULL),(28,1,324,4,NULL,NULL),(29,1,325,4,NULL,NULL),(30,1,326,4,NULL,NULL),(31,1,327,4,NULL,NULL),(32,1,328,4,NULL,NULL),(33,1,329,4,NULL,NULL),(34,1,330,4,NULL,NULL),(35,1,331,4,NULL,NULL),(36,1,332,4,NULL,NULL),(37,1,333,4,NULL,NULL),(38,1,334,4,NULL,NULL),(39,1,335,4,NULL,NULL),(40,1,336,4,NULL,NULL),(41,1,337,4,NULL,NULL),(42,1,338,4,NULL,NULL),(43,1,339,4,NULL,NULL),(44,1,340,4,NULL,NULL),(45,2,1,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(46,2,2,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(47,2,3,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(48,2,4,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(49,2,5,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(50,2,6,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(51,2,7,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(52,2,8,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(53,2,9,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(54,2,10,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(55,2,11,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(56,2,12,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(57,2,13,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(58,2,14,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(59,2,15,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(60,2,16,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(61,2,17,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(62,2,18,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(63,2,19,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(64,2,20,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(65,2,21,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(66,2,22,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(67,2,23,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(68,2,24,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(69,2,25,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(70,2,26,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(71,2,27,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(72,2,28,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(73,2,29,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(74,2,30,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(75,2,31,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(76,2,32,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(77,2,33,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(78,2,34,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(79,2,35,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(80,2,36,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(81,2,37,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(82,2,38,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(83,2,39,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(84,2,40,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(85,2,41,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(86,2,42,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(87,2,43,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(88,2,44,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(89,2,45,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(90,2,46,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(91,2,47,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(92,2,48,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(93,2,49,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(94,2,50,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(95,2,51,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(96,2,52,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(97,2,53,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(98,2,54,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(99,2,55,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(100,2,56,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(101,2,57,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(102,2,58,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(103,2,59,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(104,2,60,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(105,2,61,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(106,2,62,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(107,2,63,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(108,2,64,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(109,2,65,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(110,2,66,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(111,2,67,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(112,2,68,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(113,2,69,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(114,2,70,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(115,2,71,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(116,2,72,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(117,2,73,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(118,2,74,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(119,2,75,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(120,2,76,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(121,2,77,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(122,2,78,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(123,2,79,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(124,2,80,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(125,2,81,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(126,2,82,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(127,2,83,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(128,2,84,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(129,2,85,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(130,2,86,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(131,2,87,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(132,2,88,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(133,2,89,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(134,2,90,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(135,2,91,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(136,2,92,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(137,2,93,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(138,2,94,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(139,2,95,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(140,2,96,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(141,2,97,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(142,2,98,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(143,2,99,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(144,2,100,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(145,2,101,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(146,2,102,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(147,2,103,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(148,2,104,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(149,2,105,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(150,2,106,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(151,2,107,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(152,2,108,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(153,2,109,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(154,2,110,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(155,2,111,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(156,2,112,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(157,2,113,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(158,2,114,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(159,2,115,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(160,2,116,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(161,2,117,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(162,2,118,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(163,2,119,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(164,2,120,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(165,2,121,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(166,2,122,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(167,2,123,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(168,2,124,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(169,2,125,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(170,2,126,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(171,2,127,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(172,2,128,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(173,2,129,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(174,2,130,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(175,2,131,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(176,2,132,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(177,2,133,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(178,2,134,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(179,2,135,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(180,2,136,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(181,2,137,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(182,2,138,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(183,2,139,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(184,2,140,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(185,2,141,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(186,2,142,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(187,2,143,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(188,2,144,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(189,2,145,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(190,2,146,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(191,2,147,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(192,2,148,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(193,2,149,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(194,2,150,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(195,2,151,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(196,2,152,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(197,2,153,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(198,2,154,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(199,2,155,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(200,2,156,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(201,2,157,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(202,2,158,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(203,2,159,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(204,2,160,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(205,2,161,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(206,2,162,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(207,2,163,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(208,2,164,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(209,2,165,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(210,2,166,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(211,2,167,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(212,2,168,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(213,2,169,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(214,2,170,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(215,2,171,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(216,2,172,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(217,2,173,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(218,2,174,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(219,2,175,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(220,2,176,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(221,2,177,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(222,2,178,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(223,2,179,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(224,2,180,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(225,2,181,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(226,2,182,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(227,2,183,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(228,2,184,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(229,2,185,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(230,2,186,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(231,2,187,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(232,2,188,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(233,2,189,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(234,2,190,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(235,2,191,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(236,2,192,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(237,2,193,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(238,2,194,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(239,2,195,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(240,2,196,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(241,2,197,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(242,2,198,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(243,2,199,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(244,2,200,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(245,2,201,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(246,2,202,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(247,2,203,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(248,2,204,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(249,2,205,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(250,2,206,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(251,2,207,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(252,2,208,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(253,2,209,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(254,2,210,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(255,2,211,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(256,2,212,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(257,2,213,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(258,2,214,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(259,2,215,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(260,2,216,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(261,2,217,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(262,2,218,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(263,2,219,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(264,2,220,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(265,2,221,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(266,2,222,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(267,2,223,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(268,2,224,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(269,2,225,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(270,2,226,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(271,2,227,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(272,2,228,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(273,2,229,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(274,2,230,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(275,2,231,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(276,2,232,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(277,2,233,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(278,2,234,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(279,2,235,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(280,2,236,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(281,2,237,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(282,2,238,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(283,2,239,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(284,2,240,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(285,2,241,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(286,2,242,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(287,2,243,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(288,2,244,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(289,2,245,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(290,2,246,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(291,2,247,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(292,2,248,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(293,2,249,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(294,2,250,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(295,2,251,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(296,2,252,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(297,2,253,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(298,2,254,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(299,2,255,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(300,2,256,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(301,2,257,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(302,2,258,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(303,2,259,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(304,2,260,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(305,2,261,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(306,2,262,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(307,2,263,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(308,2,264,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(309,2,265,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(310,2,266,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(311,2,267,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(312,2,268,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(313,2,269,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(314,2,270,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(315,2,271,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(316,2,272,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(317,2,273,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(318,2,274,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(319,2,275,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(320,2,276,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(321,2,277,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(322,2,278,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(323,2,279,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(324,2,280,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(325,2,281,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(326,2,282,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(327,2,283,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(328,2,284,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(329,2,285,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(330,2,286,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(331,2,287,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(332,2,288,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(333,2,289,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(334,2,290,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(335,2,291,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(336,2,292,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(337,2,293,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(338,2,294,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(339,2,295,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(340,2,296,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(341,2,297,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(342,2,298,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(343,2,299,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(344,2,300,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(345,2,301,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(346,2,302,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(347,2,303,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(348,2,304,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(349,2,305,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(350,2,306,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(351,2,307,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(352,2,308,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(353,2,309,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(354,2,310,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(355,2,311,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(356,2,312,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(357,2,313,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(358,2,314,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(359,2,315,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(360,2,316,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(361,2,317,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(362,2,318,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(363,2,319,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(364,2,320,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(365,2,321,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(366,2,322,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(367,2,323,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(368,2,324,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(369,2,325,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(370,2,326,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(371,2,327,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(372,2,328,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(373,2,329,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(374,2,330,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(375,2,331,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(376,2,332,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(377,2,333,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(378,2,334,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(379,2,335,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(380,2,336,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(381,2,337,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(382,2,338,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(383,2,339,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(384,2,340,4,'2023-08-10 14:07:33','2023-08-10 14:07:33'),(385,3,1,4,NULL,NULL),(386,3,2,4,NULL,NULL),(387,3,3,4,NULL,NULL),(388,3,4,4,NULL,NULL),(389,3,5,4,NULL,NULL),(390,3,6,4,NULL,NULL),(391,3,7,4,NULL,NULL),(392,3,8,4,NULL,NULL),(393,3,9,4,NULL,NULL),(394,3,10,4,NULL,NULL),(395,3,11,4,NULL,NULL),(396,3,12,4,NULL,NULL),(397,3,13,4,NULL,NULL),(398,3,14,4,NULL,NULL),(399,3,15,4,NULL,NULL),(400,3,16,4,NULL,NULL),(401,3,17,4,NULL,NULL),(402,3,18,4,NULL,NULL),(403,3,19,4,NULL,NULL),(404,3,20,4,NULL,NULL),(405,3,21,4,NULL,NULL),(406,3,22,4,NULL,NULL),(407,3,23,4,NULL,NULL),(408,3,24,4,NULL,NULL),(409,3,25,4,NULL,NULL),(410,3,26,4,NULL,NULL),(411,3,27,4,NULL,NULL),(412,3,28,4,NULL,NULL),(413,3,29,4,NULL,NULL),(414,3,30,4,NULL,NULL),(415,3,31,4,NULL,NULL),(416,3,32,4,NULL,NULL),(417,3,33,4,NULL,NULL),(418,3,34,4,NULL,NULL),(419,3,35,4,NULL,NULL),(420,3,36,4,NULL,NULL),(421,3,37,4,NULL,NULL),(422,3,38,4,NULL,NULL),(423,3,39,4,NULL,NULL),(424,3,40,4,NULL,NULL),(425,3,41,4,NULL,NULL),(426,3,42,4,NULL,NULL),(427,3,43,4,NULL,NULL),(428,3,44,4,NULL,NULL),(429,3,45,4,NULL,NULL),(430,3,46,4,NULL,NULL),(431,3,47,4,NULL,NULL),(432,3,48,4,NULL,NULL),(433,3,49,4,NULL,NULL),(434,3,50,4,NULL,NULL),(435,3,51,4,NULL,NULL),(436,3,52,4,NULL,NULL),(437,3,53,4,NULL,NULL),(438,3,54,4,NULL,NULL),(439,3,55,4,NULL,NULL),(440,3,56,4,NULL,NULL),(441,3,57,4,NULL,NULL),(442,3,58,4,NULL,NULL),(443,3,59,4,NULL,NULL),(444,3,60,4,NULL,NULL),(445,3,61,4,NULL,NULL),(446,3,62,4,NULL,NULL),(447,3,63,4,NULL,NULL),(448,3,64,4,NULL,NULL),(449,3,65,4,NULL,NULL),(450,3,66,4,NULL,NULL),(451,3,67,4,NULL,NULL),(452,3,68,4,NULL,NULL),(453,3,69,4,NULL,NULL),(454,3,70,4,NULL,NULL),(455,3,71,4,NULL,NULL),(456,3,72,4,NULL,NULL),(457,3,73,4,NULL,NULL),(458,3,74,4,NULL,NULL),(459,3,75,4,NULL,NULL),(460,3,76,4,NULL,NULL),(461,3,77,4,NULL,NULL),(462,3,78,4,NULL,NULL),(463,3,79,4,NULL,NULL),(464,3,80,4,NULL,NULL),(465,3,81,4,NULL,NULL),(466,3,82,4,NULL,NULL),(467,3,83,4,NULL,NULL),(468,3,84,4,NULL,NULL),(469,3,85,4,NULL,NULL),(470,3,86,4,NULL,NULL),(471,3,87,4,NULL,NULL),(472,3,88,4,NULL,NULL),(473,3,89,4,NULL,NULL),(474,3,90,4,NULL,NULL),(475,3,91,4,NULL,NULL),(476,3,92,4,NULL,NULL),(477,3,93,4,NULL,NULL),(478,3,94,4,NULL,NULL),(479,3,95,4,NULL,NULL),(480,3,96,4,NULL,NULL),(481,3,97,4,NULL,NULL),(482,3,98,4,NULL,NULL),(483,3,99,4,NULL,NULL),(484,3,100,4,NULL,NULL),(485,3,101,4,NULL,NULL),(486,3,102,4,NULL,NULL),(487,3,103,4,NULL,NULL),(488,3,104,4,NULL,NULL),(489,3,105,4,NULL,NULL),(490,3,106,4,NULL,NULL),(491,3,107,4,NULL,NULL),(492,3,108,4,NULL,NULL),(493,3,109,4,NULL,NULL),(494,3,110,4,NULL,NULL),(495,3,111,4,NULL,NULL),(496,3,112,4,NULL,NULL),(497,3,113,4,NULL,NULL),(498,3,114,4,NULL,NULL),(499,3,115,4,NULL,NULL),(500,3,116,4,NULL,NULL),(501,3,117,4,NULL,NULL),(502,3,118,4,NULL,NULL),(503,3,119,4,NULL,NULL),(504,3,120,4,NULL,NULL),(505,3,121,4,NULL,NULL),(506,3,122,4,NULL,NULL),(507,3,123,4,NULL,NULL),(508,3,124,4,NULL,NULL),(509,3,125,4,NULL,NULL),(510,3,126,4,NULL,NULL),(511,3,127,4,NULL,NULL),(512,3,128,4,NULL,NULL),(513,3,129,4,NULL,NULL),(514,3,130,4,NULL,NULL),(515,3,131,4,NULL,NULL),(516,3,132,4,NULL,NULL),(517,3,133,4,NULL,NULL),(518,3,134,4,NULL,NULL),(519,3,135,4,NULL,NULL),(520,3,136,4,NULL,NULL),(521,3,137,4,NULL,NULL),(522,3,138,4,NULL,NULL),(523,3,139,4,NULL,NULL),(524,3,140,4,NULL,NULL),(525,3,141,4,NULL,NULL),(526,3,142,4,NULL,NULL),(527,3,143,4,NULL,NULL),(528,3,144,4,NULL,NULL),(529,3,145,4,NULL,NULL),(530,3,146,4,NULL,NULL),(531,3,147,4,NULL,NULL),(532,3,148,4,NULL,NULL),(533,3,149,4,NULL,NULL),(534,3,150,4,NULL,NULL),(535,3,151,4,NULL,NULL),(536,3,152,4,NULL,NULL),(537,3,153,4,NULL,NULL),(538,3,154,4,NULL,NULL),(539,3,155,4,NULL,NULL),(540,3,156,4,NULL,NULL),(541,3,157,4,NULL,NULL),(542,3,158,4,NULL,NULL),(543,3,159,4,NULL,NULL),(544,3,160,4,NULL,NULL),(545,3,161,4,NULL,NULL),(546,3,162,4,NULL,NULL),(547,3,163,4,NULL,NULL),(548,3,164,4,NULL,NULL),(549,3,165,4,NULL,NULL),(550,3,166,4,NULL,NULL),(551,3,167,4,NULL,NULL),(552,3,168,4,NULL,NULL),(553,3,169,4,NULL,NULL),(554,3,170,4,NULL,NULL),(555,3,171,4,NULL,NULL),(556,3,172,4,NULL,NULL),(557,3,173,4,NULL,NULL),(558,3,174,4,NULL,NULL),(559,3,175,4,NULL,NULL),(560,3,176,4,NULL,NULL),(561,3,177,4,NULL,NULL),(562,3,178,4,NULL,NULL),(563,3,179,4,NULL,NULL),(564,3,180,4,NULL,NULL),(565,3,181,4,NULL,NULL),(566,3,182,4,NULL,NULL),(567,3,183,4,NULL,NULL),(568,3,184,4,NULL,NULL),(569,3,185,4,NULL,NULL),(570,3,186,4,NULL,NULL),(571,3,187,4,NULL,NULL),(572,3,188,4,NULL,NULL),(573,3,189,4,NULL,NULL),(574,3,190,4,NULL,NULL),(575,3,191,4,NULL,NULL),(576,3,192,4,NULL,NULL),(577,3,193,4,NULL,NULL),(578,3,194,4,NULL,NULL),(579,3,195,4,NULL,NULL),(580,3,196,4,NULL,NULL),(581,3,197,4,NULL,NULL),(582,3,198,4,NULL,NULL),(583,3,199,4,NULL,NULL),(584,3,200,4,NULL,NULL),(585,3,201,4,NULL,NULL),(586,3,202,4,NULL,NULL),(587,3,203,4,NULL,NULL),(588,3,204,4,NULL,NULL),(589,3,205,4,NULL,NULL),(590,3,206,4,NULL,NULL),(591,3,207,4,NULL,NULL),(592,3,208,4,NULL,NULL),(593,3,209,4,NULL,NULL),(594,3,210,4,NULL,NULL),(595,3,211,4,NULL,NULL),(596,3,212,4,NULL,NULL),(597,3,213,4,NULL,NULL),(598,3,214,4,NULL,NULL),(599,3,215,4,NULL,NULL),(600,3,216,4,NULL,NULL),(601,3,217,4,NULL,NULL),(602,3,218,4,NULL,NULL),(603,3,219,4,NULL,NULL),(604,3,220,4,NULL,NULL),(605,3,221,4,NULL,NULL),(606,3,222,4,NULL,NULL),(607,3,223,4,NULL,NULL),(608,3,224,4,NULL,NULL),(609,3,225,4,NULL,NULL),(610,3,226,4,NULL,NULL),(611,3,227,4,NULL,NULL),(612,3,228,4,NULL,NULL),(613,3,229,4,NULL,NULL),(614,3,230,4,NULL,NULL),(615,3,231,4,NULL,NULL),(616,3,232,4,NULL,NULL),(617,3,233,4,NULL,NULL),(618,3,234,4,NULL,NULL),(619,3,235,4,NULL,NULL),(620,3,236,4,NULL,NULL),(621,3,237,4,NULL,NULL),(622,3,238,4,NULL,NULL),(623,3,239,4,NULL,NULL),(624,3,240,4,NULL,NULL),(625,3,241,4,NULL,NULL),(626,3,242,4,NULL,NULL),(627,3,243,4,NULL,NULL),(628,3,244,4,NULL,NULL),(629,3,245,4,NULL,NULL),(630,3,246,4,NULL,NULL),(631,3,247,4,NULL,NULL),(632,3,248,4,NULL,NULL),(633,3,249,4,NULL,NULL),(634,3,250,4,NULL,NULL),(635,3,251,4,NULL,NULL),(636,3,252,4,NULL,NULL),(637,3,253,4,NULL,NULL),(638,3,254,4,NULL,NULL),(639,3,255,4,NULL,NULL),(640,3,256,4,NULL,NULL),(641,3,257,4,NULL,NULL),(642,3,258,4,NULL,NULL),(643,3,259,4,NULL,NULL),(644,3,260,4,NULL,NULL),(645,3,261,4,NULL,NULL),(646,3,262,4,NULL,NULL),(647,3,263,4,NULL,NULL),(648,3,264,4,NULL,NULL),(649,3,265,4,NULL,NULL),(650,3,266,4,NULL,NULL),(651,3,267,4,NULL,NULL),(652,3,268,4,NULL,NULL),(653,3,269,4,NULL,NULL),(654,3,270,4,NULL,NULL),(655,3,271,4,NULL,NULL),(656,3,272,4,NULL,NULL),(657,3,273,4,NULL,NULL),(658,3,274,4,NULL,NULL),(659,3,275,4,NULL,NULL),(660,3,276,4,NULL,NULL),(661,3,277,4,NULL,NULL),(662,3,278,4,NULL,NULL),(663,3,279,4,NULL,NULL),(664,3,280,4,NULL,NULL),(665,3,281,4,NULL,NULL),(666,3,282,4,NULL,NULL),(667,3,283,4,NULL,NULL),(668,3,284,4,NULL,NULL),(669,3,285,4,NULL,NULL),(670,3,286,4,NULL,NULL),(671,3,287,4,NULL,NULL),(672,3,288,4,NULL,NULL),(673,3,289,4,NULL,NULL),(674,3,290,4,NULL,NULL),(675,3,291,4,NULL,NULL),(676,3,292,4,NULL,NULL),(677,3,293,4,NULL,NULL),(678,3,294,4,NULL,NULL),(679,3,295,4,NULL,NULL),(680,3,296,4,NULL,NULL),(681,2,341,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(682,2,342,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(683,2,343,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(684,2,344,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(685,2,345,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(686,2,346,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(687,2,347,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(688,2,348,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(689,2,349,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(690,3,341,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(691,3,342,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(692,3,343,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(693,3,344,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(694,3,345,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(695,3,346,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(696,3,347,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(697,3,348,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(698,3,349,4,'2023-08-21 05:36:56','2023-08-21 05:36:56'),(699,2,350,4,NULL,NULL),(700,2,351,4,NULL,NULL),(701,2,352,4,NULL,NULL),(702,2,353,4,NULL,NULL),(703,2,354,4,NULL,NULL),(704,2,355,4,NULL,NULL),(705,2,356,4,NULL,NULL),(706,2,357,4,NULL,NULL),(707,2,358,4,NULL,NULL),(708,2,359,4,NULL,NULL),(709,2,360,4,NULL,NULL),(710,2,361,4,NULL,NULL),(711,2,362,4,NULL,NULL),(712,2,363,4,NULL,NULL),(713,2,364,4,NULL,NULL),(714,2,365,4,NULL,NULL),(715,2,366,4,NULL,NULL),(716,2,367,4,NULL,NULL),(717,2,368,4,NULL,NULL),(718,2,369,4,NULL,NULL),(719,2,370,4,NULL,NULL),(720,2,371,4,NULL,NULL),(721,2,372,4,NULL,NULL),(722,2,373,4,NULL,NULL),(723,2,374,4,NULL,NULL),(724,2,375,4,NULL,NULL),(725,2,376,4,NULL,NULL),(726,2,377,4,NULL,NULL),(727,2,378,4,NULL,NULL),(728,2,379,4,NULL,NULL),(729,2,380,4,NULL,NULL),(730,2,381,4,NULL,NULL),(731,2,382,4,NULL,NULL),(732,2,383,4,NULL,NULL),(733,2,384,4,NULL,NULL),(734,2,385,4,NULL,NULL),(735,3,350,4,NULL,NULL),(736,3,351,4,NULL,NULL),(737,3,352,4,NULL,NULL),(738,3,353,4,NULL,NULL),(739,3,354,4,NULL,NULL),(740,3,355,4,NULL,NULL),(741,3,356,4,NULL,NULL),(742,3,357,4,NULL,NULL),(743,3,358,4,NULL,NULL),(744,3,359,4,NULL,NULL),(745,3,360,4,NULL,NULL),(746,3,361,4,NULL,NULL),(747,3,362,4,NULL,NULL),(748,3,363,4,NULL,NULL),(749,3,364,4,NULL,NULL),(750,3,365,4,NULL,NULL),(751,3,366,4,NULL,NULL),(752,3,367,4,NULL,NULL),(753,3,368,4,NULL,NULL),(754,3,369,4,NULL,NULL),(755,3,370,4,NULL,NULL),(756,3,371,4,NULL,NULL),(757,3,372,4,NULL,NULL),(758,3,373,4,NULL,NULL),(759,3,374,4,NULL,NULL),(760,3,375,4,NULL,NULL),(761,3,376,4,NULL,NULL),(762,3,377,4,NULL,NULL),(763,3,378,4,NULL,NULL),(764,3,379,4,NULL,NULL),(765,3,380,4,NULL,NULL),(766,3,381,4,NULL,NULL),(767,3,382,4,NULL,NULL),(768,3,383,4,NULL,NULL),(769,3,384,4,NULL,NULL),(770,3,385,4,NULL,NULL),(771,2,386,4,'2023-08-21 05:41:24','2023-08-21 05:41:24'),(772,2,387,4,'2023-08-21 05:41:24','2023-08-21 05:41:24'),(773,3,386,4,'2023-08-21 05:41:25','2023-08-21 05:41:25'),(774,3,387,4,'2023-08-21 05:41:25','2023-08-21 05:41:25'),(775,2,388,4,'2023-08-21 05:41:28','2023-08-21 05:41:28'),(776,3,388,4,'2023-08-21 05:41:28','2023-08-21 05:41:28'),(777,4,1,5,NULL,NULL),(778,4,2,5,NULL,NULL),(779,4,3,5,NULL,NULL),(780,4,4,5,NULL,NULL),(781,4,5,5,NULL,NULL),(782,4,6,5,NULL,NULL),(783,4,7,5,NULL,NULL),(784,4,8,5,NULL,NULL),(785,4,9,5,NULL,NULL),(786,4,10,5,NULL,NULL),(787,4,11,5,NULL,NULL),(788,4,12,5,NULL,NULL),(789,4,13,5,NULL,NULL),(790,4,14,5,NULL,NULL),(791,4,15,5,NULL,NULL),(792,4,16,5,NULL,NULL),(793,4,17,5,NULL,NULL),(794,4,18,5,NULL,NULL),(795,4,19,5,NULL,NULL),(796,4,20,5,NULL,NULL),(797,4,21,5,NULL,NULL),(798,4,22,5,NULL,NULL),(799,4,23,5,NULL,NULL),(800,4,24,5,NULL,NULL),(801,4,25,5,NULL,NULL),(802,4,26,5,NULL,NULL),(803,4,27,5,NULL,NULL),(804,4,28,5,NULL,NULL),(805,4,29,5,NULL,NULL),(806,4,30,5,NULL,NULL),(807,4,31,5,NULL,NULL),(808,4,32,5,NULL,NULL),(809,4,33,5,NULL,NULL),(810,4,34,5,NULL,NULL),(811,4,35,4,NULL,NULL),(812,4,36,5,NULL,NULL),(813,4,37,5,NULL,NULL),(814,4,38,5,NULL,NULL),(815,4,39,5,NULL,NULL),(816,4,40,5,NULL,NULL),(817,4,41,5,NULL,NULL),(818,4,42,5,NULL,NULL),(819,4,43,5,NULL,NULL),(820,4,44,2,NULL,NULL),(821,4,45,5,NULL,NULL),(822,4,46,5,NULL,NULL),(823,4,47,2,NULL,NULL),(824,4,48,2,NULL,NULL),(825,4,49,2,NULL,NULL),(826,4,50,2,NULL,NULL),(827,4,51,5,NULL,NULL),(828,4,52,2,NULL,NULL),(829,4,53,5,NULL,NULL),(830,4,54,5,NULL,NULL),(831,4,55,5,NULL,NULL),(832,4,56,4,NULL,NULL),(833,4,57,4,NULL,NULL),(834,4,58,1,NULL,NULL),(835,4,59,4,NULL,NULL),(836,4,60,4,NULL,NULL),(837,4,61,1,NULL,NULL),(838,4,62,1,NULL,NULL),(839,4,63,5,NULL,NULL),(840,4,64,5,NULL,NULL),(841,4,65,5,NULL,NULL),(842,4,66,5,NULL,NULL),(843,4,67,5,NULL,NULL),(844,4,68,4,NULL,NULL),(845,4,69,5,NULL,NULL),(846,4,70,5,NULL,NULL),(847,4,71,5,NULL,NULL),(848,4,72,5,NULL,NULL),(849,4,73,5,NULL,NULL),(850,4,74,5,NULL,NULL),(851,4,75,5,NULL,NULL),(852,4,76,5,NULL,NULL),(853,4,77,4,NULL,NULL),(854,4,78,5,NULL,NULL),(855,4,79,4,NULL,NULL),(856,4,80,5,NULL,NULL),(857,4,81,5,NULL,NULL),(858,4,82,5,NULL,NULL),(859,4,83,5,NULL,NULL),(860,4,84,5,NULL,NULL),(861,4,85,4,NULL,NULL),(862,4,86,5,NULL,NULL),(863,4,87,5,NULL,NULL),(864,4,88,5,NULL,NULL),(865,4,89,5,NULL,NULL),(866,4,90,5,NULL,NULL),(867,4,91,5,NULL,NULL),(868,4,92,5,NULL,NULL),(869,4,93,5,NULL,NULL),(870,4,94,5,NULL,NULL),(871,4,95,5,NULL,NULL),(872,4,96,2,NULL,NULL),(873,4,97,5,NULL,NULL),(874,4,98,5,NULL,NULL),(875,4,99,1,NULL,NULL),(876,4,100,3,NULL,NULL),(877,4,101,1,NULL,NULL),(878,4,102,1,NULL,NULL),(879,4,103,5,NULL,NULL),(880,4,104,5,NULL,NULL),(881,4,105,5,NULL,NULL),(882,4,106,5,NULL,NULL),(883,4,107,4,NULL,NULL),(884,4,108,4,NULL,NULL),(885,4,109,1,NULL,NULL),(886,4,110,4,NULL,NULL),(887,4,111,4,NULL,NULL),(888,4,112,1,NULL,NULL),(889,4,113,1,NULL,NULL),(890,4,114,4,NULL,NULL),(891,4,115,4,NULL,NULL),(892,4,116,1,NULL,NULL),(893,4,117,1,NULL,NULL),(894,4,118,4,NULL,NULL),(895,4,119,4,NULL,NULL),(896,4,120,1,NULL,NULL),(897,4,121,1,NULL,NULL),(898,4,122,5,NULL,NULL),(899,4,123,5,NULL,NULL),(900,4,124,5,NULL,NULL),(901,4,125,5,NULL,NULL),(902,4,126,5,NULL,NULL),(903,4,127,5,NULL,NULL),(904,4,128,5,NULL,NULL),(905,4,129,5,NULL,NULL),(906,4,130,5,NULL,NULL),(907,4,131,5,NULL,NULL),(908,4,132,5,NULL,NULL),(909,4,133,5,NULL,NULL),(910,4,134,5,NULL,NULL),(911,4,135,5,NULL,NULL),(912,4,136,5,NULL,NULL),(913,4,137,5,NULL,NULL),(914,4,138,5,NULL,NULL),(915,4,139,5,NULL,NULL),(916,4,140,5,NULL,NULL),(917,4,141,5,NULL,NULL),(918,4,142,5,NULL,NULL),(919,4,143,5,NULL,NULL),(920,4,144,1,NULL,NULL),(921,4,145,3,NULL,NULL),(922,4,146,1,NULL,NULL),(923,4,147,5,NULL,NULL),(924,4,148,5,NULL,NULL),(925,4,149,5,NULL,NULL),(926,4,150,5,NULL,NULL),(927,4,151,1,NULL,NULL),(928,4,152,3,NULL,NULL),(929,4,153,3,NULL,NULL),(930,4,154,1,NULL,NULL),(931,4,155,5,NULL,NULL),(932,4,156,5,NULL,NULL),(933,4,157,5,NULL,NULL),(934,4,158,5,NULL,NULL),(935,4,159,5,NULL,NULL),(936,4,160,5,NULL,NULL),(937,4,161,2,NULL,NULL),(938,4,162,5,NULL,NULL),(939,4,163,5,NULL,NULL),(940,4,164,5,NULL,NULL),(941,4,165,2,NULL,NULL),(942,4,166,5,NULL,NULL),(943,4,167,5,NULL,NULL),(944,4,168,1,NULL,NULL),(945,4,169,3,NULL,NULL),(946,4,170,5,NULL,NULL),(947,4,171,5,NULL,NULL),(948,4,172,5,NULL,NULL),(949,4,173,5,NULL,NULL),(950,4,174,1,NULL,NULL),(951,4,175,3,NULL,NULL),(952,4,176,1,NULL,NULL),(953,4,177,5,NULL,NULL),(954,4,178,5,NULL,NULL),(955,4,179,5,NULL,NULL),(956,4,180,5,NULL,NULL),(957,4,181,5,NULL,NULL),(958,4,182,5,NULL,NULL),(959,4,183,5,NULL,NULL),(960,4,184,5,NULL,NULL),(961,4,185,5,NULL,NULL),(962,4,186,5,NULL,NULL),(963,4,187,1,NULL,NULL),(964,4,188,4,NULL,NULL),(965,4,189,5,NULL,NULL),(966,4,190,4,NULL,NULL),(967,4,191,4,NULL,NULL),(968,4,192,1,NULL,NULL),(969,4,193,1,NULL,NULL),(970,4,194,5,NULL,NULL),(971,4,195,5,NULL,NULL),(972,4,196,5,NULL,NULL),(973,4,197,5,NULL,NULL),(974,4,198,5,NULL,NULL),(975,4,199,5,NULL,NULL),(976,4,200,5,NULL,NULL),(977,4,201,5,NULL,NULL),(978,4,202,5,NULL,NULL),(979,4,203,3,NULL,NULL),(980,4,204,5,NULL,NULL),(981,4,205,5,NULL,NULL),(982,4,206,5,NULL,NULL),(983,4,207,5,NULL,NULL),(984,4,208,5,NULL,NULL),(985,4,209,5,NULL,NULL),(986,4,210,4,NULL,NULL),(987,4,211,5,NULL,NULL),(988,4,212,5,NULL,NULL),(989,4,213,5,NULL,NULL),(990,4,214,5,NULL,NULL),(991,4,215,5,NULL,NULL),(992,4,216,5,NULL,NULL),(993,4,217,5,NULL,NULL),(994,4,218,5,NULL,NULL),(995,4,219,1,NULL,NULL),(996,4,220,3,NULL,NULL),(997,4,221,1,NULL,NULL),(998,4,222,1,NULL,NULL),(999,4,223,5,NULL,NULL),(1000,4,224,5,NULL,NULL),(1001,4,225,5,NULL,NULL),(1002,4,226,5,NULL,NULL),(1003,4,227,5,NULL,NULL),(1004,4,228,5,NULL,NULL),(1005,4,229,5,NULL,NULL),(1006,4,230,5,NULL,NULL),(1007,4,231,5,NULL,NULL),(1008,4,232,5,NULL,NULL),(1009,4,233,5,NULL,NULL),(1010,4,234,5,NULL,NULL),(1011,4,235,5,NULL,NULL),(1012,4,236,5,NULL,NULL),(1013,4,237,5,NULL,NULL),(1014,4,238,5,NULL,NULL),(1015,4,239,5,NULL,NULL),(1016,4,240,5,NULL,NULL),(1017,4,241,5,NULL,NULL),(1018,4,242,5,NULL,NULL),(1019,4,243,5,NULL,NULL),(1020,4,244,5,NULL,NULL),(1021,4,245,5,NULL,NULL),(1022,4,246,5,NULL,NULL),(1023,4,247,5,NULL,NULL),(1024,4,248,5,NULL,NULL),(1025,4,249,5,NULL,NULL),(1026,4,250,5,NULL,NULL),(1027,4,251,5,NULL,NULL),(1028,4,252,5,NULL,NULL),(1029,4,253,5,NULL,NULL),(1030,4,254,5,NULL,NULL),(1031,4,255,5,NULL,NULL),(1032,4,256,5,NULL,NULL),(1033,4,257,5,NULL,NULL),(1034,4,258,5,NULL,NULL),(1035,4,259,5,NULL,NULL),(1036,4,260,5,NULL,NULL),(1037,4,261,5,NULL,NULL),(1038,4,262,5,NULL,NULL),(1039,4,263,5,NULL,NULL),(1040,4,264,5,NULL,NULL),(1041,4,265,5,NULL,NULL),(1042,4,266,5,NULL,NULL),(1043,4,267,5,NULL,NULL),(1044,4,268,5,NULL,NULL),(1045,4,269,5,NULL,NULL),(1046,4,270,5,NULL,NULL),(1047,4,271,5,NULL,NULL),(1048,4,272,5,NULL,NULL),(1049,4,273,5,NULL,NULL),(1050,4,274,5,NULL,NULL),(1051,4,275,5,NULL,NULL),(1052,4,276,5,NULL,NULL),(1053,4,277,5,NULL,NULL),(1054,4,278,5,NULL,NULL),(1055,4,279,5,NULL,NULL),(1056,4,280,5,NULL,NULL),(1057,4,281,5,NULL,NULL),(1058,4,282,5,NULL,NULL),(1059,4,283,5,NULL,NULL),(1060,4,284,5,NULL,NULL),(1061,4,285,5,NULL,NULL),(1062,4,286,5,NULL,NULL),(1063,4,287,5,NULL,NULL),(1064,4,288,5,NULL,NULL),(1065,4,289,5,NULL,NULL),(1066,4,290,5,NULL,NULL),(1067,4,291,5,NULL,NULL),(1068,4,292,5,NULL,NULL),(1069,4,293,5,NULL,NULL),(1070,4,294,5,NULL,NULL),(1071,4,295,5,NULL,NULL),(1072,4,296,5,NULL,NULL),(1073,4,341,5,NULL,NULL),(1074,4,342,5,NULL,NULL),(1075,4,343,5,NULL,NULL),(1076,4,344,5,NULL,NULL),(1077,4,345,5,NULL,NULL),(1078,4,346,5,NULL,NULL),(1079,4,347,5,NULL,NULL),(1080,4,348,5,NULL,NULL),(1081,4,349,5,NULL,NULL),(1082,4,350,5,NULL,NULL),(1083,4,351,5,NULL,NULL),(1084,4,352,5,NULL,NULL),(1085,4,353,5,NULL,NULL),(1086,4,354,5,NULL,NULL),(1087,4,355,5,NULL,NULL),(1088,4,356,5,NULL,NULL),(1089,4,357,5,NULL,NULL),(1090,4,358,5,NULL,NULL),(1091,4,359,5,NULL,NULL),(1092,4,360,5,NULL,NULL),(1093,4,361,5,NULL,NULL),(1094,4,362,5,NULL,NULL),(1095,4,363,5,NULL,NULL),(1096,4,364,5,NULL,NULL),(1097,4,365,5,NULL,NULL),(1098,4,366,5,NULL,NULL),(1099,4,367,5,NULL,NULL),(1100,4,368,5,NULL,NULL),(1101,4,369,5,NULL,NULL),(1102,4,370,5,NULL,NULL),(1103,4,371,5,NULL,NULL),(1104,4,372,5,NULL,NULL),(1105,4,373,5,NULL,NULL),(1106,4,374,5,NULL,NULL),(1107,4,375,5,NULL,NULL),(1108,4,376,5,NULL,NULL),(1109,4,377,5,NULL,NULL),(1110,4,378,5,NULL,NULL),(1111,4,379,5,NULL,NULL),(1112,4,380,5,NULL,NULL),(1113,4,381,5,NULL,NULL),(1114,4,382,5,NULL,NULL),(1115,4,383,5,NULL,NULL),(1116,4,384,5,NULL,NULL),(1117,4,385,5,NULL,NULL),(1118,4,386,5,NULL,NULL),(1119,4,387,5,NULL,NULL),(1120,4,388,5,NULL,NULL),(1121,8,1,4,NULL,NULL),(1122,8,2,4,NULL,NULL),(1123,8,3,4,NULL,NULL),(1124,8,4,4,NULL,NULL),(1125,8,5,4,NULL,NULL),(1126,8,6,4,NULL,NULL),(1127,8,7,4,NULL,NULL),(1128,8,8,4,NULL,NULL),(1129,8,9,4,NULL,NULL),(1130,8,10,4,NULL,NULL),(1131,8,11,4,NULL,NULL),(1132,8,12,4,NULL,NULL),(1133,8,13,4,NULL,NULL),(1134,8,14,4,NULL,NULL),(1135,8,15,4,NULL,NULL),(1136,8,16,4,NULL,NULL),(1137,8,17,4,NULL,NULL),(1138,8,18,4,NULL,NULL),(1139,8,19,4,NULL,NULL),(1140,8,20,4,NULL,NULL),(1141,8,21,4,NULL,NULL),(1142,8,22,4,NULL,NULL),(1143,8,23,4,NULL,NULL),(1144,8,24,4,NULL,NULL),(1145,8,25,4,NULL,NULL),(1146,8,26,4,NULL,NULL),(1147,8,27,4,NULL,NULL),(1148,8,28,4,NULL,NULL),(1149,8,29,4,NULL,NULL),(1150,8,30,4,NULL,NULL),(1151,8,31,4,NULL,NULL),(1152,8,32,4,NULL,NULL),(1153,8,33,4,NULL,NULL),(1154,8,34,4,NULL,NULL),(1155,8,35,4,NULL,NULL),(1156,8,36,4,NULL,NULL),(1157,8,37,4,NULL,NULL),(1158,8,38,4,NULL,NULL),(1159,8,39,4,NULL,NULL),(1160,8,40,4,NULL,NULL),(1161,8,41,4,NULL,NULL),(1162,8,42,4,NULL,NULL),(1163,8,43,4,NULL,NULL),(1164,8,44,4,NULL,NULL),(1165,8,45,4,NULL,NULL),(1166,8,46,4,NULL,NULL),(1167,8,47,4,NULL,NULL),(1168,8,48,4,NULL,NULL),(1169,8,49,4,NULL,NULL),(1170,8,50,4,NULL,NULL),(1171,8,51,4,NULL,NULL),(1172,8,52,4,NULL,NULL),(1173,8,53,4,NULL,NULL),(1174,8,54,4,NULL,NULL),(1175,8,55,4,NULL,NULL),(1176,8,56,4,NULL,NULL),(1177,8,57,4,NULL,NULL),(1178,8,58,4,NULL,NULL),(1179,8,59,4,NULL,NULL),(1180,8,60,4,NULL,NULL),(1181,8,61,4,NULL,NULL),(1182,8,62,4,NULL,NULL),(1183,8,63,4,NULL,NULL),(1184,8,64,4,NULL,NULL),(1185,8,65,4,NULL,NULL),(1186,8,66,4,NULL,NULL),(1187,8,67,4,NULL,NULL),(1188,8,68,4,NULL,NULL),(1189,8,69,4,NULL,NULL),(1190,8,70,4,NULL,NULL),(1191,8,71,4,NULL,NULL),(1192,8,72,4,NULL,NULL),(1193,8,73,4,NULL,NULL),(1194,8,74,4,NULL,NULL),(1195,8,75,4,NULL,NULL),(1196,8,76,4,NULL,NULL),(1197,8,77,4,NULL,NULL),(1198,8,78,4,NULL,NULL),(1199,8,79,4,NULL,NULL),(1200,8,80,4,NULL,NULL),(1201,8,81,4,NULL,NULL),(1202,8,82,4,NULL,NULL),(1203,8,83,4,NULL,NULL),(1204,8,84,4,NULL,NULL),(1205,8,85,4,NULL,NULL),(1206,8,86,4,NULL,NULL),(1207,8,87,4,NULL,NULL),(1208,8,88,4,NULL,NULL),(1209,8,89,4,NULL,NULL),(1210,8,90,4,NULL,NULL),(1211,8,91,4,NULL,NULL),(1212,8,92,4,NULL,NULL),(1213,8,93,4,NULL,NULL),(1214,8,94,4,NULL,NULL),(1215,8,95,4,NULL,NULL),(1216,8,96,4,NULL,NULL),(1217,8,97,4,NULL,NULL),(1218,8,98,4,NULL,NULL),(1219,8,99,4,NULL,NULL),(1220,8,100,4,NULL,NULL),(1221,8,101,4,NULL,NULL),(1222,8,102,4,NULL,NULL),(1223,8,103,4,NULL,NULL),(1224,8,104,4,NULL,NULL),(1225,8,105,4,NULL,NULL),(1226,8,106,4,NULL,NULL),(1227,8,107,4,NULL,NULL),(1228,8,108,4,NULL,NULL),(1229,8,109,4,NULL,NULL),(1230,8,110,4,NULL,NULL),(1231,8,111,4,NULL,NULL),(1232,8,112,4,NULL,NULL),(1233,8,113,4,NULL,NULL),(1234,8,114,4,NULL,NULL),(1235,8,115,4,NULL,NULL),(1236,8,116,4,NULL,NULL),(1237,8,117,4,NULL,NULL),(1238,8,118,4,NULL,NULL),(1239,8,119,4,NULL,NULL),(1240,8,120,4,NULL,NULL),(1241,8,121,4,NULL,NULL),(1242,8,122,4,NULL,NULL),(1243,8,123,4,NULL,NULL),(1244,8,124,4,NULL,NULL),(1245,8,125,4,NULL,NULL),(1246,8,126,4,NULL,NULL),(1247,8,127,4,NULL,NULL),(1248,8,128,4,NULL,NULL),(1249,8,129,4,NULL,NULL),(1250,8,130,4,NULL,NULL),(1251,8,131,4,NULL,NULL),(1252,8,132,4,NULL,NULL),(1253,8,133,4,NULL,NULL),(1254,8,134,4,NULL,NULL),(1255,8,135,4,NULL,NULL),(1256,8,136,4,NULL,NULL),(1257,8,137,4,NULL,NULL),(1258,8,138,4,NULL,NULL),(1259,8,139,4,NULL,NULL),(1260,8,140,4,NULL,NULL),(1261,8,141,4,NULL,NULL),(1262,8,142,4,NULL,NULL),(1263,8,143,4,NULL,NULL),(1264,8,144,4,NULL,NULL),(1265,8,145,4,NULL,NULL),(1266,8,146,4,NULL,NULL),(1267,8,147,4,NULL,NULL),(1268,8,148,4,NULL,NULL),(1269,8,149,4,NULL,NULL),(1270,8,150,4,NULL,NULL),(1271,8,151,4,NULL,NULL),(1272,8,152,4,NULL,NULL),(1273,8,153,4,NULL,NULL),(1274,8,154,4,NULL,NULL),(1275,8,155,4,NULL,NULL),(1276,8,156,4,NULL,NULL),(1277,8,157,4,NULL,NULL),(1278,8,158,4,NULL,NULL),(1279,8,159,4,NULL,NULL),(1280,8,160,4,NULL,NULL),(1281,8,161,4,NULL,NULL),(1282,8,162,4,NULL,NULL),(1283,8,163,4,NULL,NULL),(1284,8,164,4,NULL,NULL),(1285,8,165,4,NULL,NULL),(1286,8,166,4,NULL,NULL),(1287,8,167,4,NULL,NULL),(1288,8,168,4,NULL,NULL),(1289,8,169,4,NULL,NULL),(1290,8,170,4,NULL,NULL),(1291,8,171,4,NULL,NULL),(1292,8,172,4,NULL,NULL),(1293,8,173,4,NULL,NULL),(1294,8,174,4,NULL,NULL),(1295,8,175,4,NULL,NULL),(1296,8,176,4,NULL,NULL),(1297,8,177,4,NULL,NULL),(1298,8,178,4,NULL,NULL),(1299,8,179,4,NULL,NULL),(1300,8,180,4,NULL,NULL),(1301,8,181,4,NULL,NULL),(1302,8,182,4,NULL,NULL),(1303,8,183,4,NULL,NULL),(1304,8,184,4,NULL,NULL),(1305,8,185,4,NULL,NULL),(1306,8,186,4,NULL,NULL),(1307,8,187,4,NULL,NULL),(1308,8,188,4,NULL,NULL),(1309,8,189,4,NULL,NULL),(1310,8,190,4,NULL,NULL),(1311,8,191,4,NULL,NULL),(1312,8,192,4,NULL,NULL),(1313,8,193,4,NULL,NULL),(1314,8,194,4,NULL,NULL),(1315,8,195,4,NULL,NULL),(1316,8,196,4,NULL,NULL),(1317,8,197,4,NULL,NULL),(1318,8,198,4,NULL,NULL),(1319,8,199,4,NULL,NULL),(1320,8,200,4,NULL,NULL),(1321,8,201,4,NULL,NULL),(1322,8,202,4,NULL,NULL),(1323,8,203,4,NULL,NULL),(1324,8,204,4,NULL,NULL),(1325,8,205,4,NULL,NULL),(1326,8,206,4,NULL,NULL),(1327,8,207,4,NULL,NULL),(1328,8,208,4,NULL,NULL),(1329,8,209,4,NULL,NULL),(1330,8,210,4,NULL,NULL),(1331,8,211,4,NULL,NULL),(1332,8,212,4,NULL,NULL),(1333,8,213,4,NULL,NULL),(1334,8,214,4,NULL,NULL),(1335,8,215,4,NULL,NULL),(1336,8,216,4,NULL,NULL),(1337,8,217,4,NULL,NULL),(1338,8,218,4,NULL,NULL),(1339,8,219,4,NULL,NULL),(1340,8,220,4,NULL,NULL),(1341,8,221,4,NULL,NULL),(1342,8,222,4,NULL,NULL),(1343,8,223,4,NULL,NULL),(1344,8,224,4,NULL,NULL),(1345,8,225,4,NULL,NULL),(1346,8,226,4,NULL,NULL),(1347,8,227,4,NULL,NULL),(1348,8,228,4,NULL,NULL),(1349,8,229,4,NULL,NULL),(1350,8,230,4,NULL,NULL),(1351,8,231,4,NULL,NULL),(1352,8,232,4,NULL,NULL),(1353,8,233,4,NULL,NULL),(1354,8,234,4,NULL,NULL),(1355,8,235,4,NULL,NULL),(1356,8,236,4,NULL,NULL),(1357,8,237,4,NULL,NULL),(1358,8,238,4,NULL,NULL),(1359,8,239,4,NULL,NULL),(1360,8,240,4,NULL,NULL),(1361,8,241,4,NULL,NULL),(1362,8,242,4,NULL,NULL),(1363,8,243,4,NULL,NULL),(1364,8,244,4,NULL,NULL),(1365,8,245,4,NULL,NULL),(1366,8,246,4,NULL,NULL),(1367,8,247,4,NULL,NULL),(1368,8,248,4,NULL,NULL),(1369,8,249,4,NULL,NULL),(1370,8,250,4,NULL,NULL),(1371,8,251,4,NULL,NULL),(1372,8,252,4,NULL,NULL),(1373,8,253,4,NULL,NULL),(1374,8,254,4,NULL,NULL),(1375,8,255,4,NULL,NULL),(1376,8,256,4,NULL,NULL),(1377,8,257,4,NULL,NULL),(1378,8,258,4,NULL,NULL),(1379,8,259,4,NULL,NULL),(1380,8,260,4,NULL,NULL),(1381,8,261,4,NULL,NULL),(1382,8,262,4,NULL,NULL),(1383,8,263,4,NULL,NULL),(1384,8,264,4,NULL,NULL),(1385,8,265,4,NULL,NULL),(1386,8,266,4,NULL,NULL),(1387,8,267,4,NULL,NULL),(1388,8,268,4,NULL,NULL),(1389,8,269,4,NULL,NULL),(1390,8,270,4,NULL,NULL),(1391,8,271,4,NULL,NULL),(1392,8,272,4,NULL,NULL),(1393,8,273,4,NULL,NULL),(1394,8,274,4,NULL,NULL),(1395,8,275,4,NULL,NULL),(1396,8,276,4,NULL,NULL),(1397,8,277,4,NULL,NULL),(1398,8,278,4,NULL,NULL),(1399,8,279,4,NULL,NULL),(1400,8,280,4,NULL,NULL),(1401,8,281,4,NULL,NULL),(1402,8,282,4,NULL,NULL),(1403,8,283,4,NULL,NULL),(1404,8,284,4,NULL,NULL),(1405,8,285,4,NULL,NULL),(1406,8,286,4,NULL,NULL),(1407,8,287,4,NULL,NULL),(1408,8,288,4,NULL,NULL),(1409,8,289,4,NULL,NULL),(1410,8,290,4,NULL,NULL),(1411,8,291,4,NULL,NULL),(1412,8,292,4,NULL,NULL),(1413,8,293,4,NULL,NULL),(1414,8,294,4,NULL,NULL),(1415,8,295,4,NULL,NULL),(1416,8,296,4,NULL,NULL),(1417,8,341,4,NULL,NULL),(1418,8,342,4,NULL,NULL),(1419,8,343,4,NULL,NULL),(1420,8,344,4,NULL,NULL),(1421,8,345,4,NULL,NULL),(1422,8,346,4,NULL,NULL),(1423,8,347,4,NULL,NULL),(1424,8,348,4,NULL,NULL),(1425,8,349,4,NULL,NULL),(1426,8,350,4,NULL,NULL),(1427,8,351,4,NULL,NULL),(1428,8,352,4,NULL,NULL),(1429,8,353,4,NULL,NULL),(1430,8,354,4,NULL,NULL),(1431,8,355,4,NULL,NULL),(1432,8,356,4,NULL,NULL),(1433,8,357,4,NULL,NULL),(1434,8,358,4,NULL,NULL),(1435,8,359,4,NULL,NULL),(1436,8,360,4,NULL,NULL),(1437,8,361,4,NULL,NULL),(1438,8,362,4,NULL,NULL),(1439,8,363,4,NULL,NULL),(1440,8,364,4,NULL,NULL),(1441,8,365,4,NULL,NULL),(1442,8,366,4,NULL,NULL),(1443,8,367,4,NULL,NULL),(1444,8,368,4,NULL,NULL),(1445,8,369,4,NULL,NULL),(1446,8,370,4,NULL,NULL),(1447,8,371,4,NULL,NULL),(1448,8,372,4,NULL,NULL),(1449,8,373,4,NULL,NULL),(1450,8,374,4,NULL,NULL),(1451,8,375,4,NULL,NULL),(1452,8,376,4,NULL,NULL),(1453,8,377,4,NULL,NULL),(1454,8,378,4,NULL,NULL),(1455,8,379,4,NULL,NULL),(1456,8,380,4,NULL,NULL),(1457,8,381,4,NULL,NULL),(1458,8,382,4,NULL,NULL),(1459,8,383,4,NULL,NULL),(1460,8,384,4,NULL,NULL),(1461,8,385,4,NULL,NULL),(1462,8,386,4,NULL,NULL),(1463,8,387,4,NULL,NULL),(1464,8,388,4,NULL,NULL),(1465,9,1,5,NULL,NULL),(1466,9,2,5,NULL,NULL),(1467,9,3,5,NULL,NULL),(1468,9,4,5,NULL,NULL),(1469,9,5,5,NULL,NULL),(1470,9,6,5,NULL,NULL),(1471,9,7,5,NULL,NULL),(1472,9,8,5,NULL,NULL),(1473,9,9,5,NULL,NULL),(1474,9,10,5,NULL,NULL),(1475,9,11,5,NULL,NULL),(1476,9,12,5,NULL,NULL),(1477,9,13,5,NULL,NULL),(1478,9,14,5,NULL,NULL),(1479,9,15,5,NULL,NULL),(1480,9,16,5,NULL,NULL),(1481,9,17,5,NULL,NULL),(1482,9,18,5,NULL,NULL),(1483,9,19,5,NULL,NULL),(1484,9,20,5,NULL,NULL),(1485,9,21,5,NULL,NULL),(1486,9,22,5,NULL,NULL),(1487,9,23,5,NULL,NULL),(1488,9,24,5,NULL,NULL),(1489,9,25,5,NULL,NULL),(1490,9,26,5,NULL,NULL),(1491,9,27,5,NULL,NULL),(1492,9,28,5,NULL,NULL),(1493,9,29,5,NULL,NULL),(1494,9,30,5,NULL,NULL),(1495,9,31,5,NULL,NULL),(1496,9,32,5,NULL,NULL),(1497,9,33,5,NULL,NULL),(1498,9,34,5,NULL,NULL),(1499,9,35,5,NULL,NULL),(1500,9,36,5,NULL,NULL),(1501,9,37,5,NULL,NULL),(1502,9,38,5,NULL,NULL),(1503,9,39,5,NULL,NULL),(1504,9,40,5,NULL,NULL),(1505,9,41,5,NULL,NULL),(1506,9,42,5,NULL,NULL),(1507,9,43,5,NULL,NULL),(1508,9,44,5,NULL,NULL),(1509,9,45,5,NULL,NULL),(1510,9,46,5,NULL,NULL),(1511,9,47,5,NULL,NULL),(1512,9,48,5,NULL,NULL),(1513,9,49,5,NULL,NULL),(1514,9,50,5,NULL,NULL),(1515,9,51,5,NULL,NULL),(1516,9,52,2,NULL,NULL),(1517,9,53,5,NULL,NULL),(1518,9,54,5,NULL,NULL),(1519,9,55,5,NULL,NULL),(1520,9,56,4,NULL,NULL),(1521,9,57,4,NULL,NULL),(1522,9,58,1,NULL,NULL),(1523,9,59,4,NULL,NULL),(1524,9,60,4,NULL,NULL),(1525,9,61,1,NULL,NULL),(1526,9,62,1,NULL,NULL),(1527,9,63,5,NULL,NULL),(1528,9,64,5,NULL,NULL),(1529,9,65,5,NULL,NULL),(1530,9,66,5,NULL,NULL),(1531,9,67,5,NULL,NULL),(1532,9,68,4,NULL,NULL),(1533,9,69,5,NULL,NULL),(1534,9,70,5,NULL,NULL),(1535,9,71,5,NULL,NULL),(1536,9,72,5,NULL,NULL),(1537,9,73,5,NULL,NULL),(1538,9,74,5,NULL,NULL),(1539,9,75,5,NULL,NULL),(1540,9,76,5,NULL,NULL),(1541,9,77,4,NULL,NULL),(1542,9,78,5,NULL,NULL),(1543,9,79,4,NULL,NULL),(1544,9,80,4,NULL,NULL),(1545,9,81,5,NULL,NULL),(1546,9,82,4,NULL,NULL),(1547,9,83,5,NULL,NULL),(1548,9,84,5,NULL,NULL),(1549,9,85,4,NULL,NULL),(1550,9,86,5,NULL,NULL),(1551,9,87,5,NULL,NULL),(1552,9,88,5,NULL,NULL),(1553,9,89,5,NULL,NULL),(1554,9,90,5,NULL,NULL),(1555,9,91,5,NULL,NULL),(1556,9,92,5,NULL,NULL),(1557,9,93,5,NULL,NULL),(1558,9,94,5,NULL,NULL),(1559,9,95,5,NULL,NULL),(1560,9,96,5,NULL,NULL),(1561,9,97,5,NULL,NULL),(1562,9,98,5,NULL,NULL),(1563,9,99,5,NULL,NULL),(1564,9,100,2,NULL,NULL),(1565,9,101,5,NULL,NULL),(1566,9,102,5,NULL,NULL),(1567,9,103,5,NULL,NULL),(1568,9,104,5,NULL,NULL),(1569,9,105,5,NULL,NULL),(1570,9,106,5,NULL,NULL),(1571,9,107,4,NULL,NULL),(1572,9,108,5,NULL,NULL),(1573,9,109,5,NULL,NULL),(1574,9,110,4,NULL,NULL),(1575,9,111,5,NULL,NULL),(1576,9,112,5,NULL,NULL),(1577,9,113,5,NULL,NULL),(1578,9,114,4,NULL,NULL),(1579,9,115,4,NULL,NULL),(1580,9,116,1,NULL,NULL),(1581,9,117,1,NULL,NULL),(1582,9,118,4,NULL,NULL),(1583,9,119,4,NULL,NULL),(1584,9,120,1,NULL,NULL),(1585,9,121,1,NULL,NULL),(1586,9,122,5,NULL,NULL),(1587,9,123,5,NULL,NULL),(1588,9,124,5,NULL,NULL),(1589,9,125,5,NULL,NULL),(1590,9,126,5,NULL,NULL),(1591,9,127,5,NULL,NULL),(1592,9,128,5,NULL,NULL),(1593,9,129,2,NULL,NULL),(1594,9,130,5,NULL,NULL),(1595,9,131,5,NULL,NULL),(1596,9,132,5,NULL,NULL),(1597,9,133,2,NULL,NULL),(1598,9,134,5,NULL,NULL),(1599,9,135,5,NULL,NULL),(1600,9,136,5,NULL,NULL),(1601,9,137,5,NULL,NULL),(1602,9,138,5,NULL,NULL),(1603,9,139,5,NULL,NULL),(1604,9,140,2,NULL,NULL),(1605,9,141,5,NULL,NULL),(1606,9,142,5,NULL,NULL),(1607,9,143,5,NULL,NULL),(1608,9,144,5,NULL,NULL),(1609,9,145,2,NULL,NULL),(1610,9,146,5,NULL,NULL),(1611,9,147,5,NULL,NULL),(1612,9,148,5,NULL,NULL),(1613,9,149,5,NULL,NULL),(1614,9,150,5,NULL,NULL),(1615,9,151,1,NULL,NULL),(1616,9,152,3,NULL,NULL),(1617,9,153,1,NULL,NULL),(1618,9,154,1,NULL,NULL),(1619,9,155,5,NULL,NULL),(1620,9,156,5,NULL,NULL),(1621,9,157,5,NULL,NULL),(1622,9,158,5,NULL,NULL),(1623,9,159,5,NULL,NULL),(1624,9,160,5,NULL,NULL),(1625,9,161,2,NULL,NULL),(1626,9,162,5,NULL,NULL),(1627,9,163,5,NULL,NULL),(1628,9,164,5,NULL,NULL),(1629,9,165,2,NULL,NULL),(1630,9,166,5,NULL,NULL),(1631,9,167,5,NULL,NULL),(1632,9,168,5,NULL,NULL),(1633,9,169,5,NULL,NULL),(1634,9,170,5,NULL,NULL),(1635,9,171,5,NULL,NULL),(1636,9,172,5,NULL,NULL),(1637,9,173,5,NULL,NULL),(1638,9,174,5,NULL,NULL),(1639,9,175,5,NULL,NULL),(1640,9,176,5,NULL,NULL),(1641,9,177,5,NULL,NULL),(1642,9,178,5,NULL,NULL),(1643,9,179,5,NULL,NULL),(1644,9,180,5,NULL,NULL),(1645,9,181,5,NULL,NULL),(1646,9,182,5,NULL,NULL),(1647,9,183,5,NULL,NULL),(1648,9,184,5,NULL,NULL),(1649,9,185,5,NULL,NULL),(1650,9,186,5,NULL,NULL),(1651,9,187,5,NULL,NULL),(1652,9,188,5,NULL,NULL),(1653,9,189,5,NULL,NULL),(1654,9,190,5,NULL,NULL),(1655,9,191,5,NULL,NULL),(1656,9,192,5,NULL,NULL),(1657,9,193,5,NULL,NULL),(1658,9,194,5,NULL,NULL),(1659,9,195,5,NULL,NULL),(1660,9,196,5,NULL,NULL),(1661,9,197,5,NULL,NULL),(1662,9,198,5,NULL,NULL),(1663,9,199,5,NULL,NULL),(1664,9,200,5,NULL,NULL),(1665,9,201,5,NULL,NULL),(1666,9,202,5,NULL,NULL),(1667,9,203,5,NULL,NULL),(1668,9,204,5,NULL,NULL),(1669,9,205,5,NULL,NULL),(1670,9,206,5,NULL,NULL),(1671,9,207,5,NULL,NULL),(1672,9,208,5,NULL,NULL),(1673,9,209,5,NULL,NULL),(1674,9,210,5,NULL,NULL),(1675,9,211,5,NULL,NULL),(1676,9,212,5,NULL,NULL),(1677,9,213,5,NULL,NULL),(1678,9,214,4,NULL,NULL),(1679,9,215,5,NULL,NULL),(1680,9,216,5,NULL,NULL),(1681,9,217,5,NULL,NULL),(1682,9,218,5,NULL,NULL),(1683,9,219,5,NULL,NULL),(1684,9,220,5,NULL,NULL),(1685,9,221,5,NULL,NULL),(1686,9,222,5,NULL,NULL),(1687,9,223,5,NULL,NULL),(1688,9,224,5,NULL,NULL),(1689,9,225,5,NULL,NULL),(1690,9,226,5,NULL,NULL),(1691,9,227,5,NULL,NULL),(1692,9,228,2,NULL,NULL),(1693,9,229,5,NULL,NULL),(1694,9,230,5,NULL,NULL),(1695,9,231,5,NULL,NULL),(1696,9,232,5,NULL,NULL),(1697,9,233,4,NULL,NULL),(1698,9,234,5,NULL,NULL),(1699,9,235,4,NULL,NULL),(1700,9,236,5,NULL,NULL),(1701,9,237,5,NULL,NULL),(1702,9,238,4,NULL,NULL),(1703,9,239,5,NULL,NULL),(1704,9,240,5,NULL,NULL),(1705,9,241,5,NULL,NULL),(1706,9,242,5,NULL,NULL),(1707,9,243,5,NULL,NULL),(1708,9,244,5,NULL,NULL),(1709,9,245,5,NULL,NULL),(1710,9,246,5,NULL,NULL),(1711,9,247,5,NULL,NULL),(1712,9,248,5,NULL,NULL),(1713,9,249,5,NULL,NULL),(1714,9,250,5,NULL,NULL),(1715,9,251,5,NULL,NULL),(1716,9,252,5,NULL,NULL),(1717,9,253,5,NULL,NULL),(1718,9,254,5,NULL,NULL),(1719,9,255,5,NULL,NULL),(1720,9,256,5,NULL,NULL),(1721,9,257,5,NULL,NULL),(1722,9,258,5,NULL,NULL),(1723,9,259,5,NULL,NULL),(1724,9,260,5,NULL,NULL),(1725,9,261,5,NULL,NULL),(1726,9,262,5,NULL,NULL),(1727,9,263,5,NULL,NULL),(1728,9,264,5,NULL,NULL),(1729,9,265,5,NULL,NULL),(1730,9,266,5,NULL,NULL),(1731,9,267,5,NULL,NULL),(1732,9,268,5,NULL,NULL),(1733,9,269,5,NULL,NULL),(1734,9,270,5,NULL,NULL),(1735,9,271,5,NULL,NULL),(1736,9,272,5,NULL,NULL),(1737,9,273,5,NULL,NULL),(1738,9,274,5,NULL,NULL),(1739,9,275,5,NULL,NULL),(1740,9,276,5,NULL,NULL),(1741,9,277,5,NULL,NULL),(1742,9,278,5,NULL,NULL),(1743,9,279,5,NULL,NULL),(1744,9,280,5,NULL,NULL),(1745,9,281,5,NULL,NULL),(1746,9,282,4,NULL,NULL),(1747,9,283,2,NULL,NULL),(1748,9,284,5,NULL,NULL),(1749,9,285,5,NULL,NULL),(1750,9,286,5,NULL,NULL),(1751,9,287,5,NULL,NULL),(1752,9,288,5,NULL,NULL),(1753,9,289,5,NULL,NULL),(1754,9,290,5,NULL,NULL),(1755,9,291,5,NULL,NULL),(1756,9,292,5,NULL,NULL),(1757,9,293,5,NULL,NULL),(1758,9,294,5,NULL,NULL),(1759,9,295,5,NULL,NULL),(1760,9,296,5,NULL,NULL),(1761,9,341,5,NULL,NULL),(1762,9,342,5,NULL,NULL),(1763,9,343,5,NULL,NULL),(1764,9,344,5,NULL,NULL),(1765,9,345,5,NULL,NULL),(1766,9,346,5,NULL,NULL),(1767,9,347,5,NULL,NULL),(1768,9,348,5,NULL,NULL),(1769,9,349,5,NULL,NULL),(1770,9,350,5,NULL,NULL),(1771,9,351,5,NULL,NULL),(1772,9,352,5,NULL,NULL),(1773,9,353,5,NULL,NULL),(1774,9,354,5,NULL,NULL),(1775,9,355,5,NULL,NULL),(1776,9,356,5,NULL,NULL),(1777,9,357,5,NULL,NULL),(1778,9,358,5,NULL,NULL),(1779,9,359,5,NULL,NULL),(1780,9,360,5,NULL,NULL),(1781,9,361,5,NULL,NULL),(1782,9,362,5,NULL,NULL),(1783,9,363,5,NULL,NULL),(1784,9,364,5,NULL,NULL),(1785,9,365,5,NULL,NULL),(1786,9,366,5,NULL,NULL),(1787,9,367,5,NULL,NULL),(1788,9,368,5,NULL,NULL),(1789,9,369,5,NULL,NULL),(1790,9,370,5,NULL,NULL),(1791,9,371,5,NULL,NULL),(1792,9,372,5,NULL,NULL),(1793,9,373,5,NULL,NULL),(1794,9,374,5,NULL,NULL),(1795,9,375,5,NULL,NULL),(1796,9,376,5,NULL,NULL),(1797,9,377,5,NULL,NULL),(1798,9,378,5,NULL,NULL),(1799,9,379,5,NULL,NULL),(1800,9,380,5,NULL,NULL),(1801,9,381,5,NULL,NULL),(1802,9,382,5,NULL,NULL),(1803,9,383,5,NULL,NULL),(1804,9,384,5,NULL,NULL),(1805,9,385,5,NULL,NULL),(1806,9,386,5,NULL,NULL),(1807,9,387,5,NULL,NULL),(1808,9,388,5,NULL,NULL);
/*!40000 ALTER TABLE `user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_taskboard_settings`
--

DROP TABLE IF EXISTS `user_taskboard_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_taskboard_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `board_column_id` int(10) unsigned NOT NULL,
  `collapsed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_taskboard_settings_company_id_foreign` (`company_id`),
  KEY `user_taskboard_settings_user_id_foreign` (`user_id`),
  KEY `user_taskboard_settings_board_column_id_foreign` (`board_column_id`),
  CONSTRAINT `user_taskboard_settings_board_column_id_foreign` FOREIGN KEY (`board_column_id`) REFERENCES `taskboard_columns` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_taskboard_settings_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_taskboard_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_taskboard_settings`
--

LOCK TABLES `user_taskboard_settings` WRITE;
/*!40000 ALTER TABLE `user_taskboard_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_taskboard_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_auth_id` bigint(20) unsigned DEFAULT NULL,
  `is_superadmin` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `image` varchar(191) DEFAULT NULL,
  `country_phonecode` int(11) DEFAULT NULL,
  `mobile` varchar(191) DEFAULT NULL,
  `gender` enum('male','female','others') DEFAULT 'male',
  `salutation` enum('mr','mrs','miss','dr','sir','madam') DEFAULT NULL,
  `locale` varchar(191) NOT NULL DEFAULT 'en',
  `status` enum('active','deactive') NOT NULL DEFAULT 'active',
  `login` enum('enable','disable') NOT NULL DEFAULT 'enable',
  `onesignal_player_id` text DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `country_id` int(10) unsigned DEFAULT NULL,
  `dark_theme` tinyint(1) NOT NULL,
  `rtl` tinyint(1) NOT NULL,
  `admin_approval` tinyint(1) NOT NULL DEFAULT 1,
  `permission_sync` tinyint(1) NOT NULL DEFAULT 1,
  `google_calendar_status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `customised_permissions` tinyint(1) NOT NULL DEFAULT 0,
  `stripe_id` varchar(191) DEFAULT NULL,
  `pm_type` varchar(191) DEFAULT NULL,
  `pm_last_four` varchar(4) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_company_id_unique` (`email`,`company_id`),
  KEY `users_country_id_foreign` (`country_id`),
  KEY `users_company_id_foreign` (`company_id`),
  KEY `users_user_auth_id_foreign` (`user_auth_id`),
  KEY `users_stripe_id_index` (`stripe_id`),
  CONSTRAINT `users_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `users_user_auth_id_foreign` FOREIGN KEY (`user_auth_id`) REFERENCES `user_auths` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,1,'SmartKerja','avtsventures@gmail.com','9711e2cc75c294f7767daca325d6e670.png',NULL,NULL,NULL,NULL,'en','active','enable',NULL,'2024-07-15 13:23:24',1,NULL,0,0,1,1,0,'2023-08-10 14:07:32','2024-07-15 13:24:02',0,NULL,NULL,NULL,NULL),(2,1,2,0,'Admin','admin@example.com',NULL,NULL,NULL,'male',NULL,'en','active','enable',NULL,'2023-08-21 23:50:07',1,NULL,0,0,1,1,1,'2023-08-10 14:07:33','2023-08-21 23:50:07',0,NULL,NULL,NULL,NULL),(3,3,3,0,'Ascot Hill','ascothill21k@gmail.com',NULL,NULL,NULL,'male',NULL,'en','active','enable',NULL,'2024-07-14 15:45:18',1,NULL,0,0,1,1,1,'2023-08-10 14:17:26','2024-07-14 15:45:18',0,NULL,NULL,NULL,NULL),(4,1,4,0,'Ali','ali@mail.com',NULL,93,NULL,'male',NULL,'en','active','disable',NULL,NULL,1,1,0,0,1,1,1,'2023-08-21 05:44:54','2023-08-21 05:44:54',0,NULL,NULL,NULL,NULL),(8,7,8,0,'Admin Smartkerja','sm4rtkerja@gmail.com','7ee9b0c5991cc52eff6852d8786cd762.png',60,NULL,'male',NULL,'en','active','enable',NULL,'2024-07-15 00:24:18',1,129,0,0,1,1,1,'2023-08-21 16:25:19','2024-07-15 00:24:18',0,NULL,NULL,NULL,NULL),(9,7,9,0,'Zulkifli','zkief2010@gmail.com','f54d48ceec53e1b193ebbfc9a11d2762.png',60,'123213634','male','mr','en','active','enable',NULL,NULL,1,129,0,0,1,1,1,'2023-08-21 16:31:15','2023-08-21 16:31:15',0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_chat`
--

DROP TABLE IF EXISTS `users_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_chat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_one` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `message` mediumtext DEFAULT NULL,
  `from` int(10) unsigned DEFAULT NULL,
  `to` int(10) unsigned DEFAULT NULL,
  `message_seen` enum('yes','no') NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `notification_sent` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `users_chat_company_id_foreign` (`company_id`),
  KEY `users_chat_user_one_foreign` (`user_one`),
  KEY `users_chat_user_id_foreign` (`user_id`),
  KEY `users_chat_from_foreign` (`from`),
  KEY `users_chat_to_foreign` (`to`),
  CONSTRAINT `users_chat_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_chat_from_foreign` FOREIGN KEY (`from`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_chat_to_foreign` FOREIGN KEY (`to`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_chat_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_chat_user_one_foreign` FOREIGN KEY (`user_one`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_chat`
--

LOCK TABLES `users_chat` WRITE;
/*!40000 ALTER TABLE `users_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_chat_files`
--

DROP TABLE IF EXISTS `users_chat_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_chat_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `users_chat_id` int(10) unsigned NOT NULL,
  `filename` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `google_url` varchar(191) DEFAULT NULL,
  `hashname` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `external_link` varchar(191) DEFAULT NULL,
  `external_link_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_chat_files_company_id_foreign` (`company_id`),
  KEY `users_chat_files_user_id_foreign` (`user_id`),
  KEY `users_chat_files_users_chat_id_foreign` (`users_chat_id`),
  CONSTRAINT `users_chat_files_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_chat_files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_chat_files_users_chat_id_foreign` FOREIGN KEY (`users_chat_id`) REFERENCES `users_chat` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_chat_files`
--

LOCK TABLES `users_chat_files` WRITE;
/*!40000 ALTER TABLE `users_chat_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_chat_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visa_details`
--

DROP TABLE IF EXISTS `visa_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visa_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `country_id` int(10) unsigned DEFAULT NULL,
  `added_by` int(10) unsigned DEFAULT NULL,
  `visa_number` varchar(191) NOT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `file` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visa_details_company_id_foreign` (`company_id`),
  KEY `visa_details_user_id_foreign` (`user_id`),
  KEY `visa_details_added_by_foreign` (`added_by`),
  KEY `visa_details_country_id_foreign` (`country_id`),
  CONSTRAINT `visa_details_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `visa_details_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visa_details_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visa_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visa_details`
--

LOCK TABLES `visa_details` WRITE;
/*!40000 ALTER TABLE `visa_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `visa_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'app_smartkerja'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-15 13:49:52
